#!/usr/bin/env bash
set -euo pipefail
cd /home/jovyan/adapointr_work/PoinTr
base=logs/cranial_scqr_v12_qa1/qa1_descriptive_statistics_v1_20261010
mkdir -p logs/cranial_scqr_v12_qa1
test -d logs/cranial_scqr_v12_qa1
test ! -L logs/cranial_scqr_v12_qa1
test "$(stat -c %U logs/cranial_scqr_v12_qa1)" = jovyan
test ! -e "$base"
test ! -e "$base.launcher.log"
test ! -e "$base.pid"
test ! -e "$base.exit_code"
set -o noclobber
exec > "$base.launcher.log" 2>&1
printf '%s\n' "$$" > "$base.pid"
trap 'rc=$?; trap - EXIT; printf "%s\n" "$rc" > "$base.exit_code"; exit "$rc"' EXIT
printf '[start] '; date -Is
timeout --signal=TERM --kill-after=20s 600s env CUDA_VISIBLE_DEVICES= PYTHONDONTWRITEBYTECODE=1 /opt/conda/envs/adapointr-mamba/bin/python -B tools/analyze_cranial_scqr_v12_qa1.py --execution-request docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_statistics_execution_authorization_request_v1.json --execution-request-sha256 a568b4219aaeef8ce9ea05df58df32ce2c8a3ebbba9a3daac39fc55dad3c3eda --authorization-receipt logs/cranial_scqr_v12_qa1/qa1_statistics_authorization_receipt_v1.json --authorization-receipt-sha256 e977d3f455c939d0898213f677e581c5cf02509d759547130c78ab4068edebc5
printf '[done] PASS_DESCRIPTIVE_ONLY_PENDING_SEPARATE_FREEZE_AUDIT\n'
