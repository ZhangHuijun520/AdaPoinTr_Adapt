#!/usr/bin/env bash
set -uo pipefail

if [[ "$#" -ne 6 ]]; then
  echo "usage: $0 PROTOCOL EXECUTION_AUTH OUTPUT_DIR LAUNCH_LOG PID_FILE EXIT_FILE" >&2
  exit 64
fi

readonly PROJECT_ROOT="/home/jovyan/adapointr_work/PoinTr"
readonly PYTHON_BIN="/opt/conda/envs/adapointr-mamba/bin/python"
readonly RUNNER="${PROJECT_ROOT}/tools/run_cranial_scqr_v12_qa1_zero_update_preflight.py"
readonly EXPECTED_HOSTNAME="shu-common-25721452-notebook-qjr526-0"
readonly EXPECTED_PYTHON_SHA256="01b4275dc374dcae51d245bda004daad6d7882d3f5de7f9852567bb7ab83180d"
readonly EXPECTED_GPU_NAME="NVIDIA GeForce RTX 4090 D"
readonly EXPECTED_GPU_UUID="GPU-8d14c403-a24c-d914-a68d-9eb0f8544fff"
readonly PROTOCOL="$1"
readonly EXECUTION_AUTH="$2"
readonly OUTPUT_DIR="$3"
readonly LAUNCH_LOG="$4"
readonly PID_FILE="$5"
readonly EXIT_FILE="$6"

if [[ "$(hostname)" != "${EXPECTED_HOSTNAME}" ]]; then
  echo "hostname differs from execution authorization" >&2
  exit 69
fi
if [[ "$(sha256sum "$(readlink -f "${PYTHON_BIN}")" | awk '{print $1}')" != "${EXPECTED_PYTHON_SHA256}" ]]; then
  echo "Python binary differs from execution authorization" >&2
  exit 69
fi
actual_gpu_name="$(nvidia-smi --query-gpu=name --format=csv,noheader | sed -n '1p')"
actual_gpu_uuid="$(nvidia-smi --query-gpu=uuid --format=csv,noheader | sed -n '1p')"
if [[ "${actual_gpu_name}" != "${EXPECTED_GPU_NAME}" || "${actual_gpu_uuid}" != "${EXPECTED_GPU_UUID}" ]]; then
  echo "GPU resource differs from execution authorization" >&2
  exit 69
fi
if [[ ! -f "${PROTOCOL}" || ! -f "${EXECUTION_AUTH}" || ! -f "${RUNNER}" ]]; then
  echo "protocol, execution authorization and runner are required" >&2
  exit 66
fi
if [[ -e "${OUTPUT_DIR}" || -e "${LAUNCH_LOG}" || -e "${PID_FILE}" || -e "${EXIT_FILE}" ]]; then
  echo "refusing to reuse a preflight output or sidecar path" >&2
  exit 73
fi
mkdir -p "$(dirname "${LAUNCH_LOG}")" "$(dirname "${PID_FILE}")" "$(dirname "${EXIT_FILE}")"
printf '%s\n' "$$" > "${PID_FILE}"
export CUDA_VISIBLE_DEVICES=0
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export PYTHONDONTWRITEBYTECODE=1
export V12_QA1_ZERO_UPDATE_PREFLIGHT_EXECUTION_AUTHORIZED=1

"${PYTHON_BIN}" -B "${RUNNER}" \
  --protocol "${PROTOCOL}" \
  --execution-authorization "${EXECUTION_AUTH}" \
  --output-dir "${OUTPUT_DIR}" \
  > "${LAUNCH_LOG}" 2>&1
status=$?
printf '%s\n' "${status}" > "${EXIT_FILE}"
exit "${status}"
