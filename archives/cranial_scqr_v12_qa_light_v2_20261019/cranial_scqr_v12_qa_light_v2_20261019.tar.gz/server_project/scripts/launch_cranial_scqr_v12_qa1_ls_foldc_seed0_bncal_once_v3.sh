#!/usr/bin/env bash
set -Eeuo pipefail

readonly ROOT="/home/jovyan/adapointr_work/PoinTr"
readonly PYTHON="/opt/conda/envs/adapointr-mamba/bin/python"
readonly REQUEST="$ROOT/docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_ls_foldc_seed0_bncal_execution_authorization_request_v3.json"
readonly SUPERSEDED_REQUEST_V1="$ROOT/docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_ls_foldc_seed0_bncal_execution_authorization_request_v1.json"
readonly INVALID_REQUEST_V2="$ROOT/docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_ls_foldc_seed0_bncal_execution_authorization_request_v2.json"
readonly SUPERSEDED_RECEIPT_V1="$ROOT/logs/cranial_scqr_v12_qa1/qa1_bncal_authorization/cranial_scqr_v12_qa1_LS_foldC_seed0_bncal_execution_authorization_receipt_v1_20261008T123437Z.json"
readonly SUPERSEDED_RECEIPT_SIDECAR_V1="$SUPERSEDED_RECEIPT_V1.sha256"
readonly SUPERSEDED_RUNTIME_V1="$ROOT/cfgs/SkullBreak_models/cranial_scqr_v12_qa1_bncal_authorized_v2/CranialSCQRV12QA1_LS_foldC_seed0.yaml"
readonly INVALID_V2_PARENT_B0_RUNTIME="$ROOT/cfgs/SkullBreak_models/cranial_scqr_v12_qa1_bncal_authorized_v3/CranialSCQRV12QA1_B0_foldC_seed0.yaml"
readonly RECEIPT="$ROOT/logs/cranial_scqr_v12_qa1/qa1_bncal_authorization/cranial_scqr_v12_qa1_LS_foldC_seed0_bncal_execution_authorization_receipt_v3_20261008T125431Z.json"
readonly RECEIPT_SIDECAR="$RECEIPT.sha256"
readonly RUNTIME_PARENT="$ROOT/cfgs/SkullBreak_models/cranial_scqr_v12_qa1_bncal_authorized_v4"
readonly RUNTIME="$RUNTIME_PARENT/CranialSCQRV12QA1_LS_foldC_seed0.yaml"
readonly RUN_ID="cranial_scqr_v12_qa1_LS_foldC_seed0_bncal_v3_20261008T125431Z"
readonly LOG_PARENT="$ROOT/logs/cranial_scqr_v12_qa1/qa1_bncal"
readonly MASTER="$LOG_PARENT/$RUN_ID"
readonly LAUNCHER_LOG="$LOG_PARENT/$RUN_ID.launcher.log"
readonly PID_FILE="$LOG_PARENT/$RUN_ID.pid"
readonly EXIT_FILE="$LOG_PARENT/$RUN_ID.exit_code"
readonly EXPERIMENT="$ROOT/experiments/CranialSCQRV12QA1_LS_foldC_seed0/cranial_scqr_v12_qa1_training_authorized_v1/cranial_scqr_v12_qa1_LS_foldC_seed0_v1_20261008T082520Z"
readonly OUTPUT_CHECKPOINT="$EXPERIMENT/ckpt-last-bncal.pth"
readonly OUTPUT_RECEIPT="$EXPERIMENT/v12_qa1_bncal_receipt.json"
readonly OUTPUT_SIDECAR="$EXPERIMENT/v12_qa1_bncal_files.sha256"
readonly EXPECTED_HOSTNAME="shu-common-25721452-notebook-g909cr-0"
readonly EXPECTED_GPU_NAME="NVIDIA GeForce RTX 4090 D"
readonly EXPECTED_GPU_UUID="GPU-1ab30ef5-7fda-9b57-037b-c4da094b174e"
readonly EXPECTED_PYTHON_SHA256="01b4275dc374dcae51d245bda004daad6d7882d3f5de7f9852567bb7ab83180d"

cd "$ROOT"

verify_identity_and_materials() {
  if [[ "$(hostname)" != "$EXPECTED_HOSTNAME" ]]; then
    echo "[blocked] hostname differs from authorization" >&2
    return 69
  fi
  if [[ "$(id -un)" != "jovyan" ]]; then
    echo "[blocked] user differs from authorization" >&2
    return 69
  fi
  if [[ "$(sha256sum "$(readlink -f "$PYTHON")" | awk '{print $1}')" != "$EXPECTED_PYTHON_SHA256" ]]; then
    echo "[blocked] Python binary differs from authorization" >&2
    return 69
  fi
  if [[ ! -d "$RUNTIME_PARENT" || -L "$RUNTIME_PARENT" || "$(stat -c %U "$RUNTIME_PARENT")" != "jovyan" ]]; then
    echo "[blocked] runtime-config parent is not an owned real directory" >&2
    return 73
  fi

  echo "74140b7650691e8309fc57971ab777546e1a491cf66b3f2dc783d00aab5a98c6  $REQUEST" | sha256sum -c -
  echo "507b6c78d7ca33ea801570cd638df70af037a6dd6cb4e42ab35fdf281d14d848  $SUPERSEDED_REQUEST_V1" | sha256sum -c -
  echo "cfa4977fa479c3137dbd694dee14522fb63468a8c60381f7474a8face805aef8  $INVALID_REQUEST_V2" | sha256sum -c -
  echo "998d01c482d0493b2fa8deb9448c5715fcddd061dc098649cf7b9b33bd0a4abb  $SUPERSEDED_RECEIPT_V1" | sha256sum -c -
  echo "0aa9d3a1bdfcdffa949ae7b0860344b8248f171536a99396560105f1b260b879  $SUPERSEDED_RECEIPT_SIDECAR_V1" | sha256sum -c -
  echo "f2d8f2b88a25e6a6bc85f794cd8e5d9c9dee1d68c927a7aea23bf38d28562772  $SUPERSEDED_RUNTIME_V1" | sha256sum -c -
  echo "c8d7f94c58c2b29a0d7e946fccf08687ac53b8ca8aa170f9f03383264939f344  $INVALID_V2_PARENT_B0_RUNTIME" | sha256sum -c -
  echo "0483de43cc3aa8eaad9b3cef655c1c3a432f3b0bbeb6a40b6816f5fd1ace874f  $RECEIPT" | sha256sum -c -
  (
    cd "$(dirname "$RECEIPT")"
    sha256sum -c "$(basename "$RECEIPT_SIDECAR")"
  )
  echo "3cc8234d7b8a7954ca682827f6ed901f1430714a79ecac95a8d3c167896f9afe  $RUNTIME" | sha256sum -c -
}

validate_runtime_only() {
  env PYTHONDONTWRITEBYTECODE=1 "$PYTHON" - "$RUNTIME" "$REQUEST" "$RECEIPT" <<'PY'
from __future__ import annotations

import hashlib
import sys
from pathlib import Path

import yaml


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


runtime_path = Path(sys.argv[1]).resolve()
request_path = Path(sys.argv[2]).resolve()
receipt_path = Path(sys.argv[3]).resolve()
payload = yaml.safe_load(runtime_path.read_text(encoding="utf-8"))
execution = payload["cranial_scqr_execution"]
qa1_lock = payload["qa1_lock"]
development = payload["development_protocol"]

assert execution["stage"] == "V12_QA1_bncal"
assert execution["status"] == "authorized_single_bncal_pending_execution"
assert execution["training_authorized"] is False
assert execution["optimizer_steps_authorized"] == 0
assert execution["bncal_authorized"] is True
assert execution["bncal_runs_authorized"] == 1
assert execution["bncal_cases_expected"] == 315
assert execution["bncal_batches_expected"] == 40
assert execution["development_payload_access_authorized"] is False
assert execution["development_evaluation_authorized"] is False
assert execution["resume_authorized"] is False
assert execution["automatic_rerun_authorized"] is False
assert execution["automatic_next_run_authorized"] is False

assert qa1_lock["run_key"] == "LS_foldC_seed0"
assert qa1_lock["candidate"] == "LS"
assert qa1_lock["fold"] == "C"
assert qa1_lock["seed"] == 0
assert development["candidate"] == "LS"
assert development["fold"] == "C"
assert development["seed"] == 0

assert execution["bncal_execution_request"] == "docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_ls_foldc_seed0_bncal_execution_authorization_request_v3.json"
assert execution["bncal_execution_request_sha256"] == sha256_file(request_path)
assert execution["bncal_authorization_receipt"] == "logs/cranial_scqr_v12_qa1/qa1_bncal_authorization/cranial_scqr_v12_qa1_LS_foldC_seed0_bncal_execution_authorization_receipt_v3_20261008T125431Z.json"
assert execution["bncal_authorization_receipt_sha256"] == sha256_file(receipt_path)
assert execution["source_training_runtime_config_sha256"] == "44b954984bcc1b0773c45c2c72c6f1ce03fbe4a7ac6780ac146c42e8667eaa69"
assert execution["source_training_state_sha256"] == "c5e5be2fade9afdf6d7795f5656332c47d76f98a85756945af66659096b1c430"
assert execution["source_training_completion_receipt_sha256"] == "dddc1b45dc09ea28e9013596bde4f397526dd7498090c3df06776e4c84f0fe7f"
assert execution["source_training_checkpoint_sha256"] == "f0c4d01e14fd6a488daa8d782f26a30cb60e8668bcdd53afadaba537ba3ec3e5"
assert execution["train_case_ids_sha256"] == "3c5883d1f582b90533ffed3ae61b1bbe8b88c39b75f40faddf25b63d8f93836d"

print("[validation-only] PASS")
PY
}

if [[ "${1:-}" == "--validate-runtime-only" ]]; then
  if [[ "$#" -ne 1 ]]; then
    echo "[blocked] validation-only mode accepts no additional arguments" >&2
    exit 64
  fi
  verify_identity_and_materials
  validate_runtime_only
  exit 0
fi

if [[ "$#" -ne 0 ]]; then
  echo "[blocked] unexpected launcher arguments" >&2
  exit 64
fi

for target in "$MASTER" "$LAUNCHER_LOG" "$PID_FILE" "$EXIT_FILE" "$OUTPUT_CHECKPOINT" "$OUTPUT_RECEIPT" "$OUTPUT_SIDECAR"; do
  if [[ -e "$target" ]]; then
    echo "[blocked] refusing to reuse frozen output path: $target" >&2
    exit 73
  fi
done

mkdir -p "$LOG_PARENT"
if [[ ! -d "$LOG_PARENT" || -L "$LOG_PARENT" || "$(stat -c %U "$LOG_PARENT")" != "jovyan" ]]; then
  echo "[blocked] launcher log parent is not an owned real directory: $LOG_PARENT" >&2
  exit 73
fi
exec >"$LAUNCHER_LOG" 2>&1

record_exit() {
  local status="$?"
  set +e
  printf '%s\n' "$status" > "$EXIT_FILE"
  if [[ -d "$MASTER" ]]; then
    date -u +%Y-%m-%dT%H:%M:%SZ > "$MASTER/finished_at_utc.txt"
  fi
  trap - EXIT
  exit "$status"
}
trap record_exit EXIT

verify_identity_and_materials
validate_runtime_only

echo "8c5ff74b4ad73105b0a45d36e9590b2659d28ebc60400b5bae0d84752a68f514  docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_formal_config_protocol_v1.json" | sha256sum -c -
echo "a13a1cedf47c25ff430dcbc09888fa0be11f849f0e49dd07fae74605449fe123  docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_bncal_guard_implementation_protocol_v2.json" | sha256sum -c -
echo "c85ce623bb99f7031e3aa50f2226b77d77d679939dc578057d66d3ebc40dc447  docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_bncal_guard_implementation_authorization_receipt_v2.json" | sha256sum -c -
echo "5d5a8226c5be17a5c05aed3d73dd827d46f0dd629b8b5f29ef78d0ae2231f1d4  docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_bncal_guard_post_implementation_p3_receipt_v2.json" | sha256sum -c -
echo "d9a9210c46fbfd8f7f601976dc28bedcdbf9abe7c2f93578e2d5a4fcd45d6fb7  tools/run_cranial_scqr_v12_qa1_bncal.py" | sha256sum -c -
echo "49fffcfccb2c97637c16300ff9be2f8f7dfdd726eb5d37d587ce8a46f3bd090a  tools/test_cranial_scqr_v12_qa1_bncal_contract.py" | sha256sum -c -
echo "c6e4c4a67f6ebf684be618cec7eb9568d775cfb03205773fc901883516939102  tools/run_cranial_scqr_v11_l4_bncal.py" | sha256sum -c -
echo "e4731999fd41a3e8f73077860e0c2ec95d18bea71fee55dcb31ff4154ae58342  tools/runner.py" | sha256sum -c -
echo "62a743c4c2143b77b0f1656c59d0482563976440d841f04bae995017dbf7588f  models/AdaPoinTr.py" | sha256sum -c -
echo "5c4c17c81f8a64c21bb239933a438b98c98f0ee587820dd1789f616f9cbd7fe2  datasets/SkullBreakDataset.py" | sha256sum -c -
echo "44b954984bcc1b0773c45c2c72c6f1ce03fbe4a7ac6780ac146c42e8667eaa69  cfgs/SkullBreak_models/cranial_scqr_v12_qa1_training_authorized_v1/CranialSCQRV12QA1_LS_foldC_seed0.yaml" | sha256sum -c -
echo "c5e5be2fade9afdf6d7795f5656332c47d76f98a85756945af66659096b1c430  $EXPERIMENT/v12_qa1_training_execution_state.json" | sha256sum -c -
echo "dddc1b45dc09ea28e9013596bde4f397526dd7498090c3df06776e4c84f0fe7f  logs/cranial_scqr_v12_qa1/qa1_training/cranial_scqr_v12_qa1_LS_foldC_seed0_v1_20261008T082520Z/training_completion_receipt.json" | sha256sum -c -
echo "f0c4d01e14fd6a488daa8d782f26a30cb60e8668bcdd53afadaba537ba3ec3e5  $EXPERIMENT/ckpt-last.pth" | sha256sum -c -
echo "3c5883d1f582b90533ffed3ae61b1bbe8b88c39b75f40faddf25b63d8f93836d  logs/skullbreak_mamba_v12_development/protocol_v1/foldC_train_case_ids.txt" | sha256sum -c -

actual_gpu_name="$(nvidia-smi --query-gpu=name --format=csv,noheader | sed -n '1p')"
actual_gpu_uuid="$(nvidia-smi --query-gpu=uuid --format=csv,noheader | sed -n '1p')"
gpu_count="$(nvidia-smi --query-gpu=uuid --format=csv,noheader | wc -l)"
read -r gpu_used gpu_total < <(nvidia-smi --query-gpu=memory.used,memory.total --format=csv,noheader,nounits | tr -d ',' | awk 'NR==1 {print $1, $2}')
gpu_free="$((gpu_total - gpu_used))"
disk_free_kib="$(df -Pk /home/jovyan | awk 'NR==2 {print $4}')"
if [[ "$gpu_count" -ne 1 || "$actual_gpu_name" != "$EXPECTED_GPU_NAME" || "$actual_gpu_uuid" != "$EXPECTED_GPU_UUID" ]]; then
  echo "[blocked] GPU identity differs from authorization" >&2
  exit 69
fi
if nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits | grep -Eq '[0-9]'; then
  echo "[blocked] a GPU compute process already exists" >&2
  exit 70
fi
if [[ "$gpu_free" -lt 22000 ]]; then
  echo "[blocked] insufficient free GPU memory: ${gpu_free} MiB" >&2
  exit 71
fi
if [[ "$disk_free_kib" -lt 8388608 ]]; then
  echo "[blocked] insufficient free disk: ${disk_free_kib} KiB" >&2
  exit 72
fi

for target in "$MASTER" "$PID_FILE" "$EXIT_FILE" "$OUTPUT_CHECKPOINT" "$OUTPUT_RECEIPT" "$OUTPUT_SIDECAR"; do
  if [[ -e "$target" ]]; then
    echo "[blocked] refusing to reuse output path after prelaunch checks: $target" >&2
    exit 73
  fi
done

mkdir -p "$MASTER"
printf '%s\n' "$$" > "$PID_FILE"
date -u +%Y-%m-%dT%H:%M:%SZ > "$MASTER/started_at_utc.txt"

cat > "$MASTER/prelaunch_environment.json" <<EOF
{
  "status": "LAUNCH_READY",
  "hostname": "$(hostname)",
  "gpu_name": "$actual_gpu_name",
  "gpu_uuid": "$actual_gpu_uuid",
  "gpu_memory_used_mib": $gpu_used,
  "gpu_memory_total_mib": $gpu_total,
  "disk_free_kib": $disk_free_kib,
  "request_sha256": "74140b7650691e8309fc57971ab777546e1a491cf66b3f2dc783d00aab5a98c6",
  "authorization_receipt_sha256": "0483de43cc3aa8eaad9b3cef655c1c3a432f3b0bbeb6a40b6816f5fd1ace874f",
  "runtime_config_sha256": "3cc8234d7b8a7954ca682827f6ed901f1430714a79ecac95a8d3c167896f9afe",
  "training_authorized": false,
  "optimizer_steps_authorized": 0,
  "bncal_runs_authorized": 1,
  "development_payload_access_authorized": false,
  "development_evaluation_authorized": false
}
EOF

echo "[stage] BNCal start $(date -u +%Y-%m-%dT%H:%M:%SZ)"
env \
  CUDA_VISIBLE_DEVICES=0 \
  CUBLAS_WORKSPACE_CONFIG=:4096:8 \
  PYTHONDONTWRITEBYTECODE=1 \
  "$PYTHON" -B -u tools/run_cranial_scqr_v12_qa1_bncal.py \
    --config cfgs/SkullBreak_models/cranial_scqr_v12_qa1_bncal_authorized_v4/CranialSCQRV12QA1_LS_foldC_seed0.yaml \
    --experiment_dir experiments/CranialSCQRV12QA1_LS_foldC_seed0/cranial_scqr_v12_qa1_training_authorized_v1/cranial_scqr_v12_qa1_LS_foldC_seed0_v1_20261008T082520Z \
    --batch_size 8 \
    --num_workers 0 \
    --seed 0
echo "[stage] BNCal execution complete $(date -u +%Y-%m-%dT%H:%M:%SZ)"
