#!/usr/bin/env bash
set -Eeuo pipefail
readonly ROOT='/home/jovyan/adapointr_work/PoinTr'
readonly PYTHON='/opt/conda/envs/adapointr-mamba/bin/python'
readonly REQUEST='/home/jovyan/adapointr_work/PoinTr/docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_lsq_foldd_seed0_bncal_execution_authorization_request_v1.json'
readonly RECEIPT='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_bncal_authorization/cranial_scqr_v12_qa1_LSQ_foldD_seed0_bncal_execution_authorization_receipt_v1_20261009T123606Z.json'
readonly RUNTIME='/home/jovyan/adapointr_work/PoinTr/cfgs/SkullBreak_models/cranial_scqr_v12_qa1_bncal_authorized_v7/CranialSCQRV12QA1_LSQ_foldD_seed0.yaml'
readonly MASTER='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_bncal/cranial_scqr_v12_qa1_LSQ_foldD_seed0_bncal_v1_20261009T123606Z'
readonly LOG='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_bncal/cranial_scqr_v12_qa1_LSQ_foldD_seed0_bncal_v1_20261009T123606Z.launcher.log'
readonly PID_FILE='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_bncal/cranial_scqr_v12_qa1_LSQ_foldD_seed0_bncal_v1_20261009T123606Z.pid'
readonly EXIT_FILE='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_bncal/cranial_scqr_v12_qa1_LSQ_foldD_seed0_bncal_v1_20261009T123606Z.exit_code'
cd "$ROOT"
export PYTHONDONTWRITEBYTECODE=1
validate_runtime() {
 BNCAL_LAUNCH_MODE="${1:-validation-only}" "$PYTHON" -B - "$RUNTIME" '1c66c1bfd1f0a4e945a0da5a6227c68753250654c8672677e844710673babfbc' '436c5994182cc3bc4c91abd1aa89233525965f3fbda7866583cccfb0e223ad41' <<'PY'
import hashlib,json,os,pwd,re,socket,subprocess,sys
from pathlib import Path
import yaml
root=Path('/home/jovyan/adapointr_work/PoinTr')
rt=Path(sys.argv[1]);request_hash=sys.argv[2];receipt_hash=sys.argv[3]
mode=os.environ.get('BNCAL_LAUNCH_MODE','validation-only');assert mode in ('validation-only','execution')
assert Path.cwd().resolve()==root
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
assert sha(root/'docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_lsq_foldd_seed0_bncal_execution_authorization_request_v1.json')==request_hash
q=json.loads(Path('/home/jovyan/adapointr_work/PoinTr/docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_lsq_foldd_seed0_bncal_execution_authorization_request_v1.json').read_text());a=json.loads(Path('/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_bncal_authorization/cranial_scqr_v12_qa1_LSQ_foldD_seed0_bncal_execution_authorization_receipt_v1_20261009T123606Z.json').read_text());cfg=yaml.safe_load(rt.read_text());ex=cfg['cranial_scqr_execution']
assert sha(rt)=='800c96e6d07aeaa67fe33fbe37d5f110ada8f489687f1cfc344e091c0cf57f49' and sha(Path('/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_bncal_authorization/cranial_scqr_v12_qa1_LSQ_foldD_seed0_bncal_execution_authorization_receipt_v1_20261009T123606Z.json'))==receipt_hash
assert q['status']=='AWAITING_EXPLICIT_USER_AUTHORIZATION' and q['execution_authorized'] is False
assert q['requested_run_keys']==a['authorized_run_keys']==['LSQ_foldD_seed0']
assert a['status']=='AUTHORIZED' and a['execution_authorized'] is True
assert a['bncal_request']=={'path':ex['bncal_execution_request'],'sha256':request_hash}
assert 'bncal_runtime_config_sha256' not in a
assert ex['bncal_execution_request_sha256']==request_hash and ex['bncal_authorization_receipt_sha256']==receipt_hash
assert ex['bncal_authorization_receipt']==q['fixed_future_execution']['authorization_receipt']
assert ex['stage']=='V12_QA1_bncal' and ex['training_authorized'] is False and ex['optimizer_steps_authorized']==0
assert ex['bncal_authorized'] is True and ex['bncal_runs_authorized']==1
assert ex['bncal_cases_expected']==315 and ex['bncal_batches_expected']==40
for key in ('development_payload_access_authorized','development_evaluation_authorized','resume_authorized','automatic_rerun_authorized','automatic_next_run_authorized'):assert ex[key] is False
assert cfg['qa1_lock']['run_key']=='LSQ_foldD_seed0' and cfg['qa1_lock']['candidate']=='LSQ' and cfg['qa1_lock']['fold']=='D' and cfg['qa1_lock']['seed']==0
bindings=q['implementation_bindings']+list(q['prerequisite_bindings'].values())+[q['source_training_freeze'][k] for k in ('runtime_config','training_state','training_completion_receipt','checkpoint')]
bindings += [{'path':q['data_scope']['train_allowlist'],'sha256':q['data_scope']['train_allowlist_sha256']}]
for b in bindings:
 p=root/b['path'];assert sha(p)==b['sha256'],str(p)
 if 'bytes' in b:assert p.stat().st_size==b['bytes']
 if 'required_status' in b:assert json.loads(p.read_text())['status']==b['required_status']
state=json.loads((root/q['source_training_freeze']['training_state']['path']).read_text())
assert state['optimizer_steps']==state['model_updates']==3939 and state['epoch_traversals_completed']==101
assert state['bncal_updates']==0 and state['development_payload_accessed'] is False and state['development_dataloader_constructed'] is False and state['bncal_authorized'] is False
for key in ('source_training_checkpoint_sha256','source_training_state_sha256','source_training_completion_receipt_sha256','source_training_runtime_config_sha256'):
 field={'source_training_checkpoint_sha256':'checkpoint','source_training_state_sha256':'training_state','source_training_completion_receipt_sha256':'training_completion_receipt','source_training_runtime_config_sha256':'runtime_config'}[key]
 assert ex[key]==q['source_training_freeze'][field]['sha256']
r=q['resource_binding'];assert socket.gethostname()==r['hostname'] and pwd.getpwuid(os.getuid()).pw_name==r['user']
assert sha(Path(r['python_executable']).resolve())==r['python_binary_sha256']
rows=subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,memory.total,memory.used,utilization.gpu,compute_mode','--format=csv,noheader,nounits'],text=True).strip().splitlines();assert len(rows)==1
gpu=[v.strip() for v in rows[0].split(',')];assert gpu[:2]==[r['gpu_name'],r['gpu_uuid']] and int(gpu[2])-int(gpu[3])>=22000 and int(gpu[4])==0 and gpu[5]==r['gpu_compute_mode']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
disk=os.statvfs('/home/jovyan');assert disk.f_bavail*disk.f_frsize>=8*1024**3
experiment=root/q['fixed_future_execution']['experiment_output']
for name in ('ckpt-last-bncal.pth','ckpt-last-bncal.pth.tmp','v12_qa1_bncal_receipt.json','v12_qa1_bncal_files.sha256'):assert not (experiment/name).exists() and not (experiment/name).is_symlink()
# Full YAML equality: the execution mapping is the only authorized change.
expected=yaml.safe_load((root/q['source_training_freeze']['runtime_config']['path']).read_text())
ex_expected=dict(q['runtime_config_materialization_only_after_explicit_authorization']['cranial_scqr_execution'])
ex_expected['bncal_execution_request_sha256']=request_hash
ex_expected['bncal_authorization_receipt_sha256']=receipt_hash
expected['cranial_scqr_execution']=ex_expected
assert cfg==expected
assert ex['bncal_execution_request']==str(Path('/home/jovyan/adapointr_work/PoinTr/docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_lsq_foldd_seed0_bncal_execution_authorization_request_v1.json').relative_to(root))
for key,value in q['authorization_receipt_schema_only_after_explicit_authorization'].items():
 if key!='bncal_request':assert a[key]==value,key
assert (root/q['fixed_future_execution']['authorization_receipt_sha256_sidecar']).read_text().split()[0]==receipt_hash
assert cfg['development_protocol']['candidate']=='LSQ' and cfg['development_protocol']['fold']=='D' and cfg['development_protocol']['seed']==0
scqr=cfg['model']['cranial_scqr'];assert scqr['variant']=='Q0' and scqr['enabled'] and scqr['local_geometry_enabled'] and scqr['contact_supervision_enabled'] and scqr['query_conditioning_enabled']
assert scqr['contact_bias_beta']==0 and scqr['auxiliary_loss_weight']==0.8346387037781536
assert sys.version.split()[0]==r['python_version'] and str(Path(r['python_executable']).resolve())==r['python_realpath']
parent=root/q['fixed_future_execution']['runtime_config_parent']
assert parent.is_dir() and not parent.is_symlink() and pwd.getpwuid(parent.stat().st_uid).pw_name==r['user']
assert parent.resolve().is_relative_to(root)
assert sha(Path(q['data_scope']['manifest']))==q['data_scope']['manifest_sha256_from_parent_audit']
assert (root/'data/SkullBreakPC_out8192').resolve()==Path(q['data_scope']['manifest']).parent
if mode=='validation-only':
 for key in ('master_output','launcher_log','pid_file','exit_file'):
  path=root/q['fixed_future_execution'][key];assert not path.exists() and not path.is_symlink(),str(path)
sessions=subprocess.run(['tmux','list-sessions'],capture_output=True,text=True)
if mode=='validation-only':
 assert sessions.returncode==1 and not sessions.stdout.strip()
else:
 assert sessions.returncode==0 and [x.split(':',1)[0] for x in sessions.stdout.splitlines()]==[q['fixed_future_execution']['tmux_session']]
for line in subprocess.check_output(['ps','-eo','pid,args'],text=True).splitlines():
 assert not re.search(r'(?:^|\s)(?:\S*/)?(?:python(?:3(?:\.\d+)?)?|torchrun)\s.*(?:main\.py|run_cranial_scqr|preflight)',line),line
assert 'torch' not in sys.modules

print('[validation-only] PASS',flush=True)
PY
}
if [[ "${1:-}" == '--validate-runtime-only' ]]; then
 [[ "$#" -eq 1 ]]
 validate_runtime
 exit 0
fi
[[ "$#" -eq 0 ]]
for target in "$MASTER" "$LOG" "$PID_FILE" "$EXIT_FILE"; do
 [[ ! -e "$target" && ! -L "$target" ]] || { echo "[blocked] existing single-use path $target" >&2; exit 73; }
done
mkdir -p "$(dirname "$LOG")"
[[ -d "$(dirname "$LOG")" && ! -L "$(dirname "$LOG")" && "$(stat -c '%U' "$(dirname "$LOG")")" == 'jovyan' ]]
set -o noclobber
exec >"$LOG" 2>&1
record_exit() { status="$?"; printf '%s\n' "$status" > "$EXIT_FILE"; }
trap record_exit EXIT
validate_runtime execution
mkdir "$MASTER"
printf '%s\n' "$$" > "$PID_FILE"
date -u +%Y-%m-%dT%H:%M:%SZ > "$MASTER/started_at_utc.txt"
echo '[stage] exactly one partial-only BNCal'
timeout --signal=TERM --kill-after=20s 1800s 'env' 'CUDA_VISIBLE_DEVICES=0' 'CUBLAS_WORKSPACE_CONFIG=:4096:8' 'NVIDIA_TF32_OVERRIDE=0' 'PYTHONDONTWRITEBYTECODE=1' '/opt/conda/envs/adapointr-mamba/bin/python' '-B' '-u' 'tools/run_cranial_scqr_v12_qa1_bncal.py' '--config' 'cfgs/SkullBreak_models/cranial_scqr_v12_qa1_bncal_authorized_v7/CranialSCQRV12QA1_LSQ_foldD_seed0.yaml' '--experiment_dir' 'experiments/CranialSCQRV12QA1_LSQ_foldD_seed0/cranial_scqr_v12_qa1_training_authorized_v1/cranial_scqr_v12_qa1_LSQ_foldD_seed0_v1_20261009T114815Z' '--batch_size' '8' '--num_workers' '0' '--seed' '0'
date -u +%Y-%m-%dT%H:%M:%SZ > "$MASTER/finished_at_utc.txt"
echo '[done] BNCal command exited 0; pending separate post-BNCal freeze audit'
