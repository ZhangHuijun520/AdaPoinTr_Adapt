#!/usr/bin/env bash
set -Eeuo pipefail
readonly ROOT='/home/jovyan/adapointr_work/PoinTr'
readonly PYTHON='/opt/conda/envs/adapointr-mamba/bin/python'
readonly MASTER='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LSQ_foldD_seed0_development_eval_v1_20261009T130327Z'
readonly LOG='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LSQ_foldD_seed0_development_eval_v1_20261009T130327Z.launcher.log'
readonly PID_FILE='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LSQ_foldD_seed0_development_eval_v1_20261009T130327Z.pid'
readonly EXIT_FILE='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LSQ_foldD_seed0_development_eval_v1_20261009T130327Z.exit_code'
cd "$ROOT"
export PYTHONDONTWRITEBYTECODE=1
validate_runtime() {
 "$PYTHON" -B - <<'PY'
import importlib.util,hashlib,json,os,pwd,socket,subprocess,sys
from pathlib import Path
root=Path('/home/jovyan/adapointr_work/PoinTr')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
assert sha(Path('/home/jovyan/adapointr_work/PoinTr/docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_lsq_foldd_seed0_development_evaluation_execution_authorization_request_v1.json'))=='aa4ae236b833f586cb256f039722b7914a545cdfe428197161dbad58290ca8fd'
assert sha(Path('/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_development_evaluation_authorization/cranial_scqr_v12_qa1_LSQ_foldD_seed0_development_evaluation_execution_authorization_receipt_v1_20261009T130327Z.json'))=='02a786a91fadeb40a9c6ed5a97cba194436faecb943df4bfa97a297e850c2e3b'
assert sha(Path('/home/jovyan/adapointr_work/PoinTr/cfgs/SkullBreak_models/cranial_scqr_v12_qa1_development_eval_authorized_v6/CranialSCQRV12QA1_LSQ_foldD_seed0.yaml'))=='d9f646a4ca6e9328e89f8b03ede8ac709acf88a723243c401765a76e2f6e590c'
q=json.loads(Path('/home/jovyan/adapointr_work/PoinTr/docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_lsq_foldd_seed0_development_evaluation_execution_authorization_request_v1.json').read_text())
items=q['implementation_bindings']+list(q['protocol_bindings'].values())+[q['post_implementation_p3']]+list(q['source_training_freeze'].values())+list(q['source_bncal_freeze'].values())
for b in items:
 p=root/b['path'];assert sha(p)==b['sha256'],str(p)
 if 'bytes' in b:assert p.stat().st_size==b['bytes']
spec=importlib.util.spec_from_file_location('qa1_eval_validation',root/'tools/run_cranial_scqr_v12_qa1_development_eval.py')
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
command=["env", "CUDA_VISIBLE_DEVICES=0", "CUBLAS_WORKSPACE_CONFIG=:4096:8", "NVIDIA_TF32_OVERRIDE=0", "PYTHONDONTWRITEBYTECODE=1", "/opt/conda/envs/adapointr-mamba/bin/python", "-B", "-u", "tools/run_cranial_scqr_v12_qa1_development_eval.py", "--execution-request", "docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_lsq_foldd_seed0_development_evaluation_execution_authorization_request_v1.json", "--execution-request-sha256", "aa4ae236b833f586cb256f039722b7914a545cdfe428197161dbad58290ca8fd", "--authorization-receipt", "logs/cranial_scqr_v12_qa1/qa1_development_evaluation_authorization/cranial_scqr_v12_qa1_LSQ_foldD_seed0_development_evaluation_execution_authorization_receipt_v1_20261009T130327Z.json", "--authorization-receipt-sha256", "02a786a91fadeb40a9c6ed5a97cba194436faecb943df4bfa97a297e850c2e3b", "--runtime-config", "cfgs/SkullBreak_models/cranial_scqr_v12_qa1_development_eval_authorized_v6/CranialSCQRV12QA1_LSQ_foldD_seed0.yaml", "--runtime-config-sha256", "d9f646a4ca6e9328e89f8b03ede8ac709acf88a723243c401765a76e2f6e590c", "--manifest", "/home/jovyan/datasets/SkullBreakPC_out8192/manifest.jsonl", "--manifest-sha256", "f1f8cae47ed7d5529dc2ca244179cedddbc039981cdc0ff24b25a5c81ad30538", "--data-root", "/home/jovyan/datasets/SkullBreakPC_out8192", "--output-dir", "logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LSQ_foldD_seed0_development_eval_v1_20261009T130327Z", "--device", "cuda:0"]
args=module.parse_args(command[command.index('tools/run_cranial_scqr_v12_qa1_development_eval.py')+1:])
for name in ('execution_request','authorization_receipt','runtime_config','manifest','data_root','output_dir'):setattr(args,name,getattr(args,name).resolve())
assert not args.output_dir.exists()
module.preflight(args)
assert 'torch' not in sys.modules, 'validation-only must not import torch'
r=q['resource_binding'];assert socket.gethostname()==r['hostname'] and pwd.getpwuid(os.getuid()).pw_name==r['user']
assert sha(Path(r['python_executable']).resolve())==r['python_binary_sha256']
gpu=subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,memory.total,memory.used','--format=csv,noheader,nounits'],text=True).strip().splitlines();assert len(gpu)==1
fields=[v.strip() for v in gpu[0].split(',')];assert fields[:2]==[r['gpu_name'],r['gpu_uuid']] and int(fields[2])-int(fields[3])>=22000
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
disk=os.statvfs('/home/jovyan');assert disk.f_bavail*disk.f_frsize>=8*1024**3
print('[validation-only] PASS',flush=True)
PY
}
if [[ "${1:-}" == '--validate-runtime-only' ]]; then validate_runtime; exit 0; fi
[[ "$#" -eq 0 ]]
for target in "$MASTER" "$LOG" "$PID_FILE" "$EXIT_FILE"; do
 [[ ! -e "$target" ]] || { echo "[blocked] existing output $target" >&2; exit 73; }
done
mkdir -p "$(dirname "$LOG")"
[[ -d "$(dirname "$LOG")" && ! -L "$(dirname "$LOG")" && "$(stat -c '%U' "$(dirname "$LOG")")" == 'jovyan' ]]
set -o noclobber
exec >"$LOG" 2>&1
record_exit() { status="$?"; printf '%s\n' "$status" > "$EXIT_FILE"; }
trap record_exit EXIT
validate_runtime
printf '%s\n' "$$" > "$PID_FILE"
echo '[stage] exactly one LSQ Fold D descriptive evaluation'
timeout --signal=TERM --kill-after=20s 7200s env CUDA_VISIBLE_DEVICES=0 CUBLAS_WORKSPACE_CONFIG=:4096:8 NVIDIA_TF32_OVERRIDE=0 PYTHONDONTWRITEBYTECODE=1 /opt/conda/envs/adapointr-mamba/bin/python -B -u tools/run_cranial_scqr_v12_qa1_development_eval.py --execution-request docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_lsq_foldd_seed0_development_evaluation_execution_authorization_request_v1.json --execution-request-sha256 aa4ae236b833f586cb256f039722b7914a545cdfe428197161dbad58290ca8fd --authorization-receipt logs/cranial_scqr_v12_qa1/qa1_development_evaluation_authorization/cranial_scqr_v12_qa1_LSQ_foldD_seed0_development_evaluation_execution_authorization_receipt_v1_20261009T130327Z.json --authorization-receipt-sha256 02a786a91fadeb40a9c6ed5a97cba194436faecb943df4bfa97a297e850c2e3b --runtime-config cfgs/SkullBreak_models/cranial_scqr_v12_qa1_development_eval_authorized_v6/CranialSCQRV12QA1_LSQ_foldD_seed0.yaml --runtime-config-sha256 d9f646a4ca6e9328e89f8b03ede8ac709acf88a723243c401765a76e2f6e590c --manifest /home/jovyan/datasets/SkullBreakPC_out8192/manifest.jsonl --manifest-sha256 f1f8cae47ed7d5529dc2ca244179cedddbc039981cdc0ff24b25a5c81ad30538 --data-root /home/jovyan/datasets/SkullBreakPC_out8192 --output-dir logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LSQ_foldD_seed0_development_eval_v1_20261009T130327Z --device cuda:0
"$PYTHON" -B - "$MASTER" <<'PY'
import hashlib,json,sys
from pathlib import Path
out=Path(sys.argv[1]);receipt=json.loads((out/'evaluation_execution_receipt.json').read_text());summary=json.loads((out/'single_run_summary.json').read_text())
assert receipt['status']=='PASS_DESCRIPTIVE_SINGLE_RUN_ONLY' and receipt['run_key']=='LSQ_foldD_seed0'
assert receipt['model_parameters_and_buffers_unchanged'] is True
assert receipt['formal_qa1_gate_applied'] is False and receipt['candidate_comparison_performed'] is False
report=out/'development_evaluation_report_zh_v1.md'
text='# LSQ Fold D 单次 development 描述性评估\n\n状态：执行凭据 PASS，等待单独 post-evaluation freeze audit。\n\n仅描述该候选该 fold，不作候选比较、C/D pooled delta、正式 QA-1 gate 或自动推进。\n\n机器可读计数：\n\n```json\n'+json.dumps(receipt['counters'],indent=2,ensure_ascii=False)+'\n```\n\n单运行描述性汇总：\n\n```json\n'+json.dumps(summary,indent=2,ensure_ascii=False)+'\n```\n'
with report.open('x',encoding='utf-8') as f:f.write(text)
names=['invocation.json','per_model_case_metrics.csv','per_model_source_metrics.csv','mechanism_diagnostics.csv','single_run_summary.json','evaluation_execution_receipt.json',report.name]
with (out/'files.sha256').open('x',encoding='ascii') as f:
 for name in names:
  p=out/name;assert p.is_file();f.write(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+name+'\n')
print('[done] EVALUATION_COMMAND_PASS_PENDING_SEPARATE_FREEZE_AUDIT',flush=True)
PY
