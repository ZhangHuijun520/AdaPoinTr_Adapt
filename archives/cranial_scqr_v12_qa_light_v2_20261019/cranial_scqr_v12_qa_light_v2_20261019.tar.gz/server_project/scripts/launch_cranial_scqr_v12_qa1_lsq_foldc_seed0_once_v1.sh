#!/usr/bin/env bash
set -Eeuo pipefail
readonly ROOT='/home/jovyan/adapointr_work/PoinTr'
readonly PYTHON='/opt/conda/envs/adapointr-mamba/bin/python'
readonly REQUEST='/home/jovyan/adapointr_work/PoinTr/docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_lsq_foldc_seed0_training_execution_authorization_request_v1.json'
readonly RECEIPT='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_training_authorization/cranial_scqr_v12_qa1_LSQ_foldC_seed0_training_execution_authorization_receipt_v1_20261009T080956Z.json'
readonly RUNTIME='/home/jovyan/adapointr_work/PoinTr/cfgs/SkullBreak_models/cranial_scqr_v12_qa1_training_authorized_v1/CranialSCQRV12QA1_LSQ_foldC_seed0.yaml'
readonly MASTER='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_training/cranial_scqr_v12_qa1_LSQ_foldC_seed0_v1_20261009T080956Z'
readonly LOG='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_training/cranial_scqr_v12_qa1_LSQ_foldC_seed0_v1_20261009T080956Z.launcher.log'
readonly PID_FILE='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_training/cranial_scqr_v12_qa1_LSQ_foldC_seed0_v1_20261009T080956Z.pid'
readonly EXIT_FILE='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_training/cranial_scqr_v12_qa1_LSQ_foldC_seed0_v1_20261009T080956Z.exit_code'
readonly EXPERIMENT='/home/jovyan/adapointr_work/PoinTr/experiments/CranialSCQRV12QA1_LSQ_foldC_seed0/cranial_scqr_v12_qa1_training_authorized_v1/cranial_scqr_v12_qa1_LSQ_foldC_seed0_v1_20261009T080956Z'
cd "$ROOT"
readonly MODE="${1:-}"
if [[ "$#" -gt 1 || ( -n "$MODE" && "$MODE" != "--validate-runtime-only" ) ]]; then
  printf '[blocked] unsupported launcher arguments\n' >&2
  exit 64
fi
if [[ "$MODE" != "--validate-runtime-only" ]]; then
# mkdir before any redirection; noclobber plus the PID marker prevents reuse.
mkdir -p "$(dirname "$LOG")"
for target in "$MASTER" "$LOG" "$PID_FILE" "$EXIT_FILE" "$EXPERIMENT"; do
  if [[ -e "$target" || -L "$target" ]]; then
    printf '[blocked] existing single-use path: %s\n' "$target" >&2
    exit 73
  fi
done
set -o noclobber
exec >"$LOG" 2>&1
printf '%s\n' "$$" > "$PID_FILE"
mkdir "$MASTER"
record_exit() {
  status="$?"
  printf '%s\n' "$status" > "$EXIT_FILE"
  date -u +%Y-%m-%dT%H:%M:%SZ > "$MASTER/finished_at_utc.txt"
}
trap record_exit EXIT
date -u +%Y-%m-%dT%H:%M:%SZ > "$MASTER/started_at_utc.txt"
fi
export PYTHONDONTWRITEBYTECODE=1
"$PYTHON" -B - "$REQUEST" "$RECEIPT" "$RUNTIME" "$MASTER" "$MODE" <<'PY'
import ast,hashlib,json,os,pwd,re,socket,subprocess,sys,time,signal
from datetime import datetime,timezone
from pathlib import Path
import yaml
root=Path('/home/jovyan/adapointr_work/PoinTr')
request_path,receipt_path,runtime_path,master=map(Path,sys.argv[1:5])
validation_only=sys.argv[5]=='--validate-runtime-only'
assert Path.cwd().resolve()==root
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''): h.update(chunk)
    return h.hexdigest()
assert sha(request_path)=='f10bf07f68ccc16bdfdb4d5a85a700f7d5cae78f62b2659c7907a15cb8a1e559'
assert sha(receipt_path)=='fb7efc11e733ca52f4dd2c8ba7acbf874797eace9bc25263819ae18d5732145d'
assert sha(runtime_path)=='4002ca2c68d604f9e9add924cf961995538e00c0bb7050b3b57e6c59a31cc3fd'
q=json.loads(request_path.read_text())
a=json.loads(receipt_path.read_text())
runtime=yaml.safe_load(runtime_path.read_text())
ex=runtime['cranial_scqr_execution']
fixed=q['fixed_future_execution']
r=q['resource_binding']
assert q['status']=='AWAITING_EXPLICIT_USER_AUTHORIZATION' and q['execution_authorized'] is False
assert q['requested_run_keys']==['LSQ_foldC_seed0']
assert a['status']=='AUTHORIZED' and a['authorized_run_keys']==['LSQ_foldC_seed0']
assert a['training_request']['sha256']=='f10bf07f68ccc16bdfdb4d5a85a700f7d5cae78f62b2659c7907a15cb8a1e559'
assert 'runtime_config_sha256' not in a
assert ex['authorization_receipt_sha256']=='fb7efc11e733ca52f4dd2c8ba7acbf874797eace9bc25263819ae18d5732145d'
assert ex['optimizer_steps_authorized']==3939 and ex['epoch_traversals_expected']==101
assert ex['bncal_authorized'] is False and ex['development_payload_access_authorized'] is False
assert ex['development_evaluation_authorized'] is False
assert runtime['qa1_lock']['run_key']=='LSQ_foldC_seed0'
assert runtime['qa1_lock']['configuration_only'] is False
scqr=runtime['model']['cranial_scqr']
assert scqr['variant']=='Q0' and scqr['query_conditioning_enabled'] is True
assert scqr['auxiliary_loss_weight']==0.8912909312609397
assert socket.gethostname()==r['hostname'] and pwd.getpwuid(os.getuid()).pw_name==r['user']
assert sha(Path(r['python_executable']).resolve())==r['python_binary_sha256']
bindings=list(q['implementation_bindings'])
p=q['prerequisite_bindings']
bindings += [p[k] for k in ('formal_config_protocol','post_implementation_p3','lambda_lock','calibration_review')]
bindings += [p['zero_update_preflight']['execution_authorization_receipt'],p['zero_update_preflight']['preflight_receipt']]
bindings += [{'path':q['model_scope']['static_template'],'sha256':q['model_scope']['static_template_sha256']},
             {'path':q['data_scope']['train_allowlist'],'sha256':q['data_scope']['train_allowlist_sha256']}]
bindings.append(q['data_scope']['development_allowlist_metadata_only'])
for binding in bindings:
    path=root/binding['path']
    assert sha(path)==binding['sha256'],str(path)
    if 'bytes' in binding: assert path.stat().st_size==binding['bytes']
    if 'required_status' in binding: assert json.loads(path.read_text())['status']==binding['required_status']
    if path.suffix=='.py': ast.parse(path.read_text())
rows=subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,memory.total,memory.used,utilization.gpu,compute_mode','--format=csv,noheader,nounits'],text=True).strip().splitlines()
assert len(rows)==1
gpu=[v.strip() for v in rows[0].split(',')]
assert gpu[:2]==[r['gpu_name'],r['gpu_uuid']]
assert int(gpu[2])-int(gpu[3])>=22000 and int(gpu[4])==0 and gpu[5]==r['gpu_compute_mode']
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
disk=os.statvfs('/home/jovyan')
assert disk.f_bavail*disk.f_frsize>=8*1024**3
assert not (root/fixed['tfboard_output']).exists()
# Compare the full YAML mapping against the only authorized changes.
expected=yaml.safe_load((root/q['model_scope']['static_template']).read_text())
expected['qa1_lock']['configuration_only']=False
expected_ex=dict(q['runtime_config_materialization_only_after_explicit_authorization']['cranial_scqr_execution'])
expected_ex['training_request_sha256']=sha(request_path)
expected_ex['authorization_receipt_sha256']=sha(receipt_path)
expected['cranial_scqr_execution']=expected_ex
assert runtime==expected
for key,value in q['authorization_receipt_schema_only_after_explicit_authorization'].items():
    if key!='training_request': assert a[key]==value,key
assert a['training_request']['path']==str(request_path.relative_to(root))
assert (root/fixed['authorization_receipt_sha256_sidecar']).read_text().split()[0]==sha(receipt_path)
manifest=Path(q['data_scope']['manifest'])
assert manifest.stat().st_size==q['data_scope']['manifest_bytes_from_parent_audit']
assert sha(manifest)==q['data_scope']['manifest_sha256_from_parent_audit']
assert (root/'data/SkullBreakPC_out8192').resolve()==manifest.parent
for key in ('experiment_output','tfboard_output','exit_file'):
    path=root/fixed[key]; assert not path.exists() and not path.is_symlink(),str(path)
if validation_only:
    for key in ('master_output','launcher_log','pid_file'):
        path=root/fixed[key]; assert not path.exists() and not path.is_symlink(),str(path)
sessions=subprocess.run(['tmux','list-sessions'],capture_output=True,text=True)
if validation_only:
    assert sessions.returncode==1 and not sessions.stdout.strip()
else:
    assert sessions.returncode==0 and [line.split(':',1)[0] for line in sessions.stdout.splitlines()]==[fixed['tmux_session']]
for line in subprocess.check_output(['ps','-eo','pid,args'],text=True).splitlines():
    assert not re.search(r'(?:^|\s)(?:\S*/)?(?:python(?:3(?:\.\d+)?)?|torchrun)\s.*(?:main\.py|run_cranial_scqr|preflight)',line),line
assert 'torch' not in sys.modules
if validation_only:
    print('[validation-only] PASS_NO_MODEL_NO_DATASET_NO_CUDA_NO_OUTPUT_WRITES',flush=True)
    sys.exit(0)

env=dict(os.environ)
env.update(CUDA_VISIBLE_DEVICES='0',CUBLAS_WORKSPACE_CONFIG=':4096:8',NVIDIA_TF32_OVERRIDE='0',PYTHONDONTWRITEBYTECODE='1')
observed={'status':'LAUNCH_READY','checked_at_utc':datetime.now(timezone.utc).isoformat(),
          'hostname':socket.gethostname(),'gpu_uuid':gpu[1],'gpu_memory_used_mib':int(gpu[3]),
          'request_sha256':'f10bf07f68ccc16bdfdb4d5a85a700f7d5cae78f62b2659c7907a15cb8a1e559','authorization_receipt_sha256':'fb7efc11e733ca52f4dd2c8ba7acbf874797eace9bc25263819ae18d5732145d',
          'runtime_config_sha256':'4002ca2c68d604f9e9add924cf961995538e00c0bb7050b3b57e6c59a31cc3fd','optimizer_steps_before_launch':0,
          'bncal_authorized':False,'development_evaluation_authorized':False}
(master/'prelaunch_environment.json').write_text(json.dumps(observed,indent=2,sort_keys=True)+'\n')
command=q['fixed_training_command_only_after_explicit_authorization']
print('[stage] launching exactly once: '+repr(command),flush=True)
started=time.monotonic()
child=subprocess.Popen(command,cwd=root,env=env,start_new_session=True)
state_path=root/fixed['experiment_output']/fixed['execution_state']
failure=None
try:
    while child.poll() is None:
        if time.monotonic()-started>r['maximum_walltime_hours']*3600:
            failure='maximum_walltime_exceeded'; break
        if state_path.exists():
            state=json.loads(state_path.read_text())
            if state.get('peak_allocated_bytes',0)>r['maximum_peak_allocated_gib']*1024**3:
                failure='peak_allocated_budget_exceeded'; break
            if state.get('optimizer_steps',0)>3939 or state.get('model_updates',0)>3939:
                failure='step_budget_exceeded'; break
            if state.get('development_payload_accessed') or state.get('development_dataloader_constructed') or state.get('bncal_updates',0):
                failure='forbidden_stage_or_data_access'; break
        # Inspect text logs for nonfinite losses, without loading tensors/checkpoints.
        experiment=root/fixed['experiment_output']
        for log in experiment.glob('*.log'):
            with log.open('rb') as f:
                f.seek(max(0,log.stat().st_size-65536)); tail=f.read().decode('utf-8',errors='replace')
            if re.search(r'(?i)(?:loss[^\n]{0,100}\b(?:nan|inf)\b|\b(?:nan|inf)\b[^\n]{0,100}loss)',tail):
                failure='nonfinite_loss'; break
        if failure: break
        time.sleep(2)
    if failure:
        raise RuntimeError(failure)
    code=child.wait()
    if code!=0:
        print('[failed] training exit code '+str(code),flush=True)
        sys.exit(code if code>0 else 128-code)
except BaseException:
    if child.poll() is None:
        os.killpg(child.pid,signal.SIGTERM)
        try: child.wait(timeout=20)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL); child.wait()
    raise
state=json.loads(state_path.read_text())
assert state['status']=='training_complete_pending_separate_bncal_authorization'
assert state['optimizer_steps']==state['model_updates']==3939
assert state['epoch_traversals_completed']==101
assert state['development_dataloader_constructed'] is False and state['development_payload_accessed'] is False
assert state['bncal_authorized'] is False and state['bncal_updates']==0
assert state['peak_allocated_bytes']<=20*1024**3
for field in ('numerical_policy','numerical_policy_at_completion'):
    policy=state[field]
    assert policy['deterministic_algorithms'] is True and policy['deterministic_warn_only'] is False
    assert policy['cuda_matmul_allow_tf32'] is False and policy['cudnn_allow_tf32'] is False
for field in ('numerical_policy','numerical_policy_at_completion'):
    policy=state[field]
    for key in ('deterministic_algorithms','deterministic_warn_only','cuda_matmul_allow_tf32','cudnn_allow_tf32','cudnn_deterministic','cudnn_benchmark','cublas_workspace_config'):
        assert policy[key]==q['numeric_policy'][key],key
checkpoint=root/fixed['experiment_output']/'ckpt-last.pth'
assert checkpoint.is_file() and state['checkpoint_sha256']==sha(checkpoint)
completion={'status':'TRAINING_PASS_PENDING_SEPARATE_BNCAL_AUTHORIZATION','run_key':'LSQ_foldC_seed0',
            'finished_at_utc':datetime.now(timezone.utc).isoformat(),'optimizer_steps':3939,'model_updates':3939,
            'epoch_traversals':101,'training_checkpoint_sha256':sha(checkpoint),'training_state_sha256':sha(state_path),
            'runtime_config_sha256':sha(runtime_path),'development_payload_accessed':False,'bncal_authorized':False,
            'bncal_runs':0,'automatic_next_run_authorized':False}
(master/'training_completion_receipt.json').write_text(json.dumps(completion,indent=2,sort_keys=True)+'\n')
print('[done] TRAINING_PASS_PENDING_SEPARATE_BNCAL_AUTHORIZATION',flush=True)
PY
