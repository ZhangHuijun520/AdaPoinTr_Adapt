#!/usr/bin/env bash
set -Eeuo pipefail

readonly ROOT="/home/jovyan/adapointr_work/PoinTr"
readonly PYTHON="/opt/conda/envs/adapointr-mamba/bin/python"
readonly REQUEST="$ROOT/docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_b0_foldc_seed0_bncal_execution_authorization_request_v2.json"
readonly SUPERSEDED_REQUEST="$ROOT/docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_b0_foldc_seed0_bncal_execution_authorization_request_v1.json"
readonly RECEIPT="$ROOT/logs/cranial_scqr_v12_qa1/qa1_bncal_authorization/cranial_scqr_v12_qa1_B0_foldC_seed0_bncal_execution_authorization_receipt_v2_20260929T151244Z.json"
readonly RUNTIME="$ROOT/cfgs/SkullBreak_models/cranial_scqr_v12_qa1_bncal_authorized_v2/CranialSCQRV12QA1_B0_foldC_seed0.yaml"
readonly RUN_ID="cranial_scqr_v12_qa1_B0_foldC_seed0_bncal_v2_20260929T151244Z"
readonly MASTER="$ROOT/logs/cranial_scqr_v12_qa1/qa1_bncal/$RUN_ID"
readonly LAUNCHER_LOG="$ROOT/logs/cranial_scqr_v12_qa1/qa1_bncal/$RUN_ID.launcher.log"
readonly PID_FILE="$ROOT/logs/cranial_scqr_v12_qa1/qa1_bncal/$RUN_ID.pid"
readonly EXIT_FILE="$ROOT/logs/cranial_scqr_v12_qa1/qa1_bncal/$RUN_ID.exit_code"
readonly EXPERIMENT="$ROOT/experiments/CranialSCQRV12QA1_B0_foldC_seed0/cranial_scqr_v12_qa1_training_authorized_v1/cranial_scqr_v12_qa1_B0_foldC_seed0_v1_20260929T100300Z"
readonly OUTPUT_CHECKPOINT="$EXPERIMENT/ckpt-last-bncal.pth"
readonly OUTPUT_RECEIPT="$EXPERIMENT/v12_qa1_bncal_receipt.json"
readonly OUTPUT_SIDECAR="$EXPERIMENT/v12_qa1_bncal_files.sha256"
readonly EXPECTED_HOSTNAME="shu-common-25721452-notebook-6jo7wh-0"
readonly EXPECTED_GPU_NAME="NVIDIA GeForce RTX 4090 D"
readonly EXPECTED_GPU_UUID="GPU-34a1b996-2bd7-88e6-9dca-164b718caea6"
readonly EXPECTED_PYTHON_SHA256="01b4275dc374dcae51d245bda004daad6d7882d3f5de7f9852567bb7ab83180d"

cd "$ROOT"

if [[ -e "$LAUNCHER_LOG" ]]; then
  echo "[blocked] refusing to reuse launcher log: $LAUNCHER_LOG" >&2
  exit 73
fi
exec >"$LAUNCHER_LOG" 2>&1

record_exit() {
  local status="$?"
  set +e
  printf '%s\n' "$status" > "$EXIT_FILE"
  if [[ -d "$MASTER" ]]; then
    date -u +%Y-%m-%dT%H:%M:%SZ > "$MASTER/finished_at_utc.txt"
  fi
  trap - EXIT
  exit "$status"
}
trap record_exit EXIT

if [[ "$(hostname)" != "$EXPECTED_HOSTNAME" ]]; then
  echo "[blocked] hostname differs from authorization" >&2
  exit 69
fi
if [[ "$(id -un)" != "jovyan" ]]; then
  echo "[blocked] user differs from authorization" >&2
  exit 69
fi
if [[ "$(sha256sum "$(readlink -f "$PYTHON")" | awk '{print $1}')" != "$EXPECTED_PYTHON_SHA256" ]]; then
  echo "[blocked] Python binary differs from authorization" >&2
  exit 69
fi

echo "d1ad1427a7876f7a2ea385752163acefda5287e2a13adb22224e3f466292139a  $REQUEST" | sha256sum -c -
echo "edc85f6cf2aebcde6cf071c1fd0bb088ffeecf1fd8fc9f589aec58e228c55df8  $SUPERSEDED_REQUEST" | sha256sum -c -
echo "02b567b15a632b3079aeff2e528abc0b279935fcfe74b158f44ab74ecfe32afd  $RECEIPT" | sha256sum -c -
echo "27d6ca5a9d3c93ee72a507df8226123a105ee6f04ee6b958cd3d484ed7709a16  $RUNTIME" | sha256sum -c -
echo "8c5ff74b4ad73105b0a45d36e9590b2659d28ebc60400b5bae0d84752a68f514  docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_formal_config_protocol_v1.json" | sha256sum -c -
echo "a13a1cedf47c25ff430dcbc09888fa0be11f849f0e49dd07fae74605449fe123  docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_bncal_guard_implementation_protocol_v2.json" | sha256sum -c -
echo "c85ce623bb99f7031e3aa50f2226b77d77d679939dc578057d66d3ebc40dc447  docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_bncal_guard_implementation_authorization_receipt_v2.json" | sha256sum -c -
echo "5d5a8226c5be17a5c05aed3d73dd827d46f0dd629b8b5f29ef78d0ae2231f1d4  docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_bncal_guard_post_implementation_p3_receipt_v2.json" | sha256sum -c -
echo "d9a9210c46fbfd8f7f601976dc28bedcdbf9abe7c2f93578e2d5a4fcd45d6fb7  tools/run_cranial_scqr_v12_qa1_bncal.py" | sha256sum -c -
echo "49fffcfccb2c97637c16300ff9be2f8f7dfdd726eb5d37d587ce8a46f3bd090a  tools/test_cranial_scqr_v12_qa1_bncal_contract.py" | sha256sum -c -
echo "c6e4c4a67f6ebf684be618cec7eb9568d775cfb03205773fc901883516939102  tools/run_cranial_scqr_v11_l4_bncal.py" | sha256sum -c -
echo "e4731999fd41a3e8f73077860e0c2ec95d18bea71fee55dcb31ff4154ae58342  tools/runner.py" | sha256sum -c -
echo "62a743c4c2143b77b0f1656c59d0482563976440d841f04bae995017dbf7588f  models/AdaPoinTr.py" | sha256sum -c -
echo "5c4c17c81f8a64c21bb239933a438b98c98f0ee587820dd1789f616f9cbd7fe2  datasets/SkullBreakDataset.py" | sha256sum -c -
echo "702a943d20253e23147afcc5aa6c294bbfa1c9d1c8c986b7d8f61c84fcba0639  cfgs/SkullBreak_models/cranial_scqr_v12_qa1_training_authorized_v1/CranialSCQRV12QA1_B0_foldC_seed0.yaml" | sha256sum -c -
echo "72df4d4f4d6909171671f45883736020bed1f02e661ef5d97beada6be3669bc2  $EXPERIMENT/v12_qa1_training_execution_state.json" | sha256sum -c -
echo "79cfaaed7393b8a387b48c8e767940bd4aaa54acb5c5c43d87eb259ae66913fb  logs/cranial_scqr_v12_qa1/qa1_training/cranial_scqr_v12_qa1_B0_foldC_seed0_v1_20260929T100300Z/training_completion_receipt.json" | sha256sum -c -
echo "282f07942d680b6e652e5e1acf0270ee389d531674cf0ce7189d2300acfaa89c  $EXPERIMENT/ckpt-last.pth" | sha256sum -c -
echo "3c5883d1f582b90533ffed3ae61b1bbe8b88c39b75f40faddf25b63d8f93836d  logs/skullbreak_mamba_v12_development/protocol_v1/foldC_train_case_ids.txt" | sha256sum -c -

actual_gpu_name="$(nvidia-smi --query-gpu=name --format=csv,noheader | sed -n '1p')"
actual_gpu_uuid="$(nvidia-smi --query-gpu=uuid --format=csv,noheader | sed -n '1p')"
gpu_count="$(nvidia-smi --query-gpu=uuid --format=csv,noheader | wc -l)"
read -r gpu_used gpu_total < <(nvidia-smi --query-gpu=memory.used,memory.total --format=csv,noheader,nounits | tr -d ',' | awk 'NR==1 {print $1, $2}')
gpu_free="$((gpu_total - gpu_used))"
disk_free_kib="$(df -Pk /home/jovyan | awk 'NR==2 {print $4}')"
if [[ "$gpu_count" -ne 1 || "$actual_gpu_name" != "$EXPECTED_GPU_NAME" || "$actual_gpu_uuid" != "$EXPECTED_GPU_UUID" ]]; then
  echo "[blocked] GPU identity differs from authorization" >&2
  exit 69
fi
if nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits | grep -Eq '[0-9]'; then
  echo "[blocked] a GPU compute process already exists" >&2
  exit 70
fi
if [[ "$gpu_free" -lt 22000 ]]; then
  echo "[blocked] insufficient free GPU memory: ${gpu_free} MiB" >&2
  exit 71
fi
if [[ "$disk_free_kib" -lt 8388608 ]]; then
  echo "[blocked] insufficient free disk: ${disk_free_kib} KiB" >&2
  exit 72
fi

for target in "$MASTER" "$PID_FILE" "$EXIT_FILE" "$OUTPUT_CHECKPOINT" "$OUTPUT_RECEIPT" "$OUTPUT_SIDECAR"; do
  if [[ -e "$target" ]]; then
    echo "[blocked] refusing to reuse output path: $target" >&2
    exit 73
  fi
done

mkdir -p "$MASTER"
printf '%s\n' "$$" > "$PID_FILE"
date -u +%Y-%m-%dT%H:%M:%SZ > "$MASTER/started_at_utc.txt"

cat > "$MASTER/prelaunch_environment.json" <<EOF
{
  "status": "LAUNCH_READY",
  "hostname": "$(hostname)",
  "gpu_name": "$actual_gpu_name",
  "gpu_uuid": "$actual_gpu_uuid",
  "gpu_memory_used_mib": $gpu_used,
  "gpu_memory_total_mib": $gpu_total,
  "disk_free_kib": $disk_free_kib,
  "request_sha256": "d1ad1427a7876f7a2ea385752163acefda5287e2a13adb22224e3f466292139a",
  "authorization_receipt_sha256": "02b567b15a632b3079aeff2e528abc0b279935fcfe74b158f44ab74ecfe32afd",
  "runtime_config_sha256": "27d6ca5a9d3c93ee72a507df8226123a105ee6f04ee6b958cd3d484ed7709a16",
  "training_authorized": false,
  "optimizer_steps_authorized": 0,
  "bncal_runs_authorized": 1,
  "development_payload_access_authorized": false,
  "development_evaluation_authorized": false
}
EOF

echo "[stage] BNCal start $(date -u +%Y-%m-%dT%H:%M:%SZ)"
env \
  CUDA_VISIBLE_DEVICES=0 \
  CUBLAS_WORKSPACE_CONFIG=:4096:8 \
  PYTHONDONTWRITEBYTECODE=1 \
  "$PYTHON" -B -u tools/run_cranial_scqr_v12_qa1_bncal.py \
    --config cfgs/SkullBreak_models/cranial_scqr_v12_qa1_bncal_authorized_v2/CranialSCQRV12QA1_B0_foldC_seed0.yaml \
    --experiment_dir experiments/CranialSCQRV12QA1_B0_foldC_seed0/cranial_scqr_v12_qa1_training_authorized_v1/cranial_scqr_v12_qa1_B0_foldC_seed0_v1_20260929T100300Z \
    --batch_size 8 \
    --num_workers 0 \
    --seed 0
echo "[stage] BNCal execution complete $(date -u +%Y-%m-%dT%H:%M:%SZ)"
