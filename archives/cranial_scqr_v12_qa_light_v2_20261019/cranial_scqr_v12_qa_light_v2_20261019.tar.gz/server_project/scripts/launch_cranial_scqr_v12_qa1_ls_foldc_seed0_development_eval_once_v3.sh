#!/usr/bin/env bash
set -Eeuo pipefail
cd /home/jovyan/adapointr_work/PoinTr
export PYTHONDONTWRITEBYTECODE=1 CUBLAS_WORKSPACE_CONFIG=:4096:8
validate_runtime() {
  /opt/conda/envs/adapointr-mamba/bin/python -B - <<'PY'
import argparse, hashlib, json, os, pathlib, shutil, socket, subprocess, sys
root = pathlib.Path('/home/jovyan/adapointr_work/PoinTr')
assert pathlib.Path.cwd().resolve() == root
sys.path.insert(0, str(root / 'tools'))
import run_cranial_scqr_v12_qa1_development_eval as evaluator
request_path = root / 'docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_ls_foldc_seed0_development_evaluation_execution_authorization_request_v3.json'
evaluator.verify_file(request_path, 'ac5255ad213cb72e9c565cc7e3db4d2bcfe5e53073f0e1df200fa531d0f1959c', 28499)
q = evaluator.load_json(request_path)
evaluator.validate_request_contract(q)
bindings = [q['superseded_scope_freeze_request'], q['superseded_v2_non_executable_request'], *q['protocol_bindings'].values(), q['post_implementation_p3'], *q['source_training_freeze'].values(), *q['source_bncal_freeze'].values(), *q['implementation_bindings']]
for item in bindings:
    p = evaluator.resolve_under(root, item['path'])
    evaluator.verify_file(p, item['sha256'], item['bytes'])
    if 'required_status' in item:
        assert evaluator.load_json(p)['status'] == item['required_status'], item['path']
a = evaluator.parse_args(json.loads(r'''["--execution-request","docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_ls_foldc_seed0_development_evaluation_execution_authorization_request_v3.json","--execution-request-sha256","ac5255ad213cb72e9c565cc7e3db4d2bcfe5e53073f0e1df200fa531d0f1959c","--authorization-receipt","logs/cranial_scqr_v12_qa1/qa1_development_evaluation_authorization/cranial_scqr_v12_qa1_LS_foldC_seed0_development_evaluation_execution_authorization_receipt_v3_20261009T031727Z.json","--authorization-receipt-sha256","a826a443a8df235ed8543bf2e911520dd4bef4b7506f50205f071012b3d85bcf","--runtime-config","cfgs/SkullBreak_models/cranial_scqr_v12_qa1_development_eval_authorized_v3/CranialSCQRV12QA1_LS_foldC_seed0.yaml","--runtime-config-sha256","e14a1564eab9b4c81f8b1087a8fce4b438075075ecfea357efad64e849a4e89f","--manifest","/home/jovyan/datasets/SkullBreakPC_out8192/manifest.jsonl","--manifest-sha256","f1f8cae47ed7d5529dc2ca244179cedddbc039981cdc0ff24b25a5c81ad30538","--data-root","/home/jovyan/datasets/SkullBreakPC_out8192","--output-dir","logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LS_foldC_seed0_development_eval_v3_20261009T031727Z","--device","cuda:0"]'''))
for name in ('execution_request','authorization_receipt','runtime_config','manifest','data_root','output_dir'):
    setattr(a, name, getattr(a, name).resolve())
assert a.output_dir == root / q['fixed_future_execution']['master_output']
assert a.data_root == pathlib.Path(q['data_scope']['data_root'])
assert a.manifest == pathlib.Path(q['data_scope']['manifest'])
assert a.manifest_sha256 == q['data_scope']['manifest_sha256']
evaluator.preflight(a)
resource = q['resource_binding']
assert socket.gethostname() == resource['hostname']
assert os.getuid() == 1000
evaluator.verify_file(pathlib.Path(resource['python_realpath']),resource['python_binary_sha256'])
rows = subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,memory.total,memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True).strip().splitlines()
assert len(rows) == 1
name,uuid,total,used,util = [v.strip() for v in rows[0].split(',')]
assert name == resource['gpu_name'] and uuid == resource['gpu_uuid']
assert int(total)-int(used) >= resource['minimum_free_gpu_memory_mib_at_launch']
assert int(util) == 0
assert shutil.disk_usage(root).free >= resource['minimum_free_disk_gib_at_launch'] * 1024**3
assert not a.output_dir.exists()
assert os.environ['CUBLAS_WORKSPACE_CONFIG'] == ':4096:8'
assert 'torch' not in sys.modules
print('[validation-only] PASS', flush=True)
PY
}
if [[ "${1:-}" == "--validate-runtime-only" ]]; then
  validate_runtime
  exit 0
fi
[[ $# -eq 0 ]]
[[ ! -e 'logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LS_foldC_seed0_development_eval_v3_20261009T031727Z' && ! -e 'logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LS_foldC_seed0_development_eval_v3_20261009T031727Z.launcher.log' && ! -e 'logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LS_foldC_seed0_development_eval_v3_20261009T031727Z.pid' && ! -e 'logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LS_foldC_seed0_development_eval_v3_20261009T031727Z.exit_code' ]]
mkdir -p 'logs/cranial_scqr_v12_qa1/qa1_development_evaluation'
[[ -d 'logs/cranial_scqr_v12_qa1/qa1_development_evaluation' ]]
[[ "$(stat -c %U 'logs/cranial_scqr_v12_qa1/qa1_development_evaluation')" == jovyan ]]
set -o noclobber
exec > 'logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LS_foldC_seed0_development_eval_v3_20261009T031727Z.launcher.log' 2>&1
trap 'status=$?; trap - EXIT; printf "%s\n" "$status" > "logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LS_foldC_seed0_development_eval_v3_20261009T031727Z.exit_code"; exit "$status"' EXIT
printf '%s\n' "$$" > 'logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LS_foldC_seed0_development_eval_v3_20261009T031727Z.pid'
printf '[stage] evaluation start %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
validate_runtime
timeout --signal=TERM --kill-after=30s 120m 'env' 'CUDA_VISIBLE_DEVICES=0' 'CUBLAS_WORKSPACE_CONFIG=:4096:8' 'PYTHONDONTWRITEBYTECODE=1' '/opt/conda/envs/adapointr-mamba/bin/python' '-B' '-u' 'tools/run_cranial_scqr_v12_qa1_development_eval.py' '--execution-request' 'docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_ls_foldc_seed0_development_evaluation_execution_authorization_request_v3.json' '--execution-request-sha256' 'ac5255ad213cb72e9c565cc7e3db4d2bcfe5e53073f0e1df200fa531d0f1959c' '--authorization-receipt' 'logs/cranial_scqr_v12_qa1/qa1_development_evaluation_authorization/cranial_scqr_v12_qa1_LS_foldC_seed0_development_evaluation_execution_authorization_receipt_v3_20261009T031727Z.json' '--authorization-receipt-sha256' 'a826a443a8df235ed8543bf2e911520dd4bef4b7506f50205f071012b3d85bcf' '--runtime-config' 'cfgs/SkullBreak_models/cranial_scqr_v12_qa1_development_eval_authorized_v3/CranialSCQRV12QA1_LS_foldC_seed0.yaml' '--runtime-config-sha256' 'e14a1564eab9b4c81f8b1087a8fce4b438075075ecfea357efad64e849a4e89f' '--manifest' '/home/jovyan/datasets/SkullBreakPC_out8192/manifest.jsonl' '--manifest-sha256' 'f1f8cae47ed7d5529dc2ca244179cedddbc039981cdc0ff24b25a5c81ad30538' '--data-root' '/home/jovyan/datasets/SkullBreakPC_out8192' '--output-dir' 'logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LS_foldC_seed0_development_eval_v3_20261009T031727Z' '--device' 'cuda:0'
/opt/conda/envs/adapointr-mamba/bin/python -B - <<'PY'
import hashlib,json,pathlib
out = pathlib.Path('logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LS_foldC_seed0_development_eval_v3_20261009T031727Z')
receipt = json.loads((out/'evaluation_execution_receipt.json').read_text())
assert receipt['status'] == 'PASS_DESCRIPTIVE_SINGLE_RUN_ONLY'
assert receipt['counters']['checkpoint_loads'] == 1
assert receipt['counters']['model_case_forward_calls'] == 105
assert receipt['counters']['npz_open_events'] == 105
assert receipt['model_parameters_and_buffers_unchanged'] is True
assert receipt['numerical_policy_before'] == receipt['numerical_policy_after']
text = 'LS_foldC_seed0 development evaluation：PASS（单运行描述性结果）\n105 cases；21 source skulls；105 forwards；1 checkpoint load。\n参数与 buffer 不变；deterministic=true；TF32=false。\n未进行正式 QA-1 gate、候选比较、训练或 BNCal；不授权后续运行。\n'
with (out/'evaluation_result_report_zh.md').open('x',encoding='utf-8') as stream: stream.write(text)
paths=sorted(p for p in out.iterdir() if p.is_file() and p.name!='files.sha256')
with (out/'files.sha256').open('x',encoding='utf-8') as stream:
    for p in paths: stream.write(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n')
print('[freeze] files.sha256 created',flush=True)
PY
(cd 'logs/cranial_scqr_v12_qa1/qa1_development_evaluation/cranial_scqr_v12_qa1_LS_foldC_seed0_development_eval_v3_20261009T031727Z' && sha256sum -c files.sha256)
printf '[done] LS_foldC_seed0 evaluation PASS %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
