#!/usr/bin/env bash
set -Eeuo pipefail
readonly ROOT='/home/jovyan/adapointr_work/PoinTr'
readonly PYTHON='/opt/conda/envs/adapointr-mamba/bin/python'
readonly REQUEST='/home/jovyan/adapointr_work/PoinTr/docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_ls_foldd_seed0_bncal_execution_authorization_request_v1.json'
readonly RECEIPT='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_bncal_authorization/cranial_scqr_v12_qa1_LS_foldD_seed0_bncal_execution_authorization_receipt_v1_20261009T061039Z.json'
readonly RUNTIME='/home/jovyan/adapointr_work/PoinTr/cfgs/SkullBreak_models/cranial_scqr_v12_qa1_bncal_authorized_v5/CranialSCQRV12QA1_LS_foldD_seed0.yaml'
readonly MASTER='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_bncal/cranial_scqr_v12_qa1_LS_foldD_seed0_bncal_v1_20261009T061039Z'
readonly LOG='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_bncal/cranial_scqr_v12_qa1_LS_foldD_seed0_bncal_v1_20261009T061039Z.launcher.log'
readonly PID_FILE='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_bncal/cranial_scqr_v12_qa1_LS_foldD_seed0_bncal_v1_20261009T061039Z.pid'
readonly EXIT_FILE='/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_bncal/cranial_scqr_v12_qa1_LS_foldD_seed0_bncal_v1_20261009T061039Z.exit_code'
cd "$ROOT"
export PYTHONDONTWRITEBYTECODE=1
validate_runtime() {
 "$PYTHON" -B - "$RUNTIME" '6e40d91b9022633b62fdfca87848553971877518768dcecca64677409353358e' 'd9602317c01ea0d2382aabac9fe7d481f95df8724297fc3f8addaa1f9584c2e4' <<'PY'
import hashlib,json,os,pwd,socket,subprocess,sys
from pathlib import Path
import yaml
root=Path('/home/jovyan/adapointr_work/PoinTr')
rt=Path(sys.argv[1]);request_hash=sys.argv[2];receipt_hash=sys.argv[3]
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
assert sha(root/'docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_ls_foldd_seed0_bncal_execution_authorization_request_v1.json')==request_hash
q=json.loads(Path('/home/jovyan/adapointr_work/PoinTr/docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_ls_foldd_seed0_bncal_execution_authorization_request_v1.json').read_text());a=json.loads(Path('/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_bncal_authorization/cranial_scqr_v12_qa1_LS_foldD_seed0_bncal_execution_authorization_receipt_v1_20261009T061039Z.json').read_text());cfg=yaml.safe_load(rt.read_text());ex=cfg['cranial_scqr_execution']
assert sha(rt)=='d174845ff436073bb7d5d48f3c12ba1636189fd84ba8e7f6f83aa16bb48b1e34' and sha(Path('/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_qa1/qa1_bncal_authorization/cranial_scqr_v12_qa1_LS_foldD_seed0_bncal_execution_authorization_receipt_v1_20261009T061039Z.json'))==receipt_hash
assert q['status']=='AWAITING_EXPLICIT_USER_AUTHORIZATION' and q['execution_authorized'] is False
assert q['requested_run_keys']==a['authorized_run_keys']==['LS_foldD_seed0']
assert a['status']=='AUTHORIZED' and a['execution_authorized'] is True
assert a['bncal_request']=={'path':ex['bncal_execution_request'],'sha256':request_hash}
assert 'bncal_runtime_config_sha256' not in a
assert ex['bncal_execution_request_sha256']==request_hash and ex['bncal_authorization_receipt_sha256']==receipt_hash
assert ex['bncal_authorization_receipt']==q['fixed_future_execution']['authorization_receipt']
assert ex['stage']=='V12_QA1_bncal' and ex['training_authorized'] is False and ex['optimizer_steps_authorized']==0
assert ex['bncal_authorized'] is True and ex['bncal_runs_authorized']==1
assert ex['bncal_cases_expected']==315 and ex['bncal_batches_expected']==40
for key in ('development_payload_access_authorized','development_evaluation_authorized','resume_authorized','automatic_rerun_authorized','automatic_next_run_authorized'):assert ex[key] is False
assert cfg['qa1_lock']['run_key']=='LS_foldD_seed0' and cfg['qa1_lock']['candidate']=='LS' and cfg['qa1_lock']['fold']=='D' and cfg['qa1_lock']['seed']==0
bindings=q['implementation_bindings']+list(q['prerequisite_bindings'].values())+[q['source_training_freeze'][k] for k in ('runtime_config','training_state','training_completion_receipt','checkpoint')]
bindings += [{'path':q['data_scope']['train_allowlist'],'sha256':q['data_scope']['train_allowlist_sha256']}]
for b in bindings:
 p=root/b['path'];assert sha(p)==b['sha256'],str(p)
 if 'bytes' in b:assert p.stat().st_size==b['bytes']
state=json.loads((root/q['source_training_freeze']['training_state']['path']).read_text())
assert state['optimizer_steps']==state['model_updates']==3939 and state['epoch_traversals_completed']==101
assert state['bncal_updates']==0 and state['development_payload_accessed'] is False
for key in ('source_training_checkpoint_sha256','source_training_state_sha256','source_training_completion_receipt_sha256','source_training_runtime_config_sha256'):
 field={'source_training_checkpoint_sha256':'checkpoint','source_training_state_sha256':'training_state','source_training_completion_receipt_sha256':'training_completion_receipt','source_training_runtime_config_sha256':'runtime_config'}[key]
 assert ex[key]==q['source_training_freeze'][field]['sha256']
r=q['resource_binding'];assert socket.gethostname()==r['hostname'] and pwd.getpwuid(os.getuid()).pw_name==r['user']
assert sha(Path(r['python_executable']).resolve())==r['python_binary_sha256']
rows=subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,memory.total,memory.used','--format=csv,noheader,nounits'],text=True).strip().splitlines();assert len(rows)==1
gpu=[v.strip() for v in rows[0].split(',')];assert gpu[:2]==[r['gpu_name'],r['gpu_uuid']] and int(gpu[2])-int(gpu[3])>=22000
assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
disk=os.statvfs('/home/jovyan');assert disk.f_bavail*disk.f_frsize>=8*1024**3
experiment=root/q['fixed_future_execution']['experiment_output']
for name in ('ckpt-last-bncal.pth','ckpt-last-bncal.pth.tmp','v12_qa1_bncal_receipt.json','v12_qa1_bncal_files.sha256'):assert not (experiment/name).exists()
print('[validation-only] PASS',flush=True)
PY
}
if [[ "${1:-}" == '--validate-runtime-only' ]]; then
 validate_runtime
 exit 0
fi
[[ "$#" -eq 0 ]]
for target in "$MASTER" "$LOG" "$PID_FILE" "$EXIT_FILE"; do
 [[ ! -e "$target" ]] || { echo "[blocked] existing single-use path $target" >&2; exit 73; }
done
mkdir -p "$(dirname "$LOG")"
[[ -d "$(dirname "$LOG")" && ! -L "$(dirname "$LOG")" && "$(stat -c '%U' "$(dirname "$LOG")")" == 'jovyan' ]]
set -o noclobber
exec >"$LOG" 2>&1
record_exit() { status="$?"; printf '%s\n' "$status" > "$EXIT_FILE"; }
trap record_exit EXIT
validate_runtime
mkdir "$MASTER"
printf '%s\n' "$$" > "$PID_FILE"
date -u +%Y-%m-%dT%H:%M:%SZ > "$MASTER/started_at_utc.txt"
echo '[stage] exactly one partial-only BNCal'
timeout --signal=TERM --kill-after=20s 1800s env CUDA_VISIBLE_DEVICES=0 CUBLAS_WORKSPACE_CONFIG=:4096:8 NVIDIA_TF32_OVERRIDE=0 PYTHONDONTWRITEBYTECODE=1 /opt/conda/envs/adapointr-mamba/bin/python -B -u tools/run_cranial_scqr_v12_qa1_bncal.py --config cfgs/SkullBreak_models/cranial_scqr_v12_qa1_bncal_authorized_v5/CranialSCQRV12QA1_LS_foldD_seed0.yaml --experiment_dir experiments/CranialSCQRV12QA1_LS_foldD_seed0/cranial_scqr_v12_qa1_training_authorized_v1/cranial_scqr_v12_qa1_LS_foldD_seed0_v1_20261009T040037Z --batch_size 8 --num_workers 0 --seed 0
date -u +%Y-%m-%dT%H:%M:%SZ > "$MASTER/finished_at_utc.txt"
echo '[done] BNCal command exited 0; pending separate post-BNCal freeze audit'
