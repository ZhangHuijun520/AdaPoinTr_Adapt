#!/usr/bin/env bash
set -uo pipefail

if [[ "$#" -ne 6 ]]; then
  echo "usage: $0 PROTOCOL EXECUTION_AUTH OUTPUT_DIR LAUNCH_LOG PID_FILE EXIT_FILE" >&2
  exit 64
fi

readonly PROJECT_ROOT="/home/jovyan/adapointr_work/PoinTr"
readonly PYTHON_BIN="/opt/conda/envs/adapointr-mamba/bin/python"
readonly RUNNER="${PROJECT_ROOT}/tools/run_cranial_scqr_v12_qa1_cd_gradient_calibration.py"
readonly PROTOCOL="$1"
readonly EXECUTION_AUTH="$2"
readonly OUTPUT_DIR="$3"
readonly LAUNCH_LOG="$4"
readonly PID_FILE="$5"
readonly EXIT_FILE="$6"

if [[ ! -f "${PROTOCOL}" || ! -f "${EXECUTION_AUTH}" ]]; then
  echo "protocol and a separately authorized execution file are required" >&2
  exit 66
fi
if [[ -e "${OUTPUT_DIR}" || -e "${LAUNCH_LOG}" || -e "${PID_FILE}" || -e "${EXIT_FILE}" ]]; then
  echo "refusing to reuse a calibration output or sidecar path" >&2
  exit 73
fi

printf '%s\n' "$$" > "${PID_FILE}"
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export PYTHONDONTWRITEBYTECODE=1
export V12_QA1_CD_CALIBRATION_EXECUTION_AUTHORIZED=1

"${PYTHON_BIN}" -B "${RUNNER}" \
  --protocol "${PROTOCOL}" \
  --execution-authorization "${EXECUTION_AUTH}" \
  --output-dir "${OUTPUT_DIR}" \
  > "${LAUNCH_LOG}" 2>&1
status=$?
printf '%s\n' "${status}" > "${EXIT_FILE}"
exit "${status}"
