# Cranial-SCQR v1.2-QA 下一阶段正式实验计划（修订版 v1）

**日期：** 2026-09-21（UTC）  
**计划标识：** `cranial-scqr-v1.2-qa-formal-plan-v1`  
**研究主题：** 基于 AdaPoinTr 的颅骨缺损点云补全、局部接触表示、查询条件化与后续 Query-Space Mamba 机制验证  
**当前状态：** 计划冻结草案；不是任何代码实现、数据读取、preflight、训练、BNCal、推理、确认集评估或删除操作的执行授权  
**适用服务器项目：** `/home/jovyan/adapointr_work/PoinTr`  

---

## 1. 文档目的与执行边界

本计划在 Cranial-SCQR v1.1 Round A、Round A-I、负对照数值诊断和 Q0 反向推理干预均已完成并归档的基础上，规定下一阶段实验的科学问题、模型矩阵、数据边界、统计方法、继续门、停止门、运行预算与授权顺序。

本计划遵循以下原则：

1. 不恢复已判定为 `NO_GO` 的 QC/direct contact log-bias Round B。
2. 不继续扫描 `beta`、temperature、log-bias 强度或其他直接 attention-bias 形式。
3. 先复核 Q0 相对 A1/LS 的信号，再拆分 Local、SCF supervision 与 Query attention。
4. 只有 Query 路径经过新折和新 seed 复核后，才允许提出 Query-Space Mamba 的实施授权。
5. confirmation20 始终保持封存，直到最终结构、权重选择、主指标、护栏和一次性评估协议全部冻结。
6. 每个实现、preflight、训练、BNCal、development 评估和 confirmation 评估阶段均须单独授权；本文件本身不授权其中任何一步。

任何后续请求若与本计划冲突，以用户最新的明确授权和新的版本化协议为准；不得在原文件上事后修改门槛或覆盖结果。

---

## 2. 父证据与来源绑定

### 2.1 本计划的直接父文档

| 文件 | SHA256 |
|---|---|
| 原始后续方案 `Cranial_SCQR_v11_后续实验方向与v12_QA正式计划_2026-09-21.md` | `1a0ebdea58a0a0444bc1325cfbcef5ba22e29e2f7362be85047b9d9d9a4b1299` |
| `l4_round_a_training_protocol_v1.json` | `b7044f4f24e2f0b4a1e38a9d4ca466f2bb8168ffe1a0ad864b3e1c8f1c3f0fe9` |
| `l4_round_a_development_evaluation_protocol_v1.json` | `04077152848c055c76fbc64f4427301af9809e2fda6cd2117d644088bad7e8ae` |
| `cranial_scqr_v11_round_a_q0_reverse_intervention_experiment_report_zh_2026-09-19.md` | `94ca5fd3f2ae829d6db097d5b94f84eefc8d025d27e0b6cb0a19b237b522c011` |

计划实施前必须重新核验这些 SHA256；若漂移，先停止并生成新的父绑定报告。

### 2.2 v1.1 已冻结结论

1. Round A 中 Q0 的 combined RimCover-P95 为 `8.145128 mm`，QC 为 `8.292559 mm`；QC 没有通过相对 Q0 的增量门。
2. QC 同权重下 direct contact bias 的即时空间对齐收益约 `0.00035 mm`，虽有方向性统计证据，但不具实际研究意义。
3. Q0 权重下推理时将 `beta` 从 0 改为 1，combined 差值为 `+0.000271 mm`，95% source-skull cluster-bootstrap CI 为 `[-0.000161,+0.000708] mm`，两折方向相反。
4. Q0 相对 A1 的探索性 RimCover-P95 差值在 Fold A/B 分别约为 `-0.564/-0.793 mm`，combined 约 `-0.678 mm`；42 个 source skull 中约 29 个方向有利于 Q0。
5. 准确表述是：Q0 是值得复核的候选，尚不是经新折和多 seed 确认的 winner；Q0/QC 差异主要表现为训练后权重状态差异，不能归因于推理阶段 direct bias。

---

## 3. 最新文献下的研究定位

### 3.1 不再主张的创新

以下表述不再作为论文核心贡献：

- generic `Local + Global + Mamba`；
- 仅将 xyz/Morton 序列输入单向 Mamba；
- 仅用 Mamba 替换 Transformer encoder；
- 仅加入普通 query cross-attention；
- 直接 contact probability log-bias；
- 普通 symmetry + confidence + progressive refinement；
- 仅凭理论 `O(N)` 复杂度声称实际效率优势。

CompletionMamba、DAPointMamba、FusionMamba、BuildingComSSSM、Mamba-Transformer completion、SymmCompletion、Simba 和 Hyper-PCN 已覆盖上述多个方向。

### 3.2 必须纳入 related work 与强基线审计的直接工作

1. **CompletionMamba**：TIP 2025，local SSM 与 shape-aware Mamba。
2. **DAPointMamba**：AAAI 2026，主要是 domain-adaptive PCC；作为 serialization/topology 风险的近邻证据，不当作与当前单域 cranial query refinement 完全等价的工作。
3. **FusionMamba / BuildingComSSSM / Mamba-Transformer completion**：说明 geometry-aware Mamba、bidirectional modeling、多尺度融合和 Mamba-Transformer hybrid 已高度拥挤。
4. **Hyper-PCN / SymmCompletion / Simba**：说明高阶关系、对称性和渐进 refinement 已有强近邻。
5. **Automatic Skull Reconstruction by Deep Learnable Symmetry Enforcement**：颅骨专用对称先验强基线。
6. **MedPCFM**：2026 年直接在 SkullFix、SkullBreak 和 Mandibular Defect 上研究 PTv3、diffusion 与 flow matching，是本项目必须补入的 medical point-cloud completion 强近邻。
7. **MedPCFM-TED**：2026-09-15 的 cranial implant one-step flow-matching 预印本；须明确其预印本状态，但不能从相关工作中遗漏。
8. **QGGA**：其 query-aware gating 面向图像、文本和点云多模态补全，只能作为 query-aware fusion 的近邻，不视为对当前单模态 local-to-query 路径的直接覆盖。

### 3.3 推荐论文定位

若 LSQ 最终成立：

> 面向颅骨植入体边界恢复的 contact-supervised query refinement；SCF 通过训练期 representation shaping 影响 missing-region query，而非通过推理期 direct contact bias。

若 LQ 成立而 SCF 不成立：

> 面向颅骨边界恢复的 local-geometry query refinement。

只有 Query-Mamba 相对 matched Transformer 和容量对照表现出独立质量或实际效率优势时，才在标题和核心贡献中保留 Mamba。

---

## 4. 数据角色与四折解释

### 4.1 冻结数据角色

| 数据角色 | 规模 | 当前允许用途 | 禁止解释 |
|---|---:|---|---|
| development84 | 84 skull / 420 case | 适应性开发与 source-grouped 四折 OOF | 独立测试或新来源验证 |
| 每一折 | 63 train skull / 315 case；21 dev skull / 105 case | fold-train 训练、fold-dev 评估 | case-level 随机切分 |
| confirmation20 | 20 skull / 100 case | 最终协议冻结后的单次阶段性确认 | 当前开发、门槛选择或失败分析 |
| official test / old monitor | 以既有账本为准 | 仅在未来单独授权的历史 benchmark | 独立未暴露测试 |
| MUG、SkullFix 和其他来源 | 以 source ledger 为准 | 仅在新的独立协议中使用 | 自动并入当前训练或验证 |

### 4.2 Fold C/D 的准确角色

A-D 的 dev skull 集两两互斥，并集为 development84；每个 skull 的五种缺损保持成组。Fold C/D 尚未被用于 SCQR-v1.1 的 dev outcome 观察，因此适合作为新假设的第一站。

但四折训练集互相重叠，C/D dev skull 曾作为 A/B train skull 参与其他折的训练。故 C/D 只能称为：

> `prospectively analyzed internal OOF replication folds`

不得称为独立测试、外部验证或完全未暴露来源。

### 4.3 访问边界

- 训练只允许相应 fold 的 315 个 train case。
- BNCal 只允许同一 fold 的 315 个 train case，partial-only。
- development 评估只允许对应 fold 的 105 个 dev case。
- confirmation20、official test、old monitor、MUG payload 和未授权 SkullFix payload 均保持禁止。
- 任何 NPZ 读取均须由对应阶段的单独授权明确给出。

---

## 5. 科学问题与假设

### H-Q1：Local 路径总体增量

在其他训练条件相同的情况下，`L0-B0` 是否改善 RimCover-P95，同时不损害 implant/final 护栏？

解释边界：该比较是整个 Local 路径的嵌套增量，不是纯粹的单一算子因果效应。

### H-Q2：SCF 的条件作用

在 Local 存在时，SCF supervision 是否分别在无 Query 和有 Query 条件下改善结果？

```text
LS-L0
LSQ-LQ
```

### H-Q3：Query attention 的条件作用

在 Local 存在时，Query attention 是否分别在无 SCF 和有 SCF 条件下改善结果？

```text
LQ-L0
LSQ-LS
```

### H-Q4：SCF × Query interaction

```text
I = (LSQ-LQ) - (LS-L0)
```

若 `I<0`，表示在当前指标定义下存在方向性正交互；只有新 seed 复核后才能将其表述为稳定协同。

### H-M1：Mamba 特有增量

在已确认有效的 Query architecture 上，Query-Space Mamba 是否相对 matched Transformer 和参数匹配非交互对照提供独立质量或端到端效率增益？

---

## 6. 模型矩阵与因果边界

### 6.1 QA 模型

| ID | Local geometry | SCF auxiliary | Query attention | Direct contact bias | 角色 |
|---|---:|---:|---:|---:|---|
| B0 | 0 | 0 | 0 | 0 | 无 Local 的嵌套总体基线 |
| L0 | 1 | 0 | 0 | 0 | Local-only |
| LS | 1 | 1 | 0 | 0 | 等同既有 A1 |
| LQ | 1 | 0 | 1 | 0 | Local + Query |
| LSQ | 1 | 1 | 1 | 0 | 等同既有 Q0 |
| QC | 1 | 1 | 1 | 1 | 冻结负结果；不进入新训练 |

### 6.2 设计名称

本设计不是完整三因素 factorial。正式名称固定为：

> 无 Local 的嵌套基线 B0，加上 Local=1 条件下的 SCF × Query 2×2 因子设计。

### 6.3 初始化与容量控制

1. 同 fold、同 seed 的公共参数必须由相同 RNG 状态初始化，并输出公共参数 initialization hash。
2. 新增模块使用独立 RNG stream，不能因模块创建顺序改变公共主干初值。
3. LQ 与 LSQ 应实例化相同的 SCF head；LQ 通过冻结的 `lambda_scf=0` 阻止 SCF loss 作用，明确记录 head 是否进入 optimizer 以及是否获得梯度。
4. Query attention 的参数量、FLOPs 和显存增量必须报告。
5. 若 Query 效应通过 QA-2，进入 Mamba 前增加 parameter-matched MLP/residual control；若无法匹配，应限制因果表述为“Query block 增量”，不能直接归因于 attention 信息交换。

---

## 7. 冻结指标与统计单位

### 7.1 主指标

```text
rim_gt_rim_to_pred_p95_mm
```

展示名称：`RimCover-P95`，越低越好。

聚合顺序固定为：

```text
每个 case 计算指标
→ 同一 source skull 的五种 defect 等权平均
→ source skull 等权平均
```

禁止将所有 rim 点或所有 case 直接池化后重新计算一个 P95。

### 7.2 护栏指标

- zero-contact count；
- disaster count；
- implant CD-L1；
- final CD-L1；
- final HD95；
- final NSD@1mm；
- 必要的 contact HD95/NSD 与缺损类型分层结果；
- 参数量、FLOPs、端到端延迟和峰值显存仅作为效率指标，不替代几何质量。

### 7.3 不确定性

- bootstrap unit：source skull；
- repeats：10,000；
- bootstrap seed：沿用冻结值 `20260910`；
- 报告 fold-specific point estimate、pooled point estimate 和 95% percentile CI；
- 多 seed 阶段不得把 fold、case、skull 和 seed 当作彼此独立观测；应分别报告 seed 内 source-skull 不确定性和 seed 间波动。

### 7.4 比较层级

QA-1 的唯一主比较：

```text
LSQ - LS
```

只有主比较通过后，才解释关键次比较：

```text
LSQ - B0
```

其他指标和病例分层均为次要或探索性分析，不以结果驱动方式挑选。

---

## 8. 实际意义阈值（SESOI）校准

原 `0.10 mm` 暂时保留为候选资源门，但在查看 QA-1 C/D 结果前必须完成并冻结数值依据。

### 8.1 优先复用已有证据

先只读核验既有 P0 representation audit、metric contract、重复采样或 reference-rim 稳定性材料。若已有材料足以证明 `0.10 mm` 明显高于指标数值与采样不稳定度，则直接冻结：

```text
delta_practical = 0.10 mm
```

### 8.2 材料不足时

必须另行申请最小化的 measurement-stability audit；不得在本计划授权下打开 NPZ。该审计只允许估计指标重复计算、允许的重采样和物理尺度转换所产生的不稳定度，不允许评价候选模型。

定义 `epsilon95` 为预先规定的 source-skull 聚合绝对变化的 95% 分位数，则：

```text
delta_practical = max(0.10 mm, 2 * epsilon95)
```

该公式、audit 方法和最终数值必须在任何 QA-1 dev inference 前冻结。不得看到模型结果后移动阈值。

---

## 9. Stage V12-P0：只读协议锁定

目标：在不读取 NPZ、不加载 checkpoint、不使用 GPU 的条件下，为 QA-1 建立机器可读父绑定。

必须核验：

1. A-D train/dev 清单路径、行数、SHA256 和 source-skull 分组不变量；
2. B0/LS/LSQ 现有 A/B 配置、模型 switch、训练参数和 evaluator identity；
3. Fold C/D 需要生成的精确配置字段，不实际创建配置；
4. AdamW、FP32、batch=8、101 次遍历、3939 optimizer steps 的继承条件；
5. train-only partial-only BNCal 为 315 case、40 batch；
6. confirmation20、official test、old monitor 和 MUG 排除边界；
7. SESOI 是否可从既有冻结材料锁定；
8. 当前代码没有因后续工具或清理发生语义漂移；
9. 旧 checkpoint 已从服务器删除但有本机已核验归档；QA-1 新训练不依赖其恢复；未来若需加载旧权重，必须由用户重新上传精确归档并另行授权。

输出：

- `v12_qa1_preregistered_protocol_v1.json` 草案；
- `v12_qa1_readonly_audit_report_zh_v1.md`；
- implementation-only authorization request；
- 父文件 SHA256 清单。

本阶段不得创建正式配置、读取 payload、训练、BNCal、推理或启动 tmux。

---

## 10. Stage V12-P1：QA-1 配置实施

仅在单独 implementation-only 授权后执行。

允许：

- 创建 B0/LS/LSQ × Fold C/D × seed0 的六份配置或生成器输出；
- 创建 QA-1 协议、静态验证器和 synthetic CPU contract tests；
- 执行 JSON/YAML/Python/shell 语法检查和 synthetic CPU tests。

禁止：

- 修改 v1.1 公共模型实现；
- 提前实现 L0/LQ；
- 加载真实 checkpoint；
- 打开 NPZ；
- 使用 GPU；
- 训练、BNCal 或 dev inference。

如果现有模型无法仅通过配置覆盖支持 C/D，应停止并提出独立 hotfix，不得把共享代码修改夹带进配置阶段。

---

## 11. Stage V12-P2：零更新 preflight

在单独授权下，对六个 QA-1 run 逐一完成零更新 preflight：

- optimizer steps = 0；
- model updates = 0；
- 不产生 checkpoint；
- 不进入 dev evaluator；
- 只访问授权的 fold-train 元数据或人工输入；真实 NPZ 是否允许读取由该次授权决定；
- 验证 loader 长度、train/dev allowlist、参数组、公共初始化 hash、输出目录不存在和禁止数据未访问；
- 失败时停止，不自动 hotfix 或重试。

通过后，为每个训练 run 分别生成精确 training authorization request。

---

## 12. Stage QA-1：Q0/LSQ 的 C/D 内部 OOF 复现

### 12.1 运行矩阵

```text
B0  × Fold C/D × seed0
LS  × Fold C/D × seed0
LSQ × Fold C/D × seed0
```

共 6 个从头训练 run。每个 run 必须单独授权，不得批量推导后续 run 权限。

若冻结协议确认继承 v1.1 训练合同，则每个 run 使用：

- development84 对应 fold 的 315 个 train case；
- AdamW；
- FP32；
- batch=8；
- 101 次遍历；
- 3939 optimizer steps；
- 训练成功后一次 315-case、40-batch、partial-only BNCal；
- 单张 RTX 4090 D；
- tmux、新日志和新不可覆盖输出目录；
- 禁止 resume、自动重跑、batch/精度/epoch/step 调整。

### 12.2 QA-1 评估

六条训练和 BNCal 回执全部冻结后，另行进行只读准备、evaluator implementation/preflight 和一次正式 C/D development 评估授权。

预期 forward 数量必须在执行请求中精确列出，并由结果回执核对；不得访问 A/B、confirmation20 或其他分区来补足失败结果。

### 12.3 QA-1 通过门

令 `Delta = LSQ - LS`，负值更好。

**方向门：**

```text
Fold C Delta <= 0
Fold D Delta <= 0
```

**实际幅度门：**

```text
pooled Delta <= -delta_practical
```

**统计证据：**

```text
pooled 95% source-skull cluster-bootstrap CI upper bound < 0
```

**硬安全门：**

- 不允许出现 LSQ 独有的新 disaster case；
- Fold C/D 的 disaster count 均不得高于 LS；
- zero-contact count 任一折高于 LS 时，不得直接判定通过，进入 `REVIEW_ZONE`；
- Implant CD-L1 `Delta <= +0.10 mm`；
- Final CD-L1 `Delta <= +0.10 mm`；
- Final HD95 `Delta <= +0.50 mm`；
- Final NSD@1mm `Delta >= -0.01`。

### 12.4 QA-1 分类

| 分类 | 条件 | 唯一下一步 |
|---|---|---|
| `CONFIRMED_INTERNAL_REPLICATION` | 方向、幅度、CI 和全部安全门通过 | 进入 QA-2 实施准备 |
| `PROMISING_UNCERTAIN` | 达到幅度但 CI 跨 0，或仅有轻微预设 review-zone 问题 | 先做只读异质性复盘；不进入 Mamba |
| `HETEROGENEOUS` | C/D 方向相反或强 source sensitivity | 优先做平衡新 seed 复核；不进入 QA-2/Mamba |
| `NO_REPLICATION` | 未达到幅度，或 C/D 均不改善 | 冻结 query 路线；转向 task-specific local representation/baseline 研究 |
| `SAFETY_FAIL` | 任一硬安全门失败 | 停止当前路线，不以均值改善覆盖失败病例 |

不得将 `PROMISING_UNCERTAIN` 自动升级为通过。

---

## 13. Stage QA-2：Local=1 条件下的 SCF × Query 分解

只有 QA-1 分类为 `CONFIRMED_INTERNAL_REPLICATION` 才允许进入。

### 13.1 实施顺序

1. 单独只读 pre-implementation audit；
2. 单独 implementation-only 授权，仅实现 L0/LQ 与对应测试；
3. 验证 B0/LS/LSQ inactive path 与 v1.1 语义一致；
4. 单独零更新 preflight；
5. 逐 run 授权训练。

### 13.2 新运行

```text
L0 × Fold A/B/C/D × seed0
LQ × Fold A/B/C/D × seed0
```

共 8 个新 run。

B0/LS/LSQ 的现有 OOF 结果只有在 config、代码路径、初始化合同、allowlist、BNCal 和 evaluator 全部通过 identity audit 时才能复用。若公共 forward 或训练语义改变，必须停止并重新制定完整重训预算，不自动重训。

### 13.3 分析

主要机制比较：

```text
LS-L0
LQ-L0
LSQ-LQ
LSQ-LS
I = (LSQ-LQ) - (LS-L0)
```

总体嵌套比较：

```text
L0-B0
winner-B0
```

QA-2 用于机制发现和 minimal winner 选择，仍属于 development analysis，不是最终确认。

### 13.4 Minimal winner 规则

当两个候选的主指标差异未达到 `delta_practical`，且安全指标没有稳定优势时，选择参数更少、机制更简单的模型。

- 若 `LSQ>LQ` 且新 seed 后仍成立，SCF 可保留；
- 若 `LQ≈LSQ`，删除 SCF，优先 LQ；
- 若 Query 无稳定增益，停止 Query/Mamba 路线；
- 若只有 Local 有效，转向 local representation，而不是继续堆 query 或 Mamba。

---

## 14. SCF representation-shaping 机制验证

### 14.1 不作为主要证据的实验

在 `beta=0` 且 SCF probability 不进入 forward 的模型中，推理阶段关闭 SCF head 理论上应为 no-op。该实验只用于实现契约，不作为“SCF 影响表示”的主要证据。

### 14.2 有因果意义的训练干预

核心比较由 LQ 与 LSQ 提供：

- 公共参数相同初始化；
- 结构相同；
- 唯一主要差异为 `lambda_scf=0` 与冻结的 `lambda_scf>0`；
- 必要时增加 `SCF stop-gradient-to-H` 诊断模型，区分 head 计算与 shared representation 梯度作用。

### 14.3 梯度审计

只在另行授权的训练 instrumentation 中记录：

```text
||grad_scf||
||grad_rec||
||grad_scf|| / ||grad_rec||
cos(grad_scf, grad_rec)
```

要求：

- 对 loss weight 归一化；
- 分 local encoder、shared H、query block、decoder 记录；
- 报告随 epoch/step 的轨迹，而非只取一个 batch；
- instrumentation 开关必须通过“不改变模型输出和更新”的 synthetic/zero-step contract。

只有 `LSQ>LQ` 经新 seed 复核、SCF 梯度稳定到达 shared H，且 stop-gradient 干预削弱收益时，才支持“SCF 通过 representation shaping 起作用”的机制表述。

---

## 15. Stage QA-3：平衡的新 seed 稳定性

QA-2 选定 minimal winner 后执行。

### 15.1 最小稳定性矩阵

优先对 winner 与最近机制对照执行：

```text
winner / nearest-control × Fold A/B/C/D × seed1
```

共 8 个新 run。

示例：

- winner=LSQ：`LSQ/LQ × A-D × seed1`；
- winner=LQ：`LQ/L0 × A-D × seed1`；
- winner=LS：`LS/L0 × A-D × seed1`。

如需证明总体优于无 Local 基线，再增加：

```text
B0 × Fold A/B/C/D × seed1
```

共 4 个可选 run，须单独授权。

### 15.2 稳定性要求

- seed0 与 seed1 的 winner-vs-nearest-control pooled 方向均应有利于 winner；
- 报告每个 seed 的 fold-specific 和 pooled 结果；
- 报告 seed 间均值、范围和 SD，但不以两 seed 的均值掩盖单 seed 反向；
- 若 seed 方向相反，分类为 seed-sensitive，不进入 Mamba；
- 若只有很小效应且未达到 `delta_practical`，选择更简单模型。

不默认在 A/B 上做 seed1/2；优先使用 A-D 的平衡 seed1，以同时观察 fold 和 seed 异质性。

---

## 16. Query attention 的容量匹配验证

若 QA-2/QA-3 支持 Query block，进入 Mamba 前建立一个 parameter-matched 非交互对照：

```text
LP = Local backbone + parameter/FLOP-matched MLP or residual block
```

要求：

- 参数量与 LQ 尽可能匹配；
- 不进行 local-to-query token 交换；
- 使用同 fold、同 seed、公共初始化合同；
- 先在预注册的最小折/seed 范围完成信息价值评估。

只有 LQ 同时优于 L0 和 LP，才能较强地把增益归因于 query coupling，而不是泛化的额外容量。

---

## 17. Query-Space Mamba 条件进入计划

### 17.1 进入条件

以下条件全部满足后才允许起草 Mamba implementation protocol：

1. QA-1 通过；
2. QA-2 明确 minimal winner；
3. QA-3 新 seed 方向稳定；
4. Query block 优于必要的容量对照；
5. confirmation20 尚未打开；
6. Mamba 近邻工作与可复现基线审计完成。

### 17.2 候选

| ID | 基础模型 | Query 后模块 | 角色 |
|---|---|---|---|
| G0 | QA winner | 无 | 冻结基础模型 |
| GM | QA winner | Bidirectional Query-Mamba | Mamba 候选 |
| GT | QA winner | matched Transformer | 架构对照 |
| GP | QA winner | parameter-matched MLP/residual | 容量对照 |

### 17.3 第一版结构约束

- Mamba 放在已经获得证据支持的 missing-region query path，不放回原 encoder-post 位置；
- query anchor 坐标采用冻结 canonical Morton/Z-order；
- 默认使用双向或正反向共享的 Query-Mamba，避免把无序集合强行解释为单向因果序列；
- 不做 ordering sweep；
- 允许一次预注册的 reverse-order 或刚体变换稳定性审计，但不能据结果调选 ordering；
- 所有 sort/inverse-sort 开销必须计入端到端 latency。

### 17.4 Mamba 继续门

保留 Mamba 至少需满足之一：

1. GM 相对 GT 和 GP 在主几何指标上达到预先冻结的实际改善，并通过全部安全门；
2. GM 在质量非劣的前提下，端到端延迟或峰值显存获得预先冻结的实际优势。

由于 query 数约为 256，不预设 Mamba 一定具有可观的复杂度优势。若 GM 仅优于 G0、但不优于 GT/GP，不得声称 Mamba-specific contribution。

---

## 18. 强基线计划

### 18.1 必需内部基线

- AdaPoinTr/B0；
- minimal QA winner；
- nearest mechanism control；
- 若论文保留 Mamba，则加入 matched Transformer 与容量对照。

### 18.2 外部近邻优先级

1. MedPCFM 的 deterministic PTv3 baseline；
2. MedPCFM/PCFM 或 MedPCFM-TED，在代码、许可证、点数和 split 可复现时；
3. CompletionMamba，在论文保留 Mamba 时；
4. 一个颅骨 symmetry 强基线或明确的公开结果对照；
5. Hyper-PCN/Simba 等作为 general PCC 近邻，而非必须全部重实现。

### 18.3 公平比较要求

只有下列条件一致或被明确校正时才允许直接比较数值：

- source skull 与 split；
- 输入/输出点数；
- partial/implant 目标定义；
- normalization 与 mm 恢复；
- BNCal/BatchNorm 策略；
- checkpoint 选择；
- 指标实现与聚合单位。

若无法满足，只作相关工作或协议差异说明，不把论文表格数字直接并列成排行榜。

---

## 19. Confirmation20 与最终确认

confirmation20 只有在以下项目全部冻结后才允许打开一次：

- 最终模型结构；
- 是否保留 Mamba；
- 训练和 BNCal 合同；
- seed 与 checkpoint 选择规则；
- primary endpoint、SESOI、护栏和失败规则；
- evaluator 和统计脚本；
- 一次性 authorization request；
- 结果无论正负均冻结且不得重跑的规则。

如果最终 Mamba 失败并被移除，不得为了保持“Mamba 论文”叙事重新打开 confirmation20 调整模型。确认失败后只能如实报告，或建立新的数据来源和新协议。

---

## 20. 运行预算

| 阶段 | 新训练 run | 是否立即授权 |
|---|---:|---:|
| QA-1：B0/LS/LSQ × C/D × seed0 | 6 | 否 |
| QA-2：L0/LQ × A-D × seed0 | 8 | 仅 QA-1 通过后 |
| QA-3：winner/control × A-D × seed1 | 8 | 仅 QA-2 后 |
| QA-3 可选 B0 × A-D × seed1 | 4 | 视总体基线问题另行授权 |
| Mamba Round-A：GM/GT/GP × 两折 | 6 | 仅全部进入条件满足后 |

最低 QA 主线为 22 个新训练 run；含可选 B0 稳定性和第一轮 Mamba 时最多约 32 个。任何阶段失败后立即按停止门退出，不能因为总预算未用完而继续。

所有正式训练仍须逐 run 授权；不得把本表理解为批量训练许可。

---

## 21. 失败分类与停止规则

统一分类：

```text
F1  local representation weak
F2  SCF accurate but query ignores local signal
F3  coarse zero-support
F4  coarse normal but dense refinement fails
F5  implant global distortion
F6  zero-contact
F7  seed-sensitive optimization
F8  fold/source heterogeneity
F9  capacity-only gain
F10 Mamba ordering sensitivity
```

停止规则：

- QA-1 `NO_REPLICATION` 或 `SAFETY_FAIL`：停止 Query/SCF/Mamba 主线；
- QA-1 `HETEROGENEOUS`：只允许新 seed/异质性协议，不允许堆模块；
- QA-2 Query 无增益：停止 Query-Space Mamba；
- QA-3 seed 方向相反：停止架构扩展；
- GM 不优于 GT/GP：删除 Mamba 核心主张；
- 任一阶段访问未授权数据、计数漂移或结果目录预存在：执行无效并停止，不自动重跑。

---

## 22. 结果与可复现材料

每个阶段至少冻结：

- preregistered protocol；
- implementation/preflight/execution authorization request；
- authorization receipt；
- runtime config 与 SHA256；
- train/dev allowlist SHA256；
- initialization/parameter-group hash；
- launcher、tmux session、主日志和退出码；
- checkpoint inventory（训练阶段）；
- BNCal receipt（如适用）；
- case-level metrics CSV；
- skull-level metrics CSV；
- fold/pooled summary JSON；
- cluster-bootstrap 输出；
- failure taxonomy；
- 中文结果报告；
- `files.sha256` 与 freeze receipt。

正式结果写入新的不可变目录；目标存在即停止。失败结果、hotfix 前失败证据和负结果均须保留。

---

## 23. Git、本机与归档边界

服务器工作目录当前不是 Git worktree，因此：

- 不在服务器初始化 Git；
- 重要父文件和新文件使用 SHA256 绑定；
- Git commit、annotated tag 和 GitHub push 仍以 Windows 本机规范仓库为准，除非用户另行授权服务器 Git 操作；
- 服务器命令不得引用或猜测 Windows 路径；
- 需要长期保存的结果必须在服务器创建可恢复归档，由用户下载到 `E:\ResearchBackups\AdaPoinTr` 并明确确认哈希验证；
- 未收到本机下载与验证确认前，不得因“可能已有备份”删除服务器产物。

---

## 24. 下一步唯一允许的阶段

本计划完成后，下一步应为：

> **V12-P0 只读协议锁定与 QA-1 pre-implementation 核验。**

该阶段只核验父绑定、A-D 清单、B0/LS/LSQ 配置与代码身份、SESOI 证据、资源合同和禁止数据边界，并生成机器可读 QA-1 协议草案及 implementation-only 授权请求。

在用户单独明确授权前，仍禁止：

- 创建 C/D 正式配置；
- 修改模型代码；
- 读取任何 NPZ payload；
- 加载 checkpoint；
- 使用 GPU；
- preflight；
- 训练或 BNCal；
- development/confirmation 评估；
- 自动恢复旧 checkpoint；
- 进入 QA-2、QA-3、Mamba 或任何后续 run。

---

## 25. 参考文献与近邻工作

1. Yu X. et al. *AdaPoinTr: Diverse Point Cloud Completion With Adaptive Geometry-Aware Transformers.* IEEE TPAMI, 2023.
2. Fu Z. et al. *CompletionMamba: Taming State Space Model for Point Cloud Completion.* IEEE TIP, 2025. DOI: `10.1109/TIP.2025.3597041`.
3. Li Y. et al. *DAPointMamba: Domain Adaptive Point Mamba for Point Cloud Completion.* AAAI, 2026. DOI: `10.1609/aaai.v40i8.37596`.
4. Wu X. et al. *FusionMamba: Efficient 3D Point Cloud Completion via Spatially-Aware State Space Models and Multi-Scale Information Fusion.* Information Fusion, 2026, 104378.
5. Li H. et al. *BuildingComSSSM: Building Point Cloud Completion with Geometry-Aware Mambas.* IJAEOG, 2026, 105269.
6. Wu W. et al. *A Point Cloud Completion Network Integrating Mamba and Transformer Architectures.* Expert Systems with Applications, 2026, 130826.
7. Li L. et al. *Hyper-PCN: Hypergraph-Based Point Cloud Completion via High-Order Correlation Modeling.* CVPR, 2026.
8. Yan H. et al. *SymmCompletion: High-Fidelity and High-Consistency Point Cloud Completion with Symmetry Guidance.* AAAI, 2025.
9. Zhang L. et al. *Simba: Towards High-Fidelity and Geometrically-Consistent Point Cloud Completion via Transformation Diffusion.* AAAI, 2026.
10. Wodzinski M., Daniol M., Hemmerling D. *Automatic Skull Reconstruction by Deep Learnable Symmetry Enforcement.* Computer Methods and Programs in Biomedicine, 2025, 108670.
11. Liang J. et al. *Rethinking Multi-Modal Point Cloud Completion: Query-Aware Gating Attention and Gramian Volume Alignment.* IJCAI, 2026.
12. Kwarciak K., Wodzinski M. *MedPCFM: Improving Medical Point Cloud Completion by Integrating Point Transformers and Flow Matching.* arXiv:2606.24433, 2026.
13. Kwarciak K., Wodzinski M. *MedPCFM-TED: One-Step Point Cloud Flow Matching for Implant Generation via Teacher-Guided Endpoint Distillation.* arXiv:2609.16934, 2026（预印本）.
14. Wodzinski M. et al. *High-Resolution Cranial Defect Reconstruction by Iterative, Low-Resolution, Point Cloud Completion Transformers.* MICCAI, 2023.

---

## 26. 最短决策树

```text
V12-P0 read-only protocol lock
└─ parent/split/SESOI/code identity valid?
   ├─ No  -> stop and repair protocol only
   └─ Yes -> P1 config implementation + P2 zero-step preflight
             └─ QA-1: B0/LS/LSQ × C/D × seed0
                ├─ no replication / safety fail -> stop Query/Mamba
                ├─ heterogeneous -> balanced seed diagnosis only
                └─ confirmed -> QA-2: L0/LQ × A-D × seed0
                                └─ choose minimal winner
                                   ├─ Query not needed -> stop Query-Mamba
                                   └─ Query needed -> QA-3 balanced seed1
                                                     ├─ unstable -> stop expansion
                                                     └─ stable -> capacity control
                                                                ├─ capacity-only -> remove Query claim
                                                                └─ query-specific -> GM vs GT vs GP
                                                                                   ├─ no Mamba-specific gain -> remove Mamba
                                                                                   └─ gain -> freeze final candidate
                                                                                              -> one-shot confirmation20
```

