# Cranial-SCQR v1.2-QA：V12-P0 只读协议锁定与 QA-1 pre-implementation 核验报告 v1

**生成时间：** 2026-09-21T11:23:51Z  
**状态：** `P0_CONDITIONAL_PASS`  
**结论：** 数据、split、代码身份、训练合同和主指标合同通过；QA-1 正式配置尚不可实施，必须先完成 Fold C/D 的 train-only 梯度量级 calibration。  

## 1. 本阶段实际边界

本阶段仅执行了：

- 读取文本协议、JSON/YAML 配置、Python/shell 源码、case ID 清单和既有 receipt；
- 计算文件 SHA256；
- 对纯文本 case ID 清单执行 source-skull 分组和集合不变量核验；
- 按既有冻结哈希规则在内存中计算 C/D calibration 的 4-skull/20-case 选择；
- 观察服务器身份、磁盘、进程、GPU 空闲状态和 Python 解释器存在性；
- 生成本报告、机器可读协议、父哈希清单和下一阶段 implementation-only 授权请求。

本阶段没有：

- 打开任何 NPZ；
- 加载、反序列化或恢复 checkpoint；
- 导入 PyTorch/CUDA 进行模型计算；
- 使用 GPU；
- 创建 C/D 正式训练配置；
- 创建 calibration runner、launcher、selection 文件或 calibration 配置；
- 运行语法测试、synthetic contract、preflight、训练、BNCal 或 development 评估；
- 访问 confirmation20、official test、old monitor、MUG 或 SkullFix payload；
- 修改任何既有文件。

## 2. 环境核验

| 项目 | 结果 |
|---|---|
| 工作目录 | `/home/jovyan/adapointr_work/PoinTr` |
| hostname | `shu-common-25721452-notebook-ty0omk-0` |
| 用户 | `jovyan` |
| Git | 当前服务器目录不是 Git worktree |
| 磁盘 | `/home/jovyan` 约 24 GiB 可用 |
| 实验进程 | 0 |
| GPU 只读观察 | RTX 4090 D，UUID `GPU-169c0659-ccea-3c18-9f44-62b3c7b19a5e`，0% 利用率 |
| 后续候选解释器 | `/opt/conda/envs/adapointr-mamba/bin/python`，Python 3.10.20 |

GPU UUID 只是本次只读观察，不构成后续 calibration 或训练的资源绑定。

## 3. 数据与四折不变量

manifest 仅计算哈希，没有打印内容：

```text
/home/jovyan/datasets/SkullBreakPC_out8192/manifest.jsonl
bytes  = 734982
sha256 = f1f8cae47ed7d5529dc2ca244179cedddbc039981cdc0ff24b25a5c81ad30538
```

独立重算结果：

- A-D 每折均为 315 train cases / 63 source skulls；
- A-D 每折均为 105 dev cases / 21 source skulls；
- 每折 train/dev 交集为 0，并集为 420 cases；
- A-D dev sets 两两不相交；
- 四个 dev set 的并集为 420 cases / 84 source skulls；
- 每折 train set 恰为 development84 减去本折 dev set；
- 每个 source skull 恰有五种冻结 defect；
- `development84_case_ids.txt` 与四个 dev set 并集完全一致，SHA256 为 `78e28617281154f65aa4cd644337931602d4c8ec9833b1a0140c3826bdcf3e70`。

因此 C/D 可以作为尚未观察 SCQR dev outcome 的内部 OOF 复现折，但不是独立测试或新来源验证。

## 4. 代码与配置身份

关键当前实现与 v1.1 冻结身份一致：

| 文件 | SHA256 | 结论 |
|---|---|---|
| `models/AdaPoinTr.py` | `62a743c4c2143b77b0f1656c59d0482563976440d841f04bae995017dbf7588f` | 与 v1.1 evaluation/intervention 绑定一致 |
| `datasets/SkullBreakDataset.py` | `5c4c17c81f8a64c21bb239933a438b98c98f0ee587820dd1789f616f9cbd7fe2` | 与冻结 calibration 绑定一致 |
| `tools/runner.py` | `07d6b9b05ada5549d8ed4781f57f31c1655e50eb5917583cd0f4e9b151b61804` | 与八个 v1.1 正式训练请求及 training protocol 一致 |
| `utils/skullfix_metrics.py` | `0c4342cd19fb19a659302b0e350c3be34bd21447d2034bdc9d2e81a180174ee5` | 与正式 development evaluator 一致 |
| `models/cranial_scqr/contact_support.py` | `358ea31017344fa4905aac7e495dc87ed7f74496954fd34d7390cd0ea579028f` | 一致 |
| `models/cranial_scqr/local_geometry.py` | `b533efead76c38ff7bc83a5245a88c98e275a37e0523cbbfb793a63b4d645665` | 一致 |
| `models/cranial_scqr/query_conditioning.py` | `e631f6649b3a218e63c39f15f6232607469106ae63b0c7cdf578636b110d9057` | 一致 |

对 A/B 已授权 YAML 的结构化比较确认：排除 candidate/authorization 元数据后，A1 与 Q0 的科学设计差异只有：

```text
model.cranial_scqr.query_conditioning_enabled: false -> true
model.cranial_scqr.variant: A1 -> Q0
```

因此 v1.2 的 LS/LSQ 可继续分别绑定为 v1.1 A1/Q0 的语义别名；本阶段不需要修改模型代码。

## 5. 可继承训练合同

只要后续每阶段重新核验全部哈希，QA-1 可以继承：

- 从头训练，无初始 checkpoint；
- AdamW，learning rate `1e-4`，weight decay `5e-4`；
- FP32、AMP off，不改变 TF32；
- batch=8，drop_last=true，39 batches/traversal；
- epoch labels 0..100，共 101 次遍历；
- 每 run 3939 optimizer steps；
- final-only checkpoint，无 best checkpoint、early stopping、resume、自动重跑；
- 训练成功后一次 315-case、40-batch、partial-only BNCal；
- training 只读 `partial/implant`，BNCal 只读 `partial`；
- development 在训练期间禁用。

以上仍不是训练授权。

## 6. 阻断项：Fold C/D 缺少 `lambda_scf`

既有 calibration protocol 明确只覆盖 Fold A/B：

```text
Fold A lambda_scf = 0.8852418767331852
Fold B lambda_scf = 0.8592013565676653
```

没有任何冻结 receipt 给出 Fold C/D 数值。根据 v1.1 合同，`lambda_scf` 是按 fold 的 train-only gradient ratio 得到，供该 fold 的 LS/LSQ 共用；因此不得：

- 复制 A 或 B 的值；
- 取 A/B 均值；
- 事后根据 C/D dev 结果调整；
- 先创建带猜测值的正式 LS/LSQ 训练配置。

故 QA-1 正式配置 materialization 当前状态为 `NOT_READY`。

## 7. C/D calibration 选择的只读计算结果

完全复用 v1.1 冻结规则：

```text
salt = cranial-scqr-v1.1-lambda-calibration-v1
rank = SHA256(UTF-8(salt) + NUL + UTF-8(skull_id)) ascending
take = first 4 train skulls per fold
layout = one defect type per batch, four skulls in hash rank order
```

Fold C：

```text
selected_skulls = train:113, train:002, train:062, train:017
20-case selection SHA256 = ea2302d73932ad4e95c15849bd1b553537b2e230687317977e0b23fcf7141609
```

Fold D：

```text
selected_skulls = train:113, train:002, train:026, train:041
20-case selection SHA256 = aad630032369c24072c92fc2fd8de8be12f431ca5f83df835796cbfecaf3097b
```

两折共 40 次 payload open event、30 个 unique cases、10 次完整 forward、20 次 autograd；optimizer/checkpoint/BNCal/model update 均为 0。这里只冻结设计，当前没有授权或执行这些访问。

## 8. SESOI 锁定

`delta_practical=0.10 mm` 继续冻结为固定 8192 点 representation 上的配对工程资源门：

- 不是临床容差；
- 不是统计显著性阈值；
- 不解释为 dense surface 重采样误差界；
- 不得看到 C/D 结果后移动。

依据：正式比较对每个候选复用相同固定 case representation 和 evaluator，不含随机点重采样；同条件重复未发现 nondeterminism，Round A-I 数值负对照约为 `0.00000236 mm`，direct bias 即时效应约 `0.00035 mm`，均远低于 `0.10 mm`。既有 P0 的 GT-self RimCover 均值约 `1.743128 mm` 是 defective-side 2 mm band 的固定非零参考，不是测量变异。

该锁定仅适用于当前固定表示的开发决策，论文不得把 `0.10 mm` 写成临床有意义阈值。

## 9. Checkpoint 与归档状态

服务器 16 个 v1.1 训练/BNCal checkpoint 已按清单删除，checkpoint cleanup receipt 状态为 `PASS`；服务器运输归档也已在用户确认本机归档和恢复验证通过后删除。当前项目中没有发现 `ckpt-last.pth` 或 `ckpt-last-bncal.pth`。

QA-1 是从头训练，不依赖恢复旧权重。未来如需旧 checkpoint，必须由用户从本机已核验归档重新上传，并单独授权；不得猜测 Windows 路径或假定自动同步。

## 10. P0 最终判定

| 项目 | 判定 |
|---|---|
| split/source-skull 合同 | PASS |
| 数据访问边界 | PASS |
| v1.1 代码身份 | PASS |
| 训练/BNCal 合同可继承性 | CONDITIONAL PASS，后续每阶段重验哈希 |
| 主指标与统计单位 | PASS |
| `0.10 mm` 工程 SESOI | LOCKED，固定 representation 限定 |
| 旧服务器 checkpoint 依赖 | NONE |
| C/D `lambda_scf` | MISSING / BLOCKING |
| QA-1 正式配置实施 | NOT READY |
| QA-1 preflight/训练/评估 | NOT AUTHORIZED |

总体状态：

```text
P0_CONDITIONAL_PASS
NEXT = C/D gradient-calibration prerequisite implementation-only
```

下一步只允许按 `v12_qa1_prerequisite_implementation_authorization_request_v1.json` 创建独立的新 calibration 工具、协议、selection files 和 calibration-locked LS templates，并只执行静态/JSON/YAML/synthetic CPU 检查。该步骤仍不得打开 NPZ、使用 GPU或执行 calibration。

