LS_foldC_seed0 development evaluation：PASS（单运行描述性结果）
105 cases；21 source skulls；105 forwards；1 checkpoint load。
参数与 buffer 不变；deterministic=true；TF32=false。
未进行正式 QA-1 gate、候选比较、训练或 BNCal；不授权后续运行。
