# B0 Fold C 单次 development 描述性评估

状态：执行凭据 PASS，等待单独 post-evaluation freeze audit。

仅描述该候选该 fold，不作候选比较、C/D pooled delta、正式 QA-1 gate 或自动推进。

机器可读计数：

```json
{
  "checkpoint_loads": 1,
  "member_gt": 105,
  "member_implant": 105,
  "member_partial": 105,
  "model_buffer_updates": 0,
  "model_case_forward_calls": 105,
  "model_parameter_updates": 0,
  "npz_open_events": 105,
  "optimizer_constructions": 0,
  "optimizer_steps": 0
}
```

单运行描述性汇总：

```json
{
  "automatic_next_run": false,
  "candidate": "B0",
  "candidate_comparison_performed": false,
  "case_count": 105,
  "disaster_count": 9,
  "fold": "C",
  "formal_qa1_gate_applied": false,
  "run_key": "B0_foldC_seed0",
  "seed": 0,
  "source_count": 21,
  "source_equal_weight_metrics": {
    "final_cd_l1_mm": 2.392490955894377,
    "final_hd95_mm": 5.660926193249467,
    "final_nsd_at_1mm": 0.14953845796130955,
    "implant_cd_l1_mm": 4.220761989633937,
    "implant_hd95_mm": 9.43921592012128,
    "implant_nsd_at_1mm": 0.19308093843005955,
    "implant_pred_to_ref_mean_mm": 4.6341298864810385,
    "implant_ref_to_pred_mean_mm": 3.807394092786834,
    "rim_contact_cd_l1_mm": 7.269810684308065,
    "rim_contact_hd95_mm": 25.235362201537978,
    "rim_contact_precision": 0.4494787770249709,
    "rim_contact_recall": 0.41386667235888225,
    "rim_gt_rim_to_pred_mean_mm": 5.072794075365247,
    "rim_gt_rim_to_pred_p95_mm": 11.142992793289029,
    "rim_predicted_rim_points": 185.94285714285718,
    "rim_reference_rim_points": 200.8857142857143
  },
  "status": "DESCRIPTIVE_SINGLE_RUN_ONLY",
  "zero_contact_count": 0
}
```
