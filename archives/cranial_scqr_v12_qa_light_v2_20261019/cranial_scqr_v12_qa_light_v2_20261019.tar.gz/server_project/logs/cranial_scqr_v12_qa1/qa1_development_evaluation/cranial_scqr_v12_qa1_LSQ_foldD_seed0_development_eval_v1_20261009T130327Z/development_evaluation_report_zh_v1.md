# LSQ Fold D 单次 development 描述性评估

状态：执行凭据 PASS，等待单独 post-evaluation freeze audit。

仅描述该候选该 fold，不作候选比较、C/D pooled delta、正式 QA-1 gate 或自动推进。

机器可读计数：

```json
{
  "checkpoint_loads": 1,
  "member_gt": 105,
  "member_implant": 105,
  "member_partial": 105,
  "model_buffer_updates": 0,
  "model_case_forward_calls": 105,
  "model_parameter_updates": 0,
  "npz_open_events": 105,
  "optimizer_constructions": 0,
  "optimizer_steps": 0
}
```

单运行描述性汇总：

```json
{
  "automatic_next_run": false,
  "candidate": "LSQ",
  "candidate_comparison_performed": false,
  "case_count": 105,
  "disaster_count": 5,
  "fold": "D",
  "formal_qa1_gate_applied": false,
  "run_key": "LSQ_foldD_seed0",
  "seed": 0,
  "source_count": 21,
  "source_equal_weight_metrics": {
    "final_cd_l1_mm": 2.336911647628655,
    "final_hd95_mm": 5.308276798928714,
    "final_nsd_at_1mm": 0.14799417162698414,
    "implant_cd_l1_mm": 3.167235955627036,
    "implant_hd95_mm": 7.801529528821178,
    "implant_nsd_at_1mm": 0.21112758091517855,
    "implant_pred_to_ref_mean_mm": 3.7498811357333492,
    "implant_ref_to_pred_mean_mm": 2.584590775520723,
    "rim_contact_cd_l1_mm": 5.046009939643503,
    "rim_contact_hd95_mm": 19.440409843284037,
    "rim_contact_precision": 0.5071255832310535,
    "rim_contact_recall": 0.49037538918501555,
    "rim_gt_rim_to_pred_mean_mm": 3.5257668507691426,
    "rim_gt_rim_to_pred_p95_mm": 8.64186677825635,
    "rim_predicted_rim_points": 207.45714285714288,
    "rim_reference_rim_points": 212.48571428571427
  },
  "status": "DESCRIPTIVE_SINGLE_RUN_ONLY",
  "zero_contact_count": 0
}
```
