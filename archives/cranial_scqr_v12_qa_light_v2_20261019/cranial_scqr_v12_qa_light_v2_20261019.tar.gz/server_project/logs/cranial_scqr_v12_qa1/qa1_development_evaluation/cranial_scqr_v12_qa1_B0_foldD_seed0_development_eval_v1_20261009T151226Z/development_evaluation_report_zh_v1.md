# B0 Fold D 单次 development 描述性评估

状态：执行凭据 PASS，等待单独 post-evaluation freeze audit。

仅描述该候选该 fold，不作候选比较、C/D pooled delta、正式 QA-1 gate 或自动推进。

机器可读计数：

```json
{
  "checkpoint_loads": 1,
  "member_gt": 105,
  "member_implant": 105,
  "member_partial": 105,
  "model_buffer_updates": 0,
  "model_case_forward_calls": 105,
  "model_parameter_updates": 0,
  "npz_open_events": 105,
  "optimizer_constructions": 0,
  "optimizer_steps": 0
}
```

单运行描述性汇总：

```json
{
  "automatic_next_run": false,
  "candidate": "B0",
  "candidate_comparison_performed": false,
  "case_count": 105,
  "disaster_count": 11,
  "fold": "D",
  "formal_qa1_gate_applied": false,
  "run_key": "B0_foldD_seed0",
  "seed": 0,
  "source_count": 21,
  "source_equal_weight_metrics": {
    "final_cd_l1_mm": 2.4013509447244323,
    "final_hd95_mm": 5.608632500537327,
    "final_nsd_at_1mm": 0.1472931392609127,
    "implant_cd_l1_mm": 3.5016687854735937,
    "implant_hd95_mm": 9.20436750286937,
    "implant_nsd_at_1mm": 0.19446440197172624,
    "implant_pred_to_ref_mean_mm": 4.004294480713651,
    "implant_ref_to_pred_mean_mm": 2.999043090233536,
    "rim_contact_cd_l1_mm": 6.075101523715851,
    "rim_contact_hd95_mm": 23.236951551854084,
    "rim_contact_precision": 0.4785544441743997,
    "rim_contact_recall": 0.4702540904455923,
    "rim_gt_rim_to_pred_mean_mm": 4.226030196649027,
    "rim_gt_rim_to_pred_p95_mm": 10.430083858516307,
    "rim_predicted_rim_points": 204.74285714285716,
    "rim_reference_rim_points": 212.48571428571427
  },
  "status": "DESCRIPTIVE_SINGLE_RUN_ONLY",
  "zero_contact_count": 0
}
```
