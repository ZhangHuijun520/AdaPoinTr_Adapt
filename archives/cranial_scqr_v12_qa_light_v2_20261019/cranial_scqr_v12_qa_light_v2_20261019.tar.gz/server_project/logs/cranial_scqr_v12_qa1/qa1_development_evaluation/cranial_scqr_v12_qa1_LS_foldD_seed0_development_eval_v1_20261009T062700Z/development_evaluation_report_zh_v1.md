# LS Fold D 单次 development 描述性评估

状态：执行凭据 PASS，等待单独 post-evaluation freeze audit。

仅描述该候选该 fold，不作候选比较、C/D pooled delta、正式 QA-1 gate 或自动推进。

机器可读计数：

```json
{
  "checkpoint_loads": 1,
  "member_gt": 105,
  "member_implant": 105,
  "member_partial": 105,
  "model_buffer_updates": 0,
  "model_case_forward_calls": 105,
  "model_parameter_updates": 0,
  "npz_open_events": 105,
  "optimizer_constructions": 0,
  "optimizer_steps": 0
}
```

单运行描述性汇总：

```json
{
  "automatic_next_run": false,
  "candidate": "LS",
  "candidate_comparison_performed": false,
  "case_count": 105,
  "disaster_count": 4,
  "fold": "D",
  "formal_qa1_gate_applied": false,
  "run_key": "LS_foldD_seed0",
  "seed": 0,
  "source_count": 21,
  "source_equal_weight_metrics": {
    "final_cd_l1_mm": 2.284062340969236,
    "final_hd95_mm": 5.025315654403023,
    "final_nsd_at_1mm": 0.14888044084821428,
    "implant_cd_l1_mm": 2.917086070372976,
    "implant_hd95_mm": 7.301842573388963,
    "implant_nsd_at_1mm": 0.21995500837053578,
    "implant_pred_to_ref_mean_mm": 3.418761951228451,
    "implant_ref_to_pred_mean_mm": 2.4154101895175017,
    "rim_contact_cd_l1_mm": 4.606190697209566,
    "rim_contact_hd95_mm": 18.55447789581156,
    "rim_contact_precision": 0.544292085066415,
    "rim_contact_recall": 0.5019594264159842,
    "rim_gt_rim_to_pred_mean_mm": 3.4542628597649423,
    "rim_gt_rim_to_pred_p95_mm": 9.044280038037575,
    "rim_predicted_rim_points": 196.1619047619048,
    "rim_reference_rim_points": 212.48571428571427
  },
  "status": "DESCRIPTIVE_SINGLE_RUN_ONLY",
  "zero_contact_count": 0
}
```
