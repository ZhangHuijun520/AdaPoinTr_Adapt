# LSQ Fold C 单次 development 描述性评估

状态：执行凭据 PASS，等待单独 post-evaluation freeze audit。

仅描述该候选该 fold，不作候选比较、C/D pooled delta、正式 QA-1 gate 或自动推进。

机器可读计数：

```json
{
  "checkpoint_loads": 1,
  "member_gt": 105,
  "member_implant": 105,
  "member_partial": 105,
  "model_buffer_updates": 0,
  "model_case_forward_calls": 105,
  "model_parameter_updates": 0,
  "npz_open_events": 105,
  "optimizer_constructions": 0,
  "optimizer_steps": 0
}
```

单运行描述性汇总：

```json
{
  "automatic_next_run": false,
  "candidate": "LSQ",
  "candidate_comparison_performed": false,
  "case_count": 105,
  "disaster_count": 1,
  "fold": "C",
  "formal_qa1_gate_applied": false,
  "run_key": "LSQ_foldC_seed0",
  "seed": 0,
  "source_count": 21,
  "source_equal_weight_metrics": {
    "final_cd_l1_mm": 2.201194127058829,
    "final_hd95_mm": 4.634117424253208,
    "final_nsd_at_1mm": 0.15253906249999996,
    "implant_cd_l1_mm": 2.2276447694166523,
    "implant_hd95_mm": 5.655353700807549,
    "implant_nsd_at_1mm": 0.2430559430803571,
    "implant_pred_to_ref_mean_mm": 2.6197040695099196,
    "implant_ref_to_pred_mean_mm": 1.8355854693233842,
    "rim_contact_cd_l1_mm": 3.2808380235299035,
    "rim_contact_hd95_mm": 14.007208599916908,
    "rim_contact_precision": 0.5387801054343556,
    "rim_contact_recall": 0.5554464044810128,
    "rim_gt_rim_to_pred_mean_mm": 2.628433642396833,
    "rim_gt_rim_to_pred_p95_mm": 6.459630195086484,
    "rim_predicted_rim_points": 206.0952380952381,
    "rim_reference_rim_points": 200.8857142857143
  },
  "status": "DESCRIPTIVE_SINGLE_RUN_ONLY",
  "zero_contact_count": 0
}
```
