# Cranial-SCQR v1.2 QA-1 六-run 零更新 preflight

- 状态：**PASS**
- run ID：`v12_qa1_zero_update_preflight_v2_20260922T143530Z`
- 输入：固定人工点云；真实 manifest/NPZ/checkpoint 访问均为 0。
- 精确计数：12 forward、6 backward、0 optimizer construct/step、0 更新。
- 本结果不是训练、BNCal、development 评估或正式计时授权。

## 六个 run

| run | loss | gradients | state |
|---|---:|---:|---|
| B0_foldC_seed0 | 1.87773204 | 324 | unchanged |
| B0_foldD_seed0 | 1.87773204 | 324 | unchanged |
| LS_foldC_seed0 | 2.49519157 | 339 | unchanged |
| LS_foldD_seed0 | 2.45594454 | 339 | unchanged |
| LSQ_foldC_seed0 | 2.49925685 | 358 | unchanged |
| LSQ_foldD_seed0 | 2.46001005 | 358 | unchanged |
