# Cranial-SCQR v1.2 QA-1 Fold C/D train-only 梯度量级校准

- 状态：**PASS**
- run ID：`v12_qa1_cd_gradient_calibration_v1_20260921T142811Z`
- optimizer 构造/step：0/0；checkpoint：0；BNCal：0。
- 仅访问 Fold C/D train 入选 case 的 partial/implant 和 normalization scale。
- eval + autograd，临时 residual warmup factor=1；不是训练。

## 每折结果

| fold | median g_rec/g_scf | unclipped λ | final λ | clipped |
|---|---:|---:|---:|---:|
| C | 8.91290931 | 0.891290931 | 0.891290931 | False |
| D | 8.34638704 | 0.834638704 | 0.834638704 | False |
