#!/bin/bash
set -euC
cd /home/jovyan/adapointr_work/PoinTr
mkdir -p -- /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldD_seed0_v1_20261019/control
test -d /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldD_seed0_v1_20261019/control
exec 3>/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldD_seed0_v1_20261019/control/master.log
exec 1>&3 2>&1
printf '%s\n' "$$" >/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldD_seed0_v1_20261019/control/pid.txt
export CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 MPLBACKEND=Agg
set +e
/usr/bin/timeout -k 5 7200 /opt/conda/envs/adapointr-mamba/bin/python3.10 -I -S -B -c 'import resource,runpy,sys;resource.setrlimit(resource.RLIMIT_FSIZE,(33554432,33554432));sys.path[:0]=['"'"'/home/jovyan/adapointr_work/PoinTr/tools'"'"', '"'"'/home/jovyan/adapointr_work/PoinTr'"'"', '"'"'/home/jovyan/adapointr_work/PoinTr/third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider'"'"', '"'"'/opt/conda/envs/adapointr-mamba/lib/python3.10/site-packages'"'"'];p=sys.argv.pop(1);runpy.run_path(p,run_name='"'"'__main__'"'"')' /home/jovyan/adapointr_work/PoinTr/tools/run_cranial_scqr_v12_rsd_r1b_foldD_v1.py --request /home/jovyan/adapointr_work/PoinTr/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_same_process_foldD_seed0_execution_request_v1_20261019.json --request-sha256 4f4a3c89d86bcaf6f76ed62b02b61155b98b553c834101222ab00c56d1a6bb97 --authorization /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldD_seed0_v1_20261019/control/authorization_receipt.json --authorization-sha256 b95c06278b1a1b5cbe77d7c17610945de9925f60538ee64ef5db730f98a66cb3 --runtime /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldD_seed0_v1_20261019/control/runtime.json --runtime-sha256 12543630876670f8474fdd0915b318d94d0cf0a190bbadbbcb4cf7be74626221
code=$?
printf '%s\n' "$code" >/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldD_seed0_v1_20261019/control/exit_code.txt
exit "$code"
