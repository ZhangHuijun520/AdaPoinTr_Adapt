#!/bin/bash
set -euC
cd /home/jovyan/adapointr_work/PoinTr
mkdir -p -- /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldC_seed0_v1_20261019/control
test -d /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldC_seed0_v1_20261019/control
exec 3>/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldC_seed0_v1_20261019/control/master.log
exec 1>&3 2>&1
printf '%s\n' "$$" >/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldC_seed0_v1_20261019/control/pid.txt
export CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 MPLBACKEND=Agg
set +e
/usr/bin/timeout -k 5 7200 /opt/conda/envs/adapointr-mamba/bin/python3.10 -I -S -B -c 'import resource,runpy,sys;resource.setrlimit(resource.RLIMIT_FSIZE,(33554432,33554432));sys.path[:0]=['"'"'/home/jovyan/adapointr_work/PoinTr/tools'"'"', '"'"'/home/jovyan/adapointr_work/PoinTr'"'"', '"'"'/home/jovyan/adapointr_work/PoinTr/third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider'"'"', '"'"'/opt/conda/envs/adapointr-mamba/lib/python3.10/site-packages'"'"'];p=sys.argv.pop(1);runpy.run_path(p,run_name='"'"'__main__'"'"')' /home/jovyan/adapointr_work/PoinTr/tools/run_cranial_scqr_v12_rsd_r1b_v3.py --request /home/jovyan/adapointr_work/PoinTr/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_same_process_foldC_seed0_execution_request_v1_20261019.json --request-sha256 4e36c6bfaecce3c9ae15c412f6079d8e9d9f0635f1de8df8c13c2493e121b0ca --authorization /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldC_seed0_v1_20261019/control/authorization.json --authorization-sha256 699963f829fff6738ac0df720e9ed0da0229d08527a2c1fcc76887ce105484b7 --runtime /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldC_seed0_v1_20261019/control/runtime.json --runtime-sha256 1200c613c945f19964292ed1c33a86523957d6db35e8611c5673797dc641bb60
code=$?
printf '%s\n' "$code" >/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldC_seed0_v1_20261019/control/exit_code.txt
exit "$code"
