#!/bin/bash
set -u -o pipefail
umask 077
cd -- /home/jovyan/adapointr_work/PoinTr || exit 90
set -C
test -d /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/control || exit 91
launcher_pid=$$
case "$launcher_pid" in ""|*[!0-9]*) exit 96 ;; esac
test ! -e /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/result && test ! -L /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/result || exit 92
test ! -e /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/control/started.json && test ! -L /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/control/started.json || exit 92
test ! -e /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/control/master.log && test ! -L /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/control/master.log || exit 92
test ! -e /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/control/pid.txt && test ! -L /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/control/pid.txt || exit 92
test ! -e /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/control/exit_code.txt && test ! -L /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/control/exit_code.txt || exit 92
exec 3>/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/control/master.log || exit 93
printf '%s\n' "$launcher_pid" >/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/control/pid.txt || exit 94
export CUDA_VISIBLE_DEVICES=0
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1
/usr/bin/timeout -k 5 600 /opt/conda/envs/adapointr-mamba/bin/python3.10 -I -S -B -c 'import resource,runpy,sys;resource.setrlimit(resource.RLIMIT_FSIZE,(33554432,33554432));entry=sys.argv.pop(1);sys.argv[0]=entry;runpy.run_path(entry,run_name="__main__")' /home/jovyan/adapointr_work/PoinTr/tools/run_cranial_scqr_v12_rsd_r1b_synthetic_gpu_preflight_minimal_v7.py --request /home/jovyan/adapointr_work/PoinTr/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_gpu_zero_update_preflight_execution_request_minimal_v7_20261018.json --request-sha256 9b845598585aa594e80e2cf087b4ce41b7069e32bbc844f4da16f0e72719d1a9 --authorization /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/control/authorization.json --authorization-sha256 ba67dc440c4818db09cf8db65f93f10bc1860502a73b4448960d2f1ceb8c2595 --runtime /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/control/runtime.json --runtime-sha256 771b89ff9dabf37386ca347e9b67e0dbf8019527655f2f9fe5edcdfdbbd89868 >&3 2>&1
rc=$?
printf '%s\n' "$rc" >/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/control/exit_code.txt || exit 95
exit "$rc"
