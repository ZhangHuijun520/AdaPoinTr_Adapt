#!/bin/bash
set -euC
cd /home/jovyan/adapointr_work/PoinTr
mkdir -p -- /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/real_query_intervention_foldC_seed0_v1_20261019/control
test -d /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/real_query_intervention_foldC_seed0_v1_20261019/control
exec 3>/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/real_query_intervention_foldC_seed0_v1_20261019/control/master.log
exec 1>&3 2>&1
printf '%s\n' "$$" >/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/real_query_intervention_foldC_seed0_v1_20261019/control/pid.txt
export CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 MPLBACKEND=Agg
set +e
/usr/bin/timeout -k 5 7200 /opt/conda/envs/adapointr-mamba/bin/python3.10 -I -S -B -c 'import resource,runpy,sys;resource.setrlimit(resource.RLIMIT_FSIZE,(33554432,33554432));sys.path[:0]=['"'"'/home/jovyan/adapointr_work/PoinTr/tools'"'"', '"'"'/home/jovyan/adapointr_work/PoinTr'"'"', '"'"'/home/jovyan/adapointr_work/PoinTr/third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider'"'"', '"'"'/opt/conda/envs/adapointr-mamba/lib/python3.10/site-packages'"'"'];p=sys.argv.pop(1);runpy.run_path(p,run_name='"'"'__main__'"'"')' /home/jovyan/adapointr_work/PoinTr/tools/run_cranial_scqr_v12_rsd_r1b_v2.py --request /home/jovyan/adapointr_work/PoinTr/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_foldC_seed0_real_intervention_execution_request_v1_20261019.json --request-sha256 69c10ecbae5189c6934c5502d1ea5f5f498ee8977183f4c86fc802c8538974b0 --authorization /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/real_query_intervention_foldC_seed0_v1_20261019/control/authorization.json --authorization-sha256 f3f1c3b94f412a51f41b38409e88ec5e9400a8aab8f27cb8f1f2b283ec03c787 --runtime /home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/real_query_intervention_foldC_seed0_v1_20261019/control/runtime.json --runtime-sha256 e3be7be31d3d285ee1b108953bd5ce71a7e6278c9064acb0ed66c43b5cc415c3
code=$?
printf '%s\n' "$code" >/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/real_query_intervention_foldC_seed0_v1_20261019/control/exit_code.txt
exit "$code"
