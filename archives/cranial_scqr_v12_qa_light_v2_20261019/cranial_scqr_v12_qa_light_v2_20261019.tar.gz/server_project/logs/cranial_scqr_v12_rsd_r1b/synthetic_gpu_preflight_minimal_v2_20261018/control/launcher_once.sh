#!/bin/bash
set -u -o pipefail
umask 077
cd -- '/home/jovyan/adapointr_work/PoinTr' || exit 90
set -C
test -d '/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/control' || exit 91
test ! -e '/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/result' && test ! -L '/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/result' || exit 92
test ! -e '/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/control/started.json' && test ! -L '/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/control/started.json' || exit 92
test ! -e '/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/control/master.log' && test ! -L '/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/control/master.log' || exit 92
test ! -e '/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/control/pid.txt' && test ! -L '/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/control/pid.txt' || exit 92
test ! -e '/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/control/exit_code.txt' && test ! -L '/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/control/exit_code.txt' || exit 92
exec 3>'/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/control/master.log' || exit 93
printf '%s\n' "$" >'/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/control/pid.txt' || exit 94
export CUDA_VISIBLE_DEVICES='0'
export CUBLAS_WORKSPACE_CONFIG=':4096:8'
export OMP_NUM_THREADS='1'
export MKL_NUM_THREADS='1'
export PYTHONDONTWRITEBYTECODE='1'
'/usr/bin/timeout' '-k' '5' '600' '/opt/conda/envs/adapointr-mamba/bin/python3.10' '-I' '-S' '-B' '-c' 'import resource,runpy,sys;resource.setrlimit(resource.RLIMIT_FSIZE,(33554432,33554432));entry=sys.argv.pop(1);sys.argv[0]=entry;runpy.run_path(entry,run_name="__main__")' '/home/jovyan/adapointr_work/PoinTr/tools/run_cranial_scqr_v12_rsd_r1b_synthetic_gpu_preflight_minimal_v2.py' '--request' '/home/jovyan/adapointr_work/PoinTr/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_gpu_zero_update_preflight_execution_request_minimal_v2_20261018.json' '--request-sha256' '6849e9eddddc2f1a324ac7ae7c92f788b8a295410dac937a04cbae94e9a3d2df' '--authorization' '/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/control/authorization.json' '--authorization-sha256' '3447934aebd1c87593e90b1eea9dd7fcfa8973de4e7aaf56561b4cf205cdd121' '--runtime' '/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/control/runtime.json' '--runtime-sha256' '1891feec2a16ae3c6d271342d0f2d43a12e1641c09f023dd6f5422cd54ea9807' >&3 2>&1
rc=$?
printf '%s\n' "$rc" >'/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v2_20261018/control/exit_code.txt' || exit 95
exit "$rc"
