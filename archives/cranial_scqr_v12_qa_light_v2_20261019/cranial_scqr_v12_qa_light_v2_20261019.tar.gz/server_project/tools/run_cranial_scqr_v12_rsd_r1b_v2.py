#!/usr/bin/env python3
"""Single-fold R1-B adapter. Import is inert; execution needs a new hash chain.

Implementation-only tests may import pure guards. No synthetic or real model
execution is enabled by protocol confirmation or an implementation receipt.
"""

import argparse
import csv
import hashlib
import importlib.metadata
import json
import math
import os
import random
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
ROOT = TOOLS.parent
if str(TOOLS) not in sys.path:
    sys.path.insert(0, str(TOOLS))
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import cranial_scqr_v12_rsd_r1b_contract_v2 as c
import shlex
import shutil


def json_read(path):
    with Path(path).open(encoding="utf-8") as stream:
        return json.load(stream)


def json_exclusive(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def safe_json(value):
    if isinstance(value, dict):
        return {key: safe_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [safe_json(item) for item in value]
    if isinstance(value, float) and not math.isfinite(value):
        return {"value": None, "missing_reason": "nonfinite", "raw": str(value)}
    return value


def migration_counts(rows):
    counts = {"both_flag_0": 0, "native_only": 0, "off_only": 0, "both_event": 0}
    labels = {(0, 0): "both_flag_0", (1, 0): "native_only", (0, 1): "off_only", (1, 1): "both_event"}
    for row in rows:
        flags = (row["native_disaster"], row["off_disaster"])
        c.require(flags in labels, "nonbinary event transition")
        counts[labels[flags]] += 1
    counts["native_zero_contact_count"] = sum(row["native_zero_contact"] for row in rows)
    counts["off_zero_contact_count"] = sum(row["off_zero_contact"] for row in rows)
    return counts



def checked_authorization_paths(args):
    """Check all three original paths before any chain hash or JSON read.

    Reject lexical traversal and every symlink component without resolving the
    argument first. This retains the existing checked_path guard, not an
    OS-hard isolation or concurrent-filesystem-race guarantee.
    """
    checked = []
    root = ROOT.absolute()
    for name in ("request", "authorization", "runtime"):
        original = Path(getattr(args, name))
        c.require(".." not in original.parts, "authorization chain traversal: " + name)
        original = original if original.is_absolute() else Path.cwd() / original
        try:
            relative = original.relative_to(root)
        except ValueError:
            raise c.ContractError("authorization chain path outside project: " + name)
        path = c.checked_path(root, relative)
        checked.append((path, getattr(args, name + "_sha256")))
    return checked


def text_execution_preconditions(args):
    """Authorization rejection precedes ALL implementation/checkpoint/data reads."""
    c.require(ROOT.resolve() == Path("/home/jovyan/adapointr_work/PoinTr"), "execution must run in canonical server root")
    paths = checked_authorization_paths(args)
    for path, digest in paths:
        c.require(c.sha256_file(path) == digest, "execution chain SHA mismatch")
    request, auth, runtime = (json_read(path) for path, _digest in paths)
    c.validate_chain(request, auth, runtime, args.request_sha256, args.authorization_sha256)
    environment = request["environment_contract"]
    c.require(sys.version.split()[0] == environment["python_version"], "Python environment drift")
    for package in ("torch", "numpy", "scipy"):
        c.require(importlib.metadata.version(package) == environment[package + "_version"], "package environment drift: " + package)
    for binding in environment["binary_bindings"] + environment["extension_source_bindings"]:
        c.bound_path(ROOT, binding)
    output = ROOT / request["output_relative"]
    relative = Path(request["output_relative"])
    c.require(not relative.is_absolute() and ".." not in relative.parts and relative.parts[:2] == ("logs", "cranial_scqr_v12_rsd_r1b"), "output path outside R1-B namespace")
    c.require(not output.exists() and output.parent.is_dir(), "output must be new with verified existing parent")
    c.require(output.resolve().parent == output.parent.resolve(), "output parent resolution")
    try:
        output.parent.resolve().relative_to(ROOT.resolve())
    except ValueError:
        raise c.ContractError("output parent escapes project")
    for binding in request["implementation_bindings"]:
        c.bound_path(ROOT, binding)
    confirmation = json_read(c.bound_path(ROOT, request["protocol_confirmation"]))
    c.require(confirmation.get("status") == "CONFIRMED_PROTOCOL_ONLY" and confirmation.get("protocol_sha256") == c.PROTOCOL_SHA, "protocol confirmation missing")
    protocol_source = c.bound_path(ROOT, request["protocol_source"])
    c.require(c.sha256_file(protocol_source) == c.PROTOCOL_SHA, "confirmed protocol source bytes differ")
    p3 = json_read(c.bound_path(ROOT, request["post_implementation_p3"]))
    c.require(p3.get("status") == "PASS_IMPLEMENTATION_ONLY" and p3.get("gpu_used") is False, "P3 missing")
    tolerance = c.small_json(ROOT, request["native_replay_tolerances"])
    confirmation = c.small_json(ROOT, request["tolerance_confirmation"])
    c.validate_tolerance_confirmation(tolerance, confirmation)
    c.read_preflight_chain(ROOT, request)
    validate_launch_preconditions(request)
    allow_path = c.bound_path(ROOT, request["allowlist"])
    allow_sha = {"C": "0bc9286bea354c60870818e47207a9da7f156704557f366ef27847d589f5c0b0",
                 "D": "7afc9edc6654891cc8593ab2ce172657e1227e4583ed3281b159ab3ae2be68ac"}
    c.require(request["allowlist"]["sha256"] == allow_sha[request["fold"]], "allowlist changed")
    case_ids = [line.strip() for line in allow_path.read_text().splitlines() if line.strip()]
    c.require(len(case_ids) == len(set(case_ids)) == 105, "allowlist cardinality")
    # Payload/checkpoint binding verification starts only after the text chain.
    for model in request["models"].values():
        for key in ("checkpoint", "model_config", "reference_csv", "bncal_receipt"):
            c.bound_path(ROOT, model[key])
        bncal = json_read(c.bound_path(ROOT, model["bncal_receipt"]))
        c.require(bncal.get("status") == "PASS" and bncal.get("run_key") == model["run_key"] and
                  bncal.get("bncal_checkpoint_sha256") == model["checkpoint"]["sha256"] and
                  bncal.get("parameters_unchanged") is True and bncal.get("development_payload_opened") == 0,
                  "BNCal parent receipt failed")
    return request, case_ids, output, tolerance


def canonical_tensor_hash(mapping):
    """RSD canonical-state-v1, length-delimited UTF8 metadata and little-endian raw bytes."""
    c.require(sys.byteorder == "little", "unsupported canonical state host byte order")
    digest = hashlib.sha256(b"RSD-canonical-state-v1\0")
    for name, tensor in sorted(mapping.items()):
        array = tensor.detach().cpu().contiguous().numpy()
        parts = (name.encode("utf-8"), str(array.dtype).encode("ascii"),
                 json.dumps(list(array.shape), separators=(",", ":")).encode("ascii"), array.tobytes(order="C"))
        for part in parts:
            digest.update(len(part).to_bytes(8, "little"))
            digest.update(part)
    return digest.hexdigest()


def state_hashes(model):
    return {"parameters": canonical_tensor_hash(dict(model.named_parameters())),
            "buffers": canonical_tensor_hash(dict(model.named_buffers()))}


def snapshot_rng(torch, np):
    return (random.getstate(), np.random.get_state(), torch.random.get_rng_state().clone(),
            [state.clone() for state in torch.cuda.get_rng_state_all()])


def restore_rng(torch, np, states):
    random.setstate(states[0])
    np.random.set_state(states[1])
    torch.random.set_rng_state(states[2])
    torch.cuda.set_rng_state_all(states[3])


def points_member(sample, member, ledger, np):
    ledger.read_member(member)
    c.require(member in sample.files, "missing NPZ member")
    array = np.asarray(sample[member], dtype=np.float32).copy()
    c.require(array.shape == (8192, 3) and bool(np.isfinite(array).all()), "8192x3 finite member required")
    return array


def extra_geometry(pred, coarse, arrays, record):
    """Post-forward diagnostics only; reuse original world/NN primitives."""
    import numpy as np
    from utils.skullfix_metrics import normalized_to_world, directed_nearest_neighbor_distances as nn

    norm = record["normalization"]
    world = lambda x: normalized_to_world(x, norm["centroid"], norm["scale"])
    partial, target, predicted, coarse_world = map(world, (arrays["partial"], arrays["implant"], pred, coarse))
    reference_mask, predicted_mask = nn(partial, target) <= 2.0, nn(partial, predicted) <= 2.0
    a, b = partial[predicted_mask], partial[reference_mask]
    c.require(len(a) > 0 and len(b) > 0, "R1B_NONFINITE_CONTACT_OR_EMPTY_FOOTPRINT")
    ab, ba = nn(a, b), nn(b, a)
    coarse_distances = nn(b, coarse_world)
    center_coarse, center_target = coarse_world.mean(0), target.mean(0)
    rc = float(np.sqrt(np.square(coarse_world - center_coarse).sum(1).mean()))
    rt = float(np.sqrt(np.square(target - center_target).sum(1).mean()))
    c.require(math.isfinite(rt) and rt > 0, "invalid GT radius")
    out = {
        "contact_pred_to_ref_mean_mm": float(ab.mean()), "contact_pred_to_ref_p95_mm": float(np.percentile(ab, 95)),
        "contact_ref_to_pred_mean_mm": float(ba.mean()), "contact_ref_to_pred_p95_mm": float(np.percentile(ba, 95)),
        "contact_intersection_points": int(np.logical_and(reference_mask, predicted_mask).sum()),
        "coarse_rimcover_p95_mm": float(np.percentile(coarse_distances, 95)),
        "coarse_rim_support_2mm": float((coarse_distances <= 2.0).mean()),
        "coarse_gt_centroid_distance_mm": float(np.linalg.norm(center_coarse - center_target)),
        "coarse_gt_rms_radius_ratio": rc / rt,
    }
    c.require(all(math.isfinite(value) for value in out.values()), "nonfinite extra geometry")
    return out


class BoundedCSV:
    def __init__(self, path, fields, budget):
        self.stream = path.open("x", encoding="utf-8", newline="")
        self.writer = csv.DictWriter(self.stream, fieldnames=fields)
        self.writer.writeheader()
        self.budget = budget
        self.previous_size = 0

    def write(self, row):
        self.writer.writerow(row)
        self.stream.flush()
        self.budget["bytes"] += self.stream.tell() - self.previous_size
        self.previous_size = self.stream.tell()
        c.require(self.budget["bytes"] <= 16 * 1024 * 1024, "scalar output byte budget exceeded")

    def close(self):
        self.stream.close()


def run_authorized(args):
    started_monotonic = time.monotonic()
    request, case_ids, output, tolerance = text_execution_preconditions(args)
    # No torch/np/CUDA/model import above this line.
    c.require(os.environ.get("CUBLAS_WORKSPACE_CONFIG") == ":4096:8", "CUBLAS environment must be set by authorized launcher")
    c.require(os.environ.get("OMP_NUM_THREADS") == "1" and os.environ.get("MKL_NUM_THREADS") == "1", "thread environment must be frozen before imports")
    gpu = subprocess.check_output(["nvidia-smi", "--query-gpu=uuid,name,driver_version", "--format=csv,noheader"], text=True).strip().splitlines()
    c.require(len(gpu) == 1 and gpu[0].split(",", 1)[0].strip() == request["resource"]["gpu_uuid"], "GPU UUID mismatch")
    c.require(gpu[0].split(",")[2].strip() == request["environment_contract"]["gpu_driver"], "GPU driver drift")
    compute_pids = subprocess.check_output(["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"], text=True).strip()
    c.require(not compute_pids, "GPU already has compute processes; stop")
    prepare_provider_paths()
    import numpy as np
    import torch
    import run_cranial_scqr_v12_qa1_development_eval as qa
    torch.set_float32_matmul_precision("highest")

    numerical_before = qa.configure_numerical_policy(torch)
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    c.require(torch.version.cuda == request["environment_contract"]["cuda_version"] and
              torch.backends.cudnn.version() == request["environment_contract"]["cudnn_version"], "CUDA/cuDNN environment drift")
    c.require(torch.cuda.device_count() == 1 and torch.cuda.get_device_name(0) == "NVIDIA GeForce RTX 4090 D", "one RTX4090D required")
    entry_numerical_before = assert_entry_numerical(torch)
    c.require(torch.cuda.get_device_properties(0).total_memory == c.RESOURCE["cuda_device_total_memory_bytes"], "CUDA byte identity")
    assert_compiled_provider()

    data_root = Path(request["data_root"]).resolve()
    manifest_path = data_root / "manifest.jsonl"
    c.require(c.sha256_file(manifest_path) == "f1f8cae47ed7d5529dc2ca244179cedddbc039981cdc0ff24b25a5c81ad30538", "manifest SHA mismatch")
    records = qa._load_manifest(manifest_path, data_root, case_ids)
    for rec in records.values():
        n = rec["normalization"]
        c.require(len(n["centroid"]) == 3 and all(math.isfinite(float(x)) for x in n["centroid"]) and
                  math.isfinite(float(n["scale"])) and float(n["scale"]) > 0, "invalid normalization metadata")
    sources = {}
    for rec in records.values():
        sources.setdefault(rec["source_skull_id"], []).append(rec["defect_type"])
    c.require(len(sources) == 21 and all(len(ds) == 5 and set(ds) == set(c.DEFECTS) for ds in sources.values()), "source/defect matrix")
    reference = {candidate: c.read_native_csv(c.bound_path(ROOT, model["reference_csv"]), case_ids)
                 for candidate, model in request["models"].items()}
    output.mkdir(exist_ok=False)
    json_exclusive(output / "invocation.json", {"request_sha256": args.request_sha256,
                   "authorization_sha256": args.authorization_sha256, "runtime_sha256": args.runtime_sha256,
                   "started_at_utc": utc_now(), "numerical_before": numerical_before, "entry_numerical_before": entry_numerical_before})
    ledger = c.AccessLedger(case_ids, request["fold"])
    # The two preconditions checkpoint SHA checks completed before ledger creation.
    ledger.record_checkpoint_hash()
    ledger.record_checkpoint_hash()
    models, rng_streams, before = {}, {}, {}
    writers = []
    rows = []
    last_case = None
    last_row = None
    try:
        for candidate in ("LS", "LSQ"):
            b = request["models"][candidate]
            ledger.record_checkpoint_hash()
            model = qa.v11._load_model(c.bound_path(ROOT, b["model_config"]), c.bound_path(ROOT, b["checkpoint"]), ledger, b["run_key"]).to("cuda:0")
            model.eval()
            # RSD collects only outlet scalars: no heavy/GT-positive v1.1 diagnostics.
            model.enable_full_instrumentation(False)
            models[candidate] = model
            before[candidate] = state_hashes(model)
            rng_streams[candidate] = snapshot_rng(torch, np)
        identity_fields = ("condition", "fold", "seed", "case_id", "skull_id", "source_skull_id", "defect_type")
        query_fields = ("query_applicable", "query_missing_reason", "query_outlet_calls", "alpha_q", "query_warmup", "query_rms",
                        "potential_residual_rms", "applied_residual_rms", "relative_potential_residual_rms",
                        "attention_entropy_mean", "effective_proxy_count_mean", "attention_max_weight_mean")
        extra_fields = ("contact_pred_to_ref_mean_mm", "contact_pred_to_ref_p95_mm", "contact_ref_to_pred_mean_mm",
                        "contact_ref_to_pred_p95_mm", "contact_intersection_points", "coarse_rimcover_p95_mm",
                        "coarse_rim_support_2mm", "coarse_gt_centroid_distance_mm", "coarse_gt_rms_radius_ratio")
        scalar_budget = {"bytes": 0}
        writer = BoundedCSV(output / "per_condition_case_metrics.csv", identity_fields + c.CONTINUOUS + c.EXACT_METRICS + extra_fields + query_fields + ("contact_hd95_margin_mm",), scalar_budget)
        writers.append(writer)
        with torch.no_grad():
            for case_id in case_ids:
                last_case = case_id
                record = records[case_id]
                ledger.begin_case(case_id)
                with np.load(record["resolved_point_path"], allow_pickle=False) as sample:
                    arrays = {"partial": points_member(sample, "partial", ledger, np)}
                    partial = torch.from_numpy(arrays["partial"]).unsqueeze(0).to(device="cuda:0", dtype=torch.float32)
                    preds, diagnostics = {}, {}
                    lsq_pre = rng_streams["LSQ"]
                    for condition in c.CONDITIONS:
                        c.require(time.monotonic() - started_monotonic <= request["max_wall_seconds"], "frozen wall-time budget exceeded")
                        candidate = "LS" if condition == "LS_native" else "LSQ"
                        model = models[candidate]
                        c.require(not model.training, "model left eval mode")
                        restore_rng(torch, np, lsq_pre if condition == "LSQ_query_off" else rng_streams[candidate])
                        diagnostic = {}
                        ledger.begin_forward(condition)
                        result = model(partial, epoch=None, rsd_condition=condition, rsd_diagnostics=diagnostic)
                        c.require(isinstance(result, (tuple, list)) and len(result) == 2 and
                                  all(bool(torch.isfinite(t).all()) for t in result), "invalid/nonfinite forward output")
                        c.require(torch.cuda.max_memory_reserved(0) <= request["max_vram_mib"] * 1024 * 1024,
                                  "frozen VRAM budget exceeded")
                        c.validate_memory(int(torch.cuda.max_memory_allocated(0)), int(torch.cuda.max_memory_reserved(0)))
                        ledger.end_forward()
                        if condition != "LSQ_query_off":
                            rng_streams[candidate] = snapshot_rng(torch, np)
                        if candidate == "LSQ":
                            c.require(diagnostic.get("query_outlet_calls") == 1, "RSD outlet not traversed once")
                        preds[condition] = tuple(t.squeeze(0).detach().cpu().numpy() for t in result)
                        diagnostics[condition] = diagnostic
                        del result
                    restore_rng(torch, np, rng_streams["LSQ"])
                    c.require(np.array_equal(preds["LSQ_native"][0], preds["LSQ_query_off"][0]),
                              "query outlet changed upstream coarse anchors; stop before GT read")
                    arrays["implant"] = points_member(sample, "implant", ledger, np)
                    arrays["gt"] = points_member(sample, "gt", ledger, np)
                case_rows = []
                for condition in c.CONDITIONS:
                    coarse, implant = preds[condition]
                    metric, _coarse = qa.v11._metric_rows(implant, coarse, arrays, record)
                    identity = {"condition": condition, "fold": request["fold"], "seed": 0,
                                "case_id": case_id, "skull_id": record["skull_id"],
                                "source_skull_id": record["source_skull_id"], "defect_type": record["defect_type"]}
                    last_row = {**identity, **metric}
                    c.audit_metric_flags(metric)
                    candidate = "LS" if condition == "LS_native" else "LSQ"
                    if condition.endswith("native"):
                        c.assert_native_replay(last_row, reference[candidate][case_id], tolerance)
                    extra = extra_geometry(implant, coarse, arrays, record)
                    query = {key: diagnostics[condition].get(key) for key in query_fields}
                    if condition == "LS_native":
                        query["query_missing_reason"] = "not_applicable"
                    row = {**last_row, **extra, **query, "contact_hd95_margin_mm": metric["rim_contact_hd95_mm"] - 50.0}
                    writer.write(row)
                    rows.append(row)
                    case_rows.append(row)
                for candidate in ("LS", "LSQ"):
                    c.require(canonical_tensor_hash(dict(models[candidate].named_buffers())) == before[candidate]["buffers"], "buffer changed within case")
                ledger.end_case()
                del partial, arrays, preds, diagnostics, case_rows
        ledger.assert_final()
        after = {candidate: state_hashes(model) for candidate, model in models.items()}
        c.require(before == after, "parameter/buffer state changed")
        numerical_after = qa.assert_numerical_policy(torch)
        entry_numerical_after = assert_entry_numerical(torch)
        c.require(entry_numerical_before == entry_numerical_after, "entry numerical policy drift")
        paired = []
        for i in range(0, len(rows), 3):
            ls, native, off = rows[i:i + 3]
            item = {k: off[k] for k in ("fold", "seed", "case_id", "source_skull_id", "defect_type")}
            item.update({"native_disaster": native["disaster"], "off_disaster": off["disaster"],
                         "native_zero_contact": native["zero_contact_2mm"], "off_zero_contact": off["zero_contact_2mm"]})
            item.update({"off_minus_native_" + k: off[k] - native[k] for k in c.CONTINUOUS})
            paired.append(item)
        paired_writer = BoundedCSV(output / "paired_intervention_case_deltas.csv", tuple(paired[0]), scalar_budget)
        writers.append(paired_writer)
        for row in paired:
            paired_writer.write(row)
        groups = {}
        for row in paired:
            groups.setdefault(row["source_skull_id"], []).append(row)
        source_rows = [{"source_skull_id": source, "event_transitions": migration_counts(values), **{
            "off_minus_native_" + key: sum(row["off_minus_native_" + key] for row in values) / 5.0
            for key in c.CONTINUOUS}} for source, values in sorted(groups.items())]
        transitions = migration_counts(paired)
        json_exclusive(output / "fold_descriptive_summary.json", {
            "source_rows": source_rows, "source_equal_weight_delta": {
                "off_minus_native_" + k: sum(row["off_minus_native_" + k] for row in source_rows) / 21.0 for k in c.CONTINUOUS},
            "by_defect_delta": {defect: {"off_minus_native_" + k: sum(row["off_minus_native_" + k] for row in paired if row["defect_type"] == defect) / 21.0 for k in c.CONTINUOUS} for defect in c.DEFECTS},
            "by_defect_event_transitions": {defect: migration_counts([row for row in paired if row["defect_type"] == defect]) for defect in c.DEFECTS},
            "disaster_transitions": transitions, "formal_gate": False, "bootstrap": False,
            "mechanism_classification": None, "automatic_next_fold": False})
        json_exclusive(output / "native_replay_audit.json", {
            "status": "PASS_NATIVE_METRIC_REPLAY_ONLY", "cases_checked": {"LS_native": 105, "LSQ_native": 105},
            "tolerance_binding": request["native_replay_tolerances"],
            "native_csv_bindings": {key: value["reference_csv"] for key, value in request["models"].items()},
            "identity_or_exact_flag_mismatches": 0, "continuous_tolerance_exceedances": 0,
            "prediction_coordinate_equality_tested": False})
        c.require(sum(path.stat().st_size for path in output.iterdir() if path.is_file()) + 32768 <= request["output_limit_bytes"], "final output receipt budget exceeded")
        json_exclusive(output / "execution_receipt.json", {"status": "PASS_R1B_SINGLE_FOLD_DESCRIPTIVE_ONLY",
            "fold": request["fold"], "finished_at_utc": utc_now(), "counts": ledger.counts,
            "state_before": before, "state_after": after, "numerical_before": numerical_before,
            "numerical_after": numerical_after, "entry_numerical_before": entry_numerical_before,
            "entry_numerical_after": entry_numerical_after, "predictions_saved": False, "formal_gate": False,
            "peak_vram_reserved_bytes": int(torch.cuda.max_memory_reserved(0)),
            "automatic_retry": False, "automatic_next_fold": False, "state_hash_format": "RSD-canonical-state-v1"})
    except Exception as exc:
        ledger.failed = True
        # Do not reload/repair a mutated model; capture what remains observable.
        try:
            after_failure = {candidate: state_hashes(model) for candidate, model in models.items()}
        except Exception:
            after_failure = {"unavailable": True}
        json_exclusive(output / "failure_receipt.json", safe_json({"status": "FAILED_STOPPED_NO_RETRY",
            "error_type": type(exc).__name__, "error": str(exc), "last_case_id": last_case,
            "last_metric_row": last_row, "counts": ledger.counts, "state_before": before,
            "state_after_failure": after_failure, "formal_gate": False, "automatic_retry": False,
            "automatic_next_fold": False}))
        raise
    finally:
        for writer in writers:
            writer.close()
    # Success artifacts are bounded and indexed only after writers close.
    try:
        files = [path for path in output.iterdir() if path.is_file()]
        c.require(sum(path.stat().st_size for path in files) + 4096 <= request["output_limit_bytes"], "final output size cap")
        with (output / "files.sha256").open("x", encoding="utf-8") as stream:
            for path in sorted(files):
                stream.write(c.sha256_file(path) + "  " + path.name + "\n")
    except Exception as exc:
        json_exclusive(output / "failure_receipt.json", {"status": "FAILED_FINAL_FREEZE_NO_RETRY",
            "error_type": type(exc).__name__, "error": str(exc), "counts": ledger.counts,
            "automatic_retry": False, "automatic_next_fold": False})
        raise
    return 0



def prepare_provider_paths():
    c.require(sys.flags.isolated == 1 and sys.flags.no_site == 1 and sys.dont_write_bytecode,
              "authorized launcher requires -I -S -B")
    c.require(not any(k == "pointnet2_ops" or k.startswith("pointnet2_ops.") for k in sys.modules),
              "provider imported before authorized binding")
    provider = ROOT / c.PROVIDER_RELATIVE
    site = Path("/opt/conda/envs/adapointr-mamba/lib/python3.10/site-packages")
    # Same fixed dependency order as the v7 launcher; no .pth execution.
    fixed = [str(TOOLS), str(ROOT), str(provider), str(site)]
    sys.path[:] = fixed + [p for p in sys.path if p not in fixed]


def assert_compiled_provider():
    import pointnet2_ops._ext as native
    from pointnet2_ops import pointnet2_utils as wrapper
    from utils import pointnet2_utils as adapter
    c.validate_provider_origins(ROOT, {"native": str(Path(native.__file__).resolve()),
        "wrapper": str(Path(wrapper.__file__).resolve()), "adapter": str(Path(adapter.__file__).resolve())},
        adapter.using_fallback(), all(getattr(adapter, n) is getattr(wrapper, n)
        for n in ("furthest_point_sample", "gather_operation")))


def validate_launch_preconditions(request):
    c.require(str(Path(sys.executable).resolve()) == c.RESOURCE["python_realpath"], "Python realpath")
    binary = Path(c.RESOURCE["python_realpath"])
    c.require(not binary.is_symlink() and binary.stat().st_size == 17331920 and
              c.sha256_file(binary) == c.RESOURCE["python_binary_sha256"], "Python binary drift")
    c.require(shutil.disk_usage(ROOT).free >= 2147483648, "disk free")
    raw = subprocess.run(["nvidia-smi", "--query-gpu=name,uuid,driver_version,memory.total,memory.used,utilization.gpu",
        "--format=csv,noheader,nounits"], check=True, capture_output=True, timeout=10).stdout
    fields = raw.decode("utf-8", errors="strict").strip().split(",")
    c.require(len(fields) == 6, "smi schema")
    name, uuid, driver = [p.strip() for p in fields[:3]]
    total, used, util = [int(p.strip()) for p in fields[3:]]
    c.require(name == c.RESOURCE["gpu_name"] and uuid == c.RESOURCE["gpu_uuid"] and
              driver == c.RESOURCE["driver_version"] and total == 24564 and
              total-used >= 22000 and util == 0, "launch GPU resource")
    c.require(not subprocess.run(["nvidia-smi","--query-compute-apps=pid","--format=csv,noheader,nounits"],
              check=True, capture_output=True, timeout=10).stdout.strip(), "unknown GPU process")


def assert_entry_numerical(torch):
    actual = {"deterministic_algorithms":torch.are_deterministic_algorithms_enabled(),
        "warn_only":torch.is_deterministic_algorithms_warn_only_enabled(),
        "cudnn_deterministic":torch.backends.cudnn.deterministic, "cudnn_benchmark":torch.backends.cudnn.benchmark,
        "matmul_allow_tf32":torch.backends.cuda.matmul.allow_tf32, "cudnn_allow_tf32":torch.backends.cudnn.allow_tf32,
        "float32_matmul_precision":torch.get_float32_matmul_precision(),
        "CUBLAS_WORKSPACE_CONFIG":os.environ.get("CUBLAS_WORKSPACE_CONFIG"),
        "OMP_NUM_THREADS":os.environ.get("OMP_NUM_THREADS"), "MKL_NUM_THREADS":os.environ.get("MKL_NUM_THREADS"),
        "torch_num_threads":torch.get_num_threads(), "torch_num_interop_threads":torch.get_num_interop_threads()}
    c.require(actual == c.NUMERICAL, "strict numerical/TF32/thread drift")
    return actual


def caller_capture_contract(stdout, stderr, returncode):
    c.require(type(stdout) is bytes and type(stderr) is bytes and type(returncode) is int, "raw byte capture required")
    return {"stdout_utf8":stdout.decode("utf-8", errors="replace"), "stderr_utf8":stderr.decode("utf-8", errors="replace"),
            "stderr_sha256":hashlib.sha256(stderr).hexdigest(), "exit_code":returncode,
            "powershell_terminal_statement":"exit $LASTEXITCODE", "wsl_entry":"--exec"}


def render_launcher(request, request_sha, auth_sha, runtime_sha):
    c.validate_request(request)
    paths = request["launch_paths"]
    c.require(set(paths) == {"request","authorization","runtime","entry","control"} and
              paths["entry"] == "tools/run_cranial_scqr_v12_rsd_r1b_v2.py", "launch paths")
    for value in paths.values():
        p = Path(value)
        c.require(not p.is_absolute() and ".." not in p.parts and
                  "\n" not in value and "\r" not in value, "unsafe launcher path")
    c.require(paths["control"].startswith("logs/cranial_scqr_v12_rsd_r1b/") and
              request["output_relative"].startswith(paths["control"].rsplit("/",1)[0] + "/"), "launch namespace")
    for digest in (request_sha, auth_sha, runtime_sha):
        c.require(len(digest) == 64 and all(k in "0123456789abcdef" for k in digest), "launcher hash")
    quote = shlex.quote
    control = str(ROOT / paths["control"])
    boot = ("import resource,runpy,sys;resource.setrlimit(resource.RLIMIT_FSIZE,(33554432,33554432));"
            "sys.path[:0]=" + repr([str(TOOLS),str(ROOT),str(ROOT/c.PROVIDER_RELATIVE),
            "/opt/conda/envs/adapointr-mamba/lib/python3.10/site-packages"]) +
            ";p=sys.argv.pop(1);runpy.run_path(p,run_name='__main__')")
    argv = [c.RESOURCE["python_realpath"],"-I","-S","-B","-c",boot,str(ROOT/paths["entry"])]
    for key, sha in (("request",request_sha),("authorization",auth_sha),("runtime",runtime_sha)):
        argv += ["--"+key,str(ROOT/paths[key]),"--"+key+"-sha256",sha]
    lines = ["#!/bin/bash", "set -euC", "cd " + quote(str(ROOT)),
        "mkdir -p -- " + quote(control), "test -d " + quote(control),
        "exec 3>" + quote(control+"/master.log"), "exec 1>&3 2>&1",
        "printf '%s\\n' \"$$\" >" + quote(control+"/pid.txt"),
        "export CUBLAS_WORKSPACE_CONFIG=:4096:8 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 MPLBACKEND=Agg",
        "set +e", "/usr/bin/timeout -k 5 7200 " + " ".join(quote(v) for v in argv),
        "code=$?", "printf '%s\\n' \"$code\" >" + quote(control+"/exit_code.txt"), "exit \"$code\""]
    return "\n".join(lines) + "\n"


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("request", "authorization", "runtime"):
        parser.add_argument("--" + name, required=True, type=Path)
        parser.add_argument("--" + name + "-sha256", required=True)
    args = parser.parse_args(argv)
    return run_authorized(args)


if __name__ == "__main__":
    raise SystemExit(main())
