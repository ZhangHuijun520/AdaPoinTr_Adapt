#!/usr/bin/env python
"""Single-run train-only BatchNorm calibration for Cranial-SCQR v1.2 QA-1."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import random
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from tools import builder  # noqa: E402
from utils.config import cfg_from_yaml_file  # noqa: E402


VERSION = "cranial-scqr-v1.2-QA1-bncal-v1"
STAGE = "V12_QA1_bncal"
SOURCE_STATE_VERSION = "cranial-scqr-v1.2-QA1-training-execution-state-v1"
SOURCE_STATE_STATUS = "training_complete_pending_separate_bncal_authorization"
SOURCE_COMPLETION_STATUS = "TRAINING_PASS_PENDING_SEPARATE_BNCAL_AUTHORIZATION"
FORMAL_CONFIG_PROTOCOL_ID = "cranial-scqr-v1.2-QA1-formal-config-v1"
EXPECTED_CASES = 315
EXPECTED_BATCHES = 40
EXPECTED_SOURCES = 63
EXPECTED_STEPS = 3939
EXPECTED_TRAVERSALS = 101
EXPECTED_DEFECTS = {
    "bilateral",
    "frontoorbital",
    "parietotemporal",
    "random_1",
    "random_2",
}


def assert_bncal_numeric_policy(torch_api=None) -> dict:
    api = torch if torch_api is None else torch_api
    policy = {
        "deterministic_algorithms": api.are_deterministic_algorithms_enabled(),
        "deterministic_warn_only": api.is_deterministic_algorithms_warn_only_enabled(),
        "cuda_matmul_allow_tf32": api.backends.cuda.matmul.allow_tf32,
        "cudnn_allow_tf32": api.backends.cudnn.allow_tf32,
        "cudnn_deterministic": api.backends.cudnn.deterministic,
        "cudnn_benchmark": api.backends.cudnn.benchmark,
        "cublas_workspace_config": os.environ.get("CUBLAS_WORKSPACE_CONFIG"),
    }
    expected = {
        "deterministic_algorithms": True, "deterministic_warn_only": False,
        "cuda_matmul_allow_tf32": False, "cudnn_allow_tf32": False,
        "cudnn_deterministic": True, "cudnn_benchmark": False,
        "cublas_workspace_config": ":4096:8",
    }
    if policy != expected:
        raise RuntimeError(f"QA-1 BNCal numerical policy drifted: {policy}")
    return policy


def configure_bncal_numeric_policy(config, torch_api=None):
    execution = config.cranial_scqr_execution
    if str(execution.stage) != STAGE or execution.bncal_authorized is not True:
        raise RuntimeError("Strict numerical policy requires authorized QA-1 BNCal")
    if os.environ.get("CUBLAS_WORKSPACE_CONFIG") != ":4096:8":
        raise RuntimeError("CUBLAS_WORKSPACE_CONFIG=:4096:8 required before launch")
    api = torch if torch_api is None else torch_api
    api.use_deterministic_algorithms(True, warn_only=False)
    api.backends.cuda.matmul.allow_tf32 = False
    api.backends.cudnn.allow_tf32 = False
    api.backends.cudnn.deterministic = True
    api.backends.cudnn.benchmark = False
    return assert_bncal_numeric_policy(api)


def validate_bncal_numeric_request(request):
    numerical = request.get("resource_binding", {})
    if (numerical.get("deterministic_algorithms") is not True
            or numerical.get("tf32") is not False
            or numerical.get("cublas_workspace_config") != ":4096:8"):
        raise RuntimeError("QA-1 BNCal request numerical contract drifted")


def canonical_json(payload: dict) -> bytes:
    return (
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n"
    ).encode("utf-8")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def tensor_map_sha256(items) -> str:
    digest = hashlib.sha256()
    for name, tensor in sorted(items):
        value = tensor.detach().cpu().contiguous()
        digest.update(name.encode("utf-8") + b"\0")
        digest.update(str(value.dtype).encode("ascii") + b"\0")
        digest.update(str(tuple(value.shape)).encode("ascii") + b"\0")
        digest.update(value.numpy().tobytes())
    return digest.hexdigest()


def resolve_repo_path(value: str) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = REPO_ROOT / path
    return path.resolve()


def load_bound_json(path_value: str, expected_sha256: str, label: str) -> tuple[Path, dict]:
    path = resolve_repo_path(path_value)
    if not path.is_file() or sha256_file(path) != expected_sha256:
        raise RuntimeError(f"{label} path or SHA256 binding is invalid")
    return path, json.loads(path.read_text(encoding="utf-8"))


def read_ids(path: Path) -> list[str]:
    values = [
        line.strip()
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]
    if len(values) != EXPECTED_CASES or len(set(values)) != EXPECTED_CASES:
        raise RuntimeError("BNCal train allowlist must contain 315 unique cases")
    return values


def source_id(case_id: str) -> str:
    parts = case_id.split("__")
    if len(parts) != 3 or parts[0] != "train":
        raise RuntimeError(f"Invalid development84 train case ID: {case_id}")
    return parts[1]


class PartialOnlyDataset(Dataset):
    """Open only the NPZ partial member; implant/GT is never indexed."""

    def __init__(self, config):
        others = config.dataset.train.others
        data_root = Path(str(others.DATA_ROOT)).expanduser()
        if not data_root.is_absolute():
            data_root = REPO_ROOT / data_root
        self.data_root = data_root.resolve()
        manifest = Path(str(config.dataset.train._base_.MANIFEST)).expanduser()
        if not manifest.is_absolute():
            manifest = self.data_root / manifest
        self.manifest_path = manifest.resolve()
        allowlist = resolve_repo_path(str(others.include_case_ids_file))
        self.allowlist_path = allowlist
        self.case_ids = read_ids(allowlist)
        allowed = set(self.case_ids)

        records = {}
        with self.manifest_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                record = json.loads(line)
                case_id = str(record.get("case_id", ""))
                if case_id not in allowed:
                    continue
                if record.get("official_split") != "train":
                    raise RuntimeError(f"BNCal case is outside official train: {case_id}")
                if record.get("monitor_split") == "monitor":
                    raise RuntimeError(f"BNCal case is in old monitor: {case_id}")
                if case_id in records:
                    raise RuntimeError(f"Duplicate BNCal manifest case: {case_id}")
                records[case_id] = record
        if set(records) != allowed:
            raise RuntimeError("BNCal manifest and train allowlist case sets differ")
        sources = {source_id(value) for value in self.case_ids}
        defects = {value.split("__")[2] for value in self.case_ids}
        if len(sources) != EXPECTED_SOURCES or defects != EXPECTED_DEFECTS:
            raise RuntimeError("BNCal source/defect identity drifted")
        self.records = [records[value] for value in self.case_ids]
        self.opened_case_ids: list[str] = []

    def __len__(self):
        return len(self.records)

    def __getitem__(self, index):
        record = self.records[index]
        point_path = Path(str(record["point_path"])).expanduser()
        if not point_path.is_absolute():
            point_path = self.data_root / point_path
        with np.load(point_path.resolve(), allow_pickle=False) as payload:
            if "partial" not in payload.files:
                raise RuntimeError(f"partial missing: {record['case_id']}")
            partial = payload["partial"].astype(np.float32, copy=True)
        if partial.shape != (8192, 3) or not np.isfinite(partial).all():
            raise RuntimeError(f"Invalid partial array: {record['case_id']}")
        self.opened_case_ids.append(str(record["case_id"]))
        return str(record["case_id"]), torch.from_numpy(partial)


def validate_execution(config, config_path: Path, experiment_dir: Path):
    execution = config.cranial_scqr_execution
    development = config.development_protocol
    qa1_lock = config.qa1_lock
    run_key = str(qa1_lock.run_key)
    if (
        str(execution.stage) != STAGE
        or bool(execution.training_authorized)
        or not bool(execution.bncal_authorized)
        or int(execution.optimizer_steps_authorized) != 0
        or int(execution.bncal_runs_authorized) != 1
        or int(execution.bncal_cases_expected) != EXPECTED_CASES
        or int(execution.bncal_batches_expected) != EXPECTED_BATCHES
        or bool(execution.development_payload_access_authorized)
        or bool(execution.development_evaluation_authorized)
        or bool(execution.resume_authorized)
        or bool(execution.automatic_rerun_authorized)
        or bool(execution.automatic_next_run_authorized)
        or int(development.seed) != 0
        or int(qa1_lock.seed) != 0
        or str(development.candidate) != str(qa1_lock.candidate)
        or str(development.fold) != str(qa1_lock.fold)
    ):
        raise RuntimeError("v1.2 QA-1 BNCal runtime authorization contract is invalid")

    request_path, request = load_bound_json(
        str(execution.bncal_execution_request),
        str(execution.bncal_execution_request_sha256),
        "BNCal execution request",
    )
    if (
        request.get("status") != "AWAITING_EXPLICIT_USER_AUTHORIZATION"
        or request.get("execution_authorized") is not False
        or request.get("requested_run_keys") != [run_key]
    ):
        raise RuntimeError("BNCal execution request is invalid")
    request_contract = request.get("bncal_contract", {})
    validate_bncal_numeric_request(request)
    if (
        request_contract.get("train_cases") != EXPECTED_CASES
        or request_contract.get("batches") != EXPECTED_BATCHES
        or request_contract.get("forward_calls") != EXPECTED_BATCHES
        or request_contract.get("optimizer_steps") != 0
        or request_contract.get("model_parameter_updates") != 0
        or request_contract.get("input") != "partial only"
    ):
        raise RuntimeError("BNCal execution request contract drifted")

    _, authorization = load_bound_json(
        str(execution.bncal_authorization_receipt),
        str(execution.bncal_authorization_receipt_sha256),
        "BNCal authorization receipt",
    )
    if (
        authorization.get("status") != "AUTHORIZED"
        or authorization.get("execution_authorized") is not True
        or authorization.get("authorized_run_keys") != [run_key]
        or authorization.get("training_authorized") is not False
        or authorization.get("bncal_authorized") is not True
        or authorization.get("optimizer_steps_authorized") != 0
        or authorization.get("development_payload_access_authorized") is not False
        or authorization.get("development_evaluation_authorized") is not False
        or authorization.get("automatic_rerun_authorized") is not False
        or authorization.get("automatic_next_run_authorized") is not False
        or authorization.get("bncal_request", {}).get("path") != str(
            execution.bncal_execution_request
        )
        or authorization.get("bncal_request", {}).get("sha256")
        != sha256_file(request_path)
    ):
        raise RuntimeError("BNCal authorization receipt is invalid")

    _, formal_protocol = load_bound_json(
        str(execution.formal_config_protocol),
        str(execution.formal_config_protocol_sha256),
        "formal config protocol",
    )
    if (
        formal_protocol.get("protocol_id") != FORMAL_CONFIG_PROTOCOL_ID
        or formal_protocol.get("status") != "FROZEN_IMPLEMENTATION_ONLY"
    ):
        raise RuntimeError("formal config protocol is invalid")

    _, p3_receipt = load_bound_json(
        str(execution.bncal_post_implementation_p3_receipt),
        str(execution.bncal_post_implementation_p3_receipt_sha256),
        "BNCal post-implementation P3 receipt",
    )
    if (
        p3_receipt.get("status") != "PASS_IMPLEMENTATION_ONLY"
        or p3_receipt.get("bncal_authorized_by_this_receipt") is not False
        or p3_receipt.get("development_payload_access_authorized_by_this_receipt")
        is not False
    ):
        raise RuntimeError("BNCal implementation P3 receipt is invalid")

    completion_path, completion = load_bound_json(
        str(execution.source_training_completion_receipt),
        str(execution.source_training_completion_receipt_sha256),
        "source training completion receipt",
    )
    state_path = experiment_dir / "v12_qa1_training_execution_state.json"
    checkpoint_path = experiment_dir / "ckpt-last.pth"
    if not state_path.is_file() or not checkpoint_path.is_file():
        raise RuntimeError("BNCal requires completed v1.2 training state and ckpt-last")
    state = json.loads(state_path.read_text(encoding="utf-8"))
    state_sha = sha256_file(state_path)
    checkpoint_sha = sha256_file(checkpoint_path)
    if (
        state.get("receipt_version") != SOURCE_STATE_VERSION
        or state.get("status") != SOURCE_STATE_STATUS
        or state.get("optimizer_steps") != EXPECTED_STEPS
        or state.get("model_updates") != EXPECTED_STEPS
        or state.get("epoch_traversals_completed") != EXPECTED_TRAVERSALS
        or state.get("development_dataloader_constructed") is not False
        or state.get("development_payload_accessed") is not False
        or state.get("bncal_authorized") is not False
        or state.get("bncal_updates") != 0
        or state.get("runtime_config_sha256")
        != str(execution.source_training_runtime_config_sha256)
        or state.get("checkpoint_sha256") != checkpoint_sha
        or state.get("candidate") != str(development.candidate)
        or state.get("fold") != str(development.fold)
        or state.get("seed") != 0
    ):
        raise RuntimeError("v1.2 QA-1 source training state is invalid")
    if (
        state_sha != str(execution.source_training_state_sha256)
        or checkpoint_sha != str(execution.source_training_checkpoint_sha256)
        or completion.get("status") != SOURCE_COMPLETION_STATUS
        or completion.get("optimizer_steps") != EXPECTED_STEPS
        or completion.get("model_updates") != EXPECTED_STEPS
        or completion.get("epoch_traversals") != EXPECTED_TRAVERSALS
        or completion.get("bncal_runs") != 0
        or completion.get("development_payload_accessed") is not False
        or completion.get("training_state_sha256") != state_sha
        or completion.get("training_checkpoint_sha256") != checkpoint_sha
    ):
        raise RuntimeError("v1.2 QA-1 source completion receipt is invalid")

    allowlist_path = resolve_repo_path(str(execution.train_case_ids))
    if (
        str(config.dataset.train.others.include_case_ids_file)
        != str(execution.train_case_ids)
        or str(qa1_lock.train_case_ids) != str(execution.train_case_ids)
        or sha256_file(allowlist_path) != str(execution.train_case_ids_sha256)
        or str(qa1_lock.train_case_ids_sha256)
        != str(execution.train_case_ids_sha256)
        or len(read_ids(allowlist_path)) != EXPECTED_CASES
    ):
        raise RuntimeError("BNCal train allowlist binding is invalid")
    return state_path, checkpoint_path, state, completion_path


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--experiment_dir", type=Path, required=True)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--num_workers", type=int, default=0)
    parser.add_argument("--seed", type=int, default=0)
    return parser.parse_args()


def main():
    args = parse_args()
    config_path = args.config.resolve()
    experiment_dir = args.experiment_dir.resolve()
    if args.batch_size != 8 or args.num_workers != 0 or args.seed != 0:
        raise RuntimeError("SCQR v1.2 QA-1 BNCal requires batch=8, workers=0, seed=0")
    output_checkpoint = experiment_dir / "ckpt-last-bncal.pth"
    receipt_path = experiment_dir / "v12_qa1_bncal_receipt.json"
    files_path = experiment_dir / "v12_qa1_bncal_files.sha256"
    for path in (output_checkpoint, receipt_path, files_path):
        if path.exists():
            raise RuntimeError(f"BNCal output already exists; rerun forbidden: {path}")

    config = cfg_from_yaml_file(str(config_path))
    state_path, checkpoint_path, training_state, completion_path = validate_execution(
        config, config_path, experiment_dir
    )
    numerical_policy = configure_bncal_numeric_policy(config)
    random.seed(0)
    np.random.seed(0)
    torch.manual_seed(0)
    torch.cuda.manual_seed_all(0)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise RuntimeError("SCQR v1.2 QA-1 BNCal requires exactly one visible CUDA GPU")

    dataset = PartialOnlyDataset(config)
    loader = DataLoader(
        dataset,
        batch_size=8,
        shuffle=False,
        drop_last=False,
        num_workers=0,
    )
    if len(loader) != EXPECTED_BATCHES:
        raise RuntimeError(f"BNCal requires 40 batches, got {len(loader)}")

    device = torch.device("cuda:0")
    model = builder.model_builder(config.model).to(device)
    builder.load_model(model, str(checkpoint_path))
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    parameter_sha_before = tensor_map_sha256(model.named_parameters())
    state_before = {
        name: value.detach().cpu().clone() for name, value in model.state_dict().items()
    }
    batchnorm = {
        name: module
        for name, module in model.named_modules()
        if isinstance(module, nn.modules.batchnorm._BatchNorm)
    }
    if not batchnorm:
        raise RuntimeError("SCQR model has no BatchNorm layers")
    model.eval()
    for module in batchnorm.values():
        module.reset_running_stats()
        module.momentum = None
        module.train()

    started = datetime.now(timezone.utc).isoformat()
    torch.cuda.reset_peak_memory_stats()
    batches = 0
    with torch.inference_mode():
        for _, partial in tqdm(loader, total=EXPECTED_BATCHES, desc="SCQR v1.2 QA-1 BNCal"):
            assert_bncal_numeric_policy()
            model(partial.to(device, non_blocking=False), epoch=None)
            batches += 1
    numerical_policy_at_completion = assert_bncal_numeric_policy()
    if batches != EXPECTED_BATCHES:
        raise RuntimeError(f"BNCal batch count mismatch: {batches}")
    if len(dataset.opened_case_ids) != EXPECTED_CASES:
        raise RuntimeError("BNCal payload-open count mismatch")
    if dataset.opened_case_ids != dataset.case_ids:
        raise RuntimeError("BNCal payload order differs from frozen allowlist")

    parameter_sha_after = tensor_map_sha256(model.named_parameters())
    if parameter_sha_after != parameter_sha_before:
        raise RuntimeError("BNCal changed model parameters")
    changed = []
    for name, after in model.state_dict().items():
        if not torch.equal(state_before[name], after.detach().cpu()):
            changed.append(name)
    allowed = {
        f"{name}.{suffix}"
        for name in batchnorm
        for suffix in ("running_mean", "running_var", "num_batches_tracked")
    }
    unexpected = sorted(set(changed).difference(allowed))
    if unexpected:
        raise RuntimeError(f"BNCal changed non-BN state: {unexpected[:10]}")

    source_checkpoint = torch.load(checkpoint_path, map_location="cpu")
    source_checkpoint["base_model"] = {
        name: value.detach().cpu() for name, value in model.state_dict().items()
    }
    source_checkpoint["bn_recalibration"] = {
        "version": VERSION,
        "source_checkpoint_sha256": sha256_file(checkpoint_path),
        "source_training_state_sha256": sha256_file(state_path),
        "source_training_completion_receipt_sha256": sha256_file(completion_path),
        "train_case_ids_sha256": sha256_file(dataset.allowlist_path),
        "partial_only": True,
        "implant_or_gt_members_opened": 0,
        "batches": batches,
        "cases": len(dataset.opened_case_ids),
        "reset_running_stats": True,
    }
    temporary = output_checkpoint.with_suffix(".pth.tmp")
    torch.save(source_checkpoint, temporary)
    os.replace(temporary, output_checkpoint)

    receipt = {
        "receipt_version": VERSION,
        "numerical_policy": numerical_policy,
        "numerical_policy_at_completion": numerical_policy_at_completion,
        "status": "PASS",
        "run_key": str(config.qa1_lock.run_key),
        "candidate": str(config.development_protocol.candidate),
        "fold": str(config.development_protocol.fold),
        "seed": 0,
        "started_at_utc": started,
        "finished_at_utc": datetime.now(timezone.utc).isoformat(),
        "bncal_runtime_config_sha256": sha256_file(config_path),
        "bncal_execution_request_sha256": str(
            config.cranial_scqr_execution.bncal_execution_request_sha256
        ),
        "bncal_authorization_receipt_sha256": str(
            config.cranial_scqr_execution.bncal_authorization_receipt_sha256
        ),
        "training_state_sha256": sha256_file(state_path),
        "source_checkpoint_sha256": sha256_file(checkpoint_path),
        "source_training_completion_receipt_sha256": sha256_file(completion_path),
        "bncal_checkpoint_sha256": sha256_file(output_checkpoint),
        "train_case_ids_sha256": sha256_file(dataset.allowlist_path),
        "train_cases": EXPECTED_CASES,
        "train_sources": EXPECTED_SOURCES,
        "bncal_batches": batches,
        "bncal_forward_calls": batches,
        "bncal_buffer_update_batches": batches,
        "optimizer_constructions": 0,
        "optimizer_steps": 0,
        "model_parameter_updates": 0,
        "parameter_sha256_before": parameter_sha_before,
        "parameter_sha256_after": parameter_sha_after,
        "parameters_unchanged": True,
        "batchnorm_layer_count": len(batchnorm),
        "changed_bn_buffer_count": len(changed),
        "changed_bn_buffers": sorted(changed),
        "non_bn_state_changes": [],
        "payload_open_events": len(dataset.opened_case_ids),
        "npz_members_opened": ["partial"],
        "implant_or_gt_members_opened": 0,
        "development_payload_opened": 0,
        "confirmation20_payload_opened": 0,
        "official_test_payload_opened": 0,
        "old_monitor_payload_opened": 0,
        "mug_payload_opened": 0,
        "peak_allocated_bytes": int(torch.cuda.max_memory_allocated()),
        "development_evaluation_authorized_by_this_receipt": False,
        "next_run_authorized_by_this_receipt": False,
    }
    receipt_path.write_bytes(canonical_json(receipt))
    files_path.write_text(
        f"{sha256_file(output_checkpoint)}  {output_checkpoint.name}\n"
        f"{sha256_file(receipt_path)}  {receipt_path.name}\n",
        encoding="ascii",
    )
    print(f"[done] BNCal PASS run_key={receipt['run_key']}")
    print(f"[count] cases={EXPECTED_CASES} batches={batches} optimizer_steps=0")
    print(f"[saved] {output_checkpoint}")
    print(f"[saved] {receipt_path}")


if __name__ == "__main__":
    main()
