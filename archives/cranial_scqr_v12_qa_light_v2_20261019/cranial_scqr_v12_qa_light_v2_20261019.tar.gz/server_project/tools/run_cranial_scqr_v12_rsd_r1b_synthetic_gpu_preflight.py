#!/usr/bin/env python3
"""Inert synthetic-only adapter; authorization and every file hash precede torch.

No real checkpoint loader, dataset builder, loss, optimizer or evaluation entry
point is called. CPU contracts exercise pure guards and tiny fake models only.
"""

import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
import random
import shutil
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
import cranial_scqr_v12_rsd_r1b_synthetic_preflight_contract as c


def write_json(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def load_file_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def synthetic_input(torch):
    return torch.tensor([[((i % 32) - 15.5) / 32,
                          (((i // 32) % 16) - 7.5) / 16,
                          ((i // 512) - 7.5) / 16] for i in range(8192)],
                        dtype=torch.float32, device='cpu').unsqueeze(0).contiguous()


def model_mapping(document, candidate):
    """Never merge dataset bases or honor historical runtime authorization."""
    require = c.require
    require(isinstance(document, dict) and isinstance(document.get('model'), dict), 'model submapping missing')
    model = document['model']
    require('_base_' not in model and model.get('NAME') == 'AdaPoinTr', 'model-only YAML contract')
    require(model.get('num_query') == 256 and model.get('num_points') == 8192 and model.get('center_num') == [512, 256], 'model shape drift')
    for key, depth in (('encoder_config', 6), ('decoder_config', 8)):
        require(model.get(key, {}).get('embed_dim') == 384 and model[key].get('depth') == depth, 'network architecture drift')
    scqr = model.get('cranial_scqr', {})
    require(candidate in ('LS', 'LSQ') and scqr.get('variant') == {'LS': 'A1', 'LSQ': 'Q0'}[candidate], 'candidate variant')
    require(scqr.get('enabled') is True and scqr.get('local_geometry_enabled') is True and
            scqr.get('contact_supervision_enabled') is True and
            scqr.get('query_conditioning_enabled') is (candidate == 'LSQ'), 'SCQR component contract')
    require(scqr.get('initialization_seed') == 31001 and scqr.get('alpha_query_init') == 0.01 and
            scqr.get('alpha_local_init') == 0.01 and scqr.get('contact_bias_beta') == 0.0 and
            scqr.get('warmup_epochs') == 20 and scqr.get('attention_dropout') == 0.0 and
            model.get('mamba_adapter', {}).get('enabled') is False, 'initialization/module drift')
    return model


def numerical_values(torch):
    return {'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(),
            'warn_only': torch.is_deterministic_algorithms_warn_only_enabled(),
            'cudnn_deterministic': torch.backends.cudnn.deterministic,
            'cudnn_benchmark': torch.backends.cudnn.benchmark,
            'matmul_allow_tf32': torch.backends.cuda.matmul.allow_tf32,
            'cudnn_allow_tf32': torch.backends.cudnn.allow_tf32,
            'float32_matmul_precision': torch.get_float32_matmul_precision(),
            'CUBLAS_WORKSPACE_CONFIG': os.environ.get('CUBLAS_WORKSPACE_CONFIG'),
            'OMP_NUM_THREADS': os.environ.get('OMP_NUM_THREADS'),
            'MKL_NUM_THREADS': os.environ.get('MKL_NUM_THREADS'),
            'torch_num_threads': torch.get_num_threads(),
            'torch_num_interop_threads': torch.get_num_interop_threads()}


def assert_numerical(torch):
    expected = {'deterministic_algorithms': True, 'warn_only': False, 'cudnn_deterministic': True,
                'cudnn_benchmark': False, 'matmul_allow_tf32': False, 'cudnn_allow_tf32': False,
                'float32_matmul_precision': 'highest', 'CUBLAS_WORKSPACE_CONFIG': ':4096:8',
                'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1', 'torch_num_threads': 1, 'torch_num_interop_threads': 1}
    actual = numerical_values(torch)
    c.require(actual == expected, 'numerical/TF32/thread policy drift')
    return actual


def configure_numerical(torch):
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True, warn_only=False)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.set_float32_matmul_precision('highest')
    return assert_numerical(torch)


def state_record(model, hash_fn):
    c.require(all(not module.training for module in model.modules()), 'all modules must remain eval')
    c.require(not getattr(model, 'full_instrumentation_enabled', False) and
              not getattr(model.base_model, 'full_instrumentation_enabled', False), 'full instrumentation forbidden')
    return {'parameters': hash_fn(dict(model.named_parameters())), 'buffers': hash_fn(dict(model.named_buffers())),
            'schema': [(name, str(t.dtype), list(t.shape)) for name, t in sorted(model.state_dict().items())]}


def rng_snapshot(torch, np, *, cuda=True):
    return (random.getstate(), np.random.get_state(), torch.random.get_rng_state().clone(),
            [item.clone() for item in torch.cuda.get_rng_state_all()] if cuda else [])


def rng_restore(torch, np, states, *, cuda=True):
    random.setstate(states[0]); np.random.set_state(states[1]); torch.random.set_rng_state(states[2])
    if cuda:
        torch.cuda.set_rng_state_all(states[3])


def rng_hash(states):
    h = hashlib.sha256(b'R1B-synthetic-rng-v1\0')
    h.update(json.dumps(states[0], separators=(',', ':')).encode())
    n = states[1]
    h.update(n[0].encode()); h.update(n[1].tobytes()); h.update(json.dumps(n[2:]).encode())
    h.update(states[2].cpu().numpy().tobytes())
    for state in states[3]:
        h.update(state.cpu().numpy().tobytes())
    return h.hexdigest()


def compare_tensor(torch, left, right, label):
    same = left.shape == right.shape and left.dtype == right.dtype and left.device == right.device
    equal = same and torch.equal(left, right)
    c.require(equal, 'exact tensor mismatch: ' + label)
    return {'label': label, 'exact_equal': True, 'max_abs_difference': float((left - right).abs().max().cpu().item())}


def standalone_outlets(torch, select, hash_fn, ledger, device, sync, policy):
    records = []
    for magnitude in (0.0, 0.25):
        q = torch.ones(1, 2, 384, dtype=torch.float32, device=device)
        residual = torch.full_like(q, magnitude)
        out = SimpleNamespace(queries=q + residual, residual=residual,
                              attention=torch.tensor([[[1., 0.], [.5, .5]]], dtype=torch.float32, device=device), warmup=1.0)
        alpha = torch.tensor([0.01], dtype=torch.float32, device=device)
        tensors = {'q': q, 'residual': residual, 'conditioned': out.queries, 'attention': out.attention, 'alpha': alpha}
        before = hash_fn(tensors)
        results, diagnostics = [], []
        for condition, traced in (('LSQ_native', False), ('LSQ_native', True), ('LSQ_query_off', True), ('LSQ_native', True)):
            policy()
            ledger.add('standalone_select_rsd_queries_calls')
            diag = {} if traced else None
            result = select(q, out, alpha, condition, diag)
            sync()
            c.require(result is (q if condition == 'LSQ_query_off' else out.queries), 'outlet object identity')
            if diag is not None:
                c.assert_scalars(diag, off=condition == 'LSQ_query_off')
                c.require(diag['query_rms'] == 1.0 and diag['potential_residual_rms'] == magnitude and
                          diag['relative_potential_residual_rms'] == magnitude and diag['alpha_q'] == float(alpha.item()) and
                          diag['effective_proxy_count_mean'] == 1.5 and diag['attention_max_weight_mean'] == .75 and
                          abs(diag['attention_entropy_mean'] - math.log(2) / 2) <= 1e-6, 'artificial scalar expectation')
                diagnostics.append(diag)
            results.append(result)
        c.require(torch.equal(results[0], results[1]) and torch.equal(results[1], results[3]), 'native trace/restore')
        c.require(torch.equal(results[1] - results[2], torch.full_like(q, magnitude)), 'known residual difference')
        c.require(torch.equal(results[1], results[2]) == (magnitude == 0.0), 'zero/nonzero outlet control')
        c.require(diagnostics[0] == diagnostics[2], 'restored scalar exact equality')
        c.require(before == hash_fn(tensors), 'outlet fixture mutated')
        records.append({'residual_magnitude': magnitude, 'fixture_hash': before, 'diagnostics': diagnostics,
                        'native_restored_exact': True, 'known_residual_exact': True})
    return records


def run_sequence(models, x, torch, np, hash_fn, ledger, order, *, cuda, sync, policy, memory, progress):
    """Same sequence for authorized CUDA and tiny artificial CPU contract doubles."""
    before = {key: state_record(model, hash_fn) for key, model in models.items()}
    input_hash = hash_fn({'partial': x})
    snapshot = rng_snapshot(torch, np, cuda=cuda)
    hooks, results, records, comparisons = [], {}, [], []
    for candidate, model in models.items():
        conditioner = model.base_model.scqr_query_conditioner
        if candidate == 'LS':
            c.require(conditioner is None, 'LS conditioner must be absent')
        else:
            c.require(conditioner is not None, 'LSQ conditioner missing')
            def hook(_module, _inputs, _output):
                ledger.add('full_forward_lsq_conditioner_calls')
            hooks.append(conditioner.register_forward_hook(hook))
    try:
        with torch.no_grad():
            for item in order:
                index, candidate = item['index'], item['model']
                policy(); memory()
                c.require({key: state_record(model, hash_fn) for key, model in models.items()} == before, 'state changed before forward')
                c.require(input_hash == hash_fn({'partial': x}), 'input mutated before forward')
                rng_restore(torch, np, snapshot, cuda=cuda)
                ledger.begin(index, item)
                diagnostics = {} if item['diagnostics'] == 'FRESH_EMPTY_DICT' else None
                if item['rsd_condition'] is None:
                    returned = models[candidate](x, epoch=None)
                else:
                    returned = models[candidate](x, epoch=None, rsd_condition=item['rsd_condition'], rsd_diagnostics=diagnostics)
                sync(); memory(); policy()
                c.require(isinstance(returned, tuple) and len(returned) >= 2, 'model return schema')
                coarse, dense = returned[:2]
                for value, shape in ((coarse, (1, 256, 3)), (dense, (1, 8192, 3))):
                    c.require(tuple(value.shape) == shape and value.dtype == torch.float32 and value.device == x.device and
                              bool(torch.isfinite(value).all()), 'invalid output shape/dtype/finite/device')
                after = {key: state_record(model, hash_fn) for key, model in models.items()}
                c.require(after == before and input_hash == hash_fn({'partial': x}), 'state/input mutation after forward')
                if diagnostics is not None:
                    if candidate == 'LS':
                        c.require(diagnostics == {'query_applicable': False, 'query_outlet_calls': 0}, 'LS missing semantics')
                        diagnostics = {**{name: None for name in c.SCALARS}, **diagnostics, 'missing_reason': 'not_applicable'}
                    else:
                        c.assert_scalars(diagnostics, off=item['rsd_condition'] == 'LSQ_query_off')
                        ledger.add('traced_full_forward_lsq_query_outlet_calls')
                row = {'index': index, 'candidate': candidate, 'condition': item['rsd_condition'],
                       'diagnostics': diagnostics, 'state_after': after,
                       'rng_after_hash': rng_hash(rng_snapshot(torch, np, cuda=cuda))}
                # Fail at the first comparable condition, before any later call.
                anchor = 1 if index == 2 else 3 if index in (4, 5, 7, 8) else None
                if anchor is not None:
                    for axis, label in enumerate(('coarse', 'dense')):
                        comparisons.append(compare_tensor(torch, results[anchor][axis], (coarse, dense)[axis],
                                                          '%s:%d=%d' % (label, anchor, index)))
                    c.require(records[anchor-1]['rng_after_hash'] == row['rng_after_hash'], 'native RNG drift')
                if index in (7, 8):
                    c.require(records[4]['diagnostics'] == diagnostics, 'repeat diagnostic scalar drift')
                if index == 6:
                    comparisons.append(compare_tensor(torch, results[5][0], coarse, 'coarse:5=6 negative control'))
                    c.require(records[4]['rng_after_hash'] == row['rng_after_hash'], 'off RNG side effect')
                    native = records[4]['diagnostics']
                    c.require(all(native[name] == diagnostics[name] for name in c.SCALARS if name != 'applied_residual_rms'),
                              'off potential/attention drift')
                ledger.end()
                results[index] = (coarse.detach(), dense.detach())
                records.append(row)
                progress({'completed_forward': index, 'counts': dict(ledger.counts), 'state_verified': True})
        policy(); memory()
        return {'state_before': before, 'state_after': {key: state_record(m, hash_fn) for key, m in models.items()},
                'input_hash': input_hash, 'records': records, 'comparisons': comparisons,
                'full_dense_off_minus_native_max_abs': float((results[6][1] - results[5][1]).abs().max().cpu().item())}
    except Exception:
        ledger.failed = True
        raise
    finally:
        for handle in hooks:
            handle.remove()


def gpu_observation():
    command = ['nvidia-smi', '--query-gpu=name,uuid,driver_version,memory.total,memory.used,utilization.gpu', '--format=csv,noheader,nounits']
    result = subprocess.run(command, check=True, capture_output=True, text=True, timeout=10)
    lines = result.stdout.strip().splitlines()
    c.require(len(lines) == 1, 'exactly one GPU')
    fields = [field.strip() for field in lines[0].split(',')]
    processes = subprocess.run(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader,nounits'],
                               check=True, capture_output=True, text=True, timeout=10)
    return {'name': fields[0], 'uuid': fields[1], 'driver': fields[2], 'total_mib': int(fields[3]),
            'used_mib': int(fields[4]), 'utilization': int(fields[5]), 'compute_pid_text': processes.stdout.strip()}


def text_preconditions(args):
    root = c.ROOT
    c.require(all(hasattr(args, name) for name in ('request', 'request_sha256', 'authorization', 'authorization_sha256',
                                                  'runtime', 'runtime_sha256')), 'complete hash chain arguments required')
    c.require(HERE.parent.resolve() == root and Path.cwd().resolve() == root and root.resolve() == root, 'canonical project cwd required')
    expected_chain = {
        'request': root / 'docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_gpu_zero_update_preflight_execution_request_v2.json',
        'authorization': root / 'logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_v2_20261011/control/authorization_receipt_v2.json',
        'runtime': root / 'logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_v2_20261011/control/runtime_v2.json',
    }
    for key, expected in expected_chain.items():
        c.require(getattr(args, key).resolve() == expected and c.under(expected, root), 'exact chain namespace required before reads')
    paths = []
    for path, expected in ((args.request, args.request_sha256), (args.authorization, args.authorization_sha256),
                           (args.runtime, args.runtime_sha256)):
        resolved = path.resolve()
        c.require(c.under(resolved, root) and resolved.is_file() and c.sha_string(expected) and c.digest(resolved) == expected,
                  'chain hash/path drift')
        paths.append(resolved)
    request, auth, runtime = [c.strict_json(path) for path in paths]
    original_path = c.bound(root, request['parent_request_v1'])
    original = c.strict_json(original_path)
    c.validate_chain(request, original, auth, runtime, args.request_sha256, args.authorization_sha256)
    for key, given in (('authorization_receipt_relative', args.authorization), ('runtime_relative', args.runtime)):
        c.require((root / request['fixed_future_execution'][key]).resolve() == given.resolve(), 'frozen control path mismatch')
    resource = request['resource_binding']
    c.require(socket.gethostname() == resource['hostname'] and os.getuid() == 1000 and
              sys.version.split()[0] == resource['python_version'] and
              str(Path(sys.executable).resolve()) == resource['python_realpath'] and
              c.digest(Path(sys.executable).resolve()) == resource['python_binary_sha256'], 'host/user/Python drift')
    for package, version in resource['package_metadata_versions'].items():
        c.require(importlib.metadata.version(package) == version, 'package drift: ' + package)
    extra = []
    for key in ('protocol_binding', 'readonly_observation_binding', 'post_implementation_p3',
                'preflight_implementation_p3_binding', 'dependency_inventory_binding', 'input_identity_binding'):
        extra.append(c.bound(root, request[key]))
    for binding in request['preflight_implementation_bindings'] + request['additional_observed_source_bindings'] + request['model_structure_sources']:
        extra.append(c.bound(root, binding))
    for name, sha in request['implementation_sha256'].items():
        p = root / name
        c.require(c.under(p, root) and p.is_file() and c.digest(p) == sha, 'R1-B source drift: ' + name)
        extra.append(p.resolve())
    parent_p3 = c.strict_json(root / request['post_implementation_p3']['path'])
    preflight_p3 = c.strict_json(root / request['preflight_implementation_p3_binding']['path'])
    c.require(parent_p3['status'] == 'PASS_IMPLEMENTATION_ONLY' and parent_p3['gpu_used'] is False and
              parent_p3['implementation_sha256'] == request['implementation_sha256'], 'R1-B P3 mismatch')
    c.require(preflight_p3['status'] == 'PASS_SYNTHETIC_PREFLIGHT_IMPLEMENTATION_ONLY' and
              preflight_p3['gpu_used'] is False and preflight_p3['preflight_implementation_bindings'] == request['preflight_implementation_bindings'], 'dedicated tool P3 mismatch')
    inventory = c.strict_json(root / request['dependency_inventory_binding']['path'])
    c.require(inventory['status'] == 'FROZEN_STATIC_CODE_BINARY_INVENTORY_CPU_ONLY' and inventory['files'], 'dependency inventory missing')
    seen = set()
    for binding in inventory['files']:
        p = Path(binding['absolute_path']).resolve()
        c.require((c.under(p, root) or c.under(p, c.ENV_ROOT)) and str(p) not in seen and p.is_file() and
                  p.stat().st_size == binding['bytes'] and c.digest(p) == binding['sha256'], 'dependency source/binary drift')
        seen.add(str(p)); extra.append(p)
    for binding in inventory.get('system_loader_files', []):
        p = Path(binding['absolute_path']).resolve()
        c.require(any(c.under(p, Path(prefix)) for prefix in ('/usr/lib', '/lib', '/usr/local/nvidia/lib64')) and p.is_file() and
                  p.stat().st_size == binding['bytes'] and c.digest(p) == binding['sha256'], 'OS loader binary drift')
        extra.append(p)
    observed = gpu_observation()
    c.require(observed['name'] == resource['gpu_name'] and observed['uuid'] == resource['gpu_uuid'] and
              observed['driver'] == resource['driver_version'] and observed['total_mib'] == resource['gpu_memory_total_mib'] and
              observed['utilization'] == 0 and not observed['compute_pid_text'] and
              observed['total_mib'] - observed['used_mib'] >= resource['minimum_free_gpu_memory_mib_at_launch'], 'GPU resource drift/busy')
    c.require(shutil.disk_usage(root).free >= resource['minimum_free_disk_bytes_at_launch'], 'disk budget')
    output = root / request['fixed_future_execution']['output_relative']
    c.require(c.under(output, root) and not output.exists() and not output.is_symlink() and output.parent.is_dir(), 'output must be new, with existing safe parent')
    return request, output, paths + [original_path] + extra, observed


def authorized_run(args):
    process_started = time.monotonic()
    request, output, read_files, observed = text_preconditions(args)
    c.require(time.monotonic() - process_started < 600, 'pre-execution hash audit exceeded walltime')
    ledger = c.Ledger(request['success_exact_counts'])
    output.mkdir(exist_ok=False)
    # Execution is already separately authorized. No directories/control files
    # outside this newly owned output may be written by this process.
    os.environ.update(CUBLAS_WORKSPACE_CONFIG=':4096:8', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
    sys.dont_write_bytecode = True
    timeout = lambda _sig, _frame: (_ for _ in ()).throw(c.ContractError('600-second walltime budget exceeded'))
    signal.signal(signal.SIGALRM, timeout)
    started = process_started
    signal.signal(signal.SIGTERM, timeout)
    signal.setitimer(signal.ITIMER_REAL, 600 - (time.monotonic() - started))
    write_json(output / 'invocation.json', {'pid': os.getpid(), 'request_sha256': args.request_sha256,
               'authorization_sha256': args.authorization_sha256, 'runtime_sha256': args.runtime_sha256, 'synthetic_only': True})
    sys.addaudithook(c.FileBoundary(read_files, output))
    models, hooks = {}, []
    try:
        import torch
        import numpy as np
        import yaml
        from easydict import EasyDict
        numerical_before = configure_numerical(torch)
        env = request['environment_runtime_contract']
        c.require(torch.__version__ == env['torch_version'] and np.__version__ == env['numpy_version'] and
                  torch.version.cuda == env['cuda_version'] and torch.backends.cudnn.version() == env['cudnn_version'], 'CUDA/cuDNN runtime drift')
        c.require(torch.cuda.device_count() == 1 and torch.cuda.get_device_name(0) == request['resource_binding']['gpu_name'] and
                  torch.cuda.get_device_properties(0).total_memory // (1024**2) == request['resource_binding']['gpu_memory_total_mib'],
                  'CUDA-visible GPU contract')
        from models import build_model_from_cfg
        support = load_file_module(c.ROOT / 'tools/run_cranial_scqr_v12_rsd_r1b.py', 'rsd_preflight_hash_support')
        bypass = load_file_module(c.ROOT / 'models/cranial_scqr/rsd_query_bypass.py', 'rsd_preflight_outlet_support')
        cpu_input = synthetic_input(torch)
        expected_input = c.strict_json(c.ROOT / request['input_identity_binding']['path'])
        cpu_input_hash = support.canonical_tensor_hash({'partial': cpu_input})
        c.require(cpu_input_hash == expected_input['canonical_input_hash'], 'frozen artificial CPU input identity')
        torch.cuda.reset_peak_memory_stats(0)
        for candidate, binding in zip(('LS', 'LSQ'), request['model_structure_sources']):
            random.seed(0); np.random.seed(0); torch.random.default_generator.manual_seed(0)
            config = model_mapping(yaml.safe_load((c.ROOT / binding['path']).read_text()), candidate)
            ledger.add('model_constructions')
            model = build_model_from_cfg(EasyDict(config)).float().eval()
            cpu_state = state_record(model, support.canonical_tensor_hash)
            models[candidate] = model.to('cuda:0')
            c.require(state_record(model, support.canonical_tensor_hash) == cpu_state, 'CPU-to-CUDA model state change')
        x = cpu_input.to('cuda:0')
        c.require(support.canonical_tensor_hash({'partial': x}) == cpu_input_hash and torch.equal(cpu_input, x.cpu()), 'CPU/CUDA input identity')
        random.seed(0); np.random.seed(0); torch.manual_seed(0); torch.cuda.manual_seed_all(0)
        initial_states = {key: state_record(model, support.canonical_tensor_hash) for key, model in models.items()}
        memory_records = []
        def memory():
            allocated, reserved = torch.cuda.max_memory_allocated(0), torch.cuda.max_memory_reserved(0)
            c.require(allocated <= 20000 * 1024**2 and reserved <= 20000 * 1024**2, 'peak VRAM cap exceeded')
            memory_records.append({'peak_allocated_bytes': allocated, 'peak_reserved_bytes': reserved})
        policy = lambda: assert_numerical(torch)
        sync = lambda: torch.cuda.synchronize(0)
        def progress(value):
            number = value['completed_forward']
            write_json(output / ('progress_%02d.json' % number), value)
            print('SYNTHETIC_PROGRESS:' + json.dumps(value), flush=True)
        with torch.no_grad():
            outlet = standalone_outlets(torch, bypass.select_rsd_queries, support.canonical_tensor_hash,
                                        ledger, 'cuda:0', sync, policy)
        c.require({key: state_record(model, support.canonical_tensor_hash) for key, model in models.items()} == initial_states,
                  'state changed during standalone outlets')
        sequence = run_sequence(models, x, torch, np, support.canonical_tensor_hash, ledger, request['full_forward_order'],
                                cuda=True, sync=sync, policy=policy, memory=memory, progress=progress)
        c.require(time.monotonic() - started <= 600, 'walltime cap')
        ledger.finish()
        c.require(support.canonical_tensor_hash({'partial': cpu_input}) == cpu_input_hash, 'CPU input mutated during run')
        for name, expected in request['implementation_sha256'].items():
            c.require(c.digest(c.ROOT / name) == expected, 'R1-B source changed during preflight')
        for binding in request['preflight_implementation_bindings'] + request['model_structure_sources']:
            c.bound(c.ROOT, binding)
        write_json(output / 'equality_scalar_state.json', {'standalone': outlet, 'full_sequence': sequence})
        write_json(output / 'environment_input_identity.json', {'resource_before': observed, 'environment': env,
                   'dependency_inventory_binding': request['dependency_inventory_binding'], 'input_cpu_cuda_hash': cpu_input_hash,
                   'input_cpu_gpu_exact': True, 'shape': [1,8192,3], 'synthetic_only': True})
        write_json(output / 'numerical_memory.json', {'before': numerical_before, 'after': assert_numerical(torch), 'memory_records': memory_records})
        receipt = {'status': 'PASS_SYNTHETIC_R1B_ZERO_UPDATE', 'synthetic_only': True, 'counts': ledger.counts,
                   'implementation_sha256': request['implementation_sha256'],
                   'preflight_implementation_bindings': request['preflight_implementation_bindings'],
                   'model_forwards': 8, 'real_payload_open_events': 0, 'real_checkpoint_loads': 0,
                   'real_checkpoint_byte_reads': 0, 'optimizer_steps': 0, 'parameter_updates': 0, 'buffer_updates': 0,
                   'formal_gate': False, 'global_cuda_equivalence_proven': False, 'automatic_retry': False,
                   'wall_elapsed_seconds': time.monotonic()-started, 'state_hash_format': 'RSD-canonical-state-v1'}
        write_json(output / 'completion_receipt.json', receipt)
        files = sorted(p for p in output.iterdir() if p.is_file())
        c.require(sum(p.stat().st_size for p in files) + 4096 <= 16 * 1024**2, 'result size cap')
        with (output / 'files.sha256').open('x', encoding='utf-8') as stream:
            for path in files:
                stream.write(c.digest(path) + '  ' + path.name + '\n')
        print('SYNTHETIC_RECEIPT:' + json.dumps(receipt), flush=True)
        return 0
    except Exception as exc:
        ledger.failed = True
        after = {}
        if models:
            try:
                after = {key: state_record(model, support.canonical_tensor_hash) for key, model in models.items()}
            except Exception:
                after = {'unavailable': True}
        write_json(output / 'failure_receipt.json', {'status': 'FAILED_STOPPED_NO_RETRY', 'error_type': type(exc).__name__,
                   'error': str(exc), 'counts': ledger.counts, 'state_after_failure': after, 'automatic_retry': False,
                   'state_before': locals().get('initial_states', {'unavailable': True}),
                   'counts_are_attempt_ledger_not_a_claim_of_no_mutation_after_failure': True,
                   'formal_gate': False, 'synthetic_only': True})
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('request', 'authorization', 'runtime'):
        parser.add_argument('--' + name, required=True, type=Path)
        parser.add_argument('--' + name + '-sha256', required=True)
    return authorized_run(parser.parse_args(argv))


if __name__ == '__main__':
    raise SystemExit(main())
