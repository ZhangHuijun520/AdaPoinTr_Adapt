#!/usr/bin/env python
"""Synthetic CPU control-plane tests for the QA-1 zero-update preflight."""

from __future__ import annotations

import ast
import copy
import hashlib
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RUNNER_PATH = ROOT / "tools/run_cranial_scqr_v12_qa1_zero_update_preflight.py"
PROTOCOL_PATH = (
    ROOT
    / "docs/cranial_scqr_v12_qa_research_2026_09_21"
    / "v12_qa1_zero_update_preflight_protocol_v1.json"
)


def load_runner():
    spec = importlib.util.spec_from_file_location("qa1_zero_update_runner", RUNNER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot create runner import spec")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class FakeParameter:
    def __init__(self, requires_grad=True):
        self.requires_grad = requires_grad


class FakeModel:
    def __init__(self):
        self._named = [
            ("encoder.weight", FakeParameter()),
            ("decoder.weight", FakeParameter()),
            ("frozen.bias", FakeParameter(False)),
        ]

    def named_parameters(self):
        return iter(self._named)

    def parameters(self):
        return (parameter for _, parameter in self._named)


class QA1ZeroUpdateContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.torch_was_loaded = "torch" in sys.modules
        cls.runner = load_runner()

    def artificial_config(self, run):
        candidate = run["candidate"]
        fold = run["fold"]
        train = (
            "logs/skullbreak_mamba_v12_development/protocol_v1/"
            f"fold{fold}_train_case_ids.txt"
        )
        dev = (
            "logs/skullbreak_mamba_v12_development/protocol_v1/"
            f"fold{fold}_dev_case_ids.txt"
        )
        alias = {"B0": None, "LS": "A1", "LSQ": "Q0"}[candidate]
        switches = {
            "B0": ("B0", False, False, False, False, None),
            "LS": ("A1", True, True, True, False, run["lambda_scf"]),
            "LSQ": ("Q0", True, True, True, True, run["lambda_scf"]),
        }[candidate]
        lock = {
            "run_key": run["run_key"], "candidate": candidate,
            "fold": fold, "seed": 0, "lambda_scf": run["lambda_scf"],
        }
        if alias is not None:
            lock["v11_alias"] = alias
        development = {
            "candidate": candidate, "fold": fold, "seed": 0,
            "qa_stage": "QA-1", "protected_splits_accessed": False,
            "confirmation_allowed": False, "old_monitor_allowed": False,
            "official_test_allowed": False, "mug_payload_allowed": False,
            "skullfix_payload_allowed": False,
        }
        return {
            "model": {"cranial_scqr": {
                "variant": switches[0], "enabled": switches[1],
                "local_geometry_enabled": switches[2],
                "contact_supervision_enabled": switches[3],
                "query_conditioning_enabled": switches[4],
                "contact_bias_beta": 0.0,
                "auxiliary_loss_weight": switches[5],
            }},
            "dataset": {
                "train": {"others": {"include_case_ids_file": train}},
                "val": {"others": {"include_case_ids_file": dev}},
                "test": {"others": {"include_case_ids_file": dev}},
            },
            "total_bs": 8, "step_per_update": 1, "max_epoch": 100,
            "cranial_scqr_execution": {
                "stage": "V12_P1_QA1_static_template",
                "status": "training_locked_pending_P2_and_per_run_authorization",
                "training_authorized": False,
                "optimizer_steps_authorized": 0,
                "bncal_authorized": False,
                "development_payload_access_authorized": False,
                "development_evaluation_authorized": False,
                "formal_timing_authorized": False,
                "resume_authorized": False,
                "automatic_rerun_authorized": False,
                "checkpoint_initial_state": "scratch",
            },
            "qa1_lock": lock,
            "development_protocol": development,
        }

    def test_frozen_protocol_shape_and_exact_counts(self):
        payload = json.loads(PROTOCOL_PATH.read_text(encoding="utf-8"))
        self.runner.validate_protocol_payload(payload)
        self.assertFalse(payload["execution_authorized"])
        self.assertEqual([row["run_key"] for row in payload["runs"]], list(self.runner.RUN_KEYS))
        self.assertEqual(payload["execution_count_contract"], self.runner.EXECUTION_COUNTS)

    def test_matrix_extra_or_reordered_run_is_rejected(self):
        payload = json.loads(PROTOCOL_PATH.read_text(encoding="utf-8"))
        extra = copy.deepcopy(payload)
        extra["runs"].append(copy.deepcopy(extra["runs"][0]))
        with self.assertRaises(self.runner.ContractError):
            self.runner.validate_protocol_payload(extra)
        reordered = copy.deepcopy(payload)
        reordered["runs"][0], reordered["runs"][1] = reordered["runs"][1], reordered["runs"][0]
        with self.assertRaises(self.runner.ContractError):
            self.runner.validate_protocol_payload(reordered)

    def test_artificial_config_lock_lambda_and_candidate_tamper(self):
        for run in self.runner.expected_run_specs():
            payload = self.artificial_config(run)
            self.runner.validate_config_payload(payload, run)
            tampered = copy.deepcopy(payload)
            tampered["cranial_scqr_execution"]["training_authorized"] = True
            with self.assertRaises(self.runner.ContractError):
                self.runner.validate_config_payload(tampered, run)
            tampered = copy.deepcopy(payload)
            tampered["qa1_lock"]["lambda_scf"] = 0.5
            with self.assertRaises(self.runner.ContractError):
                self.runner.validate_config_payload(tampered, run)
            tampered = copy.deepcopy(payload)
            tampered["model"]["cranial_scqr"]["query_conditioning_enabled"] = not tampered["model"]["cranial_scqr"]["query_conditioning_enabled"]
            with self.assertRaises(self.runner.ContractError):
                self.runner.validate_config_payload(tampered, run)

    def test_artificial_allowlists_count_hash_disjointness_and_loader_math(self):
        train = [f"train_case_{index:03d}" for index in range(315)]
        dev = [f"dev_case_{index:03d}" for index in range(105)]
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            train_path = root / "train.txt"
            dev_path = root / "dev.txt"
            train_path.write_text("\n".join(train) + "\n", encoding="utf-8")
            dev_path.write_text("\n".join(dev) + "\n", encoding="utf-8")
            spec = {
                "train_sha256": self.runner.sha256_file(train_path),
                "dev_sha256": self.runner.sha256_file(dev_path),
            }
            result = self.runner.validate_fold_lists("C", spec, train_path, dev_path)
            self.assertEqual(result["loader_batches"], 39)
            self.assertEqual(result["train_dev_overlap"], 0)
            dev_path.write_text("\n".join([train[0]] + dev[1:]) + "\n", encoding="utf-8")
            spec["dev_sha256"] = self.runner.sha256_file(dev_path)
            with self.assertRaises(self.runner.ContractError):
                self.runner.validate_fold_lists("C", spec, train_path, dev_path)

    def test_hash_and_parent_path_guards(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "item.txt"
            path.write_text("alpha\n", encoding="utf-8")
            self.assertEqual(
                self.runner.sha256_file(path), hashlib.sha256(b"alpha\n").hexdigest()
            )
        with self.assertRaises(self.runner.ContractError):
            self.runner.ensure_project_path(Path("/tmp/outside"))

    def test_output_exists_guard(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(FileExistsError):
                self.runner.ensure_absent_output(Path(tmp))

    def test_execution_authorization_is_a_required_second_key(self):
        output = ROOT / "logs/cranial_scqr_v12_qa1/synthetic_never_created"
        self.assertFalse(output.exists())
        base = {
            "authorization_id": self.runner.AUTHORIZATION_ID,
            "status": "AUTHORIZED", "execution_authorized": True,
            "allowed_runs": 1,
            "protocol": {
                "path": str(PROTOCOL_PATH.relative_to(ROOT)),
                "sha256": self.runner.sha256_file(PROTOCOL_PATH),
            },
            "runner": {
                "path": str(RUNNER_PATH.relative_to(ROOT)),
                "sha256": self.runner.sha256_file(RUNNER_PATH),
            },
            "output_dir": str(output.relative_to(ROOT)),
            "python_executable": "/opt/conda/envs/adapointr-mamba/bin/python",
            "device": "cuda:0", "gpu_name": "synthetic-never-used",
            "execution_counts": self.runner.EXECUTION_COUNTS,
            "training_authorized": False, "bncal_authorized": False,
            "development_evaluation_authorized": False,
            "automatic_retry_authorized": False, "resume_authorized": False,
        }
        with tempfile.TemporaryDirectory() as tmp:
            auth = Path(tmp) / "auth.json"
            auth.write_text(json.dumps(base), encoding="utf-8")
            accepted = self.runner.validate_execution_authorization(
                auth, PROTOCOL_PATH, output
            )
            self.assertTrue(accepted["execution_authorized"])
            base["execution_authorized"] = False
            auth.write_text(json.dumps(base), encoding="utf-8")
            with self.assertRaises(self.runner.ContractError):
                self.runner.validate_execution_authorization(auth, PROTOCOL_PATH, output)
        self.assertFalse(output.exists())

    def test_trainable_membership_without_optimizer(self):
        result = self.runner.trainable_membership(FakeModel())
        self.assertEqual(result["group_count"], 1)
        self.assertEqual(result["trainable_tensor_count"], 2)
        self.assertEqual(
            result["trainable_names_sha256"],
            self.runner.sha256_lines(["decoder.weight", "encoder.weight"]),
        )

    def test_initialization_identity_contract(self):
        rows = []
        for run in self.runner.expected_run_specs():
            rows.append({
                "candidate": run["candidate"],
                "initial_common_state_sha256": "common",
                "initial_full_state_sha256": f"full-{run['candidate']}",
                "trainable_parameter_membership": {
                    "trainable_names_sha256": f"names-{run['candidate']}"
                },
            })
        result = self.runner.verify_initialization_identity(rows)
        self.assertTrue(result["cross_candidate_shared_initialization_equal"])
        rows[-1]["initial_full_state_sha256"] = "drift"
        with self.assertRaises(self.runner.ContractError):
            self.runner.verify_initialization_identity(rows)

    def test_runtime_heavy_imports_are_lazy_and_no_optimizer_step_exists(self):
        source = RUNNER_PATH.read_text(encoding="utf-8")
        tree = ast.parse(source)
        prefix = source.split("def import_runtime_components", 1)[0]
        self.assertNotIn("import torch", prefix)
        self.assertNotIn("from models", prefix)
        self.assertNotIn("from datasets", source)
        self.assertNotIn("torch.optim", source)
        self.assertNotIn(".step(", source)
        imported = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imported.update(alias.name.split(".")[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                imported.add(node.module.split(".")[0])
        self.assertNotIn("datasets", imported)
        if not self.torch_was_loaded:
            self.assertNotIn("torch", sys.modules)


if __name__ == "__main__":
    unittest.main(verbosity=2)
