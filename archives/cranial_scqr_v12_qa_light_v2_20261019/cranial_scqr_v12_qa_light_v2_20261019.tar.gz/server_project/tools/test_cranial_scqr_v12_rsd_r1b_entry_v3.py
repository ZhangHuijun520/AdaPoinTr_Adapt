"""Exactly24 standard-library/artificial checks. No WSL, CUDA, model or real data."""
import ast
import copy
import csv
import hashlib
import io
import json
import math
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import cranial_scqr_v12_rsd_r1b_contract_v3 as c
import run_cranial_scqr_v12_rsd_r1b_v3 as run


def tolerance():
    return {"status":"FROZEN_CONFIRMED_BEFORE_DEV", "basis_scope":"ARTIFICIAL_ONLY",
        "rule":"abs_difference <= atol + rtol * abs(reference)", "policy":"STRICT_ZERO_SLACK_REPLAY_ADMISSION",
        "draft_sha256":c.DRAFT_SHA,"plan_sha256":c.PLAN_SHA,"user_confirmed":True,
        "fields":{k:{"atol":0,"rtol":0} for k in c.CONTINUOUS}}


def metric():
    return {**{k:1.0 for k in c.CONTINUOUS}, "rim_reference_rim_points":3,"rim_predicted_rim_points":3,
        "zero_contact_2mm":0,"disaster":0,"case_id":"fake","source_skull_id":"fake","skull_id":"fake",
        "defect_type":"bilateral","fold":"C","seed":0}


def bind(path, digest="a"*64):
    return {"path":path,"bytes":1,"sha256":digest}


def request():
    return {"schema":"cranial-scqr-v1.2-RSD-R1B-fold-request-v3",
        "status":"AWAITING_EXPLICIT_USER_AUTHORIZATION","execution_authorized":False,"request_id":"artificial",
        "protocol_sha256":c.PROTOCOL_SHA,"fold":"C","seed":0,"conditions":list(c.CONDITIONS),
        "permissions":{k:False for k in c.FALSE_PERMISSIONS},
        "budget":{"cases":105,"forwards":315,"npz_opens":105,"checkpoint_loads":2,"checkpoint_hash_verifications":4,
            "member_partial":105,"member_implant":105,"member_gt":105,"optimizer_steps":0,"parameter_updates":0,
            "buffer_updates":0,"bncal_forwards":0},
        "forward_epoch":None,"rng_contract":"candidate-isolated-native-progression-v1",
        "empty_contact_policy":"STOP_KEEP_ORIGINAL_FLAGS","output_limit_bytes":16777216,
        "max_wall_seconds":7200,"max_vram_mib":20000,
        "environment_contract":{**{k:"fake" for k in ("python_version","torch_version","numpy_version",
            "scipy_version","cuda_version","gpu_driver")},"cudnn_version":90100,"cpu_threads":1,
            "binary_bindings":[bind("fake.so")],"extension_source_bindings":[bind("fake.cpp")]},
        "data_root":"/home/jovyan/datasets/SkullBreakPC_out8192",
        "resource":{"hostname":c.RESOURCE["hostname"],"gpu_uuid":c.RESOURCE["gpu_uuid"]},
        "models":{k:{"run_key":k+"_foldC_seed0","checkpoint":{"sha256":c.CHECKPOINT_SHA[k+"_foldC_seed0"]},
            "reference_csv":{"sha256":c.FROZEN_REFERENCE_SHA[k+"_foldC_seed0"]}} for k in ("LS","LSQ")},
        "implementation_bindings":[bind(k,v) for k,v in c.LEGACY_MAP.items()],
        "entry_bindings":[bind(k) for k in c.ENTRY_NAMES],
        "launch_contract":c.launch_contract(),
        "output_relative":"logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldC_seed0_artificial/result",
        "launch_paths":{"request":"docs/artificial_request.json","authorization":"logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldC_seed0_artificial/control/auth.json",
            "runtime":"logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldC_seed0_artificial/control/runtime.json",
            "entry":"tools/run_cranial_scqr_v12_rsd_r1b_v3.py","control":"logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldC_seed0_artificial/control"},
        "historical_policy":"REPORT_EXACT_DIFFERENCES_NOT_PAIRED_STOP",
        "supplement":bind("fake_supplement.md",c.SUPPLEMENT_SHA),
        "supplement_confirmation":bind("fake_confirmation.json"),
        "prior_exposure":{"failed_cases":1,"failed_forwards":3,"new_forwards":315,
            "cumulative_forwards_after_success":318,"consumed_request_sha256":c.CONSUMED_REQUEST_SHA},
        "preflight_evidence":{"request":bind("fake_request.json",c.V7_SHA),"audit":bind("fake_audit.json",c.AUDIT_SHA)}}


def preflight():
    state = {"LS":{"parameters":"fake","buffers":"fake"},"LSQ":{"parameters":"fake","buffers":"fake"}}
    v7={"resource_binding":copy.deepcopy(c.RESOURCE),"implementation_sha256":dict(c.LEGACY_MAP),
        "environment_runtime_contract":{"torch_version":"2.4.1+cu118","numpy_version":"2.2.6",
            "cuda_version":"11.8","cudnn_version":90100},"provider_wheel_sha256":"fake"}
    audit={"status":"PASS_FORMAL_READONLY_POST_PREFLIGHT_FREEZE_AUDIT","request_sha256":c.V7_SHA,
        "final_manifest_equal_initial":True,"summary":{"exit_code":0,"full_forward_completions":8,
            "exact_tensor_comparisons":11,"state_parameter_buffer_schema_equal_all8":True,"RNG_hash_equal_all8":True,
            "peak_allocated_bytes":835195904,"peak_reserved_bytes":859832320}}
    comp={"status":"PASS_SYNTHETIC_R1B_ZERO_UPDATE","synthetic_only":True,"counts":dict(c.COUNTS),
        "implementation_sha256":dict(c.LEGACY_MAP),**{k:0 for k in ("real_payload_open_events","real_checkpoint_loads",
            "real_checkpoint_byte_reads","optimizer_steps","parameter_updates","buffer_updates")}}
    blobs={"completion_receipt.json":comp,
        "gpu_identity.json":{"nvidia_smi":{"name":c.RESOURCE["gpu_name"],"uuid":c.RESOURCE["gpu_uuid"],
            "driver":c.RESOURCE["driver_version"],"total_mib":24564},
            "cuda":{"actual":{"visible_count":1,"name":c.RESOURCE["gpu_name"],"total_memory_bytes":25261047808}}},
        "environment_input_identity.json":{"environment":v7["environment_runtime_contract"],
            "provider_wheel_sha256":"fake","input_cpu_gpu_exact":True,"shape":[1,8192,3],"synthetic_only":True},
        "numerical_memory.json":{"before":dict(c.NUMERICAL),"after":dict(c.NUMERICAL)},
        "equality_scalar_state.json":{"full_sequence":{"state_before":state,"state_after":state,
            "records":[{"state_after":state,"rng_after_hash":"fake"} for _ in range(8)],
            "comparisons":[{"exact_equal":True,"max_abs_difference":0} for _ in range(11)]}}}
    return v7,audit,blobs,{"status":"PASS_IMPLEMENTATION_ONLY","implementation_sha256":dict(c.LEGACY_MAP)}


def inventory():
    data={("fake_%02d.json"%i):b'{}' for i in range(15)}
    manifest="".join(hashlib.sha256(b).hexdigest()+"  "+p+"\n" for p,b in data.items()).encode()
    data["files.sha256"]=manifest
    rows=[{"path":p,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()} for p,b in data.items()]
    return rows,data,manifest



def confirmed():
    return {"status":"CONFIRMED_SUPPLEMENT_IMPLEMENTATION_ONLY",
        "supplement_sha256":c.SUPPLEMENT_SHA,"selected_option":"B_NEW_SAME_PROCESS_DIAGNOSTIC",
        "execution_authorized":False,"old_zero_tolerance_unchanged":True,"prior_request_consumed":True}


class BytesState:
    def __init__(self, values):
        self.values = list(values)
    def tolist(self):
        return list(self.values)


def rng_states():
    return ((3,(1,2,3),None),("MT19937",BytesState([1,2,3]),4,0,0.0),
            BytesState([4,5]),[BytesState([6,7])])


def sources():
    return (ast.parse(os.environ["R1B_V3_PARENT_RUNNER_SOURCE"]),
            ast.parse(os.environ["R1B_V3_CHILD_RUNNER_SOURCE"]))


def functions(tree):
    return {n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}


class Contracts(unittest.TestCase):
    def test_N01_confirmation(self):
        c.validate_supplement_confirmation(confirmed())
        for key,value in (("status","DRAFT"),("execution_authorized",True),
                ("supplement_sha256","0"*64),("old_zero_tolerance_unchanged",False),
                ("prior_request_consumed",False),("selected_option","C")):
            v=confirmed();v[key]=value
            with self.assertRaises(c.ContractError):c.validate_supplement_confirmation(v)

    def test_N02_request_branch_and_exposure(self):
        with patch.object(c.socket,"gethostname",return_value=c.RESOURCE["hostname"]):
            c.validate_request(request())
            for key,value in (("schema","cranial-scqr-v1.2-RSD-R1B-fold-request-v2"),
                  ("historical_policy","EPSILON"),("request_id","r1b_foldC_seed0_real_intervention_v1_20261019"),
                  ("output_relative","logs/cranial_scqr_v12_rsd_r1b/old/result")):
                v=request();v[key]=value
                with self.assertRaises(c.ContractError):c.validate_request(v)
            v=request();v["prior_exposure"]["cumulative_forwards_after_success"]=315
            with self.assertRaises(c.ContractError):c.validate_request(v)
            v=request();v["supplement"]["sha256"]="0"*64
            with self.assertRaises(c.ContractError):c.validate_request(v)

    def test_N03_zero_tolerance_not_widened(self):
        old=metric();new=metric();new["implant_cd_l1_mm"]=math.nextafter(1.0,2.0)
        with self.assertRaises(c.ContractError):c.assert_native_replay(new,old,tolerance())
        t=tolerance();t["fields"]["implant_cd_l1_mm"]["atol"]=1e-6
        with self.assertRaises(c.ContractError):c.validate_tolerances(t)

    def test_N04_historical_no_epsilon(self):
        a=metric();a["condition"]="LS_native"
        b=dict(a);b["implant_cd_l1_mm"]=math.nextafter(1.0,2.0)
        row=c.historical_comparison(b,a)
        self.assertEqual(row["historical_numeric_status"],"HISTORICAL_NUMERIC_DIFFERENCE")
        self.assertEqual(row["historical_implant_cd_l1_mm"],1.0)
        self.assertEqual(row["current_implant_cd_l1_mm"],b["implant_cd_l1_mm"])
        self.assertGreater(row["absolute_difference_implant_cd_l1_mm"],0)
        self.assertEqual(c.historical_comparison(a,a)["historical_numeric_status"],"EXACT_NATIVE_METRIC_REPLAY")

    def test_N05_historical_flags_not_hidden(self):
        old=metric();old["condition"]="LSQ_native"
        new=dict(old,rim_contact_hd95_mm=51,disaster=1,rim_predicted_rim_points=4)
        row=c.historical_comparison(new,old)
        self.assertEqual(row["historical_event_or_count_status"],"HISTORICAL_EVENT_OR_COUNT_DIFFERENCE")
        self.assertEqual(row["historical_disaster"],0)
        self.assertEqual(row["current_disaster"],1)

    def test_N06_historical_identity_blocks(self):
        old=metric();old["condition"]="LS_native"
        for key in c.HISTORICAL_IDENTITY:
            new=dict(old);new[key]="foreign"
            with self.assertRaises(c.ContractError):c.historical_comparison(new,old)
        new=dict(old,condition="LSQ_query_off")
        with self.assertRaises(c.ContractError):c.historical_comparison(new,old)

    def test_N07_historical_invalid_reference_blocks(self):
        old=metric();old["condition"]="LS_native"
        for change in ({"implant_cd_l1_mm":float("nan")},{"rim_predicted_rim_points":-1},
                      {"disaster":1},{"rim_predicted_rim_points":0,"zero_contact_2mm":1}):
            with self.assertRaises(c.ContractError):c.historical_comparison(old,dict(old,**change))
        ids=["fake_%03d"%i for i in range(105)]
        rows=[dict(metric(),case_id=i) for i in ids]
        stream=io.StringIO();w=csv.DictWriter(stream,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
        with patch.object(Path,"open",return_value=io.StringIO(stream.getvalue())):
            c.read_native_csv(Path("fake.csv"),ids)
        rows[1]["fold"]="D"
        stream=io.StringIO();w=csv.DictWriter(stream,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
        with patch.object(Path,"open",return_value=io.StringIO(stream.getvalue())):
            with self.assertRaises(c.ContractError):c.read_native_csv(Path("fake.csv"),ids)

    def test_N08_history_order_and_partial(self):
        ids=["fake_%03d"%i for i in range(105)];h=c.HistoricalLedger(ids)
        row=dict(metric(),case_id=ids[0],condition="LS_native")
        h.compare(row,row)
        self.assertEqual(h.receipt()["scope"],"PARTIAL_ONLY")
        self.assertEqual(h.receipt()["numeric_status"],"NOT_ADJUDICATED_PARTIAL")
        with self.assertRaises(c.ContractError):h.receipt(complete=True)
        with self.assertRaises(c.ContractError):h.compare(row,row)
        with self.assertRaises(c.ContractError):c.HistoricalLedger(ids[:-1])

    def test_N09_full105_history_no_filter(self):
        ids=["fake_%03d"%i for i in range(105)];h=c.HistoricalLedger(ids);stream=io.StringIO()
        writer=csv.DictWriter(stream,fieldnames=c.HISTORY_FIELDS);writer.writeheader()
        for case in ids:
            for condition in ("LS_native","LSQ_native"):
                ref=dict(metric(),case_id=case,condition=condition)
                actual=dict(ref,implant_cd_l1_mm=2.0,rim_contact_hd95_mm=51,disaster=1)
                writer.writerow(h.compare(actual,ref))
        receipt=h.receipt(complete=True)
        self.assertEqual(receipt["native_case_rows"],210)
        self.assertEqual(receipt["numeric_difference_rows"],210)
        self.assertEqual(receipt["event_or_count_difference_rows"],210)
        self.assertFalse(receipt["old_zero_tolerance_request_passed"])
        stream.seek(0);self.assertEqual(len(list(csv.DictReader(stream))),210)

    def test_N10_rng_canonical_domains(self):
        base=rng_states();digest=run.rng_fingerprint(base)
        self.assertEqual(digest,run.rng_fingerprint(copy.deepcopy(base)))
        for i in range(4):
            value=list(copy.deepcopy(base))
            if i==0:value[0]=(3,(9,2,3),None)
            if i==1:value[1]=("MT19937",BytesState([9,2,3]),4,0,0.0)
            if i==2:value[2]=BytesState([9,5])
            if i==3:value[3]=[BytesState([9,7])]
            self.assertNotEqual(digest,run.rng_fingerprint(value))

    def test_N11_rng_mismatch_stops(self):
        row={"case_id":"fake","pre_native":"a"*64,"pre_off":"a"*64,
             "post_native":"b"*64,"post_off":"b"*64}
        c.validate_paired_rng(row)
        for key in ("pre_off","post_off"):
            x=dict(row);x[key]="c"*64
            with self.assertRaises(c.ContractError):c.validate_paired_rng(x)
        x=dict(row);x["post_off"]="bad"
        with self.assertRaises(c.ContractError):c.validate_paired_rng(x)

    def test_N12_outlet_stops(self):
        good={"query_outlet_calls":1,"applied_residual_rms":0.0,"potential_residual_rms":0.3}
        c.validate_paired_outlet(good)
        for key,value in (("query_outlet_calls",2),("applied_residual_rms",1e-30),
                          ("potential_residual_rms",float("inf"))):
            x=dict(good);x[key]=value
            with self.assertRaises(c.ContractError):c.validate_paired_outlet(x)

    def test_N13_current_pairing_AST_preserved(self):
        p,q=functions(sources()[0]),functions(sources()[1])
        # Entire original current-native pairing and descriptive aggregation block is identical.
        def block(node):
            body=node.body
            a=next(i for i,n in enumerate(body) if isinstance(n,ast.Try))
            body=body[a].body
            start=next(i for i,n in enumerate(body) if isinstance(n,ast.Assign)
                and isinstance(n.targets[0],ast.Name) and n.targets[0].id=="paired")
            stop=next(i for i,n in enumerate(body[start:],start) if isinstance(n,ast.Expr)
                and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name)
                and n.value.func.id=="json_exclusive")
            return ast.dump(ast.Module(body=body[start:stop+1],type_ignores=[]))
        self.assertEqual(block(p["run_authorized"]),block(q["run_authorized"]))

    def test_N14_105_case_315_forward_ledger(self):
        ids=["fake_%03d"%i for i in range(105)];ledger=c.AccessLedger(ids,"C")
        for k in ("LS","LSQ"):ledger.record_checkpoint_load(k+"_foldC_seed0")
        for _ in range(4):ledger.record_checkpoint_hash()
        for case in ids:
            ledger.begin_case(case);ledger.read_member("partial")
            for condition in c.CONDITIONS:ledger.begin_forward(condition);ledger.end_forward()
            ledger.read_member("implant");ledger.read_member("gt");ledger.end_case()
        ledger.assert_final()
        with self.assertRaises(c.ContractError):ledger.begin_case(ids[0])

    def test_N15_GT_order_and_failed_latch(self):
        ledger=c.AccessLedger(["fake_%03d"%i for i in range(105)],"C")
        for k in ("LS","LSQ"):ledger.record_checkpoint_load(k+"_foldC_seed0")
        ledger.begin_case("fake_000")
        with self.assertRaises(c.ContractError):ledger.read_member("gt")
        with self.assertRaises(c.ContractError):ledger.read_member("partial")

    def test_N16_core_helpers_preserved(self):
        p,q=map(functions,sources())
        for name in ("snapshot_rng","restore_rng","canonical_tensor_hash","state_hashes",
                "points_member","extra_geometry","assert_compiled_provider","prepare_provider_paths",
                "validate_launch_preconditions","assert_entry_numerical","migration_counts"):
            self.assertEqual(ast.dump(p[name]),ast.dump(q[name]),name)

    def test_N17_no_heavy_imports(self):
        self.assertNotIn("torch",sys.modules)
        self.assertNotIn("numpy",sys.modules)
        for _,tree in zip((0,1),sources()):
            for node in tree.body:
                if isinstance(node,ast.Import):
                    self.assertNotIn("torch",[a.name for a in node.names])

    def test_N18_path_guards(self):
        # Existing parent/noclobber checks remain; all path operations below are
        # artificial mocks: no fixture directories, links or JSON files exist.
        with patch.object(c.socket,"gethostname",return_value=c.RESOURCE["hostname"]):
            text=run.render_launcher(request(),"a"*64,"b"*64,"c"*64)
        self.assertLess(text.index("mkdir -p"),text.index("exec 3>"))
        self.assertIn("set -euC",text)
        with self.assertRaises(c.ContractError):c.checked_path(Path.cwd(),"../escape")
        root=Path.cwd()/"__r1b_authpath_memory_only__"
        names=("request","authorization","runtime")
        values={k:root/(k+"_parent")/(k+".json") for k in names}
        args=SimpleNamespace(**values,**{k+"_sha256":"a"*64 for k in names})
        events=[]
        def resolve(path,*a,**kw):
            events.append(("resolve",path))
            return path
        def run_case(linked=None):
            events.clear()
            def is_link(path):
                events.append(("link_check",path))
                return path==linked
            with patch.object(run,"ROOT",root),patch.object(Path,"is_symlink",is_link),\
                 patch.object(Path,"is_file",return_value=True),patch.object(Path,"resolve",resolve),\
                 patch.object(c,"sha256_file",side_effect=AssertionError("hash before guard complete")),\
                 patch.object(run,"json_read",side_effect=AssertionError("JSON before guard complete")):
                return run.checked_authorization_paths(args)
        checked=run_case()
        self.assertEqual(checked,[(values[k],"a"*64) for k in names])
        # Check file, immediate parent and root aliases for each argument.
        # A linked root ancestor is additionally rejected in every role matrix.
        for role in names:
            for linked in (values[role],values[role].parent,root,root.parent):
                with self.subTest(role=role,linked=str(linked)):
                    with self.assertRaises(c.ContractError) as caught:run_case(linked)
                    self.assertIn(str(linked),str(caught.exception))
                    self.assertFalse(any(kind=="resolve" and
                        (p==linked or linked in p.parents) for kind,p in events))
        # Relative safe arguments retain cwd semantics; lexical escape, outside
        # root and dangling/final aliases fail without hash/JSON reads.
        args.request=Path("request_parent")/"request.json"
        with patch.object(Path,"cwd",return_value=root):
            self.assertEqual(run_case()[0][0],values["request"])
        for bad in (root/"sub"/".."/"request.json",root.parent/"outside.json"):
            args.request=bad
            with self.assertRaises(c.ContractError):run_case()
        args.request=values["request"]
        self.assertEqual(run_case()[0][0],values["request"])


    def test_N19_launcher_and_raw_capture(self):
        with patch.object(c.socket,"gethostname",return_value=c.RESOURCE["hostname"]):
            text=run.render_launcher(request(),"a"*64,"b"*64,"c"*64)
        self.assertIn("run_cranial_scqr_v12_rsd_r1b_v3.py",text)
        self.assertIn('"$$"',text)
        self.assertIn('exit "$code"',text)
        self.assertEqual(run.caller_capture_contract(b'a',b'\\xff',1)["exit_code"],1)

    def test_N20_pre_authorization_no_IO(self):
        events=[]
        with patch.object(c,"sha256_file",side_effect=lambda *a:events.append(a)),\
             patch.object(c,"bound_path",side_effect=AssertionError("forbidden IO")):
            with self.assertRaises(c.ContractError):run.text_execution_preconditions(SimpleNamespace())
        self.assertEqual(events,[])

    def test_N21_confirmation_before_checkpoint(self):
        fn=functions(sources()[1])["text_execution_preconditions"]
        text=ast.unparse(fn)
        self.assertLess(text.index("validate_supplement_confirmation"),text.index("Payload/checkpoint") if
                        "Payload/checkpoint" in text else text.index("for model in"))
        self.assertNotIn("assert_native_replay",ast.unparse(functions(sources()[1])["run_authorized"]))
        self.assertIn("validate_tolerance_confirmation",text)

    def test_N22_p3_exact_new_binding(self):
        bindings=request()["entry_bindings"]
        p3={"status":"PASS_LOCAL_IMPLEMENTATION_ONLY","entry_sha256":c.binding_map(bindings),
            "legacy_implementation_sha256":dict(c.LEGACY_MAP),"tests_passed":24,"tests_failed":0,
            "gpu_used":False,"scientific_delta_scoped":True,"old_entry_unchanged":True,
            "supplement_sha256":c.SUPPLEMENT_SHA}
        c.validate_entry_p3(bindings,p3)
        p3["entry_sha256"]={}
        with self.assertRaises(c.ContractError):c.validate_entry_p3(bindings,p3)

    def test_N23_limits_and_permissions(self):
        c.validate_memory(1,1)
        for value in (-1,20000*1024*1024+1,True):
            with self.assertRaises(c.ContractError):c.validate_memory(value,1)
        with patch.object(c.socket,"gethostname",return_value=c.RESOURCE["hostname"]):
            for key in ("training","bncal","automatic_retry","resume","other_fold"):
                v=request();v["permissions"][key]=True
                with self.assertRaises(c.ContractError):c.validate_request(v)
            v=request();v["budget"]["forwards"]=316
            with self.assertRaises(c.ContractError):c.validate_request(v)
        c.validate_preflight_values(*preflight())

    def test_N24_runner_pair_wiring_and_chain(self):
        body=ast.unparse(functions(sources()[1])["run_authorized"])
        self.assertEqual(body.count("ledger.begin_forward(condition)"),1)
        self.assertEqual(body.count("model(partial, epoch=None"),1)
        for text in ("historical_native_comparison.csv","history.compare","history.receipt(complete=True)",
                     "validate_paired_rng(current_pair)","validate_paired_outlet(diagnostic)",
                     "paired_rng_evidence.json","PASS_CURRENT_PAIRED_DIAGNOSTIC_ONLY",
                     "old_zero_tolerance_request_passed"):
            self.assertIn(text,body)
        self.assertIn("array_equal(preds['LSQ_native'][0], preds['LSQ_query_off'][0])",body)
        r=request();A="b"*64;S="a"*64
        auth={"status":"AUTHORIZED_ONCE","execution_authorized":True,"request_sha256":S,
              "request_id":r["request_id"],"fold":"C","permissions":dict(r["permissions"])}
        runtime={"stage":"V12_RSD_R1B_SAME_PROCESS_PAIRED_FOLD","request_sha256":S,
                 "authorization_receipt_sha256":A,"fold":"C","runs_authorized":1}
        with patch.object(c.socket,"gethostname",return_value=c.RESOURCE["hostname"]):
            c.validate_chain(r,auth,runtime,S,A)
            auth["runtime_sha256"]="c"*64
            with self.assertRaises(c.ContractError):c.validate_chain(r,auth,runtime,S,A)


if __name__ == "__main__":
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Contracts)
    if suite.countTestCases()!=24:raise SystemExit("expected exactly24")
    result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
    print(json.dumps({"tests_run":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),
        "passed":result.wasSuccessful() and result.testsRun==24,"gpu_used":False,"model_forwards":0,
        "real_payload_reads":0,"checkpoint_loads":0},sort_keys=True))
    raise SystemExit(0 if result.wasSuccessful() and result.testsRun==24 else 1)

