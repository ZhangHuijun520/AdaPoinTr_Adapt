"""Pure-text and CPU-only tests for the v1.2 QA-1 BNCal guard/tool."""

from __future__ import annotations

import copy
import hashlib
import json
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace as NS

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from tools import run_cranial_scqr_v12_qa1_bncal as bncal_mod


EXPECTED_V11_BNCAL_SHA256 = (
    "c6e4c4a67f6ebf684be618cec7eb9568d775cfb03205773fc901883516939102"
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, payload: dict) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return sha256(path)


def expect_runtime_error(callback, label: str) -> None:
    try:
        callback()
    except RuntimeError:
        return
    raise AssertionError(f"expected RuntimeError: {label}")


def build_fixture(root: Path):
    bncal_mod.REPO_ROOT = root
    run_key = "B0_foldC_seed0"
    config_path = root / "bncal_runtime.yaml"
    config_path.write_text("runtime: synthetic\n", encoding="utf-8")

    allowlist = root / "foldC_train_case_ids.txt"
    allowlist.write_text(
        "".join(f"case_{index:03d}\n" for index in range(bncal_mod.EXPECTED_CASES)),
        encoding="utf-8",
    )
    allowlist_sha = sha256(allowlist)

    experiment_dir = root / "experiment"
    experiment_dir.mkdir()
    checkpoint = experiment_dir / "ckpt-last.pth"
    checkpoint.write_bytes(b"synthetic-checkpoint\n")
    checkpoint_sha = sha256(checkpoint)

    source_runtime = root / "source_training_runtime.yaml"
    source_runtime.write_text("stage: V12_QA1_training\n", encoding="utf-8")
    source_runtime_sha = sha256(source_runtime)
    state_path = experiment_dir / "v12_qa1_training_execution_state.json"
    state_sha = write_json(
        state_path,
        {
            "receipt_version": bncal_mod.SOURCE_STATE_VERSION,
            "status": bncal_mod.SOURCE_STATE_STATUS,
            "optimizer_steps": 3939,
            "model_updates": 3939,
            "epoch_traversals_completed": 101,
            "development_dataloader_constructed": False,
            "development_payload_accessed": False,
            "bncal_authorized": False,
            "bncal_updates": 0,
            "runtime_config_sha256": source_runtime_sha,
            "checkpoint_sha256": checkpoint_sha,
            "candidate": "B0",
            "fold": "C",
            "seed": 0,
        },
    )
    completion_path = root / "training_completion_receipt.json"
    completion_sha = write_json(
        completion_path,
        {
            "status": bncal_mod.SOURCE_COMPLETION_STATUS,
            "optimizer_steps": 3939,
            "model_updates": 3939,
            "epoch_traversals": 101,
            "bncal_runs": 0,
            "development_payload_accessed": False,
            "training_state_sha256": state_sha,
            "training_checkpoint_sha256": checkpoint_sha,
        },
    )

    request_path = root / "bncal_request.json"
    request_sha = write_json(
        request_path,
        {
            "status": "AWAITING_EXPLICIT_USER_AUTHORIZATION",
            "execution_authorized": False,
            "requested_run_keys": [run_key],
            "resource_binding": {
                "deterministic_algorithms": True,
                "tf32": False,
                "cublas_workspace_config": ":4096:8",
            },
            "bncal_contract": {
                "train_cases": 315,
                "batches": 40,
                "forward_calls": 40,
                "optimizer_steps": 0,
                "model_parameter_updates": 0,
                "input": "partial only",
            },
        },
    )
    formal_path = root / "formal_protocol.json"
    formal_sha = write_json(
        formal_path,
        {
            "protocol_id": bncal_mod.FORMAL_CONFIG_PROTOCOL_ID,
            "status": "FROZEN_IMPLEMENTATION_ONLY",
        },
    )
    p3_path = root / "bncal_p3.json"
    p3_sha = write_json(
        p3_path,
        {
            "status": "PASS_IMPLEMENTATION_ONLY",
            "bncal_authorized_by_this_receipt": False,
            "development_payload_access_authorized_by_this_receipt": False,
        },
    )

    execution = NS(
        stage=bncal_mod.STAGE,
        training_authorized=False,
        bncal_authorized=True,
        optimizer_steps_authorized=0,
        bncal_runs_authorized=1,
        bncal_cases_expected=315,
        bncal_batches_expected=40,
        development_payload_access_authorized=False,
        development_evaluation_authorized=False,
        resume_authorized=False,
        automatic_rerun_authorized=False,
        automatic_next_run_authorized=False,
        bncal_execution_request="bncal_request.json",
        bncal_execution_request_sha256=request_sha,
        bncal_authorization_receipt="authorization.json",
        bncal_authorization_receipt_sha256="PENDING",
        formal_config_protocol="formal_protocol.json",
        formal_config_protocol_sha256=formal_sha,
        bncal_post_implementation_p3_receipt="bncal_p3.json",
        bncal_post_implementation_p3_receipt_sha256=p3_sha,
        source_training_completion_receipt="training_completion_receipt.json",
        source_training_completion_receipt_sha256=completion_sha,
        source_training_runtime_config_sha256=source_runtime_sha,
        source_training_state_sha256=state_sha,
        source_training_checkpoint_sha256=checkpoint_sha,
        train_case_ids="foldC_train_case_ids.txt",
        train_case_ids_sha256=allowlist_sha,
    )
    config = NS(
        cranial_scqr_execution=execution,
        development_protocol=NS(candidate="B0", fold="C", seed=0),
        qa1_lock=NS(
            run_key=run_key,
            candidate="B0",
            fold="C",
            seed=0,
            train_case_ids="foldC_train_case_ids.txt",
            train_case_ids_sha256=allowlist_sha,
        ),
        dataset=NS(
            train=NS(others=NS(include_case_ids_file="foldC_train_case_ids.txt"))
        ),
    )
    authorization_path = root / "authorization.json"
    authorization_sha = write_json(
        authorization_path,
        {
            "status": "AUTHORIZED",
            "execution_authorized": True,
            "authorized_run_keys": [run_key],
            "training_authorized": False,
            "bncal_authorized": True,
            "optimizer_steps_authorized": 0,
            "development_payload_access_authorized": False,
            "development_evaluation_authorized": False,
            "automatic_rerun_authorized": False,
            "automatic_next_run_authorized": False,
            "bncal_request": {
                "path": "bncal_request.json",
                "sha256": request_sha,
            },
        },
    )
    execution.bncal_authorization_receipt_sha256 = authorization_sha
    return config, config_path, experiment_dir


def test_valid_and_rejections() -> None:
    with tempfile.TemporaryDirectory(prefix="v12_qa1_bncal_guard_") as temporary:
        root = Path(temporary)
        config, config_path, experiment_dir = build_fixture(root)
        result = bncal_mod.validate_execution(config, config_path, experiment_dir)
        assert result[0].name == "v12_qa1_training_execution_state.json"
        assert result[1].name == "ckpt-last.pth"

        authorization_path = root / "authorization.json"
        authorization = json.loads(authorization_path.read_text(encoding="utf-8"))
        assert "bncal_runtime_config_sha256" not in authorization
        authorization["unexpected_mutation"] = True
        write_json(authorization_path, authorization)
        expect_runtime_error(
            lambda: bncal_mod.validate_execution(config, config_path, experiment_dir),
            "runtime config must bind the authorization receipt SHA256",
        )
        authorization.pop("unexpected_mutation")
        assert write_json(authorization_path, authorization) == (
            config.cranial_scqr_execution.bncal_authorization_receipt_sha256
        )

        bad_stage = copy.deepcopy(config)
        bad_stage.cranial_scqr_execution.stage = "L4_roundA_training"
        expect_runtime_error(
            lambda: bncal_mod.validate_execution(bad_stage, config_path, experiment_dir),
            "v1.1 stage must fail",
        )

        bad_training = copy.deepcopy(config)
        bad_training.cranial_scqr_execution.training_authorized = True
        expect_runtime_error(
            lambda: bncal_mod.validate_execution(
                bad_training, config_path, experiment_dir
            ),
            "training authorization must stay false",
        )

        bad_dev = copy.deepcopy(config)
        bad_dev.cranial_scqr_execution.development_payload_access_authorized = True
        expect_runtime_error(
            lambda: bncal_mod.validate_execution(bad_dev, config_path, experiment_dir),
            "development access must stay false",
        )

        state_path = experiment_dir / "v12_qa1_training_execution_state.json"
        original = json.loads(state_path.read_text(encoding="utf-8"))
        drifted = dict(original)
        drifted["optimizer_steps"] = 3938
        write_json(state_path, drifted)
        expect_runtime_error(
            lambda: bncal_mod.validate_execution(config, config_path, experiment_dir),
            "source step drift must fail",
        )


def test_v11_identity_and_output_contract() -> None:
    assert sha256(REPO_ROOT / "tools" / "run_cranial_scqr_v11_l4_bncal.py") == (
        EXPECTED_V11_BNCAL_SHA256
    )
    text = (
        REPO_ROOT / "tools" / "run_cranial_scqr_v12_qa1_bncal.py"
    ).read_text(encoding="utf-8")
    assert 'STAGE = "V12_QA1_bncal"' in text
    assert 'state_path = experiment_dir / "v12_qa1_training_execution_state.json"' in text
    assert 'receipt_path = experiment_dir / "v12_qa1_bncal_receipt.json"' in text
    assert 'files_path = experiment_dir / "v12_qa1_bncal_files.sha256"' in text
    assert 'output_checkpoint = experiment_dir / "ckpt-last-bncal.pth"' in text
    assert "development_dataloader_constructed" in text
    assert "SOURCE_STATE_STATUS" in text
    assert 'authorization.get("bncal_runtime_config_sha256")' not in text


def main() -> None:
    test_valid_and_rejections()
    test_v11_identity_and_output_contract()
    print(
        json.dumps(
            {
                "status": "PASS",
                "tests": 2,
                "real_dataset_constructions": 0,
                "manifest_files_opened": 0,
                "npz_payload_files_opened": 0,
                "checkpoint_payload_files_opened": 0,
                "cuda_calls": 0,
                "optimizer_steps": 0,
                "model_parameter_updates": 0,
                "training_runs": 0,
                "bncal_runs": 0,
                "development_evaluations": 0,
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
