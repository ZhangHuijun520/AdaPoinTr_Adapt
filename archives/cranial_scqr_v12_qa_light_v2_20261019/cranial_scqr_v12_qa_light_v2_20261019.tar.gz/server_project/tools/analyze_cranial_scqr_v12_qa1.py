"""QA-1 authorized CPU descriptive analysis. No torch, payload or gate execution."""
import argparse
import csv
import hashlib
import json
import math
import os
import socket
from collections import defaultdict
from pathlib import Path

import numpy as np

PRIMARY = 'rim_gt_rim_to_pred_p95_mm'
METRICS = (PRIMARY, 'implant_cd_l1_mm', 'final_cd_l1_mm',
           'final_hd95_mm', 'final_nsd_at_1mm')
DEFECTS = {'bilateral', 'frontoorbital', 'parietotemporal', 'random_1', 'random_2'}
RUNS = {f'{c}_fold{f}_seed0' for c in ('B0', 'LS', 'LSQ') for f in ('C', 'D')}
SUPPLEMENT_SHA = '85751899ec1c9d274c6f899049e45823e4acf9c41fe50504efae60561cbf0b8f'
LOCK = 'NOT_ADJUDICATED_HISTORICAL_NUMERICAL_EVIDENCE_GAP'


class ContractError(ValueError):
    pass


def require(ok, message):
    if not ok:
        raise ContractError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bound(root, spec):
    p = Path(spec['path'])
    require(not p.is_absolute() and '..' not in p.parts, 'relative bound path')
    p = root / p
    require(p.resolve().is_relative_to(root.resolve()), 'path escape')
    require(not p.is_symlink() and p.is_file(), 'regular file required')
    require(p.stat().st_size == spec['bytes'] and digest(p) == spec['sha256'],
            'bound file drift: ' + str(p))
    return p


def finite(value):
    try:
        v = float(value)
    except (ValueError, TypeError) as exc:
        raise ContractError('invalid numeric') from exc
    require(math.isfinite(v), 'nonfinite metric')
    return v


def validate(rows, allowlists):
    groups = defaultdict(list)
    seen = set()
    mappings = {}
    for row in rows:
        run = row['run_key']
        require(run in RUNS, 'unexpected run')
        candidate, fold, seed = run.split('_')
        require(row['candidate'] == candidate and row['fold'] == fold[-1]
                and str(row['seed']) == '0', 'identity mismatch')
        key = (run, row['case_id'])
        require(key not in seen, 'duplicate case')
        seen.add(key)
        source = str(row['source_skull_id'])
        require(bool(source), 'empty source')
        pairing = (row['fold'], row['case_id'])
        mapping = (source, row['defect_type'])
        require(pairing not in mappings or mappings[pairing] == mapping,
                'candidate source/defect mismatch')
        mappings[pairing] = mapping
        for m in METRICS:
            finite(row[m])
        for m in ('disaster', 'zero_contact_2mm'):
            require(finite(row[m]) in (0, 1), 'nonbinary event')
        groups[run].append(row)
    require(set(groups) == RUNS, 'missing run')
    sources_by_fold = {}
    for run, part in groups.items():
        fold = run.split('_')[1][-1]
        ids = [r['case_id'] for r in part]
        require(len(part) == 105 and ids == allowlists[fold], 'allowlist order/count')
        sg = defaultdict(list)
        for row in part:
            sg[str(row['source_skull_id'])].append(row)
        require(len(sg) == 21, 'source count')
        for g in sg.values():
            require(len(g) == 5 and {r['defect_type'] for r in g} == DEFECTS,
                    'five frozen defects required')
        sources_by_fold[fold] = set(sg)
    require(not sources_by_fold['C'] & sources_by_fold['D'], 'source overlap')
    return groups


def primary_deltas(rows, allowlists):
    groups = validate(rows, allowlists)
    output = []
    for fold in ('C', 'D'):
        index = {r['case_id']: r for r in groups[f'LS_fold{fold}_seed0']}
        sg = defaultdict(list)
        for left in groups[f'LSQ_fold{fold}_seed0']:
            right = index[left['case_id']]
            sg[str(left['source_skull_id'])].append({
                m: finite(left[m]) - finite(right[m]) for m in METRICS})
        for source in sorted(sg):
            output.append({'fold': fold, 'source_skull_id': source,
                           **{m: float(np.mean([x[m] for x in sg[source]]))
                              for m in METRICS}})
    return output


def bootstrap(deltas, metric, seed=20260910, samples=10000):
    require(seed == 20260910 and samples == 10000, 'frozen bootstrap')
    arrays = []
    for fold in ('C', 'D'):
        part = sorted((r for r in deltas if r['fold'] == fold),
                      key=lambda r: r['source_skull_id'])
        require(len(part) == 21 and len({r['source_skull_id'] for r in part}) == 21,
                '21 paired sources required')
        arrays.append(np.array([finite(r[metric]) for r in part], dtype=np.float64))
    rng = np.random.default_rng(seed)
    draws = np.empty(samples, dtype=np.float64)
    for start in range(0, samples, 1000):
        count = min(1000, samples - start)
        means = [a[rng.integers(0, 21, size=(count, 21))].mean(axis=1)
                 for a in arrays]
        draws[start:start + count] = 0.5 * (means[0] + means[1])
    lo, hi = np.percentile(draws, [2.5, 97.5], method='linear')
    return {'fold_C': float(arrays[0].mean()), 'fold_D': float(arrays[1].mean()),
            'pooled': float(0.5 * (arrays[0].mean() + arrays[1].mean())),
            'ci95_low': float(lo), 'ci95_high': float(hi),
            'samples': samples, 'seed': seed}


def analyze(rows, allowlists):
    deltas = primary_deltas(rows, allowlists)
    return {'comparison': 'LSQ_minus_LS', 'paired_source_count': 42,
            'metrics': {m: bootstrap(deltas, m) for m in METRICS},
            'formal_gate_status': LOCK, 'formal_classification': None,
            'gate_checks_computed': False, 'secondary_comparison_computed': False,
            'historical_missing_snapshots': ['B0_foldC_seed0', 'B0_foldD_seed0',
                                             'LS_foldC_seed0'],
            'retrospective_numerical_certification': False,
            'automatic_next_stage': False,
            'interpretation': 'Fixed-checkpoint conditional description only; '
                              'CI does not remove training numerical confounding '
                              'or quantify training-seed variability.'}, deltas


def verify_request(root, request, receipt, request_sha):
    require(request['status'] == 'AWAITING_EXPLICIT_USER_AUTHORIZATION'
            and request['execution_authorized'] is False, 'immutable pending request')
    require(request['scope'] == 'CPU_DESCRIPTIVE_LSQ_MINUS_LS_ONLY', 'scope')
    require(request['supplement']['sha256'] == SUPPLEMENT_SHA, 'supplement')
    require(request['formal_gate_authorized'] is False
            and request['secondary_comparison_authorized'] is False, 'locked stages')
    require(receipt['status'] == 'AUTHORIZED_ONCE'
            and receipt['execution_request_sha256'] == request_sha
            and receipt['run_id'] == request['run_id'], 'execution receipt')
    require(socket.gethostname() == request['hostname'], 'hostname drift')
    require(np.__version__ == request['numpy_version'], 'numpy drift')
    bound(root, request['supplement'])
    for spec in request['implementation_bindings'] + request['input_bindings']:
        bound(root, spec)
    require(digest(Path(__file__)) == request['implementation_bindings'][0]['sha256'],
            'executing implementation drift')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--execution-request', required=True)
    parser.add_argument('--execution-request-sha256', required=True)
    parser.add_argument('--authorization-receipt', required=True)
    parser.add_argument('--authorization-receipt-sha256', required=True)
    args = parser.parse_args()
    root = Path.cwd()
    require(str(root.resolve()) == '/home/jovyan/adapointr_work/PoinTr', 'project root')
    rp, ap = Path(args.execution_request), Path(args.authorization_receipt)
    require(digest(rp) == args.execution_request_sha256, 'request hash')
    require(digest(ap) == args.authorization_receipt_sha256, 'receipt hash')
    q, auth = json.loads(rp.read_text()), json.loads(ap.read_text())
    verify_request(root, q, auth, args.execution_request_sha256)
    require(set(q['case_csvs']) == RUNS, 'six input runs')
    declared = {x['path'] for x in q['input_bindings']}
    require(set(q['case_csvs'].values()) | set(q['allowlists'].values()) <= declared,
            'unbound input')
    out = root / q['output_dir']
    require(not Path(q['output_dir']).is_absolute() and '..' not in out.parts
            and out.resolve().is_relative_to(root.resolve()), 'output boundary')
    require(not out.exists(), 'output exists; retry forbidden')
    # Exclusive output reservation occurs before metrics are opened; failures remain evidence.
    out.mkdir(parents=False, exist_ok=False)
    rows = []
    for run in sorted(RUNS):
        with (root / q['case_csvs'][run]).open(newline='') as handle:
            part = list(csv.DictReader(handle))
        require(all(r['run_key'] == run for r in part), 'CSV run identity')
        rows.extend(part)
    allow = {f: (root / p).read_text().splitlines() for f, p in q['allowlists'].items()}
    result, deltas = analyze(rows, allow)
    result.update(execution_request_sha256=args.execution_request_sha256,
                  authorization_receipt_sha256=args.authorization_receipt_sha256,
                  numpy_version=np.__version__)
    for name, value in [('descriptive_summary.json', result),
                        ('paired_primary_source_deltas.json', deltas)]:
        with (out / name).open('x') as handle:
            json.dump(value, handle, indent=2, allow_nan=False)
            handle.write('\n')
    with (out / 'files.sha256').open('x') as handle:
        for p in sorted(out.iterdir()):
            if p.name != 'files.sha256':
                handle.write(f'{digest(p)}  {p.name}\n')
    print('PASS_DESCRIPTIVE_ONLY_PENDING_SEPARATE_FREEZE_AUDIT')


if __name__ == '__main__':
    main()
