#!/usr/bin/env python3
"""Fail-closed single-run development evaluator for Cranial-SCQR v1.2 QA-1.

Importing this module performs no checkpoint, manifest, NPZ, CUDA, or model
work.  Formal execution requires a separately authorized, hash-bound runtime
chain.  This implementation deliberately produces descriptive single-run
metrics only; it cannot apply the six-run QA-1 comparison gate.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

import numpy as np


TOOLS_DIR = Path(__file__).resolve().parent
REPO_ROOT = TOOLS_DIR.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))
if str(TOOLS_DIR) not in sys.path:
    sys.path.insert(0, str(TOOLS_DIR))

import run_cranial_scqr_v11_l4_round_a_dev_eval as v11  # noqa: E402


ContractError = v11.ContractError
ALLOWED_NPZ_MEMBERS = ("partial", "implant", "gt")
ALLOWED_CANDIDATES = ("B0", "LS", "LSQ")
ALLOWED_FOLDS = ("C", "D")
DEFECTS = ("bilateral", "frontoorbital", "parietotemporal", "random_1", "random_2")
REQUEST_SCHEMA = "cranial-scqr-v1.2-QA1-single-development-evaluation-request-v2"
RUNTIME_STAGE = "V12_QA1_single_development_evaluation"
V11_RUNNER_PATH = "tools/run_cranial_scqr_v11_l4_round_a_dev_eval.py"
V11_RUNNER_SHA256 = "6be1c38b46270eff278ea7a54805ba0d572e8aef81a103350308072380c38798"

SOURCE_MEAN_FIELDS = (
    "implant_cd_l1_mm",
    "implant_pred_to_ref_mean_mm",
    "implant_ref_to_pred_mean_mm",
    "implant_hd95_mm",
    "implant_nsd_at_1mm",
    "final_cd_l1_mm",
    "final_hd95_mm",
    "final_nsd_at_1mm",
    "rim_reference_rim_points",
    "rim_predicted_rim_points",
    "rim_gt_rim_to_pred_mean_mm",
    "rim_gt_rim_to_pred_p95_mm",
    "rim_contact_cd_l1_mm",
    "rim_contact_hd95_mm",
    "rim_contact_precision",
    "rim_contact_recall",
)
SOURCE_SUM_FIELDS = ("zero_contact_2mm", "disaster")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path) -> str:
    return v11.sha256_file(path)


def load_json(path: Path) -> dict[str, Any]:
    return v11.load_json(path)


def resolve_under(root: Path, relative: str, *, must_exist: bool = True) -> Path:
    return v11.resolve_under(root, relative, must_exist=must_exist)


def verify_file(path: Path, expected_sha: str, expected_bytes: int | None = None) -> None:
    v11.verify_file(path, expected_sha, expected_bytes)


def hash_tensor_mapping(mapping: Mapping[str, Any]) -> str:
    return v11.hash_tensor_mapping(mapping)


def model_state_hashes(model: Any) -> dict[str, str]:
    return v11.model_state_hashes(model)


def assert_state_unchanged(before: Mapping[str, str], after: Mapping[str, str]) -> None:
    v11.assert_state_unchanged(before, after)


def invoke_partial_only(model: Callable[[Any], Any], partial: Any) -> Any:
    return v11.invoke_partial_only(model, partial)


def forward_then_metrics(
    forward: Callable[[Any], Any],
    partial: Any,
    implant: Any,
    gt: Any,
    metric: Callable[[Any, Any, Any, Any], Any],
) -> Any:
    return v11.forward_then_metrics(forward, partial, implant, gt, metric)


class AccessLedger:
    """Audit the exact one-checkpoint, 105-case execution budget."""

    def __init__(self) -> None:
        self.counts: Counter[str] = Counter()
        self._opened: set[tuple[str, str]] = set()

    def record_checkpoint_load(self, run_key: str) -> None:
        key = ("checkpoint", run_key)
        if key in self._opened:
            raise ContractError(f"duplicate checkpoint load: {run_key}")
        self._opened.add(key)
        self.counts["checkpoint_loads"] += 1

    def record_npz_open(self, run_key: str, case_id: str) -> None:
        key = (run_key, case_id)
        if key in self._opened:
            raise ContractError(f"duplicate NPZ open: {run_key}/{case_id}")
        self._opened.add(key)
        self.counts["npz_open_events"] += 1

    def record_member(self, member: str) -> None:
        if member not in ALLOWED_NPZ_MEMBERS:
            raise ContractError(f"forbidden NPZ member: {member}")
        self.counts[f"member_{member}"] += 1

    def record_forward(self) -> None:
        self.counts["model_case_forward_calls"] += 1

    def assert_final(self) -> None:
        expected = {
            "checkpoint_loads": 1,
            "npz_open_events": 105,
            "member_partial": 105,
            "member_implant": 105,
            "member_gt": 105,
            "model_case_forward_calls": 105,
            "optimizer_constructions": 0,
            "optimizer_steps": 0,
            "model_parameter_updates": 0,
            "model_buffer_updates": 0,
        }
        for key, value in expected.items():
            if self.counts[key] != value:
                raise ContractError(f"counter {key}={self.counts[key]}, expected {value}")

    def receipt_counts(self) -> dict[str, int]:
        names = (
            "checkpoint_loads",
            "npz_open_events",
            "member_partial",
            "member_implant",
            "member_gt",
            "model_case_forward_calls",
            "optimizer_constructions",
            "optimizer_steps",
            "model_parameter_updates",
            "model_buffer_updates",
        )
        return {name: int(self.counts[name]) for name in names}


def _require_bool_false(mapping: Mapping[str, Any], names: Sequence[str]) -> None:
    for name in names:
        if mapping.get(name) is not False:
            raise ContractError(f"{name} must be exactly false")


def validate_request_contract(request: Mapping[str, Any]) -> None:
    if request.get("request_schema_version") != REQUEST_SCHEMA:
        raise ContractError("development request schema mismatch")
    if request.get("status") != "AWAITING_EXPLICIT_USER_AUTHORIZATION":
        raise ContractError("development request status mismatch")
    if request.get("execution_authorized") is not False:
        raise ContractError("request file must not self-authorize execution")
    run_key = request.get("run_key")
    candidate = request.get("candidate")
    fold = request.get("fold")
    seed = request.get("seed")
    if run_key != f"{candidate}_fold{fold}_seed{seed}":
        raise ContractError("request run identity mismatch")
    if candidate not in ALLOWED_CANDIDATES or fold not in ALLOWED_FOLDS or seed != 0:
        raise ContractError("request candidate, fold, or seed is outside QA-1")
    if request.get("requested_run_keys") != [run_key]:
        raise ContractError("request must authorize exactly one run key")
    data = request.get("data_scope", {})
    if data.get("dev_cases") != 105 or data.get("dev_sources") != 21:
        raise ContractError("request development cardinality mismatch")
    if data.get("authorized_model_input_members") != ["partial"]:
        raise ContractError("model input must be partial only")
    if data.get("authorized_metric_only_members_after_forward") != ["implant", "gt"]:
        raise ContractError("metric-only member contract mismatch")
    _require_bool_false(
        data,
        (
            "train_payload_access_authorized",
            "other_fold_payload_access_authorized",
            "confirmation20_access_authorized",
            "official_test_access_authorized",
            "old_monitor_access_authorized",
            "mug_payload_access_authorized",
            "skullfix_payload_access_authorized",
        ),
    )
    contract = request.get("single_evaluation_contract", {})
    expected = {
        "checkpoint_loads": 1,
        "model_case_forward_calls": 105,
        "batch_size": 1,
        "num_workers": 0,
        "optimizer_constructions": 0,
        "optimizer_steps": 0,
        "parameter_updates": 0,
        "buffer_updates": 0,
    }
    for key, value in expected.items():
        if contract.get(key) != value:
            raise ContractError(f"request execution contract mismatch: {key}")
    _require_bool_false(
        contract,
        (
            "training",
            "bncal",
            "prediction_pointcloud_files_saved",
            "formal_qa1_gate_application",
            "automatic_retry",
            "automatic_resume",
            "automatic_next_run",
        ),
    )
    bindings = request.get("implementation_bindings")
    if not isinstance(bindings, list) or not bindings:
        raise ContractError("implementation bindings are missing")
    by_path = {item.get("path"): item for item in bindings if isinstance(item, Mapping)}
    if by_path.get(V11_RUNNER_PATH, {}).get("sha256") != V11_RUNNER_SHA256:
        raise ContractError("v1.1 evaluator identity is not preserved")
    p3 = request.get("post_implementation_p3", {})
    if p3.get("required_status") != "PASS_IMPLEMENTATION_ONLY":
        raise ContractError("post-implementation P3 binding is missing")


def validate_execution_authorization(
    authorization: Mapping[str, Any], request: Mapping[str, Any], request_sha256: str
) -> None:
    if authorization.get("status") != "AUTHORIZED":
        raise ContractError("authorization receipt status mismatch")
    if authorization.get("authorization_effective") is not True:
        raise ContractError("authorization receipt is not effective")
    if authorization.get("execution_authorized") is not True:
        raise ContractError("development evaluation is not authorized")
    if authorization.get("authorized_once") is not True:
        raise ContractError("development evaluation must be authorized once")
    if authorization.get("request_id") != request.get("request_id"):
        raise ContractError("authorization request identity mismatch")
    if authorization.get("request_sha256") != request_sha256:
        raise ContractError("authorization request SHA mismatch")
    if authorization.get("authorized_run_keys") != [request.get("run_key")]:
        raise ContractError("authorization run key mismatch")
    _require_bool_false(
        authorization,
        (
            "training_authorized",
            "bncal_authorized",
            "automatic_rerun_authorized",
            "automatic_resume_authorized",
            "automatic_next_run_authorized",
            "formal_qa1_gate_authorized",
        ),
    )
    protected = authorization.get("protected_payload_access", {})
    if any(bool(value) for value in protected.values()):
        raise ContractError("authorization permits a protected payload")
    if authorization.get("runtime_config_sha256_present") is not False:
        raise ContractError("authorization receipt must not reverse-bind runtime SHA")


def load_runtime_yaml(path: Path) -> dict[str, Any]:
    import yaml

    with path.open("r", encoding="utf-8") as stream:
        value = yaml.safe_load(stream)
    if not isinstance(value, dict):
        raise ContractError("runtime YAML root must be a mapping")
    return value


def validate_runtime_config(
    runtime: Mapping[str, Any],
    request: Mapping[str, Any],
    request_sha256: str,
    authorization_sha256: str,
) -> Mapping[str, Any]:
    execution = runtime.get("cranial_scqr_execution")
    if not isinstance(execution, Mapping):
        raise ContractError("runtime execution mapping is missing")
    if execution.get("stage") != RUNTIME_STAGE:
        raise ContractError("runtime stage mismatch")
    if execution.get("status") != "authorized_single_evaluation_pending_execution":
        raise ContractError("runtime status mismatch")
    if execution.get("run_key") != request.get("run_key"):
        raise ContractError("runtime run key mismatch")
    if execution.get("candidate") != request.get("candidate"):
        raise ContractError("runtime candidate mismatch")
    if execution.get("fold") != request.get("fold") or execution.get("seed") != 0:
        raise ContractError("runtime fold or seed mismatch")
    if execution.get("execution_request_sha256") != request_sha256:
        raise ContractError("runtime request SHA mismatch")
    if execution.get("authorization_receipt_sha256") != authorization_sha256:
        raise ContractError("runtime authorization receipt SHA mismatch")
    if execution.get("development_evaluation_authorized") is not True:
        raise ContractError("runtime does not authorize development evaluation")
    if execution.get("development_evaluation_runs_authorized") != 1:
        raise ContractError("runtime evaluation count mismatch")
    if execution.get("development_cases_expected") != 105:
        raise ContractError("runtime case count mismatch")
    if execution.get("model_forward_calls_expected") != 105:
        raise ContractError("runtime forward count mismatch")
    if execution.get("checkpoint_loads_expected") != 1:
        raise ContractError("runtime checkpoint count mismatch")
    _require_bool_false(
        execution,
        (
            "training_authorized",
            "bncal_authorized",
            "resume_authorized",
            "automatic_rerun_authorized",
            "automatic_next_run_authorized",
            "formal_qa1_gate_authorized",
        ),
    )
    if execution.get("optimizer_steps_authorized") != 0:
        raise ContractError("runtime optimizer budget is nonzero")
    return execution


def validate_sha256_sidecar(sidecar: Path, expected: Mapping[str, str]) -> None:
    observed: dict[str, str] = {}
    for raw in sidecar.read_text(encoding="utf-8").splitlines():
        if not raw.strip():
            continue
        parts = raw.split(None, 1)
        if len(parts) != 2:
            raise ContractError("malformed SHA256 sidecar")
        digest, name = parts
        name = name.lstrip("*")
        if name in observed:
            raise ContractError(f"duplicate sidecar member: {name}")
        observed[name] = digest
    if observed != dict(expected):
        raise ContractError("BNCal sidecar contents mismatch")


def _read_allowlist(path: Path) -> list[str]:
    values = [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(values) != 105 or len(set(values)) != 105:
        raise ContractError("development allowlist must contain 105 unique cases")
    return values


def preflight(args: argparse.Namespace) -> tuple[dict[str, Any], Mapping[str, Any], list[str], Path, Path]:
    """Verify all frozen text and byte bindings before checkpoint deserialization."""

    verify_file(args.execution_request, args.execution_request_sha256)
    verify_file(args.authorization_receipt, args.authorization_receipt_sha256)
    verify_file(args.runtime_config, args.runtime_config_sha256)
    verify_file(args.manifest, args.manifest_sha256)
    request = load_json(args.execution_request)
    validate_request_contract(request)
    authorization = load_json(args.authorization_receipt)
    validate_execution_authorization(authorization, request, args.execution_request_sha256)
    runtime = load_runtime_yaml(args.runtime_config)
    execution = validate_runtime_config(
        runtime, request, args.execution_request_sha256, args.authorization_receipt_sha256
    )
    for item in request["implementation_bindings"]:
        path = resolve_under(REPO_ROOT, item["path"])
        verify_file(path, item["sha256"], item["bytes"])
    source = request["source_bncal_freeze"]
    checkpoint = resolve_under(REPO_ROOT, source["bncal_checkpoint"]["path"])
    receipt = resolve_under(REPO_ROOT, source["bncal_receipt"]["path"])
    sidecar = resolve_under(REPO_ROOT, source["bncal_files_sidecar"]["path"])
    verify_file(checkpoint, source["bncal_checkpoint"]["sha256"], source["bncal_checkpoint"]["bytes"])
    verify_file(receipt, source["bncal_receipt"]["sha256"], source["bncal_receipt"]["bytes"])
    verify_file(sidecar, source["bncal_files_sidecar"]["sha256"], source["bncal_files_sidecar"]["bytes"])
    validate_sha256_sidecar(
        sidecar,
        {
            checkpoint.name: source["bncal_checkpoint"]["sha256"],
            receipt.name: source["bncal_receipt"]["sha256"],
        },
    )
    bncal_receipt = load_json(receipt)
    if bncal_receipt.get("status") != "PASS" or bncal_receipt.get("run_key") != request["run_key"]:
        raise ContractError("source BNCal receipt status or run key mismatch")
    if bncal_receipt.get("bncal_checkpoint_sha256") != source["bncal_checkpoint"]["sha256"]:
        raise ContractError("source BNCal checkpoint binding mismatch")
    if bncal_receipt.get("parameters_unchanged") is not True:
        raise ContractError("source BNCal parameter immutability failed")
    if bncal_receipt.get("development_payload_opened") != 0:
        raise ContractError("source BNCal accessed development payload")
    model_config = resolve_under(REPO_ROOT, request["source_training_freeze"]["runtime_config"]["path"])
    verify_file(
        model_config,
        request["source_training_freeze"]["runtime_config"]["sha256"],
        request["source_training_freeze"]["runtime_config"]["bytes"],
    )
    allowlist = resolve_under(REPO_ROOT, request["data_scope"]["dev_allowlist"])
    verify_file(
        allowlist,
        request["data_scope"]["dev_allowlist_sha256"],
        request["data_scope"]["dev_allowlist_bytes"],
    )
    if execution.get("manifest_sha256") != args.manifest_sha256:
        raise ContractError("runtime manifest SHA mismatch")
    if resolve_under(REPO_ROOT, execution["execution_request"]) != args.execution_request:
        raise ContractError("runtime request path mismatch")
    if resolve_under(REPO_ROOT, execution["authorization_receipt"]) != args.authorization_receipt:
        raise ContractError("runtime authorization path mismatch")
    if resolve_under(REPO_ROOT, execution["bncal_checkpoint"]) != checkpoint:
        raise ContractError("runtime checkpoint path mismatch")
    if resolve_under(REPO_ROOT, execution["dev_allowlist"]) != allowlist:
        raise ContractError("runtime allowlist path mismatch")
    return request, execution, _read_allowlist(allowlist), model_config, checkpoint


def _load_manifest(path: Path, data_root: Path, case_ids: Sequence[str]) -> dict[str, dict[str, Any]]:
    allowed = set(case_ids)
    records: dict[str, dict[str, Any]] = {}
    with path.open("r", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            record = json.loads(line)
            case_id = str(record.get("case_id", ""))
            if case_id not in allowed:
                continue
            if case_id in records:
                raise ContractError(f"duplicate manifest case: {case_id}")
            if record.get("dataset") != "SkullBreak" or record.get("official_split") != "train":
                raise ContractError(f"protected or foreign manifest record: {case_id}")
            if record.get("monitor_split") not in (None, ""):
                raise ContractError(f"old-monitor record rejected: {case_id}")
            required = ("skull_id", "source_skull_id", "defect_type", "gate_split", "normalization", "point_path")
            if any(name not in record for name in required):
                raise ContractError(f"manifest metadata missing at line {line_number}")
            point_path = Path(str(record["point_path"]))
            if point_path.is_absolute():
                raise ContractError(f"absolute payload path rejected: {case_id}")
            resolved = (data_root.resolve() / point_path).resolve()
            try:
                resolved.relative_to(data_root.resolve())
            except ValueError as exc:
                raise ContractError(f"payload path escapes data root: {case_id}") from exc
            item = dict(record)
            item["resolved_point_path"] = str(resolved)
            records[case_id] = item
    if set(records) != allowed:
        missing = sorted(allowed - set(records))
        raise ContractError(f"manifest does not resolve exact Fold development allowlist: {missing[:3]}")
    return records


def _read_npz_member(sample: Any, member: str, ledger: AccessLedger, case_id: str) -> np.ndarray:
    if member not in ALLOWED_NPZ_MEMBERS or member not in sample.files:
        raise ContractError(f"missing or forbidden NPZ member {member}: {case_id}")
    ledger.record_member(member)
    array = np.asarray(sample[member], dtype=np.float32).copy()
    if array.ndim != 2 or array.shape[1] != 3 or array.shape[0] == 0:
        raise ContractError(f"invalid {member} shape for {case_id}: {array.shape}")
    if not np.isfinite(array).all():
        raise ContractError(f"nonfinite {member} payload: {case_id}")
    return array


def _diagnostic_candidate(candidate: str) -> str:
    return {"B0": "B0", "LS": "A1", "LSQ": "Q0"}[candidate]


def _evaluate(
    request: Mapping[str, Any],
    case_ids: Sequence[str],
    manifest: Mapping[str, Mapping[str, Any]],
    model_config: Path,
    checkpoint: Path,
    device: Any,
    ledger: AccessLedger,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, str], dict[str, str]]:
    import torch

    run_key = request["run_key"]
    candidate = request["candidate"]
    fold = request["fold"]
    model = v11._load_model(model_config, checkpoint, ledger, run_key).to(device)
    model.eval()
    model.enable_full_instrumentation(True)
    before = model_state_hashes(model)
    rows: list[dict[str, Any]] = []
    diagnostics: list[dict[str, Any]] = []
    with torch.no_grad():
        for case_id in case_ids:
            record = manifest[case_id]
            ledger.record_npz_open(run_key, case_id)
            with np.load(Path(record["resolved_point_path"]), allow_pickle=False) as sample:
                if set(ALLOWED_NPZ_MEMBERS) - set(sample.files):
                    raise ContractError(f"NPZ lacks a required member: {case_id}")
                arrays = {"partial": _read_npz_member(sample, "partial", ledger, case_id)}
                partial = torch.from_numpy(arrays["partial"]).unsqueeze(0).to(device=device, dtype=torch.float32)
                captured: dict[str, Any] = {}
                hook = None
                query_module = getattr(getattr(model, "base_model", None), "scqr_query_conditioner", None)
                if query_module is not None:
                    hook = query_module.register_forward_hook(
                        lambda _m, _i, output: captured.update(query_residual=output.residual.detach())
                    )
                try:
                    output = invoke_partial_only(model, partial)
                    ledger.record_forward()
                finally:
                    if hook is not None:
                        hook.remove()
                arrays["implant"] = _read_npz_member(sample, "implant", ledger, case_id)
                arrays["gt"] = _read_npz_member(sample, "gt", ledger, case_id)
            if not isinstance(output, (tuple, list)) or len(output) != 2:
                raise ContractError(f"unexpected eval output: {run_key}/{case_id}")
            coarse_tensor, implant_tensor = output
            if not torch.isfinite(coarse_tensor).all() or not torch.isfinite(implant_tensor).all():
                raise ContractError(f"nonfinite model output: {run_key}/{case_id}")
            pred_coarse = coarse_tensor.squeeze(0).detach().cpu().numpy()
            pred_implant = implant_tensor.squeeze(0).detach().cpu().numpy()
            instrumentation = model.pop_full_instrumentation()
            if not isinstance(instrumentation, dict):
                raise ContractError(f"missing full instrumentation: {run_key}/{case_id}")
            instrumentation["model_object"] = model
            metric_row, coarse_p95 = v11._metric_rows(pred_implant, pred_coarse, arrays, record)
            identity = {
                "run_key": run_key,
                "candidate": candidate,
                "fold": fold,
                "seed": 0,
                "case_id": case_id,
                "skull_id": record["skull_id"],
                "source_skull_id": record["source_skull_id"],
                "defect_type": record["defect_type"],
            }
            rows.append({**identity, **metric_row})
            diagnostics.append(
                {
                    **identity,
                    **v11._diagnostics(
                        _diagnostic_candidate(candidate),
                        instrumentation,
                        partial,
                        torch.from_numpy(arrays["implant"]).unsqueeze(0).to(
                            device=device, dtype=torch.float32
                        ),
                        float(record["normalization"]["scale"]),
                        captured.get("query_residual"),
                        coarse_p95,
                    ),
                }
            )
            del instrumentation, output, coarse_tensor, implant_tensor, partial
    after = model_state_hashes(model)
    assert_state_unchanged(before, after)
    del model
    torch.cuda.empty_cache()
    return rows, diagnostics, before, after


def aggregate_source_rows(rows: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    groups: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
    for row in rows:
        groups[str(row["source_skull_id"])].append(row)
    if len(rows) != 105 or len(groups) != 21:
        raise ContractError("single-run source aggregation cardinality mismatch")
    result: list[dict[str, Any]] = []
    for source, values in sorted(groups.items()):
        if len(values) != 5 or {str(row["defect_type"]) for row in values} != set(DEFECTS):
            raise ContractError(f"source does not contain exactly five frozen defects: {source}")
        first = values[0]
        item: dict[str, Any] = {
            "run_key": first["run_key"],
            "candidate": first["candidate"],
            "fold": first["fold"],
            "seed": first["seed"],
            "source_skull_id": source,
            "case_count": 5,
        }
        for name in SOURCE_MEAN_FIELDS:
            numeric = [float(row[name]) for row in values]
            item[name] = None if any(not math.isfinite(value) for value in numeric) else float(np.mean(numeric))
        for name in SOURCE_SUM_FIELDS:
            item[f"{name}_count"] = int(sum(int(row[name]) for row in values))
        result.append(item)
    return result


def single_run_summary(source_rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    if len(source_rows) != 21:
        raise ContractError("single-run summary requires 21 source rows")
    metrics: dict[str, float | None] = {}
    for name in SOURCE_MEAN_FIELDS:
        values = [row[name] for row in source_rows]
        metrics[name] = None if any(value is None for value in values) else float(np.mean(values))
    first = source_rows[0]
    return {
        "status": "DESCRIPTIVE_SINGLE_RUN_ONLY",
        "run_key": first["run_key"],
        "candidate": first["candidate"],
        "fold": first["fold"],
        "seed": first["seed"],
        "case_count": 105,
        "source_count": 21,
        "source_equal_weight_metrics": metrics,
        "zero_contact_count": int(sum(int(row["zero_contact_2mm_count"]) for row in source_rows)),
        "disaster_count": int(sum(int(row["disaster_count"]) for row in source_rows)),
        "formal_qa1_gate_applied": False,
        "candidate_comparison_performed": False,
        "automatic_next_run": False,
    }


def _write_json_exclusive(path: Path, value: Any) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def assert_numerical_policy(torch_api: Any) -> dict[str, Any]:
    """Read process flags only; never query or initialize CUDA."""
    policy = {
        "deterministic_algorithms": bool(torch_api.are_deterministic_algorithms_enabled()),
        "deterministic_warn_only": bool(torch_api.is_deterministic_algorithms_warn_only_enabled()),
        "cuda_matmul_allow_tf32": bool(torch_api.backends.cuda.matmul.allow_tf32),
        "cudnn_allow_tf32": bool(torch_api.backends.cudnn.allow_tf32),
        "cudnn_deterministic": bool(torch_api.backends.cudnn.deterministic),
        "cudnn_benchmark": bool(torch_api.backends.cudnn.benchmark),
    }
    expected = {
        "deterministic_algorithms": True,
        "deterministic_warn_only": False,
        "cuda_matmul_allow_tf32": False,
        "cudnn_allow_tf32": False,
        "cudnn_deterministic": True,
        "cudnn_benchmark": False,
    }
    if policy != expected:
        raise ContractError(f"numerical policy mismatch: {policy}")
    return policy


def configure_numerical_policy(torch_api: Any) -> dict[str, Any]:
    """Apply the frozen numerical contract before any CUDA/model work."""
    torch_api.use_deterministic_algorithms(True, warn_only=False)
    torch_api.backends.cuda.matmul.allow_tf32 = False
    torch_api.backends.cudnn.allow_tf32 = False
    torch_api.backends.cudnn.deterministic = True
    torch_api.backends.cudnn.benchmark = False
    return assert_numerical_policy(torch_api)


def run_evaluation(args: argparse.Namespace) -> int:
    import torch

    numerical_policy_before = configure_numerical_policy(torch)
    if args.device != "cuda:0":
        raise ContractError("frozen device must be cuda:0")
    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
        raise ContractError("exactly one visible CUDA device is required")
    if torch.cuda.get_device_name(0) != "NVIDIA GeForce RTX 4090 D":
        raise ContractError("visible GPU is not NVIDIA GeForce RTX 4090 D")
    if args.output_dir.exists():
        raise ContractError("output directory already exists")
    request, _execution, case_ids, model_config, checkpoint = preflight(args)
    manifest = _load_manifest(args.manifest, args.data_root, case_ids)
    args.output_dir.mkdir(parents=False, exist_ok=False)
    _write_json_exclusive(
        args.output_dir / "invocation.json",
        {
            "execution_request_sha256": args.execution_request_sha256,
            "authorization_receipt_sha256": args.authorization_receipt_sha256,
            "runtime_config_sha256": args.runtime_config_sha256,
            "manifest_sha256": args.manifest_sha256,
            "numerical_policy_before": numerical_policy_before,
            "started_at_utc": utc_now(),
        },
    )
    ledger = AccessLedger()
    try:
        rows, diagnostics, before, after = _evaluate(
            request,
            case_ids,
            manifest,
            model_config,
            checkpoint,
            torch.device(args.device),
            ledger,
        )
        ledger.assert_final()
        numerical_policy_after = assert_numerical_policy(torch)
        sources = aggregate_source_rows(rows)
        summary = single_run_summary(sources)
        v11.write_csv(args.output_dir / "per_model_case_metrics.csv", rows)
        v11.write_csv(args.output_dir / "per_model_source_metrics.csv", sources)
        v11.write_csv(args.output_dir / "mechanism_diagnostics.csv", diagnostics)
        _write_json_exclusive(args.output_dir / "single_run_summary.json", summary)
        receipt = {
            "receipt_version": "cranial-scqr-v1.2-QA1-single-development-evaluation-v1",
            "status": "PASS_DESCRIPTIVE_SINGLE_RUN_ONLY",
            "run_key": request["run_key"],
            "started_at_utc": load_json(args.output_dir / "invocation.json")["started_at_utc"],
            "finished_at_utc": utc_now(),
            "counters": ledger.receipt_counts(),
            "model_state_hashes_before": before,
            "model_state_hashes_after": after,
            "model_parameters_and_buffers_unchanged": before == after,
            "numerical_policy_before": numerical_policy_before,
            "numerical_policy_after": numerical_policy_after,
            "predictions_saved": False,
            "formal_qa1_gate_applied": False,
            "candidate_comparison_performed": False,
            "automatic_retry": False,
            "automatic_next_run": False,
        }
        _write_json_exclusive(args.output_dir / "evaluation_execution_receipt.json", receipt)
        return 0
    except Exception as exc:
        failure = {
            "receipt_version": "cranial-scqr-v1.2-QA1-single-development-evaluation-v1",
            "status": "FAILED_STOPPED_NO_RETRY",
            "run_key": request["run_key"],
            "finished_at_utc": utc_now(),
            "error_type": type(exc).__name__,
            "error": str(exc),
            "counters": ledger.receipt_counts(),
            "formal_qa1_gate_applied": False,
            "automatic_retry": False,
            "automatic_next_run": False,
        }
        failure_path = args.output_dir / "evaluation_failure_receipt.json"
        if not failure_path.exists():
            _write_json_exclusive(failure_path, failure)
        raise


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execution-request", required=True, type=Path)
    parser.add_argument("--execution-request-sha256", required=True)
    parser.add_argument("--authorization-receipt", required=True, type=Path)
    parser.add_argument("--authorization-receipt-sha256", required=True)
    parser.add_argument("--runtime-config", required=True, type=Path)
    parser.add_argument("--runtime-config-sha256", required=True)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--data-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--device", default="cuda:0")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    for name in (
        "execution_request",
        "authorization_receipt",
        "runtime_config",
        "manifest",
        "data_root",
        "output_dir",
    ):
        setattr(args, name, getattr(args, name).expanduser().resolve())
    return run_evaluation(args)


if __name__ == "__main__":
    raise SystemExit(main())
