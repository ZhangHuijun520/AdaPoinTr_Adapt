#!/usr/bin/env python3
"""Pure-text and artificial CPU contracts, never full AdaPoinTr or CUDA."""

import argparse
import ast
import copy
import hashlib
import importlib.util
import json
import os
import socket
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import cranial_scqr_v12_rsd_r1b_synthetic_preflight_contract as c
import run_cranial_scqr_v12_rsd_r1b_synthetic_gpu_preflight as run

DOCS = ROOT / 'docs'
if not (DOCS / 'v12_rsd_r1b_synthetic_gpu_zero_update_preflight_execution_request_v1.json').is_file():
    DOCS = ROOT / 'docs/cranial_scqr_v12_qa_research_2026_10_11'
ORIGINAL = json.loads((DOCS / 'v12_rsd_r1b_synthetic_gpu_zero_update_preflight_execution_request_v1.json').read_text())


def fixture():
    q = copy.deepcopy(ORIGINAL)
    q.update(request_schema_version='cranial-scqr-v1.2-RSD-R1B-synthetic-gpu-preflight-request-v2',
             request_id='artificial-only', execution_ready=True, direct_execution_allowed=False,
             parent_request_v1={'sha256': c.V1_SHA}, missing_preconditions=[],
             preflight_implementation_bindings=[{'path': name, 'sha256': 'a'*64, 'bytes': 1} for name in c.TOOL_NAMES],
             environment_runtime_contract={'cudnn_version': 90100, 'cuda_version': '11.8'})
    for key in ('preflight_implementation_p3_binding', 'dependency_inventory_binding', 'input_identity_binding'):
        q[key] = {'path': 'artificial.txt', 'sha256': 'b'*64, 'bytes': 1}
    q['resource_binding']['hostname'] = socket.gethostname()
    q['fixed_future_execution'] = {'run_id': 'r1b_synthetic_gpu_pf_v2_20261011', 'tmux_session': 'r1b-synthetic-gpu-pf-v2-20261011'}
    prefix = 'logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_v2_20261011/'
    for key, suffix in {'output_relative': 'result', 'control_relative': 'control',
                'authorization_receipt_relative': 'control/authorization_receipt_v2.json', 'runtime_relative': 'control/runtime_v2.json',
                'launcher_relative': 'control/launcher_once_v2.sh', 'log_relative': 'control/master.log',
                'pid_relative': 'control/pid.txt', 'exit_code_relative': 'control/exit_code.txt'}.items():
        q['fixed_future_execution'][key] = prefix + suffix
    return q


class TextContracts(unittest.TestCase):
    def test_inert_import(self):
        self.assertNotIn('torch', sys.modules)
        self.assertNotIn('numpy', sys.modules)
        self.assertNotIn('models', sys.modules)

    def test_compile_all_new_sources(self):
        for name in c.TOOL_NAMES:
            compile((ROOT / name).read_text(), name, 'exec')

    def test_frozen_source_v1_hash(self):
        self.assertEqual(c.digest(DOCS / 'v12_rsd_r1b_synthetic_gpu_zero_update_preflight_execution_request_v1.json'), c.V1_SHA)

    def test_v1_never_executable(self):
        with self.assertRaises(c.ContractError):
            c.validate_request(ORIGINAL, ORIGINAL)

    def test_v2_requires_final_bindings(self):
        c.validate_request(fixture(), ORIGINAL)
        for key in ('preflight_implementation_p3_binding', 'dependency_inventory_binding', 'input_identity_binding'):
            q = fixture(); q[key] = {'sha256': None, 'bytes': None}
            with self.assertRaises(c.ContractError):
                c.validate_request(q, ORIGINAL)

    def test_frozen_8_call_plan_and_shapes(self):
        for key, change in (('success_exact_counts', {'full_model_forward_attempts': 9}),
                            ('synthetic_input_contract', {'shape': [1,4096,3]}),
                            ('model_initialization_contract', {'forward_epoch': 1}),
                            ('numerical_policy', {'matmul_allow_tf32': True})):
            q = fixture(); q[key].update(change)
            with self.assertRaises(c.ContractError):
                c.validate_request(q, ORIGINAL)

    def test_forbidden_authority_and_nonready(self):
        for key in ('execution_authorized', 'implementation_authorized', 'direct_execution_allowed'):
            q = fixture(); q[key] = True
            with self.assertRaises(c.ContractError):
                c.validate_request(q, ORIGINAL)
        q = fixture(); q['execution_ready'] = False
        with self.assertRaises(c.ContractError):
            c.validate_request(q, ORIGINAL)

    def test_resource_and_output_drift(self):
        for key, value in (('gpu_uuid', 'GPU-other'), ('maximum_walltime_seconds', 601)):
            q = fixture(); q['resource_binding'][key] = value
            with self.assertRaises(c.ContractError):
                c.validate_request(q, ORIGINAL)
        q = fixture(); q['fixed_future_execution']['output_relative'] = '../outside'
        with self.assertRaises(c.ContractError):
            c.validate_request(q, ORIGINAL)

    def test_no_cycle_and_single_authorization(self):
        q = fixture()
        a = {'status': 'AUTHORIZED_ONCE_SYNTHETIC_GPU_PREFLIGHT', 'execution_authorized': True, 'request_id': q['request_id'],
             'request_sha256': 'req', 'run_id': q['fixed_future_execution']['run_id'], 'permissions': q['permissions']}
        rt = {'stage': 'V12_RSD_R1B_SYNTHETIC_GPU_PREFLIGHT', 'request_sha256': 'req', 'authorization_receipt_sha256': 'auth',
              'run_id': q['fixed_future_execution']['run_id'], 'runs_authorized': 1}
        c.validate_chain(q, ORIGINAL, a, rt, 'req', 'auth')
        for bad_a, bad_rt in (({**a, 'runtime_sha256': 'cycle'}, rt), (a, {**rt, 'runs_authorized': 2}),
                             ({**a, 'execution_authorized': False}, rt)):
            with self.assertRaises(c.ContractError):
                c.validate_chain(q, ORIGINAL, bad_a, bad_rt, 'req', 'auth')

    def test_safe_hash_paths_and_escape(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); p = root/'a.txt'; p.write_text('artificial')
            b = {'path': 'a.txt', 'bytes': p.stat().st_size, 'sha256': c.digest(p)}
            self.assertEqual(c.bound(root, b), p)
            for change in ({'path':'../escape'}, {'bytes':1}, {'sha256':'a'*64}, {'path':str(p)}):
                with self.assertRaises(c.ContractError):
                    c.bound(root, {**b, **change})

    def test_duplicate_or_nonfinite_json_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)/'a.json'
            for value in ('{"a":1,"a":2}', '{"a":NaN}', '{"a":Infinity}'):
                p.write_text(value)
                with self.assertRaises(c.ContractError):
                    c.strict_json(p)

    def test_attempt_failure_poison_and_budget(self):
        l = c.Ledger(ORIGINAL['success_exact_counts'])
        l.begin(1, ORIGINAL['full_forward_order'][0])
        with self.assertRaises(c.ContractError):
            l.begin(2, ORIGINAL['full_forward_order'][1])
        self.assertEqual(l.counts['full_model_forward_attempts'], 1)
        with self.assertRaises(c.ContractError):
            l.end()

    def test_zero_counter_forbidden(self):
        for key in ('real_payload_reads', 'optimizer_steps', 'extra_warmup_forwards', 'checkpoint_deserializations'):
            l = c.Ledger(ORIGINAL['success_exact_counts'])
            with self.assertRaises(c.ContractError):
                l.add(key)

    def test_completed_ledger_exact_artificial(self):
        l = c.Ledger(ORIGINAL['success_exact_counts'])
        for _ in range(2): l.add('model_constructions')
        for _ in range(8): l.add('standalone_select_rsd_queries_calls')
        for item in ORIGINAL['full_forward_order']:
            l.begin(item['index'], item)
            if item['model'] == 'LSQ': l.add('full_forward_lsq_conditioner_calls')
            if item['diagnostics'] == 'FRESH_EMPTY_DICT' and item['model'] == 'LSQ':
                l.add('traced_full_forward_lsq_query_outlet_calls')
            l.end()
        l.finish()
        with self.assertRaises(c.ContractError): l.add('model_constructions')

    def test_file_boundary_blocks_payload_and_external_writes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); code = root/'a.py'; code.write_text('pass')
            boundary = c.FileBoundary([code], root/'owned_output')
            boundary.check_open(code, 'r')
            boundary.check_open(root/'owned_output'/'receipt.json', 'x')
            for file, mode in ((root/'unknown.txt','r'), (root/'a.npz','r'), (root/'a.pth','rb'),
                               (code,'w'), (root/'owned_output'/'bad.csv','x'), (4,'r')):
                with self.assertRaises(c.ContractError): boundary.check_open(file,mode)
            for event, args in (('socket.connect',()), ('subprocess.Popen',()), ('os.remove',(code,))):
                with self.assertRaises(c.ContractError): boundary(event,args)

    def test_no_real_data_loader_or_checkpoint_call(self):
        tree = ast.parse((HERE/c.TOOL_NAMES[0].split('/')[-1]).read_text())
        calls = [node for node in ast.walk(tree) if isinstance(node,ast.Call)]
        names = [getattr(node.func,'attr',getattr(node.func,'id','')) for node in calls]
        for name in ('load_state_dict','save','backward','step','cfg_from_yaml_file','_load_model','np_load','build_dataloader'):
            self.assertNotIn(name,names)
        # torch.load is absent; file YAML is parsed by safe_load/model_mapping.
        self.assertFalse(any(isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name)
                             and n.func.value.id in ('torch','np','numpy') and n.func.attr=='load' for n in calls))

    def test_execution_rejection_before_heavy_import(self):
        args = SimpleNamespace()
        with self.assertRaises(c.ContractError): run.text_preconditions(args)
        self.assertNotIn('torch',sys.modules)

    def test_scalar_missing_or_nonfinite_rejected(self):
        v = {name:1.0 for name in c.SCALARS}; v.update(query_applicable=True,query_outlet_calls=1)
        c.assert_scalars(v)
        for bad in ({**v,'query_rms':float('nan')},{**v,'query_outlet_calls':0},{**v,'applied_residual_rms':0.0}):
            with self.assertRaises(c.ContractError): c.assert_scalars(bad)


class CpuContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        os.environ.update(CUDA_VISIBLE_DEVICES='', CUBLAS_WORKSPACE_CONFIG=':4096:8', OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
        import torch
        import numpy as np
        torch.cuda._lazy_init = lambda: (_ for _ in ()).throw(AssertionError('GPU forbidden during CPU contracts'))
        torch.set_num_threads(1)
        cls.torch,cls.np = torch,np
        ref = Path(os.environ.get('RSD_REFERENCE_ROOT',str(ROOT.parent/'v12_rsd_r1b_impl_v1_20261011')))
        cls.hash_module = run.load_file_module(ref/'tools/run_cranial_scqr_v12_rsd_r1b.py','artificial_cpu_rsd_hash')
        cls.bypass = run.load_file_module(ref/'models/cranial_scqr/rsd_query_bypass.py','artificial_cpu_bypass')

    def hash(self,mapping):
        return self.hash_module.canonical_tensor_hash(mapping)

    def test_unique_synthetic_shape_order_and_identity(self):
        x = run.synthetic_input(self.torch)
        self.assertEqual(tuple(x.shape),(1,8192,3))
        self.assertEqual(len(self.np.unique(x.numpy().reshape(-1,3),axis=0)),8192)
        self.assertEqual(x[0,0].tolist(),[-15.5/32,-7.5/16,-7.5/16])
        self.assertEqual(self.hash({'partial':x}),self.hash({'partial':run.synthetic_input(self.torch)}))
        self.assertNotEqual(self.hash({'partial':x}),self.hash({'partial':x.flip(1)}))

    def test_eight_known_outlet_calls(self):
        l = c.Ledger(ORIGINAL['success_exact_counts'])
        records = run.standalone_outlets(self.torch,self.bypass.select_rsd_queries,self.hash,l,'cpu',lambda:None,lambda:None)
        self.assertEqual(l.counts['standalone_select_rsd_queries_calls'],8)
        self.assertEqual(len(records),2)
        self.assertFalse(self.torch.cuda.is_initialized())

    def test_tensor_mismatch_fail_closed(self):
        x = self.torch.zeros(2)
        self.assertTrue(run.compare_tensor(self.torch,x,x.clone(),'artificial')['exact_equal'])
        for y in (x+1,x.double(),x.reshape(1,2)):
            with self.assertRaises(c.ContractError): run.compare_tensor(self.torch,x,y,'artificial')

    def test_model_submapping_does_not_inherit_authority(self):
        observed = json.loads((DOCS/'v12_rsd_r1b_synthetic_gpu_preflight_readonly_observation_v1.json').read_text())
        import yaml
        for candidate,binding in zip(('LS','LSQ'),ORIGINAL['model_structure_sources']):
            document = yaml.safe_load(observed['environment']['configs'][binding['path']]['text'])
            mapping = run.model_mapping(document,candidate)
            self.assertNotIn('dataset',mapping)
            self.assertNotIn('cranial_scqr_execution',mapping)
            document['model']['num_points']=4096
            with self.assertRaises(c.ContractError): run.model_mapping(document,candidate)

    def fake_models(self, *, mutate=False, dense_drift=False):
        t = self.torch
        class Conditioner(t.nn.Module):
            def forward(self,x): return x
        class Tiny(t.nn.Module):
            def __init__(self,candidate):
                super().__init__(); self.candidate=candidate
                self.register_buffer('counter',t.zeros(1))
                self.base_model=t.nn.Module()
                self.base_model.scqr_query_conditioner=Conditioner() if candidate=='LSQ' else None
            def forward(self,x,epoch=None,*,rsd_condition=None,rsd_diagnostics=None):
                if self.candidate=='LSQ': self.base_model.scqr_query_conditioner(x)
                if mutate: self.counter.add_(1)
                if rsd_diagnostics is not None:
                    if self.candidate=='LS': rsd_diagnostics.update(query_applicable=False,query_outlet_calls=0)
                    else:
                        v={name:1.0 for name in c.SCALARS}
                        v.update(query_applicable=True,query_outlet_calls=1)
                        if rsd_condition=='LSQ_query_off': v['applied_residual_rms']=0.0
                        rsd_diagnostics.update(v)
                dense=x.clone()
                if rsd_condition=='LSQ_query_off': dense=dense+0.25
                if dense_drift and rsd_diagnostics is not None: dense=dense+0.5
                return x[:,:256].clone(),dense
        return {key:Tiny(key).eval() for key in ('LS','LSQ')}

    def sequence(self,models):
        l=c.Ledger(ORIGINAL['success_exact_counts'])
        for _ in range(2):l.add('model_constructions')
        result=run.run_sequence(models,run.synthetic_input(self.torch),self.torch,self.np,self.hash,l,ORIGINAL['full_forward_order'],
              cuda=False,sync=lambda:None,policy=lambda:None,memory=lambda:None,progress=lambda _:None)
        return result,l

    def test_fake_cpu_full_plan_exact_and_hooks_removed(self):
        models=self.fake_models(); result,l=self.sequence(models)
        self.assertEqual(l.counts['full_model_forward_attempts'],8)
        self.assertEqual(l.counts['full_forward_lsq_conditioner_calls'],6)
        self.assertEqual(l.counts['traced_full_forward_lsq_query_outlet_calls'],4)
        self.assertEqual(result['full_dense_off_minus_native_max_abs'],0.25)
        self.assertEqual(len(models['LSQ'].base_model.scqr_query_conditioner._forward_hooks),0)

    def test_fake_state_mutation_stops_no_reload(self):
        models=self.fake_models(mutate=True)
        with self.assertRaises(c.ContractError):self.sequence(models)
        self.assertEqual(float(models['LS'].counter.item()),1.0)
        self.assertEqual(len(models['LSQ'].base_model.scqr_query_conditioner._forward_hooks),0)

    def test_fake_dense_instrumentation_drift_stops(self):
        with self.assertRaises(c.ContractError):self.sequence(self.fake_models(dense_drift=True))

    def test_rng_snapshot_restore_cpu_only(self):
        states=run.rng_snapshot(self.torch,self.np,cuda=False); before=run.rng_hash(states)
        self.torch.rand(1); self.np.random.rand(1)
        run.rng_restore(self.torch,self.np,states,cuda=False)
        self.assertEqual(before,run.rng_hash(run.rng_snapshot(self.torch,self.np,cuda=False)))
        self.assertFalse(self.torch.cuda.is_initialized())

    def test_numerical_tf32_settings_and_assertions_cpu(self):
        # Fresh process avoids global interop thread reconfiguration in a suite.
        import subprocess
        code = "import os,sys;sys.path.insert(0,sys.argv[1]);import run_cranial_scqr_v12_rsd_r1b_synthetic_gpu_preflight as r;import torch;t=torch;r.configure_numerical(t);t.backends.cuda.matmul.allow_tf32=True\ntry:r.assert_numerical(t)\nexcept r.c.ContractError:pass\nelse:raise AssertionError('TF32 drift accepted')\nassert not t.cuda.is_initialized()"
        result=subprocess.run([sys.executable,'-B','-c',code,str(HERE)],capture_output=True,text=True,timeout=30)
        self.assertEqual(result.returncode,0,result.stdout+result.stderr)


def main():
    p=argparse.ArgumentParser();p.add_argument('--torch-cpu',action='store_true');args=p.parse_args()
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(TextContracts)
    if args.torch_cpu:suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(CpuContracts))
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    return 0 if result.wasSuccessful() else 1


if __name__=='__main__':raise SystemExit(main())
