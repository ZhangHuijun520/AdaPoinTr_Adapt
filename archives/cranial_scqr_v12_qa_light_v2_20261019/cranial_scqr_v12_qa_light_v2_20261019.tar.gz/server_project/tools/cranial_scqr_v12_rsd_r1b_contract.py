"""R1-B pure-text guards and one-case access state machine (no torch import)."""

import csv
import hashlib
import json
import math
import socket
from pathlib import Path


PROTOCOL_SHA = "30eeb37fcc6e0172849c5dd4a5a457180d59b9cc0e521a9234b81158bc88b035"
SCHEMA = "cranial-scqr-v1.2-RSD-R1B-fold-request-v1"
CONDITIONS = ("LS_native", "LSQ_native", "LSQ_query_off")
DEFECTS = ("bilateral", "frontoorbital", "parietotemporal", "random_1", "random_2")
CONTINUOUS = (
    "implant_cd_l1_mm", "implant_pred_to_ref_mean_mm", "implant_ref_to_pred_mean_mm",
    "implant_hd95_mm", "implant_nsd_at_1mm", "final_cd_l1_mm", "final_hd95_mm",
    "final_nsd_at_1mm", "rim_gt_rim_to_pred_mean_mm", "rim_gt_rim_to_pred_p95_mm",
    "rim_contact_cd_l1_mm", "rim_contact_hd95_mm", "rim_contact_precision", "rim_contact_recall",
)
EXACT_METRICS = ("rim_reference_rim_points", "rim_predicted_rim_points", "zero_contact_2mm", "disaster")
CORE = ("implant_cd_l1_mm", "implant_hd95_mm", "final_cd_l1_mm", "final_hd95_mm", "rim_gt_rim_to_pred_p95_mm")
CHECKPOINT_SHA = {
    "LS_foldC_seed0": "47d21ab4e5e577515eec314b21695166c5af0fa3c02ed29c9756fe85f80cbb7e",
    "LS_foldD_seed0": "bdc2bf228e9aa57bcad58f2aecf06481aab367f308a6cae9629ba91462ca9c57",
    "LSQ_foldC_seed0": "5c2f39f029b019843ae403103933d93b6061f127ac1a95d355940e8eb6a3befa",
    "LSQ_foldD_seed0": "71da7f3b68c3dc5b97aba4530480cc9e7622b75e74b1802f2200dce99bf788ad",
}
FROZEN_REFERENCE_SHA = {
    "LS_foldC_seed0": "444fccc60f67b8773b07eca7d84d721f39b69e60fc0e15ae03a3d2b19e18fed3",
    "LS_foldD_seed0": "5c0bd80f45047132c813fcf702008c70d91036963f7553953e9d52902d3fc34a",
    "LSQ_foldC_seed0": "3c951a9b58288eb5c96216fe47d6a6beb9a2b9bad6f51820e86fa09251cfb78c",
    "LSQ_foldD_seed0": "04423809048e28700d7458407f38bb75e982b40c7c34870cadf835a0cee8482c",
}
IMMUTABLE_SOURCES = {
    "models/cranial_scqr/query_conditioning.py": "e631f6649b3a218e63c39f15f6232607469106ae63b0c7cdf578636b110d9057",
    "tools/run_cranial_scqr_v12_qa1_development_eval.py": "5d3e92094cc1eeec8788dbec4543735d95947dcbdd0449541516242dcad5d808",
    "tools/run_cranial_scqr_v11_l4_round_a_dev_eval.py": "6be1c38b46270eff278ea7a54805ba0d572e8aef81a103350308072380c38798",
    "utils/skullfix_metrics.py": "0c4342cd19fb19a659302b0e350c3be34bd21447d2034bdc9d2e81a180174ee5",
}
FALSE_PERMISSIONS = (
    "training", "bncal", "automatic_retry", "resume", "automatic_next_fold",
    "formal_gate", "bootstrap", "predictions_saved", "train", "other_fold",
    "confirmation20", "official_test", "old_monitor", "MUG", "SkullFix",
)


class ContractError(RuntimeError):
    pass


def require(ok, message):
    if not ok:
        raise ContractError(message)


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def bound_path(root, binding, *, verify=True):
    relative = Path(binding["path"])
    require(not relative.is_absolute() and ".." not in relative.parts, "unsafe relative binding")
    path = (Path(root).resolve() / relative).resolve()
    try:
        path.relative_to(Path(root).resolve())
    except ValueError:
        raise ContractError("binding escapes project")
    require(path.is_file(), "missing bound file")
    if verify:
        require(path.stat().st_size == binding["bytes"], "bound byte count mismatch")
        require(sha256_file(path) == binding["sha256"], "bound SHA256 mismatch")
    return path


def validate_request(request):
    require(request.get("schema") == SCHEMA, "R1-B request schema mismatch")
    require(request.get("status") == "AWAITING_EXPLICIT_USER_AUTHORIZATION", "request status")
    require(request.get("execution_authorized") is False, "request may not self-authorize")
    require(request.get("protocol_sha256") == PROTOCOL_SHA, "protocol SHA mismatch")
    require(request.get("fold") in ("C", "D") and type(request.get("seed")) is int and request["seed"] == 0, "fold/seed")
    require(request.get("conditions") == list(CONDITIONS), "condition order")
    for name in FALSE_PERMISSIONS:
        require(request.get("permissions", {}).get(name) is False, "forbidden or unspecified permission: " + name)
    require(all(type(v) is int for v in request.get("budget", {}).values()), "budget counts must be integers")
    require(request.get("budget") == {
        "cases": 105, "forwards": 315, "npz_opens": 105, "checkpoint_loads": 2, "checkpoint_hash_verifications": 4,
        "member_partial": 105, "member_implant": 105, "member_gt": 105,
        "optimizer_steps": 0, "parameter_updates": 0, "buffer_updates": 0,
        "bncal_forwards": 0,
    }, "R1-B budget mismatch")
    require(request.get("forward_epoch", "MISSING") is None, "native epoch must remain None (warmup=1)")
    require(request.get("rng_contract") == "candidate-isolated-native-progression-v1", "RNG contract")
    require(request.get("empty_contact_policy") == "STOP_KEEP_ORIGINAL_FLAGS", "empty contact policy")
    require(request.get("output_limit_bytes") == 16 * 1024 * 1024, "output budget")
    require(type(request.get("max_wall_seconds")) is int and request["max_wall_seconds"] > 0, "wall-time budget missing")
    require(type(request.get("max_vram_mib")) is int and 0 < request["max_vram_mib"] < 24576, "VRAM budget missing")
    environment = request.get("environment_contract", {})
    for name in ("python_version", "torch_version", "numpy_version", "scipy_version", "cuda_version", "gpu_driver"):
        require(isinstance(environment.get(name), str) and environment[name], "environment version missing: " + name)
    require(type(environment.get("cudnn_version")) is int and environment["cudnn_version"] > 0 and environment.get("cpu_threads") == 1,
            "cuDNN/thread contract")
    require(isinstance(environment.get("binary_bindings"), list) and environment["binary_bindings"] and
            isinstance(environment.get("extension_source_bindings"), list) and environment["extension_source_bindings"], "extension source/binary hashes missing")
    require(request.get("data_root") == "/home/jovyan/datasets/SkullBreakPC_out8192", "data root")
    require(request.get("resource", {}).get("hostname") == socket.gethostname(), "resource hostname mismatch")
    require(isinstance(request.get("resource", {}).get("gpu_uuid"), str) and request["resource"]["gpu_uuid"].startswith("GPU-"), "GPU resource binding")
    require(set(request.get("models", {})) == {"LS", "LSQ"}, "exactly two frozen models")
    for candidate, model in request["models"].items():
        run = candidate + "_fold" + request["fold"] + "_seed0"
        require(model.get("run_key") == run, "model run key")
        require(model.get("checkpoint", {}).get("sha256") == CHECKPOINT_SHA[run], "checkpoint matrix changed")
        require(model.get("reference_csv", {}).get("sha256") == FROZEN_REFERENCE_SHA[run], "native CSV changed")
    require(isinstance(request.get("implementation_bindings"), list) and request["implementation_bindings"], "implementation bindings missing")
    by_path = {b["path"]: b["sha256"] for b in request["implementation_bindings"]}
    require(len(by_path) == len(request["implementation_bindings"]), "duplicate implementation binding")
    for name, digest in IMMUTABLE_SOURCES.items():
        require(by_path.get(name) == digest, "immutable source binding: " + name)
    for name in ("models/AdaPoinTr.py", "models/cranial_scqr/rsd_query_bypass.py",
                 "tools/cranial_scqr_v12_rsd_r1b_contract.py", "tools/run_cranial_scqr_v12_rsd_r1b.py"):
        require(name in by_path, "new implementation unbound: " + name)


def validate_chain(request, authorization, runtime, request_sha, auth_sha):
    validate_request(request)
    require(authorization.get("status") == "AUTHORIZED_ONCE" and authorization.get("execution_authorized") is True, "execution not authorized")
    require(authorization.get("request_sha256") == request_sha and authorization.get("request_id") == request.get("request_id"), "authorization request binding")
    require(authorization.get("fold") == request["fold"], "authorization fold")
    for name in FALSE_PERMISSIONS:
        require(authorization.get("permissions", {}).get(name) is False, "authorization permission: " + name)
    require(not any("runtime" in key for key in authorization), "reverse runtime binding forbidden")
    require(runtime == {
        "stage": "V12_RSD_R1B_SINGLE_FOLD", "request_sha256": request_sha,
        "authorization_receipt_sha256": auth_sha, "fold": request["fold"],
        "runs_authorized": 1,
    }, "runtime single-way binding mismatch")


def validate_tolerances(value):
    require(value.get("status") == "FROZEN_CONFIRMED_BEFORE_DEV", "replay tolerance not frozen/confirmed")
    require(value.get("basis_scope") == "ARTIFICIAL_ONLY", "first-round tolerances require artificial-only evidence")
    require(value.get("rule") == "abs_difference <= atol + rtol * abs(reference)", "tolerance rule")
    fields = value.get("fields", {})
    require(set(fields) == set(CONTINUOUS), "every continuous metric must have a tolerance")
    for tolerances in fields.values():
        require(set(tolerances) == {"atol", "rtol"}, "tolerance fields")
        for number in tolerances.values():
            require(type(number) in (int, float) and math.isfinite(number) and number >= 0, "invalid tolerance")


def assert_native_replay(observed, reference, tolerances):
    validate_tolerances(tolerances)
    for name in ("case_id", "source_skull_id", "skull_id", "defect_type", "fold", "seed"):
        require(str(observed[name]) == str(reference[name]), "native identity mismatch: " + name)
    for name in EXACT_METRICS:
        require(float(observed[name]) == float(reference[name]), "native count/flag mismatch: " + name)
    for name in CONTINUOUS:
        actual, expected = float(observed[name]), float(reference[name])
        require(math.isfinite(actual) and math.isfinite(expected), "nonfinite native field")
        tolerance = tolerances["fields"][name]
        require(abs(actual - expected) <= tolerance["atol"] + tolerance["rtol"] * abs(expected), "native replay tolerance exceeded: " + name)


def audit_metric_flags(row):
    for name in EXACT_METRICS:
        number = float(row[name])
        require(math.isfinite(number) and number == int(number) and number >= 0, "noninteger count/flag")
    core_nonfinite = [name for name in CORE if not math.isfinite(float(row[name]))]
    hd = float(row["rim_contact_hd95_mm"])
    expected = int(bool(core_nonfinite) or (math.isfinite(hd) and hd > 50.0))
    require(int(row["disaster"]) == expected, "disaster flag mismatch")
    require(int(row["zero_contact_2mm"]) == int(int(row["rim_predicted_rim_points"]) == 0), "zero flag mismatch")
    require(not core_nonfinite, "nonfinite core stopped")
    require(int(row["rim_reference_rim_points"]) > 0 and int(row["rim_predicted_rim_points"]) > 0,
            "R1B_NONFINITE_CONTACT_OR_EMPTY_FOOTPRINT")
    require(all(math.isfinite(float(row[name])) for name in CONTINUOUS), "nonfinite metric stopped")


class AccessLedger:
    """Count attempts before effects, completions after; stop has no retry API."""

    def __init__(self, case_ids, fold):
        require(fold in ("C", "D"), "ledger fold")
        require(len(case_ids) == 105 and len(set(case_ids)) == 105, "105 unique cases required")
        self.case_ids, self.fold = tuple(case_ids), fold
        self.counts = dict(checkpoint_loads=0, checkpoint_hash_verifications=0, npz_open_events=0, member_partial=0,
                           member_implant=0, member_gt=0, forward_attempts=0,
                           model_case_forward_calls=0, optimizer_steps=0,
                           parameter_updates=0, buffer_updates=0, bncal_forwards=0)
        self.loaded = set()
        self.closed = 0
        self.active = None
        self.members = set()
        self.completed = []
        self.pending = None
        self.failed = False

    def _require(self, condition, message):
        if self.failed or not condition:
            self.failed = True
            raise ContractError(message)

    def record_checkpoint_load(self, run_key):
        allowed = {c + "_fold" + self.fold + "_seed0" for c in ("LS", "LSQ")}
        self._require(run_key in allowed and run_key not in self.loaded and self.active is None, "checkpoint load budget/order")
        self.loaded.add(run_key)
        self.counts["checkpoint_loads"] += 1

    def record_checkpoint_hash(self):
        self._require(self.active is None and self.counts["checkpoint_hash_verifications"] < 4,
                      "checkpoint byte verification budget/order")
        self.counts["checkpoint_hash_verifications"] += 1

    def begin_case(self, case_id):
        self._require(self.active is None and self.closed < 105 and len(self.loaded) == 2 and
                      case_id == self.case_ids[self.closed], "case order/duplicate/allowlist")
        self.active, self.members, self.completed = case_id, set(), []
        self.counts["npz_open_events"] += 1

    def read_member(self, member):
        self._require(self.active is not None and member in ("partial", "implant", "gt") and
                      member not in self.members, "forbidden/duplicate member")
        if member == "partial":
            self._require(not self.completed and self.pending is None, "partial timing")
        else:
            self._require(self.completed == list(CONDITIONS) and self.pending is None, "GT must follow three successful forwards")
        self.members.add(member)
        self.counts["member_" + member] += 1

    def begin_forward(self, condition):
        self._require(self.active is not None and "partial" in self.members and self.pending is None and
                      len(self.completed) < 3 and condition == CONDITIONS[len(self.completed)] and
                      self.counts["forward_attempts"] < 315, "forward condition/order/budget")
        self.pending = condition
        self.counts["forward_attempts"] += 1

    def end_forward(self):
        self._require(self.pending is not None, "forward completion without attempt")
        self.completed.append(self.pending)
        self.pending = None
        self.counts["model_case_forward_calls"] += 1

    def end_case(self):
        self._require(self.members == {"partial", "implant", "gt"} and self.completed == list(CONDITIONS) and self.pending is None, "incomplete case")
        self.closed += 1
        self.active = None

    def assert_final(self):
        self._require(self.closed == 105 and self.active is None, "incomplete fold")
        expected = {"checkpoint_loads": 2, "checkpoint_hash_verifications": 4, "npz_open_events": 105, "member_partial": 105,
                    "member_implant": 105, "member_gt": 105, "forward_attempts": 315,
                    "model_case_forward_calls": 315, "optimizer_steps": 0,
                    "parameter_updates": 0, "buffer_updates": 0, "bncal_forwards": 0}
        self._require(self.counts == expected, "final ledger mismatch")


def read_native_csv(path, case_ids):
    with Path(path).open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    require(len(rows) == 105 and [row["case_id"] for row in rows] == list(case_ids), "native CSV order/cardinality")
    return {row["case_id"]: row for row in rows}
