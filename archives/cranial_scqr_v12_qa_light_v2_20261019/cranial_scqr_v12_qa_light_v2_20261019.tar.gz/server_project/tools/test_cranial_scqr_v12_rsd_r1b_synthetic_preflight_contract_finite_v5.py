"""Artificial-only finite resolver and reader/writer regressions. No torch."""
import ast
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
import finite_dependencies_v10 as d
import finite_preflight_contract_v5 as c


class FiniteContracts(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='r1b-v10-artificial-')
        self.root = Path(self.tmp.name).resolve()
        self.addCleanup(self.tmp.cleanup)

    def row(self, rel='pkg/data/code.py', raw=b'x=1\n', domain='DEPENDENCY_CODE', kind='python', module='pkg.data.code'):
        p = self.root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(raw)
        return dict(path=str(p), root=str(self.root), domain=domain, kind=kind,
                    reason='artificial contract only', bytes=len(raw), sha256=d.sha(raw), module=module)

    def scope(self, rows):
        return dict(schema=d.SCOPE_SCHEMA, unresolved=[], required=rows, providers={},
                    optional_absent_allowlist=[], loader_targets=[], loader_edges={}, record_only=[], excluded=[])

    def rejected(self, rule, function, *args):
        with self.assertRaises(d.DependencyError) as ctx:
            function(*args)
        self.assertEqual(ctx.exception.detail['rule_id'], rule)
        return ctx.exception

    def test_dependency_data_code(self):
        self.assertEqual(d.resolve(self.scope([self.row()]))['files'], 1)

    def test_dependency_datasets_code(self):
        self.assertEqual(d.resolve(self.scope([self.row('pkg/datasets/code.py')]))['files'], 1)

    def test_project_data_preopen(self):
        row = self.row(domain='PROJECT_CODE')
        with patch.object(os, 'open', side_effect=AssertionError('must not open')):
            e = self.rejected('PROJECT_DATA_DIRECTORY', d.read_required, row, d.Budget())
        self.assertEqual(e.detail['entry_path'], row['path'])
        self.assertEqual(e.detail['relative_path'],'pkg/data/code.py')
        self.assertEqual(e.detail['counts']['completed_bytes'],0)

    def test_payload_preopen(self):
        for suffix in ('.npz', '.stl', '.pt', '.pth', '.pkl', '.pickle', '.csv', '.jsonl'):
            row = self.row('pkg/data/artificial'+suffix, kind='resource')
            with patch.object(os, 'open', side_effect=AssertionError('payload opened')):
                self.rejected('PAYLOAD_DENIED', d.read_required, row, d.Budget())

    def test_secret_redaction(self):
        row = self.row('pkg/secrets/code.py')
        e = self.rejected('SECRET_DENIED', d.read_required, row, d.Budget())
        self.assertEqual(e.detail['entry_path'], '[REDACTED_SECRET_PATH]')

    def test_root_escape(self):
        row = self.row()
        row['root'] = str(self.root/'other')
        self.rejected('ROOT_ESCAPE', d.read_required, row, d.Budget())

    def test_dotdot(self):
        row = self.row()
        row['path'] = str(self.root/'..'/'x.py')
        self.rejected('LEXICAL_ESCAPE', d.read_required, row, d.Budget())

    def test_directory_symlink(self):
        row = self.row('target/code.py')
        (self.root/'alias').symlink_to(self.root/'target', target_is_directory=True)
        row['path'] = str(self.root/'alias/code.py')
        self.rejected('DIRECTORY_LINK_OR_NONDIR', d.read_required, row, d.Budget())

    def test_file_symlink(self):
        row = self.row()
        (self.root/'link.py').symlink_to(row['path'])
        row['path'] = str(self.root/'link.py')
        self.rejected('NONREGULAR_LINK_OR_SIZE', d.read_required, row, d.Budget())

    def test_link_cycle(self):
        row = self.row()
        (self.root/'cycle').symlink_to('cycle', target_is_directory=True)
        row['path'] = str(self.root/'cycle/x.py')
        self.rejected('DIRECTORY_LINK_OR_NONDIR', d.read_required, row, d.Budget())

    def test_missing_file_detail(self):
        row = self.row()
        Path(row['path']).unlink()
        e = self.rejected('PATH_IO_ERROR', d.read_required, row, d.Budget())
        self.assertEqual(e.detail['entry_path'], row['path'])
        self.assertEqual(e.detail['operation'], 'ANCHORED_READ')

    def test_size_drift(self):
        row = self.row(); row['bytes'] += 1
        self.rejected('NONREGULAR_LINK_OR_SIZE', d.read_required, row, d.Budget())

    def test_hash_drift(self):
        row = self.row(); row['sha256'] = 'a'*64
        self.rejected('CONTENT_HASH_DRIFT', d.read_required, row, d.Budget())

    def test_expected_hash_required(self):
        row = self.row(); row['sha256'] = None
        self.rejected('EXPECTED_HASH_REQUIRED', d.read_required, row, d.Budget())

    def test_reason_required(self):
        row = self.row(); row['reason'] = ''
        self.rejected('MISSING_REASON', d.read_required, row, d.Budget())

    def test_atime_excluded(self):
        row = self.row(); p = Path(row['path']); before = d.fp(p.stat())
        os.utime(p, ns=(p.stat().st_atime_ns+1000, p.stat().st_mtime_ns))
        # utime also changes ctime: use stat objects to isolate the excluded field.
        before_stat = p.stat()
        class SameContent:
            pass
        after = SameContent()
        for k in ('st_dev','st_ino','st_mode','st_size','st_mtime_ns','st_ctime_ns'):
            setattr(after,k,getattr(before_stat,k))
        after.st_atime_ns = before_stat.st_atime_ns + 99
        self.assertEqual(d.fp(before_stat), d.fp(after))

    def test_duplicate_entity(self):
        row = self.row()
        self.rejected('DUPLICATE_ENTITY', d.resolve, self.scope([row,row]))

    def test_empty_scope(self):
        self.rejected('EMPTY_REQUIRED_SET', d.resolve, self.scope([]))

    def test_unresolved_scope(self):
        s = self.scope([self.row()]); s['unresolved'] = ['PointNet2']
        self.rejected('SCOPE_SCHEMA_OR_UNRESOLVED', d.resolve, s)

    def test_file_byte_budget(self):
        self.rejected('FILE_OR_BYTE_CAP', d.resolve, self.scope([self.row()]), {'bytes':1})

    def test_budget_cannot_expand(self):
        self.rejected('INVALID_BUDGET', d.Budget, {'seconds':901})

    def test_bool_budget(self):
        self.rejected('INVALID_BUDGET', d.Budget, {'seconds':True})

    def test_total_deadline(self):
        b = d.Budget(clock=lambda:0); b.clock = lambda:900
        self.rejected('TOTAL_DEADLINE', b.check)

    def test_import_provider_missing(self):
        s = self.scope([self.row(raw=b'import dependency\n')])
        self.rejected('IMPORT_PROVIDER_UNRESOLVED', d.resolve, s)

    def test_import_provider_bound(self):
        row = self.row(raw=b'import helper\n')
        helper = self.row('helper.py', module='helper')
        s = self.scope([row,helper]); s['providers']['helper'] = {'status':'BOUND','paths':[helper['path']]}
        self.assertEqual(d.resolve(s)['files'],2)

    def test_import_provider_not_bound(self):
        s=self.scope([self.row(raw=b'import helper\n')]); s['providers']['helper']={'status':'BOUND','paths':['/missing.py']}
        self.rejected('PROVIDER_NOT_BOUND',d.resolve,s)

    def test_optional_requires_explicit_policy(self):
        s=self.scope([self.row(raw=b'import missing\n')]); s['providers']['missing']={'status':'KNOWN_OPTIONAL_ABSENT','reason':'old registry optional'}
        self.rejected('UNAPPROVED_OPTIONAL_ABSENCE',d.resolve,s)

    def test_optional_explicit(self):
        s=self.scope([self.row(raw=b'import missing\n')]); s['providers']['missing']={'status':'KNOWN_OPTIONAL_ABSENT','reason':'artificial optional'}
        s['optional_absent_allowlist']=['missing']; self.assertEqual(d.resolve(s)['files'],1)

    def test_dynamic_literal_import(self):
        self.assertEqual(d.source_imports(b"_try_import('models.GRNet')\n",'models',True),['models.GRNet'])

    def test_dynamic_unknown_rejected(self):
        self.rejected('DYNAMIC_IMPORT_UNRESOLVED',d.source_imports,b'__import__(name)\n','x')

    def test_relative_import(self):
        self.assertEqual(d.source_imports(b'from . import child\n','pkg',True),['pkg','pkg.child'])

    def test_startup_hook_not_weight(self):
        row=self.row('pkg/hook.pth',raw=b'import hook\n',kind='startup_hook')
        row.update(hook_policy='REVIEWED_TEXT_NO_EXECUTION',hook_imports=['hook'])
        s=self.scope([row]); s['providers']['hook']={'status':'BOUND','paths':[row['path']]}
        self.assertEqual(d.resolve(s)['files'],1)

    def test_unreviewed_hook(self):
        row=self.row('pkg/hook.pth',raw=b'import hook\n',kind='startup_hook')
        self.rejected('STARTUP_HOOK_UNREVIEWED',d.resolve,self.scope([row]))

    def test_loader_parse(self):
        self.assertEqual(d.parse_loader_output('libx.so => /lib/libx.so (0x123)\nlinux-vdso.so.1 (0x23)\n'),['/lib/libx.so'])

    def test_loader_missing(self):
        self.rejected('LOADER_NOT_FOUND',d.parse_loader_output,'libx => not found')

    def test_loader_unparsed(self):
        self.rejected('LOADER_OUTPUT_UNRESOLVED',d.parse_loader_output,'unexpected output')

    def test_loader_unbound(self):
        row=self.row(); s=self.scope([row]);s['loader_targets']=[row['path']];s['loader_edges']={row['path']:['/missing.so']}
        self.rejected('LOADER_TARGET_UNBOUND',d.resolve,s)

    def test_loader_transitive_missing(self):
        row=self.row(); dep=self.row('dep.py',module='dep');s=self.scope([row,dep]);s['loader_targets']=[row['path']];s['loader_edges']={row['path']:[dep['path']]}
        self.rejected('TRANSITIVE_LOADER_UNRESOLVED',d.resolve,s)

    def test_loader_graph_closure(self):
        row=self.row();s=self.scope([row]);s['loader_targets']=[row['path']];s['loader_edges']={row['path']:[row['path']]}
        self.assertEqual(d.resolve(s)['files'],1)

    def test_record_only_not_opened(self):
        s=self.scope([self.row()]);s['record_only']=[{'package':'unrelated','path':'/unopened'}]
        self.assertEqual(d.resolve(s)['files'],1)

    def test_excluded_not_opened(self):
        s=self.scope([self.row()]);s['excluded']=[{'path':'/unopened/data','reason':'noncode'}]
        self.assertEqual(d.resolve(s)['files'],1)

    def test_roundtrip_reader_writer(self):
        s=self.scope([self.row()]);v=d.resolve(s);p=self.root/'inventory.json'
        binding=d.publish_inventory(p,v,s);self.assertEqual(c.read_inventory(p.read_bytes(),s),v)
        self.assertEqual(binding['sha256'],d.sha(p.read_bytes()))

    def test_no_overwrite(self):
        s=self.scope([self.row()]);v=d.resolve(s);p=self.root/'inventory.json';p.write_text('old')
        self.rejected('PUBLICATION_TARGET',d.publish_inventory,p,v,s);self.assertEqual(p.read_text(),'old')

    def test_old_inventory_rejected(self):
        self.rejected('INVENTORY_SCHEMA_OR_STATUS',d.validate_inventory,{'status':'FROZEN_STATIC_CODE_BINARY_INVENTORY_CPU_ONLY'},self.scope([self.row()]))

    def test_extra_inventory_row(self):
        s=self.scope([self.row()]);v=d.resolve(s);v['required'].append(v['required'][0])
        self.rejected('INVENTORY_EXACT_SET',d.validate_inventory,v,s)

    def test_inventory_scope_drift(self):
        s=self.scope([self.row()]);v=d.resolve(s);s['record_only']=['changed']
        self.rejected('INVENTORY_SCOPE_MISMATCH',d.validate_inventory,v,s)

    def test_inventory_zero_counter_type(self):
        s=self.scope([self.row()]);v=d.resolve(s);v['checkpoint_reads']=False
        self.rejected('INVENTORY_PERMISSION',d.validate_inventory,v,s)

    def test_failure_propagation(self):
        e=d.DependencyError('PROJECT_DATA_DIRECTORY','/project/data','PROJECT_CODE')
        child=d.failure_record(e);controller=c.propagate_failure(RuntimeError('controller'),child)
        supervisor=c.propagate_failure(RuntimeError('supervisor'),controller,['secondary'])
        self.assertEqual(supervisor['first_error'],child['first_error'])
        self.assertEqual(supervisor['secondary_errors'],['secondary'])

    def test_malformed_failure(self):
        self.rejected('MALFORMED_CHILD_FAILURE',c.propagate_failure,RuntimeError('x'),{})

    def test_runtime_unbound_load(self):
        s=self.scope([self.row()]);self.rejected('UNBOUND_RUNTIME_LOAD',c.validate_runtime_observation,{'x':'/unbound'},[],s)

    def test_execution_scope_escape(self):
        self.rejected('EXECUTION_SCOPE_ROOT',c.validate_execution_scope,self.scope([self.row()]))

    def test_duplicate_json(self):
        self.rejected('DUPLICATE_JSON_KEY',d.strict_json,b'{"x":1,"x":2}')

    def test_nonfinite_json(self):
        self.rejected('NONFINITE_JSON',d.strict_json,b'{"x":NaN}')

    def test_new_tool_syntax_inert(self):
        for p in list(HERE.glob('*.py'))+list(HERE.parent.glob('*.py')):
            ast.parse(p.read_bytes())
        self.assertNotIn('torch',sys.modules)

    def request_fixture(self):
        parent={k:{} for k in c.SEMANTICS}
        parent['resource_binding']={k:1 for k in ('minimum_free_gpu_memory_mib_at_launch','minimum_free_disk_bytes_at_launch','maximum_peak_allocated_mib','maximum_peak_reserved_mib','maximum_walltime_seconds')}
        rebind={'schema':'r1b-finite-resource-rebind-v1','status':'PASS_READONLY_RESOURCE_REBIND',
                'parent_resource_binding':copy.deepcopy(parent['resource_binding']),
                'resource_binding':dict(parent['resource_binding'],hostname='artificial-host',gpu_uuid='artificial-gpu')}
        q=copy.deepcopy(parent)
        q.update(schema=c.REQUEST_SCHEMA,status='AWAITING_EXPLICIT_USER_AUTHORIZATION',execution_authorized=False,
                 implementation_authorized=False,execution_ready=True,direct_execution_allowed=False,missing_preconditions=[],
                 resource_binding=rebind['resource_binding'],resource_rebind_sha256=d.sha(d.canonical(rebind)),
                 run_id=c.RUN,output_relative=c.PREFIX+'result',parent_request_sha256='a'*64)
        return q,parent,rebind

    def test_new_resource_rebind(self):
        self.assertTrue(c.validate_request(*self.request_fixture(),parent_sha256='a'*64))

    def test_resource_rebind_missing(self):
        q,p,r=self.request_fixture();self.rejected('RESOURCE_REBIND_REQUIRED',c.validate_request,q,p,{},'a'*64)

    def test_resource_rebind_drift(self):
        q,p,r=self.request_fixture();q['resource_binding']=dict(q['resource_binding'],hostname='drift')
        self.rejected('RESOURCE_REBIND_DRIFT',c.validate_request,q,p,r,'a'*64)

    def test_old_namespace_rejected(self):
        q,p,r=self.request_fixture();q['run_id']='r1b_synthetic_gpu_pf_v2_20261011'
        self.rejected('NEW_NAMESPACE_REQUIRED',c.validate_request,q,p,r,'a'*64)

    def test_numerical_semantics_not_relaxed(self):
        q,p,r=self.request_fixture();q['numerical_policy']={'tf32':True}
        self.rejected('FROZEN_SEMANTICS_DRIFT',c.validate_request,q,p,r,'a'*64)

    def test_self_authorization(self):
        q,p,r=self.request_fixture();q['execution_authorized']=True
        self.rejected('REQUEST_SELF_AUTHORIZATION',c.validate_request,q,p,r,'a'*64)

    def test_single_way_authorization(self):
        q={'permissions':{}}
        auth=dict(status='AUTHORIZED_ONCE_SYNTHETIC_FINITE_PREFLIGHT_V5',request_sha256='a'*64,run_id=c.RUN,execution_authorized=True,permissions={})
        runtime=dict(stage='R1B_SYNTHETIC_FINITE_PREFLIGHT_V5',request_sha256='a'*64,authorization_receipt_sha256='b'*64,run_id=c.RUN)
        self.assertTrue(c.validate_chain(q,auth,runtime,'a'*64,'b'*64))
        auth['runtime_sha256']='c'*64
        self.rejected('AUTHORIZATION_CHAIN',c.validate_chain,q,auth,runtime,'a'*64,'b'*64)

    def test_completion_success(self):
        value=dict(schema=c.COMPLETION_SCHEMA,status='PASS_FINITE_CPU_IMPLEMENTATION_PENDING_FREEZE',inventory_binding={},scope_sha256='a'*64,
                   implementation_sha256={},cpu_test_counts=[99,27,99],cpu_exit_codes=[0,0,0],registered_group_state='REGISTERED_EMPTY',
                   reaped=True,controller_exit_code=0,gpu_used=False,real_payload_reads=0,checkpoint_reads=0,automatic_retry=False,first_error=None)
        self.assertTrue(c.validate_cpu_completion(value,{},'a'*64,{},[99,27,99]))
        value['cpu_exit_codes']=[False,0,0]
        self.rejected('CPU_COUNTER_TYPES',c.validate_cpu_completion,value,{},'a'*64,{},[99,27,99])

    def test_alias_canonical_once(self):
        row=self.row('canonical/code.py');(self.root/'alias').symlink_to('canonical',target_is_directory=True)
        s=self.scope([row]);s['aliases']=[dict(path=str(self.root/'alias'),root=str(self.root),domain='DEPENDENCY_CODE',
            raw_target='canonical',canonical_target=str(self.root/'canonical'),action='ALIAS_ONLY_REQUIRE_CANONICAL_COVERAGE')]
        self.assertEqual(d.resolve(s)['files'],1)

    def test_alias_coverage_missing(self):
        row=self.row();(self.root/'canonical').mkdir();(self.root/'alias').symlink_to('canonical',target_is_directory=True)
        rows=[dict(path=str(self.root/'alias'),root=str(self.root),domain='DEPENDENCY_CODE',raw_target='canonical',canonical_target=str(self.root/'canonical'),action='ALIAS_ONLY_REQUIRE_CANONICAL_COVERAGE')]
        self.rejected('ALIAS_COVERAGE_MISSING',d.validate_aliases,rows,[row['path']])

    def test_exclusion_no_content_read(self):
        row=self.row();(self.root/'excluded').mkdir();(self.root/'excluded/payload.npz').write_bytes(b'artificial')
        (self.root/'alias').symlink_to('excluded',target_is_directory=True)
        s=self.scope([row]);s['aliases']=[dict(path=str(self.root/'alias'),root=str(self.root),domain='DEPENDENCY_CODE',raw_target='excluded',canonical_target=str(self.root/'excluded'),action='EXPLICIT_CONTENT_EXCLUSION_METADATA_ONLY')]
        self.assertEqual(d.resolve(s)['files'],1)

    def test_package_roles_record_only_not_interrogated(self):
        versions={name:'artificial-v1' for name in ('torch','numpy','timm','einops','PyYAML','easydict')}
        resource={'required_package_metadata_versions':versions,'record_only_package_versions':{'mamba-ssm':'unrelated'}}
        calls=[]
        def getter(name):
            calls.append(name);return versions[name]
        self.assertTrue(c.validate_metadata_roles(resource,{'package_versions':versions},getter))
        self.assertNotIn('mamba-ssm',calls)

    def test_package_roles_required_drift_blocks(self):
        versions={name:'v1' for name in ('torch','numpy','timm','einops','PyYAML','easydict')}
        self.rejected('REQUIRED_PACKAGE_VERSION_DRIFT',c.validate_metadata_roles,
                      {'required_package_metadata_versions':versions},{'package_versions':versions},lambda _: 'v2')

    def test_python_source_memory_cap(self):
        row=self.row();row['bytes']=17*1024**2
        self.rejected('METADATA_CAP',d.read_required,row,d.Budget())


if __name__ == '__main__':
    unittest.main(verbosity=2, failfast=True)
