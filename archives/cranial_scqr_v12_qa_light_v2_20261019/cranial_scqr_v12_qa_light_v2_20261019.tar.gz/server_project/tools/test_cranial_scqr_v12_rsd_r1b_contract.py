#!/usr/bin/env python3
"""Artificial-only L1 contracts. No model construction, checkpoint or real data.

--torch-cpu enables tiny CPU tensors only. It masks CUDA before import and
replaces CUDA initialization with a hard failure. No real forward is run.
"""

import argparse
import ast
import copy
import hashlib
import importlib.util
import json
import math
import os
import socket
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PARENT_MODEL = Path(os.environ.get("RSD_PARENT_MODEL", str(ROOT / "parents/AdaPoinTr.parent.py")))
sys.path.insert(0, str(HERE))
import cranial_scqr_v12_rsd_r1b_contract as c
import run_cranial_scqr_v12_rsd_r1b as run


def bypass_module():
    spec = importlib.util.spec_from_file_location("rsd_outlet_test", ROOT / "models/cranial_scqr/rsd_query_bypass.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def request_fixture():
    # Synthetic dictionaries only; no authorization/runtime files materialized.
    return {"schema": c.SCHEMA, "status": "AWAITING_EXPLICIT_USER_AUTHORIZATION",
            "execution_authorized": False, "request_id": "artificial-fixture", "fold": "C", "seed": 0,
            "protocol_sha256": c.PROTOCOL_SHA, "conditions": list(c.CONDITIONS),
            "permissions": {name: False for name in c.FALSE_PERMISSIONS},
            "budget": {"cases": 105, "forwards": 315, "npz_opens": 105, "checkpoint_loads": 2, "checkpoint_hash_verifications": 4,
                       "member_partial": 105, "member_implant": 105, "member_gt": 105,
                       "optimizer_steps": 0, "parameter_updates": 0, "buffer_updates": 0, "bncal_forwards": 0},
            "forward_epoch": None, "rng_contract": "candidate-isolated-native-progression-v1",
            "empty_contact_policy": "STOP_KEEP_ORIGINAL_FLAGS", "output_limit_bytes": 16 * 1024 * 1024,
            "max_wall_seconds": 3600,
            "max_vram_mib": 8192,
            "environment_contract": {"python_version": "synthetic", "torch_version": "synthetic", "numpy_version": "synthetic",
                "scipy_version": "synthetic", "cuda_version": "synthetic", "gpu_driver": "synthetic", "cudnn_version": 1,
                "cpu_threads": 1, "binary_bindings": [{"path": "artificial.so"}], "extension_source_bindings": [{"path": "artificial.cpp"}]},
            "data_root": "/home/jovyan/datasets/SkullBreakPC_out8192",
            "resource": {"hostname": socket.gethostname(), "gpu_uuid": "GPU-artificial-not-a-real-resource"},
            "models": {candidate: {"run_key": candidate + "_foldC_seed0",
                "checkpoint": {"sha256": c.CHECKPOINT_SHA[candidate + "_foldC_seed0"]},
                "reference_csv": {"sha256": c.FROZEN_REFERENCE_SHA[candidate + "_foldC_seed0"]}}
                for candidate in ("LS", "LSQ")},
            "implementation_bindings": [{"path": name, "sha256": sha} for name, sha in {
                **c.IMMUTABLE_SOURCES, "models/AdaPoinTr.py": "synthetic", "models/cranial_scqr/rsd_query_bypass.py": "synthetic",
                "tools/cranial_scqr_v12_rsd_r1b_contract.py": "synthetic", "tools/run_cranial_scqr_v12_rsd_r1b.py": "synthetic"}.items()]}


def tolerances():
    return {"status": "FROZEN_CONFIRMED_BEFORE_DEV", "basis_scope": "ARTIFICIAL_ONLY",
            "rule": "abs_difference <= atol + rtol * abs(reference)",
            "fields": {name: {"atol": 0.001, "rtol": 0.0} for name in c.CONTINUOUS}}


def metric_fixture():
    value = {name: 1.0 for name in c.CONTINUOUS}
    value.update(rim_reference_rim_points=3, rim_predicted_rim_points=3, zero_contact_2mm=0, disaster=0,
                 case_id="artificial", source_skull_id="000", skull_id="train:000", defect_type="bilateral", fold="C", seed=0)
    return value


class StripRSD(ast.NodeTransformer):
    """Erase only opt-in RSD plumbing, then compare the WHOLE module AST."""
    def visit_If(self, node):
        if isinstance(node.test, ast.Compare) and isinstance(node.test.left, ast.Name) and node.test.left.id == "rsd_condition":
            if isinstance(node.test.ops[0], ast.Is):
                return [self.visit(item) for item in node.body]
            return []
        return self.generic_visit(node)

    def visit_FunctionDef(self, node):
        if node.name == "_condition_scqr_queries":
            node.args.args = node.args.args[:-2]
            node.args.defaults = node.args.defaults[:-2]
        if node.name == "forward":
            keep = [(arg, default) for arg, default in zip(node.args.kwonlyargs, node.args.kw_defaults)
                    if arg.arg not in ("rsd_condition", "rsd_diagnostics")]
            node.args.kwonlyargs = [arg for arg, _default in keep]
            node.args.kw_defaults = [default for _arg, default in keep]
        return self.generic_visit(node)

    def visit_Call(self, node):
        if isinstance(node.func, ast.Attribute) and node.func.attr == "_condition_scqr_queries":
            node.args = node.args[:-2]
        return self.generic_visit(node)


class TextContracts(unittest.TestCase):
    def test_import_inert(self):
        self.assertNotIn("torch", sys.modules)
        self.assertNotIn("numpy", sys.modules)

    def test_all_sources_compile_without_import(self):
        for name in ("models/AdaPoinTr.py", "models/cranial_scqr/rsd_query_bypass.py",
                     "tools/cranial_scqr_v12_rsd_r1b_contract.py", "tools/run_cranial_scqr_v12_rsd_r1b.py"):
            source = (ROOT / name).read_text(encoding="utf-8")
            compile(source, name, "exec")

    def test_entire_legacy_ast_preserved(self):
        before = ast.parse(PARENT_MODEL.read_text(encoding="utf-8"))
        after = ast.parse((ROOT / "models/AdaPoinTr.py").read_text(encoding="utf-8"))
        self.assertEqual(ast.dump(before, include_attributes=False), ast.dump(StripRSD().visit(after), include_attributes=False))

    def test_condition_variants_and_training(self):
        m = bypass_module()
        for condition, variant in (("LS_native", "A1"), ("LSQ_native", "Q0"), ("LSQ_query_off", "Q0")):
            m.validate_rsd_condition(condition, variant, False)
            with self.assertRaises(ValueError):
                m.validate_rsd_condition(condition, variant, True)
        for condition, variant in (("LSQ_query_off", "A1"), ("LS_native", "Q0"), ("QC_native", "QC")):
            with self.assertRaises(ValueError):
                m.validate_rsd_condition(condition, variant, False)

    def test_outlet_identity_and_no_switch(self):
        m = bypass_module()
        q, native = object(), object()
        conditioned = SimpleNamespace(queries=native)
        self.assertIs(m.select_rsd_queries(q, conditioned, None, "LSQ_native"), native)
        self.assertIs(m.select_rsd_queries(q, conditioned, None, "LSQ_query_off"), q)
        self.assertIs(m.select_rsd_queries(q, conditioned, None, "LSQ_native"), native)
        with self.assertRaises(ValueError):
            m.select_rsd_queries(q, conditioned, None, "LS_native")

    def test_request_accepts_only_frozen_contract(self):
        c.validate_request(request_fixture())
        for key, value in (("seed", 1), ("fold", "A"), ("forward_epoch", 101),
                           ("execution_authorized", True), ("protocol_sha256", "wrong"), ("conditions", ["LSQ_query_off"])):
            request = request_fixture()
            request[key] = value
            with self.assertRaises(c.ContractError):
                c.validate_request(request)

    def test_permission_fields_must_all_be_false(self):
        for name in c.FALSE_PERMISSIONS:
            for value in (True, None):
                request = request_fixture()
                request["permissions"][name] = value
                with self.assertRaises(c.ContractError):
                    c.validate_request(request)

    def test_resource_and_parent_hash_drift(self):
        request = request_fixture()
        request["resource"]["hostname"] = "other-host"
        with self.assertRaises(c.ContractError):
            c.validate_request(request)
        request = request_fixture()
        request["models"]["LSQ"]["checkpoint"]["sha256"] = "other"
        with self.assertRaises(c.ContractError):
            c.validate_request(request)

    def test_one_way_authorization_chain(self):
        request = request_fixture()
        auth = {"status": "AUTHORIZED_ONCE", "execution_authorized": True, "request_sha256": "request",
                "request_id": "artificial-fixture", "fold": "C", "permissions": dict(request["permissions"])}
        runtime = {"stage": "V12_RSD_R1B_SINGLE_FOLD", "request_sha256": "request", "authorization_receipt_sha256": "auth", "fold": "C", "runs_authorized": 1}
        c.validate_chain(request, auth, runtime, "request", "auth")
        for bad_auth in ({**auth, "runtime_sha256": "cycle"}, {**auth, "status": "AUTHORIZED_IMPLEMENTATION_ONLY"}):
            with self.assertRaises(c.ContractError):
                c.validate_chain(request, bad_auth, runtime, "request", "auth")
        with self.assertRaises(c.ContractError):
            c.validate_chain(request, auth, {**runtime, "runs_authorized": 2}, "request", "auth")

    def test_binding_path_and_hash_guards(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            file = root / "artificial.txt"
            file.write_bytes(b"artificial-only")
            binding = {"path": "artificial.txt", "bytes": 15, "sha256": hashlib.sha256(b"artificial-only").hexdigest()}
            self.assertEqual(c.bound_path(root, binding), file)
            for change in ({"path": "../escape.txt"}, {"path": str(file.resolve())}, {"sha256": "bad"}, {"bytes": 14}):
                with self.assertRaises(c.ContractError):
                    c.bound_path(root, {**binding, **change})

    def test_gt_cannot_precede_three_forwards(self):
        ledger = self.ledger()
        ledger.begin_case("case000")
        ledger.read_member("partial")
        with self.assertRaises(c.ContractError):
            ledger.read_member("implant")
        self.assertTrue(ledger.failed)
        with self.assertRaises(c.ContractError):
            ledger.begin_forward("LS_native")

    def ledger(self):
        ledger = c.AccessLedger(["case%03d" % i for i in range(105)], "C")
        for _ in range(4):
            ledger.record_checkpoint_hash()
        ledger.record_checkpoint_load("LS_foldC_seed0")
        ledger.record_checkpoint_load("LSQ_foldC_seed0")
        return ledger

    def test_exact_full_artificial_access_budget(self):
        ledger = self.ledger()
        for case in ledger.case_ids:
            ledger.begin_case(case)
            ledger.read_member("partial")
            for condition in c.CONDITIONS:
                ledger.begin_forward(condition)
                ledger.end_forward()
            ledger.read_member("implant")
            ledger.read_member("gt")
            ledger.end_case()
        ledger.assert_final()
        self.assertEqual(ledger.counts["forward_attempts"], 315)
        with self.assertRaises(c.ContractError):
            ledger.begin_case("case000")

    def test_duplicate_load_wrong_fold_and_members(self):
        ledger = self.ledger()
        with self.assertRaises(c.ContractError):
            ledger.record_checkpoint_load("LS_foldC_seed0")
        ledger = self.ledger()
        with self.assertRaises(c.ContractError):
            ledger.begin_case("case001")
        ledger = self.ledger()
        ledger.begin_case("case000")
        with self.assertRaises(c.ContractError):
            ledger.read_member("reference_rim")

    def test_pending_failed_forward_cannot_read_gt(self):
        ledger = self.ledger()
        ledger.begin_case("case000")
        ledger.read_member("partial")
        ledger.begin_forward("LS_native")
        with self.assertRaises(c.ContractError):
            ledger.read_member("gt")

    def test_frozen_tolerance_and_exact_flags(self):
        original = metric_fixture()
        replay = dict(original, implant_cd_l1_mm=1.0005)
        c.assert_native_replay(replay, original, tolerances())
        for change in ({"implant_cd_l1_mm": 1.1}, {"disaster": 1}, {"case_id": "other"}, {"rim_reference_rim_points": 4}):
            with self.assertRaises(c.ContractError):
                c.assert_native_replay({**original, **change}, original, tolerances())
        for change in ({"status": "DRAFT"}, {"basis_scope": "DEVELOPMENT"}, {"fields": {}}):
            with self.assertRaises(c.ContractError):
                c.validate_tolerances({**tolerances(), **change})

    def test_strict_hd95_boundary(self):
        for hd, flag in ((49.9999, 0), (50.0, 0), (50.0001, 1)):
            c.audit_metric_flags({**metric_fixture(), "rim_contact_hd95_mm": hd, "disaster": flag})

    def test_empty_nonfinite_and_fractional_flags_stop(self):
        empty = {**metric_fixture(), "rim_predicted_rim_points": 0, "zero_contact_2mm": 1,
                 "rim_contact_hd95_mm": float("nan")}
        with self.assertRaisesRegex(c.ContractError, "EMPTY_FOOTPRINT"):
            c.audit_metric_flags(empty)
        for change in ({"implant_cd_l1_mm": float("inf"), "disaster": 1}, {"disaster": 0.5}, {"rim_contact_hd95_mm": float("nan")}):
            with self.assertRaises(c.ContractError):
                c.audit_metric_flags({**metric_fixture(), **change})

    def test_cli_has_no_auto_model_import_and_gt_in_forward(self):
        tree = ast.parse((HERE / "run_cranial_scqr_v12_rsd_r1b.py").read_text())
        top_imports = [node for node in tree.body if isinstance(node, (ast.Import, ast.ImportFrom))]
        self.assertFalse(any("torch" in ast.dump(node) or "numpy" in ast.dump(node) for node in top_imports))
        calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "model"]
        self.assertEqual(len(calls), 1)
        self.assertEqual(ast.dump(calls[0].args[0]), ast.dump(ast.Name(id="partial", ctx=ast.Load())))
        self.assertEqual({key.arg for key in calls[0].keywords}, {"epoch", "rsd_condition", "rsd_diagnostics"})

    def test_safe_failure_nonfinite_not_zero(self):
        item = run.safe_json({"hd95": float("nan")})
        self.assertIsNone(item["hd95"]["value"])
        self.assertEqual(item["hd95"]["missing_reason"], "nonfinite")
        cases = [{"native_disaster": a, "off_disaster": b, "native_zero_contact": 0, "off_zero_contact": 0}
                 for a, b in ((0, 0), (1, 0), (0, 1), (1, 1))]
        counts = run.migration_counts(cases)
        self.assertEqual([counts[name] for name in ("both_flag_0", "native_only", "off_only", "both_event")], [1, 1, 1, 1])


class TensorContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        os.environ["CUDA_VISIBLE_DEVICES"] = ""
        import torch
        torch.cuda._lazy_init = lambda: (_ for _ in ()).throw(AssertionError("CUDA access forbidden in CPU contracts"))
        torch.set_num_threads(1)
        cls.torch = torch
        cls.bypass = bypass_module()

    def sample(self, residual=0.25):
        t = self.torch
        q = t.ones(1, 2, 384, dtype=t.float32)
        r = t.full_like(q, residual)
        output = SimpleNamespace(queries=q + r, residual=r, attention=t.tensor([[[1., 0.], [.5, .5]]]), warmup=1.0)
        return q, output, t.tensor([.01])

    def test_nonzero_and_zero_residual_identity(self):
        for magnitude in (0.0, 0.25):
            q, out, alpha = self.sample(magnitude)
            native = self.bypass.select_rsd_queries(q, out, alpha, "LSQ_native")
            off = self.bypass.select_rsd_queries(q, out, alpha, "LSQ_query_off")
            restored = self.bypass.select_rsd_queries(q, out, alpha, "LSQ_native")
            self.assertTrue(self.torch.equal(native, restored))
            self.assertEqual(self.torch.equal(native, off), magnitude == 0)

    def test_scalar_axes_and_effective_count(self):
        q, out, alpha = self.sample()
        d = {}
        native = self.bypass.select_rsd_queries(q, out, alpha, "LSQ_native", d)
        self.assertIs(native, out.queries)
        self.assertAlmostEqual(d["query_rms"], 1.0)
        self.assertAlmostEqual(d["potential_residual_rms"], .25)
        self.assertAlmostEqual(d["attention_entropy_mean"], math.log(2)/2, places=6)
        self.assertAlmostEqual(d["effective_proxy_count_mean"], 1.5, places=6)
        self.assertAlmostEqual(d["attention_max_weight_mean"], .75)
        off_d = {}
        self.bypass.select_rsd_queries(q, out, alpha, "LSQ_query_off", off_d)
        self.assertEqual(off_d["applied_residual_rms"], 0)
        self.assertEqual(off_d["potential_residual_rms"], .25)

    def test_instrumentation_does_not_mutate_tensor_state(self):
        q, out, alpha = self.sample()
        before = run.canonical_tensor_hash({"q": q, "r": out.residual, "alpha": alpha})
        plain = self.bypass.select_rsd_queries(q, out, alpha, "LSQ_native")
        traced = self.bypass.select_rsd_queries(q, out, alpha, "LSQ_native", {})
        self.assertIs(plain, traced)
        self.assertEqual(before, run.canonical_tensor_hash({"q": q, "r": out.residual, "alpha": alpha}))

    def test_state_hash_detects_name_dtype_shape_value(self):
        t = self.torch
        a = t.ones(2, 2)
        original = run.canonical_tensor_hash({"a": a})
        for mapping in ({"b": a}, {"a": a.double()}, {"a": a.reshape(4)}, {"a": a + 1}):
            self.assertNotEqual(original, run.canonical_tensor_hash(mapping))
        self.assertEqual(run.canonical_tensor_hash({"b": a, "a": a}), run.canonical_tensor_hash({"a": a, "b": a}))

    def test_invalid_diagnostics_and_attention_fail_closed(self):
        q, out, alpha = self.sample()
        with self.assertRaises(ValueError):
            self.bypass.select_rsd_queries(q, out, alpha, "LSQ_native", {"leaked": 1})
        for attention in (self.torch.ones(1, 2, 2), self.torch.full((1, 2, 2), float("nan"))):
            out.attention = attention
            with self.assertRaises(ValueError):
                self.bypass.select_rsd_queries(q, out, alpha, "LSQ_native", {})
        self.assertIs(self.bypass.select_rsd_queries(q, out, alpha, "LSQ_native"), out.queries)

    def test_synthetic_directional_footprints(self):
        # Only four artificial coordinates; metric source is imported without a model.
        import numpy as np
        partial = np.array([[0., 0, 0], [3., 0, 0], [6., 0, 0], [9., 0, 0]])
        target = np.array([[0., 0, 0], [3., 0, 0]])
        pred = np.array([[0., 0, 0], [6., 0, 0], [9., 0, 0]])
        result = run.extra_geometry(pred, pred, {"partial": partial, "implant": target},
                                    {"normalization": {"centroid": [0, 0, 0], "scale": 1.0}})
        self.assertEqual(result["contact_intersection_points"], 1)
        self.assertGreater(result["contact_pred_to_ref_p95_mm"], result["contact_ref_to_pred_p95_mm"])
        self.assertTrue(all(math.isfinite(value) for value in result.values()))


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--torch-cpu", action="store_true")
    args = parser.parse_args(argv)
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(TextContracts)
    if args.torch_cpu:
        suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(TensorContracts))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
