"""CPU/text only: execute AST-isolated functions, never import the BNCal runner."""
import ast
import copy
import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace as NS, ModuleType
from unittest.mock import patch
import torch

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / 'tools/run_cranial_scqr_v12_qa1_bncal.py').read_text()
tree = ast.parse(source)
module = ModuleType('tools.run_cranial_scqr_v12_qa1_bncal')
module.__dict__.update(Path=Path, hashlib=hashlib, json=json, os=os, torch=torch, REPO_ROOT=ROOT)
safe_nodes = [n for n in tree.body if (isinstance(n, ast.Assign) and all(isinstance(t,ast.Name) and t.id.isupper() and t.id!='REPO_ROOT' for t in n.targets)) or (isinstance(n,ast.FunctionDef) and n.name not in ('main','parse_args'))]
exec(compile(ast.Module(body=safe_nodes,type_ignores=[]),'bncal_ast_functions','exec'),module.__dict__)
sys.modules['tools'] = ModuleType('tools')
sys.modules[module.__name__] = module
spec = importlib.util.spec_from_file_location('legacy_bncal_contract',ROOT/'tools/test_cranial_scqr_v12_qa1_bncal_contract.py')
legacy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(legacy)

def rejected(fn):
    try: fn()
    except RuntimeError: return
    raise AssertionError('expected fail-closed rejection')

def fake_api():
    f=NS(enabled=False,warn=True,backends=NS(cuda=NS(matmul=NS(allow_tf32=True)),cudnn=NS(allow_tf32=True,deterministic=False,benchmark=True)))
    def setter(enabled,warn_only=False): f.enabled,f.warn=enabled,warn_only
    f.use_deterministic_algorithms=setter
    f.are_deterministic_algorithms_enabled=lambda:f.enabled
    f.is_deterministic_algorithms_warn_only_enabled=lambda:f.warn
    return f

def main():
    legacy.test_valid_and_rejections()
    legacy.test_v11_identity_and_output_contract()
    config=NS(cranial_scqr_execution=NS(stage='V12_QA1_bncal',bncal_authorized=True))
    with patch.dict(os.environ,CUBLAS_WORKSPACE_CONFIG=':4096:8'):
        f=fake_api(); module.configure_bncal_numeric_policy(config,f)
        assert f.enabled and not f.warn and not f.backends.cudnn.allow_tf32
        rejected(lambda:module.configure_bncal_numeric_policy(NS(cranial_scqr_execution=NS(stage='L4_bncal',bncal_authorized=True)),f))
        rejected(lambda:module.configure_bncal_numeric_policy(NS(cranial_scqr_execution=NS(stage='V12_QA1_bncal',bncal_authorized=False)),f))
        with patch.dict(os.environ,CUBLAS_WORKSPACE_CONFIG='wrong'):
            rejected(lambda:module.configure_bncal_numeric_policy(config,f))
        broken=fake_api(); broken.use_deterministic_algorithms=lambda *a,**kw:None
        rejected(lambda:module.configure_bncal_numeric_policy(config,broken))
        for mutate in (lambda x:setattr(x,'enabled',False),lambda x:setattr(x,'warn',True),lambda x:setattr(x.backends.cuda.matmul,'allow_tf32',True),lambda x:setattr(x.backends.cudnn,'allow_tf32',True),lambda x:setattr(x.backends.cudnn,'deterministic',False),lambda x:setattr(x.backends.cudnn,'benchmark',True)):
            f=fake_api();module.configure_bncal_numeric_policy(config,f);mutate(f)
            rejected(lambda:module.assert_bncal_numeric_policy(f))
        old=(torch.are_deterministic_algorithms_enabled(),torch.is_deterministic_algorithms_warn_only_enabled(),torch.backends.cuda.matmul.allow_tf32,torch.backends.cudnn.allow_tf32,torch.backends.cudnn.deterministic,torch.backends.cudnn.benchmark)
        class NoCuda:
            def __getattr__(self,name): raise AssertionError('CUDA API prohibited: '+name)
        try:
            with patch.object(torch,'cuda',NoCuda()):
                module.configure_bncal_numeric_policy(config,torch)
                module.assert_bncal_numeric_policy(torch)
                torch.backends.cuda.matmul.allow_tf32=True
                rejected(lambda:module.assert_bncal_numeric_policy(torch))
        finally:
            torch.use_deterministic_algorithms(old[0],warn_only=old[1])
            torch.backends.cuda.matmul.allow_tf32,torch.backends.cudnn.allow_tf32=old[2:4]
            torch.backends.cudnn.deterministic,torch.backends.cudnn.benchmark=old[4:6]
    valid={'resource_binding':{'deterministic_algorithms':True,'tf32':False,'cublas_workspace_config':':4096:8'}}
    module.validate_bncal_numeric_request(valid)
    for key,value in (('deterministic_algorithms',False),('tf32',True),('cublas_workspace_config','wrong')):
        bad=copy.deepcopy(valid);bad['resource_binding'][key]=value
        rejected(lambda:module.validate_bncal_numeric_request(bad))
    rejected(lambda:module.validate_bncal_numeric_request({}))
    main_node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
    calls=[(n.lineno,ast.unparse(n.func)) for n in ast.walk(main_node) if isinstance(n,ast.Call)]
    line=min(i for i,name in calls if name=='configure_bncal_numeric_policy')
    assert line < min(i for i,name in calls if name in ('torch.cuda.manual_seed_all','PartialOnlyDataset','builder.model_builder'))
    loop=next(n for n in ast.walk(main_node) if isinstance(n,ast.For) and isinstance(n.iter,ast.Call) and ast.unparse(n.iter.func)=='tqdm')
    assert isinstance(loop.body[0],ast.Expr) and ast.unparse(loop.body[0].value.func)=='assert_bncal_numeric_policy'
    assert '"numerical_policy_at_completion": numerical_policy_at_completion' in source
    assert 'with torch.inference_mode()' in source and 'parameter_sha_after != parameter_sha_before' in source
    print(json.dumps({'status':'PASS','test_groups':6,'project_runner_imports':0,'real_dataset_constructions':0,'manifest_files_opened':0,'npz_payload_files_opened':0,'checkpoint_payload_loaded':False,'cuda_calls':0,'model_forward_calls':0,'optimizer_steps':0,'model_parameter_updates':0,'bncal_runs':0,'training_runs':0,'development_evaluations':0},sort_keys=True))

if __name__=='__main__': main()
