"""Standalone CPU/text regression suite; no project package or CUDA imports."""
from __future__ import annotations

import ast
import copy
import importlib.util
import json
import os
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace as NS, ModuleType
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


sys.modules["tools"] = ModuleType("tools")
audit = load("tools.cranial_scqr_v12_qa1_training_audit", ROOT / "tools/cranial_scqr_v12_qa1_training_audit.py")
legacy = load("qa1_contract", ROOT / "tools/test_cranial_scqr_v12_qa1_training_contract.py")


def rejected(fn):
    try:
        fn()
    except RuntimeError:
        return
    raise AssertionError("required fail-closed rejection was absent")


def fake_torch():
    fake = NS(enabled=False, warn_only=True, backends=NS(
        cuda=NS(matmul=NS(allow_tf32=True)),
        cudnn=NS(allow_tf32=True, deterministic=False, benchmark=True)))
    def setter(enabled, warn_only=False):
        fake.enabled, fake.warn_only = enabled, warn_only
    fake.use_deterministic_algorithms = setter
    fake.are_deterministic_algorithms_enabled = lambda: fake.enabled
    fake.is_deterministic_algorithms_warn_only_enabled = lambda: fake.warn_only
    return fake


def test_policy_and_rejections():
    args = NS(deterministic=True)
    config = NS(cranial_scqr_execution=NS(stage=audit.STAGE, training_authorized=True))
    with patch.dict(os.environ, {"CUBLAS_WORKSPACE_CONFIG": ":4096:8"}):
        fake = fake_torch()
        policy = audit.configure_v12_qa1_numeric_policy(args, config, fake)
        assert policy["deterministic_algorithms"] is True
        assert policy["cuda_matmul_allow_tf32"] is False
        for stage in ("L4_roundA_training", "other"):
            untouched = fake_torch()
            before = copy.deepcopy(untouched.backends)
            assert audit.configure_v12_qa1_numeric_policy(NS(), NS(cranial_scqr_execution=NS(stage=stage)), untouched) is None
            assert untouched.backends == before and untouched.enabled is False
        assert audit.configure_v12_qa1_numeric_policy(NS(), NS(), fake) is None
        rejected(lambda: audit.configure_v12_qa1_numeric_policy(NS(deterministic=False), config, fake))
        rejected(lambda: audit.configure_v12_qa1_numeric_policy(args, NS(cranial_scqr_execution=NS(stage=audit.STAGE, training_authorized=False)), fake))
        with patch.dict(os.environ, {"CUBLAS_WORKSPACE_CONFIG": "wrong"}):
            rejected(lambda: audit.configure_v12_qa1_numeric_policy(args, config, fake))
        broken = fake_torch()
        broken.use_deterministic_algorithms = lambda *a, **kw: None
        rejected(lambda: audit.configure_v12_qa1_numeric_policy(args, config, broken))
        mutations = [lambda f: setattr(f, "enabled", False), lambda f: setattr(f, "warn_only", True),
                     lambda f: setattr(f.backends.cuda.matmul, "allow_tf32", True),
                     lambda f: setattr(f.backends.cudnn, "allow_tf32", True),
                     lambda f: setattr(f.backends.cudnn, "deterministic", False),
                     lambda f: setattr(f.backends.cudnn, "benchmark", True)]
        for mutate in mutations:
            fake = fake_torch()
            audit.configure_v12_qa1_numeric_policy(args, config, fake)
            mutate(fake)
            rejected(lambda: audit.assert_v12_qa1_numeric_policy(fake))
            instance = object.__new__(audit.ScqrV12QA1TrainingAudit)
            instance.enabled, instance.steps = True, 0
            with patch.object(audit, "assert_v12_qa1_numeric_policy", lambda: audit.assert_policy_for_test(fake)):
                # Save the real checker separately so the patch cannot mask drift.
                rejected(instance.authorize_next_step)
            assert instance.steps == 0


audit.assert_policy_for_test = audit.assert_v12_qa1_numeric_policy


def test_request_binding():
    for key, bad_value in (("deterministic_algorithms", False), ("tf32", True), ("cublas_workspace_config", "wrong")):
        with tempfile.TemporaryDirectory(prefix="qa1_numeric_fixture_") as temporary:
            root = Path(temporary)
            args, config, loader = legacy.build_fixture(root)
            request_path = root / "training_request.json"
            request = json.loads(request_path.read_text())
            request["resource_binding"][key] = bad_value
            config.cranial_scqr_execution.training_request_sha256 = legacy.write_json(request_path, request)
            rejected(lambda: audit.validate_v12_qa1_training_contract(args, config, loader))


def test_runner_order_and_no_v11_change():
    path = ROOT / "tools/runner.py"
    tree = ast.parse(path.read_text())
    run = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "run_net")
    calls = [(n.lineno, ast.unparse(n.func)) for n in ast.walk(run) if isinstance(n, ast.Call)]
    numeric = min(line for line, name in calls if name == "configure_v12_qa1_numeric_policy")
    assert numeric < min(line for line, name in calls if name in ("builder.dataset_builder", "builder.model_builder"))
    legacy.test_runner_dispatch_and_v11_identity()


def test_real_torch_cpu_flags():
    import torch
    old = (torch.are_deterministic_algorithms_enabled(), torch.is_deterministic_algorithms_warn_only_enabled(),
           torch.backends.cuda.matmul.allow_tf32, torch.backends.cudnn.allow_tf32,
           torch.backends.cudnn.deterministic, torch.backends.cudnn.benchmark)
    # A tripwire forbids every cuda API access; backend flag access is not a CUDA call.
    class NoCuda:
        def __getattr__(self, name):
            raise AssertionError(f"CUDA API prohibited in CPU tests: {name}")
    try:
        with patch.object(torch, "cuda", NoCuda()), patch.dict(os.environ, {"CUBLAS_WORKSPACE_CONFIG": ":4096:8"}):
            config = NS(cranial_scqr_execution=NS(stage=audit.STAGE, training_authorized=True))
            audit.configure_v12_qa1_numeric_policy(NS(deterministic=True), config, torch)
            audit.assert_v12_qa1_numeric_policy(torch)
            instance = object.__new__(audit.ScqrV12QA1TrainingAudit)
            instance.enabled, instance.steps = True, 3938
            instance.authorize_next_step()
            instance.record_completed_step()
            rejected(instance.authorize_next_step)
            torch.backends.cudnn.allow_tf32 = True
            instance.steps = 0
            rejected(instance.authorize_next_step)
            assert instance.steps == 0
    finally:
        torch.use_deterministic_algorithms(old[0], warn_only=old[1])
        torch.backends.cuda.matmul.allow_tf32, torch.backends.cudnn.allow_tf32 = old[2:4]
        torch.backends.cudnn.deterministic, torch.backends.cudnn.benchmark = old[4:6]


def main():
    legacy.test_valid_and_rejections()
    legacy.test_step_cap()
    test_policy_and_rejections()
    test_request_binding()
    test_runner_order_and_no_v11_change()
    test_real_torch_cpu_flags()
    print(json.dumps({"status": "PASS", "test_groups": 6, "real_dataset_constructions": 0,
                      "npz_payload_files_opened": 0, "checkpoint_files_opened": 0, "cuda_calls": 0,
                      "optimizer_steps": 0, "training_runs": 0, "bncal_runs": 0,
                      "development_evaluations": 0}, sort_keys=True))


if __name__ == "__main__":
    main()
