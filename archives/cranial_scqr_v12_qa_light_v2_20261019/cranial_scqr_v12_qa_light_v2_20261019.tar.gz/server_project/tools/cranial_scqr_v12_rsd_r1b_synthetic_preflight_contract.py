"""Synthetic preflight guards. Importing this module never imports torch/models."""

import hashlib
import json
import math
import os
import re
import socket
from pathlib import Path

PROTOCOL_SHA = '923254dab787341728af9a22031b482f55a45ebd6c2bc62cfcb427511c61456b'
V1_SHA = 'd968143ce8ce39daedc398b85419300a48425c63a3203ad75604bc5f1ba16ffd'
ROOT = Path('/home/jovyan/adapointr_work/PoinTr')
ENV_ROOT = Path('/opt/conda/envs/adapointr-mamba')
TOOL_NAMES = (
    'tools/run_cranial_scqr_v12_rsd_r1b_synthetic_gpu_preflight.py',
    'tools/cranial_scqr_v12_rsd_r1b_synthetic_preflight_contract.py',
    'tools/test_cranial_scqr_v12_rsd_r1b_synthetic_preflight_contract.py',
)
SCALARS = ('alpha_q', 'query_warmup', 'query_rms', 'potential_residual_rms',
           'applied_residual_rms', 'relative_potential_residual_rms',
           'attention_entropy_mean', 'effective_proxy_count_mean', 'attention_max_weight_mean')
IMMUTABLE_FIELDS = ('synthetic_input_contract', 'model_initialization_contract', 'rng_contract',
                    'standalone_outlet_contract', 'full_forward_order', 'success_exact_counts',
                    'numerical_policy', 'equality_contract', 'state_contract', 'permissions',
                    'interpretation_limits', 'future_output_contract', 'acyclic_materialization_contract',
                    'implementation_sha256', 'model_structure_sources', 'parent_query_off_protocol_sha256',
                    'post_implementation_p3', 'formal_gate_status', 'formal_classification')


class ContractError(RuntimeError):
    pass


def require(ok, message):
    if not ok:
        raise ContractError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def sha_string(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def under(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except ValueError:
        return False


def bound(root, binding):
    relative = Path(binding['path'])
    require(not relative.is_absolute() and '..' not in relative.parts and '\\' not in str(relative), 'unsafe binding')
    path = (Path(root) / relative).resolve()
    require(not set(path.parts) & {'.codex', '.ssh', '.aws', 'secrets', 'credentials'} and path.name != 'auth.json' and
            path.suffix.lower() not in ('.npz', '.stl', '.pth', '.pt', '.pkl', '.pickle', '.csv', '.jsonl'),
            'payload/secret binding denied before byte access')
    require(under(path, root) and path.is_file(), 'missing/escaped binding')
    # Historical parent P3 has a hash-only binding; new bindings freeze bytes.
    if 'bytes' in binding:
        require(type(binding['bytes']) is int and binding['bytes'] > 0 and path.stat().st_size == binding['bytes'], 'binding bytes drift')
    require(sha_string(binding['sha256']) and digest(path) == binding['sha256'], 'binding hash drift')
    return path


def strict_json(path):
    def pairs(items):
        out = {}
        for key, value in items:
            require(key not in out, 'duplicate JSON key')
            out[key] = value
        return out
    def bad_number(value):
        raise ContractError('nonfinite JSON constant: ' + value)
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=pairs, parse_constant=bad_number)


def validate_request(request, original):
    require(request.get('request_schema_version') == 'cranial-scqr-v1.2-RSD-R1B-synthetic-gpu-preflight-request-v2', 'v2 schema only; v1 cannot execute')
    require(request.get('status') == 'AWAITING_EXPLICIT_USER_AUTHORIZATION' and request.get('execution_authorized') is False,
            'request must not self-authorize')
    require(request.get('execution_ready') is True and request.get('direct_execution_allowed') is False,
            'ready request still requires separate hash authorization')
    require(request.get('implementation_authorized') is False, 'execution request grants no implementation')
    require(request.get('protocol_binding', {}).get('sha256') == PROTOCOL_SHA, 'protocol binding')
    require(request.get('parent_request_v1', {}).get('sha256') == V1_SHA, 'immutable v1 parent binding')
    for name in IMMUTABLE_FIELDS:
        require(request.get(name) == original.get(name), 'frozen v1 semantics drift: ' + name)
    require(all(value is False for value in request['permissions'].values()), 'forbidden permissions')
    require(all(type(v) is int for v in request['success_exact_counts'].values()), 'integer budgets only')
    bindings = request.get('preflight_implementation_bindings', [])
    by_path = {b.get('path'): b for b in bindings}
    require(set(by_path) == set(TOOL_NAMES) and len(bindings) == 3, 'exactly three preflight tools')
    for b in bindings:
        require(sha_string(b.get('sha256')) and type(b.get('bytes')) is int and b['bytes'] > 0, 'final tool hash missing')
    for name in ('preflight_implementation_p3_binding', 'dependency_inventory_binding', 'input_identity_binding'):
        b = request.get(name, {})
        require(sha_string(b.get('sha256')) and type(b.get('bytes')) is int and b['bytes'] > 0, 'missing final binding: ' + name)
    require(request.get('missing_preconditions') == [], 'unresolved implementation prerequisites')
    env = request.get('environment_runtime_contract', {})
    require(type(env.get('cudnn_version')) is int and env['cudnn_version'] > 0 and env.get('cuda_version') == '11.8', 'runtime versions not frozen')
    resource = request.get('resource_binding', {})
    require(resource.get('hostname') == socket.gethostname(), 'hostname drift')
    for name in ('gpu_uuid', 'gpu_name', 'driver_version', 'python_binary_sha256', 'python_version'):
        require(resource.get(name) == original['resource_binding'].get(name), 'resource rebind required: ' + name)
    for name in ('minimum_free_gpu_memory_mib_at_launch', 'minimum_free_disk_bytes_at_launch',
                 'maximum_peak_allocated_mib', 'maximum_peak_reserved_mib', 'maximum_walltime_seconds'):
        require(resource.get(name) == original['resource_binding'].get(name), 'resource budget drift')
    future = request.get('fixed_future_execution', {})
    require(future.get('run_id') == 'r1b_synthetic_gpu_pf_v2_20261011' and
            future.get('tmux_session') == 'r1b-synthetic-gpu-pf-v2-20261011', 'unique v2 run/session')
    prefix = 'logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_v2_20261011/'
    suffixes = {'output_relative': 'result', 'control_relative': 'control',
                'authorization_receipt_relative': 'control/authorization_receipt_v2.json',
                'runtime_relative': 'control/runtime_v2.json', 'launcher_relative': 'control/launcher_once_v2.sh',
                'log_relative': 'control/master.log', 'pid_relative': 'control/pid.txt', 'exit_code_relative': 'control/exit_code.txt'}
    for key, value in suffixes.items():
        require(future.get(key) == prefix + value, 'frozen v2 path: ' + key)


def validate_chain(request, original, auth, runtime, request_sha, auth_sha):
    validate_request(request, original)
    require(auth == {'status': 'AUTHORIZED_ONCE_SYNTHETIC_GPU_PREFLIGHT', 'execution_authorized': True,
                     'request_id': request['request_id'], 'request_sha256': request_sha,
                     'run_id': request['fixed_future_execution']['run_id'], 'permissions': request['permissions']},
            'exact authorization receipt required; no reverse runtime binding')
    require(runtime == {'stage': 'V12_RSD_R1B_SYNTHETIC_GPU_PREFLIGHT', 'request_sha256': request_sha,
                        'authorization_receipt_sha256': auth_sha,
                        'run_id': request['fixed_future_execution']['run_id'], 'runs_authorized': 1},
            'single-way runtime chain')


class Ledger:
    """One-way attempt ledger; any violation permanently poisons the execution."""
    def __init__(self, expected):
        self.expected = dict(expected)
        self.counts = {key: 0 for key in expected}
        self.failed = False
        self.pending = None

    def check(self, ok, message):
        if self.failed or not ok:
            self.failed = True
            raise ContractError(message)

    def add(self, key):
        self.check(key in self.counts and self.counts[key] < self.expected[key], 'counter limit: ' + key)
        self.counts[key] += 1

    def begin(self, index, item):
        self.check(self.pending is None and index == self.counts['full_model_forward_attempts'] + 1,
                   'forward order/pending failure')
        self.add('full_model_forward_attempts')
        self.add('ls_full_forwards' if item['model'] == 'LS' else 'lsq_full_forwards')
        self.pending = index

    def end(self):
        self.check(self.pending is not None, 'completion without attempt')
        self.add('full_model_forward_completions')
        self.pending = None

    def finish(self):
        self.check(self.pending is None and self.counts == self.expected, 'incomplete/over-budget preflight')


def assert_scalars(values, *, off=False):
    require(set(values) == set(SCALARS) | {'query_applicable', 'query_outlet_calls'}, 'diagnostic schema')
    require(values['query_applicable'] is True and type(values['query_outlet_calls']) is int and values['query_outlet_calls'] == 1,
            'outlet count/applicability')
    require(all(type(values[k]) in (int, float) and math.isfinite(values[k]) for k in SCALARS), 'nonfinite scalar')
    require(values['query_warmup'] == 1.0 and values['applied_residual_rms'] ==
            (0.0 if off else values['potential_residual_rms']), 'residual/warmup contract')


class FileBoundary:
    """Process audit-hook boundary: code/bound text reads, owned output writes only.

    Dependencies are explicit frozen code/binary files, not arbitrary files in
    the environment. No pickle/NPZ/STL reads, dataset directories, subprocesses
    or network are admitted after the hook is installed.
    """
    def __init__(self, read_files, output):
        self.read_files = {str(Path(p).resolve()) for p in read_files}
        self.output = Path(output).resolve()

    def check_open(self, file, mode=None, flags=0):
        require(not isinstance(file, int), 'untracked file-descriptor open denied')
        path = Path(os.fsdecode(file)).resolve()
        require(path.suffix.lower() not in ('.npz', '.stl', '.pth', '.pt', '.pkl', '.pickle', '.csv', '.jsonl'),
                'real payload/checkpoint/CSV access denied')
        writing = any(c in (mode or '') for c in 'wax+') or bool((flags or 0) & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC))
        if writing:
            require(under(path, self.output) and path != self.output, 'write outside owned output denied')
        else:
            require(str(path) in self.read_files or under(path, self.output), 'unbound read denied: ' + str(path))

    def __call__(self, event, args):
        if event == 'open':
            self.check_open(*args)
        elif event.startswith('socket.') or event == 'subprocess.Popen' or event.startswith('os.exec') or event in ('os.system', 'os.fork', 'os.posix_spawn'):
            raise ContractError('network/subprocess forbidden during synthetic execution')
        elif event in ('os.remove', 'os.rmdir', 'os.rename', 'os.chmod', 'os.chown', 'os.link', 'os.symlink'):
            raise ContractError('destructive filesystem action forbidden')
        elif event == 'os.mkdir':
            require(under(args[0], self.output) and Path(args[0]).resolve() != self.output, 'mkdir outside owned output denied')
