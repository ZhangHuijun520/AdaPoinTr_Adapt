"""Synthetic CPU-only contract tests; never accesses experiment metrics."""
import copy
import unittest
from unittest.mock import patch

import numpy as np
import analyze_cranial_scqr_v12_qa1 as tool


def fixture():
    rows, allow = [], {}
    for fold in ('C', 'D'):
        allow[fold] = []
        for n in range(21):
            for defect in sorted(tool.DEFECTS):
                case = f'{fold}{n:03}_{defect}'
                allow[fold].append(case)
                for c in ('B0', 'LS', 'LSQ'):
                    rows.append(dict(run_key=f'{c}_fold{fold}_seed0', candidate=c,
                                     fold=fold, seed='0', case_id=case,
                                     source_skull_id=f'{fold}{n:03}', defect_type=defect,
                                     disaster='0', zero_contact_2mm='0',
                                     **{m: 10.0 + n + (0.25 if c == 'LSQ' else 0)
                                        for m in tool.METRICS}))
    # CSVs are candidate partitions in frozen allowlist order.
    rows.sort(key=lambda r: (r['run_key'], allow[r['fold']].index(r['case_id'])))
    return rows, allow


class Tests(unittest.TestCase):
    def setUp(self):
        self.rows, self.allow = fixture()

    def test_valid_630_cases_42_deltas(self):
        d = tool.primary_deltas(self.rows, self.allow)
        self.assertEqual(len(d), 42)
        self.assertTrue(all(r[tool.PRIMARY] == .25 for r in d))

    def test_constant_bootstrap(self):
        d = tool.primary_deltas(self.rows, self.allow)
        b = tool.bootstrap(d, tool.PRIMARY)
        self.assertEqual((b['pooled'], b['ci95_low'], b['ci95_high']), (.25, .25, .25))

    def test_inherited_rng_reference(self):
        d = tool.primary_deltas(self.rows, self.allow)
        for i, row in enumerate(d):
            row[tool.PRIMARY] = float(i)
        rng = np.random.default_rng(20260910)
        draws = []
        for _ in range(10):
            a = np.arange(21.)[rng.integers(0, 21, (1000, 21))].mean(1)
            b = np.arange(21., 42.)[rng.integers(0, 21, (1000, 21))].mean(1)
            draws.extend(.5 * (a + b))
        expected = np.percentile(draws, [2.5, 97.5], method='linear')
        actual = tool.bootstrap(d, tool.PRIMARY)
        np.testing.assert_array_equal(expected, [actual['ci95_low'], actual['ci95_high']])

    def test_sort_invariance(self):
        d = tool.primary_deltas(self.rows, self.allow)
        self.assertEqual(tool.bootstrap(d, tool.PRIMARY),
                         tool.bootstrap(list(reversed(d)), tool.PRIMARY))

    def test_frozen_rng_parameters(self):
        d = tool.primary_deltas(self.rows, self.allow)
        for kw in ({'seed': 1}, {'samples': 2}):
            with self.assertRaises(tool.ContractError):
                tool.bootstrap(d, tool.PRIMARY, **kw)

    def test_missing_duplicate_nonfinite_identity(self):
        mutations = [lambda r: r.pop(), lambda r: r.append(copy.deepcopy(r[0])),
                     lambda r: r[0].update({tool.PRIMARY: float('nan')}),
                     lambda r: r[0].update(seed='1'),
                     lambda r: r[0].update(disaster='2'),
                     lambda r: r[0].update(defect_type='unknown'),
                     lambda r: r[0].update(source_skull_id='wrong')]
        for mutate in mutations:
            rows = copy.deepcopy(self.rows)
            mutate(rows)
            with self.subTest(mutate=mutate), self.assertRaises(tool.ContractError):
                tool.validate(rows, self.allow)

    def test_allowlist_order(self):
        allow = copy.deepcopy(self.allow)
        allow['C'].reverse()
        with self.assertRaises(tool.ContractError):
            tool.validate(self.rows, allow)

    def test_no_secondary_or_gate_even_for_large_gain(self):
        for row in self.rows:
            if row['candidate'] == 'LSQ':
                row.update({m: -100. for m in tool.METRICS})
        result, _ = tool.analyze(self.rows, self.allow)
        self.assertEqual(result['formal_gate_status'], tool.LOCK)
        self.assertIsNone(result['formal_classification'])
        self.assertFalse(result['gate_checks_computed'])
        self.assertFalse(result['secondary_comparison_computed'])
        self.assertFalse(result['automatic_next_stage'])

    def test_no_payload_framework_dependencies(self):
        import ast
        from pathlib import Path
        tree = ast.parse(Path(tool.__file__).read_text())
        imports = [n.module for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)]
        imports += [a.name for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names]
        self.assertFalse(any(x and x.split('.')[0] in ('torch', 'pickle', 'zipfile')
                             for x in imports))

    def test_authorization_fail_before_bound_reads(self):
        from pathlib import Path
        q = {'status': 'AWAITING_EXPLICIT_USER_AUTHORIZATION', 'execution_authorized': False,
             'scope': 'CPU_DESCRIPTIVE_LSQ_MINUS_LS_ONLY',
             'supplement': {'sha256': tool.SUPPLEMENT_SHA}, 'formal_gate_authorized': False,
             'secondary_comparison_authorized': False, 'run_id': 'synthetic'}
        with patch.object(tool, 'bound', side_effect=AssertionError('must not read')):
            with self.assertRaises(tool.ContractError):
                tool.verify_request(Path('.'), q, {'status': 'NOT_AUTHORIZED'}, 'hash')


if __name__ == '__main__':
    unittest.main(verbosity=2)
