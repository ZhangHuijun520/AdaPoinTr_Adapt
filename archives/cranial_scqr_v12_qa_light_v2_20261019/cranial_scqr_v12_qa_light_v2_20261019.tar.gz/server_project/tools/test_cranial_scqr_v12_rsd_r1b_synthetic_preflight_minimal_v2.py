"""One bounded stdlib/artificial CPU suite: no torch, WSL, server or GPU.

POSIX path/torch doubles validate contracts, not kernel or OS enforcement.
Scientific function ASTs must equal the frozen finite-v5 parent exactly.
"""
import ast
import contextlib
import io
import tempfile
import copy
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path, PurePosixPath
import struct
import sys
from types import SimpleNamespace as NS
import unittest
from unittest.mock import patch, mock_open

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[2]
sys.path.insert(0, str(HERE))
import cranial_scqr_v12_rsd_r1b_synthetic_preflight_contract_minimal_v2 as c
import run_cranial_scqr_v12_rsd_r1b_synthetic_gpu_preflight_minimal_v2 as run
DOC = WORK / 'docs/cranial_scqr_v12_qa_research_2026_10_11'
ORIGINAL = json.loads((DOC / 'v12_rsd_r1b_synthetic_gpu_zero_update_preflight_execution_request_v1.json').read_text(encoding='utf-8'))
PARENT = WORK / 'server_overlays/r1b_finite_dependencies_v10_20261014/tools/run_cranial_scqr_v12_rsd_r1b_synthetic_gpu_preflight_finite_v5.py'
PROOT = '/home/jovyan/adapointr_work/PoinTr'
LINKS = set()


class Posix(PurePosixPath):
    def is_symlink(self): return str(self) in LINKS
    def resolve(self): return self
    def absolute(self): return self


def fixture():
    q = copy.deepcopy(ORIGINAL)
    q.update(schema='r1b-synthetic-preflight-minimal-request-v2', execution_ready=True,
             parent_request_v1={'sha256': c.V1_SHA}, missing_preconditions=[],
             provider_relative=str(c.PROVIDER.relative_to(c.ROOT)), provider_native_sha256=c.NATIVE_SHA,
             dependency_policy=copy.deepcopy(c.DEPENDENCY_POLICY),
             preflight_implementation_bindings=[{'path': n, 'sha256': 'a'*64, 'bytes': 1} for n in c.TOOL_NAMES],
             environment_runtime_contract={'torch_version': '2.4.1+cu118', 'numpy_version': '2.2.6',
                                           'cuda_version': '11.8', 'cudnn_version': 90100})
    q['resource_binding'].update(hostname=c.HOST, gpu_uuid=c.GPU_UUID)
    q['fixed_future_execution'] = dict(run_id=c.RUN, tmux_session='r1b-synthetic-gpu-pf-minimal-v2-20261018')
    for k, v in {'output_relative': 'result', 'control_relative': 'control',
                 'authorization_receipt_relative': 'control/authorization.json', 'runtime_relative': 'control/runtime.json',
                 'launcher_relative': 'control/launcher_once.sh', 'log_relative': 'control/master.log',
                 'pid_relative': 'control/pid.txt', 'exit_code_relative': 'control/exit_code.txt',
                 'started_relative': 'control/started.json'}.items():
        q['fixed_future_execution'][k] = c.PREFIX + v
    return q


class Tensor:
    dtype = 'float32'
    device = 'cpu'
    def __init__(self, value=0., shape=(1,)): self.value, self.shape = value, shape
    def clone(self): return Tensor(self.value, self.shape)
    def detach(self): return self
    def cpu(self): return self
    def numpy(self): return self
    def tobytes(self): return struct.pack('<d', self.value)
    def abs(self): return Tensor(abs(self.value), self.shape)
    def max(self): return self
    def item(self): return self.value
    def __sub__(self, other): return Tensor(self.value-other.value, self.shape)


class Torch:
    float32 = 'float32'
    random = NS(get_rng_state=lambda: Tensor(4.0), set_rng_state=lambda x: None)
    no_grad = staticmethod(contextlib.nullcontext)
    equal = staticmethod(lambda a, b: a.shape == b.shape and a.dtype == b.dtype and a.value == b.value)
    isfinite = staticmethod(lambda x: NS(all=lambda: math.isfinite(x.value)))


NP = NS(random=NS(get_state=lambda: ('fixture', Tensor(2.), 1, 0, 0.), set_state=lambda x: None))


def tensor_hash(mapping):
    return hashlib.sha256(json.dumps({k: [v.value, v.shape, v.dtype] for k, v in sorted(mapping.items())}).encode()).hexdigest()


class Conditioner:
    def __init__(self): self.hooks = []
    def register_forward_hook(self, fn):
        self.hooks.append(fn)
        return NS(remove=lambda: self.hooks.remove(fn))
    def __call__(self, x):
        for fn in self.hooks: fn(self, (x,), x)


class Model:
    training = False
    def __init__(self, candidate, *, mutate=False, drift=False):
        self.candidate, self.mutate, self.drift = candidate, mutate, drift
        self.base_model = NS(scqr_query_conditioner=Conditioner() if candidate == 'LSQ' else None)
        self.buffer = Tensor(0.)
    def modules(self): return [self]
    def named_parameters(self): return []
    def named_buffers(self): return [('buffer', self.buffer)]
    def state_dict(self): return dict(self.named_buffers())
    def __call__(self, x, epoch=None, rsd_condition=None, rsd_diagnostics=None):
        assert epoch is None
        if self.base_model.scqr_query_conditioner: self.base_model.scqr_query_conditioner(x)
        if self.mutate: self.buffer.value += 1
        if rsd_diagnostics is not None:
            if self.candidate == 'LS': rsd_diagnostics.update(query_applicable=False, query_outlet_calls=0)
            else:
                rsd_diagnostics.update({k: 1.0 for k in c.SCALARS})
                rsd_diagnostics.update(query_applicable=True, query_outlet_calls=1)
                if rsd_condition == 'LSQ_query_off': rsd_diagnostics['applied_residual_rms'] = 0.0
        value = .25 if rsd_condition == 'LSQ_query_off' else 0.
        if self.drift and rsd_diagnostics is not None: value += .5
        return Tensor(0., (1, 256, 3)), Tensor(value, (1, 8192, 3))


class Contracts(unittest.TestCase):
    def setUp(self):
        self.ctx = contextlib.ExitStack(); self.addCleanup(self.ctx.close)
        for name, value in [('Path', Posix), ('ROOT', Posix(PROOT)),
                            ('PROVIDER', Posix(PROOT+'/third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider'))]:
            self.ctx.enter_context(patch.object(c, name, value))
        LINKS.clear()
        self.q = fixture()
        self.boundary = c.FileBoundary([PROOT+'/models/AdaPoinTr.py'], Posix(PROOT+'/'+c.PREFIX+'result'))

    def reject(self, fn, *args, **kwargs):
        with self.assertRaises(c.ContractError): fn(*args, **kwargs)

    def test_01_import_inert(self):
        for name in ('torch', 'numpy', 'models', 'finite_dependencies_v10'):
            self.assertNotIn(name, sys.modules)

    def test_02_scientific_AST_unchanged(self):
        old = ast.parse(PARENT.read_text(encoding='utf-8'))
        new = ast.parse((HERE/c.TOOL_NAMES[0].split('/')[-1]).read_text(encoding='utf-8'))
        functions = lambda tree: {n.name: ast.dump(n, include_attributes=False) for n in tree.body if isinstance(n, ast.FunctionDef)}
        a, b = functions(old), functions(new)
        unchanged = sorted(set(a)-{'text_preconditions', 'authorized_run'})
        self.assertGreaterEqual(len(unchanged), 16)
        for name in unchanged: self.assertEqual(a[name], b[name], name)

    def test_03_parent_hash(self):
        raw = (DOC/'v12_rsd_r1b_synthetic_gpu_zero_update_preflight_execution_request_v1.json').read_bytes()
        self.assertEqual(hashlib.sha256(raw).hexdigest(), c.V1_SHA)

    def test_04_valid_request(self): c.validate_request(self.q, ORIGINAL)

    def test_05_immutable_semantics(self):
        for field in c.IMMUTABLE_FIELDS:
            q = copy.deepcopy(self.q)
            q[field] = {'__fixture_mutation__': field} if ORIGINAL[field] is None else None
            self.assertNotEqual(q[field], ORIGINAL[field], field)
            self.reject(c.validate_request, q, ORIGINAL)

    def test_06_authority_not_self_granted(self):
        for k in ('execution_authorized', 'implementation_authorized', 'direct_execution_allowed'):
            q = copy.deepcopy(self.q); q[k] = True
            self.reject(c.validate_request, q, ORIGINAL)

    def test_07_host_gpu_provider_drift(self):
        for k in ('hostname', 'gpu_uuid'):
            q = copy.deepcopy(self.q); q['resource_binding'][k] = 'other'
            self.reject(c.validate_request, q, ORIGINAL)
        q = copy.deepcopy(self.q); q['provider_native_sha256'] = 'b'*64
        self.reject(c.validate_request, q, ORIGINAL)

    def test_08_budgets_and_paths(self):
        for k in ('maximum_walltime_seconds', 'maximum_peak_allocated_mib', 'minimum_free_gpu_memory_mib_at_launch'):
            q = copy.deepcopy(self.q); q['resource_binding'][k] += 1
            self.reject(c.validate_request, q, ORIGINAL)
        q = copy.deepcopy(self.q); q['fixed_future_execution']['runtime_relative'] = 'old/runtime.json'
        self.reject(c.validate_request, q, ORIGINAL)

    def test_09_acyclic_authority_chain(self):
        auth = dict(status='AUTHORIZED_ONCE_SYNTHETIC_MINIMAL_PREFLIGHT_V2', request_sha256='a'*64,
                    run_id=c.RUN, execution_authorized=True, permissions=self.q['permissions'])
        rt = dict(stage='R1B_SYNTHETIC_MINIMAL_PREFLIGHT_V2', request_sha256='a'*64,
                  authorization_receipt_sha256='b'*64, run_id=c.RUN)
        c.validate_chain(self.q, ORIGINAL, auth, rt, 'a'*64, 'b'*64)
        auth['runtime_sha256'] = 'c'*64
        self.reject(c.validate_chain, self.q, ORIGINAL, auth, rt, 'a'*64, 'b'*64)

    def test_10_payload_and_checkpoint_preopen(self):
        for suffix in c.DENIED_SUFFIXES:
            self.reject(self.boundary.check_open, '/opt/conda/envs/adapointr-mamba/lib/python3.10/site-packages/pkg/data/item'+suffix)

    def test_11_secret_denied(self):
        for p in ('/home/jovyan/.ssh/key.py', '/home/jovyan/.codex/auth.json', '/tmp/.env'):
            self.reject(self.boundary.check_open, p)

    def test_12_project_data_vs_dependency_data(self):
        self.reject(self.boundary.check_open, PROOT+'/datasets/data/code.py')
        self.boundary.check_open('/opt/conda/envs/adapointr-mamba/lib/python3.10/site-packages/timm/data/code.py')

    def test_13_unbound_project_source(self): self.reject(self.boundary.check_open, PROOT+'/models/new.py')

    def test_14_links_and_traversal(self):
        LINKS.add(PROOT+'/models')
        self.reject(self.boundary.check_open, PROOT+'/models/AdaPoinTr.py')
        self.reject(self.boundary.check_open, PROOT+'/models/../secrets/config.py')

    def test_15_write_scope(self):
        self.boundary.check_open(str(self.boundary.output/'progress_01.json'), 'x')
        self.reject(self.boundary.check_open, PROOT+'/models/AdaPoinTr.py', 'w')

    def test_16_subprocess_network_destruction(self):
        for event in ('subprocess.Popen', 'socket.connect', 'os.exec', 'os.fork', 'os.remove', 'os.symlink'):
            self.reject(self.boundary, event, ())

    def test_17_dependency_resources_not_arbitrary_data(self):
        root = c.DEPENDENCY_POLICY['resource_root']
        self.boundary.check_open(root+'/matplotlibrc')
        self.reject(self.boundary.check_open, root+'/anything.npz')
        self.reject(self.boundary.check_open, '/tmp/metadata.json')

    def test_18_fd_and_relative_denied(self):
        self.reject(self.boundary.check_open, 4)
        self.reject(self.boundary.check_open, 'relative.py')

    def test_19_oneway_ledger(self):
        ledger = c.Ledger(ORIGINAL['success_exact_counts'])
        for _ in range(2): ledger.add('model_constructions')
        self.reject(ledger.add, 'model_constructions')
        self.reject(ledger.add, 'real_payload_reads')
        self.assertTrue(ledger.failed)

    def test_20_exact_forward_plan_and_hook_cleanup(self):
        models = {k: Model(k) for k in ('LS', 'LSQ')}
        result, ledger = self.sequence(models)
        self.assertEqual(ledger.counts['full_model_forward_attempts'], 8)
        self.assertEqual(ledger.counts['full_model_forward_completions'], 8)
        self.assertEqual(ledger.counts['full_forward_lsq_conditioner_calls'], 6)
        self.assertEqual(ledger.counts['traced_full_forward_lsq_query_outlet_calls'], 4)
        self.assertEqual(result['full_dense_off_minus_native_max_abs'], .25)
        self.assertEqual(models['LSQ'].base_model.scqr_query_conditioner.hooks, [])

    def sequence(self, models):
        ledger = c.Ledger(ORIGINAL['success_exact_counts'])
        for _ in range(2): ledger.add('model_constructions')
        result = run.run_sequence(models, Tensor(0., (1,8192,3)), Torch, NP, tensor_hash, ledger,
                  ORIGINAL['full_forward_order'], cuda=False, sync=lambda: None, policy=lambda: None,
                  memory=lambda: None, progress=lambda _: None)
        return result, ledger

    def test_21_mutation_stops_first_forward(self):
        models = {k: Model(k, mutate=True) for k in ('LS', 'LSQ')}
        self.reject(self.sequence, models)
        self.assertEqual(models['LS'].buffer.value, 1.)
        self.assertEqual(models['LSQ'].base_model.scqr_query_conditioner.hooks, [])

    def test_22_diagnostic_drift_stops(self):
        self.reject(self.sequence, {k: Model(k, drift=True) for k in ('LS','LSQ')})

    def test_23_compiled_provider_and_fallback(self):
        fn = lambda *x: None
        native = NS(__file__=str(c.PROVIDER/'pointnet2_ops/_ext.cpython-310-x86_64-linux-gnu.so'))
        wrapper = NS(__file__=str(c.PROVIDER/'pointnet2_ops/pointnet2_utils.py'), furthest_point_sample=fn, gather_operation=fn)
        adapter = NS(__file__=PROOT+'/utils/pointnet2_utils.py', furthest_point_sample=fn, gather_operation=fn, using_fallback=lambda: False)
        with patch.object(c, 'digest', return_value=c.NATIVE_SHA):
            c.assert_provider(native, wrapper, adapter)
            adapter.using_fallback = lambda: True
            self.reject(c.assert_provider, native, wrapper, adapter)
            adapter.using_fallback = lambda: False
            adapter.gather_operation = lambda: None
            self.reject(c.assert_provider, native, wrapper, adapter)

    def test_24_exact_tensor_comparison(self):
        x = Tensor(0., (2,)); run.compare_tensor(Torch, x, x.clone(), 'same')
        for y in (Tensor(1., (2,)), Tensor(0., (1,2))): self.reject(run.compare_tensor, Torch, x, y, 'different')

    def test_25_policy_cannot_expand(self):
        self.q['dependency_policy']['code_roots'].append('/home/jovyan')
        self.reject(c.validate_request, self.q, ORIGINAL)

    def test_26_no_inventory_framework(self):
        source = (HERE/c.TOOL_NAMES[0].split('/')[-1]).read_text(encoding='utf-8')
        for token in ('finite.resolve(', 'finite_scope_binding', 'formal_cpu_freeze_binding', 'finite_completion_binding'):
            self.assertNotIn(token, source)

    def test_27_scalar_schema_finite(self):
        d = {k: 1.0 for k in c.SCALARS}; d.update(query_applicable=True, query_outlet_calls=1)
        c.assert_scalars(d)
        d['query_rms'] = float('nan'); self.reject(c.assert_scalars, d)

    def test_28_no_GPU_or_real_model_entry(self):
        self.assertNotIn('torch', sys.modules)
        self.assertNotIn('models', sys.modules)


    def startup_failure(self, where, *, receipt_fails=False):
        writes, secondary, timer = [], [], []
        class Node:
            def __init__(self, text): self.text = text
            def __truediv__(self, name): return Node(self.text + '/' + name)
            def __str__(self): return self.text
            def mkdir(self, **kw):
                if where == 'mkdir' and self.text.endswith('/result'): raise OSError('fixture mkdir error')
            def open(self, *a, **k): return io.BytesIO()
        output = Node(PROOT + '/' + c.PREFIX + 'result')
        cached = NS(name='fontlist-v390.json', read_bytes=lambda: b'fixture cache')
        def write(path, value):
            if str(path).endswith('/started.json') and where == 'marker': raise OSError('fixture marker error')
            if 'error_type' in value and receipt_fails: raise PermissionError('fixture receipt IO error')
            writes.append((str(path), value))
        def digest(_):
            return 'wrong' if where == 'font' else c.DEPENDENCY_POLICY['font_cache_sha256']
        fake_signal = NS(SIGALRM=14, SIGTERM=15, ITIMER_REAL=0, signal=lambda *a: None,
                         setitimer=lambda *a: timer.append(a))
        args = NS(request_sha256='a'*64, authorization_sha256='b'*64, runtime_sha256='c'*64)
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(run, 'text_preconditions', return_value=(self.q, output, [], {})))
            stack.enter_context(patch.object(run, 'write_json', side_effect=write))
            stack.enter_context(patch.object(run, 'Path', return_value=cached))
            stack.enter_context(patch.object(c, 'digest', side_effect=digest))
            stack.enter_context(patch.object(run, 'signal', fake_signal))
            stack.enter_context(patch.object(c, 'FileBoundary', side_effect=OSError('fixture audit error')))
            stack.enter_context(patch.object(sys, 'pycache_prefix', None))
            stack.enter_context(patch.object(sys, 'dont_write_bytecode', True))
            stack.enter_context(patch.dict(os.environ, {}, clear=False))
            stack.enter_context(patch('builtins.print', side_effect=lambda *a, **k: secondary.append(a)))
            with self.assertRaisesRegex(Exception, 'fixture|font cache drift') as ctx:
                run.authorized_run(args)
        return writes, secondary, timer, ctx.exception

    def test_29_startup_marker_and_mkdir_failure_receipts(self):
        for where, phase in (('marker', 'STARTUP_MARKER'), ('mkdir', 'CREATE_OWNED_RESULT')):
            with self.subTest(where=where):
                writes, _, _, _ = self.startup_failure(where)
                path, receipt = writes[-1]
                self.assertTrue(path.endswith('/control/entry_failure.json'))
                self.assertEqual(receipt['phase'], phase)
                self.assertEqual(receipt['counts']['full_model_forward_attempts'], 0)
                self.assertFalse(receipt['automatic_retry'])

    def test_30_font_failure_receipt_and_first_error(self):
        writes, _, _, exc = self.startup_failure('font')
        self.assertTrue(writes[-1][0].endswith('/result/failure_receipt.json'))
        self.assertEqual(writes[-1][1]['phase'], 'FONT_CACHE_PREPARATION')
        self.assertIn('font cache drift', str(exc))
        _, secondary, _, exc = self.startup_failure('font', receipt_fails=True)
        self.assertIn('font cache drift', str(exc))
        self.assertIn('SYNTHETIC_FAILURE_RECEIPT_IO', str(secondary))

    def test_31_audit_install_failure_cancels_timer(self):
        writes, _, timer, _ = self.startup_failure('audit')
        self.assertEqual(writes[-1][1]['phase'], 'AUDIT_HOOK_INSTALLATION')
        self.assertEqual(timer[-1], (0, 0))
        self.assertNotIn('torch', sys.modules)

    def test_32_nested_manifest_size_hash_and_tampering(self):
        # Isolated artificial files only; never production paths.
        with tempfile.TemporaryDirectory(prefix='r1b-entry-v2-artificial-') as tmp:
            root = Path(tmp); (root/'mplconfig').mkdir()
            (root/'invocation.json').write_bytes(b'{}')
            font = root/'mplconfig/fontlist-v390.json'; font.write_bytes(b'artificial cache')
            real_digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
            with patch.object(c, 'safe_path', side_effect=lambda p: p), patch.object(c, 'digest', side_effect=real_digest):
                result = run.freeze_result(root)
                rows = (root/'files.sha256').read_text(encoding='utf-8').splitlines()
                self.assertEqual(len(rows), 2)
                self.assertTrue(any(row.endswith('  mplconfig/fontlist-v390.json') for row in rows))
                self.assertEqual(result['bytes_including_manifest'], sum(p.stat().st_size for p in root.rglob('*') if p.is_file()))
                for row in rows:
                    sha, rel = row.split('  ', 1); self.assertEqual(sha, real_digest(root/rel))
                font.write_bytes(b'tampered')
                expected = next(row.split('  ',1)[0] for row in rows if row.endswith('fontlist-v390.json'))
                self.assertNotEqual(expected, real_digest(font))

    def test_33_manifest_unexpected_child_and_nested_size_cap(self):
        with tempfile.TemporaryDirectory(prefix='r1b-entry-v2-artificial-') as tmp:
            root = Path(tmp); (root/'other').mkdir()
            with patch.object(c, 'safe_path', side_effect=lambda p: p):
                self.reject(run.result_files, root)
        # Size includes nested artifacts; fake stat only, no giant file allocation.
        font = NS(stat=lambda: NS(st_size=16*1024**2+1), relative_to=lambda p: Path('mplconfig/fontlist-v390.json'))
        with patch.object(run, 'result_files', return_value=[font]), patch.object(c, 'digest', return_value='a'*64):
            self.reject(run.freeze_result, Path('artificial-not-opened'))

    def test_34_maps_paths_deduplicate_and_deleted(self):
        raw = (b'1000-2000 r-xp 0000 08:01 1 /usr/lib/libexample.so\n'
               b'2000-3000 r--p 0000 08:01 1 /usr/lib/libexample.so\n'
               b'3000-4000 rw-p 0000 00:00 0 [heap]\n'
               b'4000-5000 r-xp 0000 08:01 2 /tmp/fixture.so (deleted)\n')
        observed = c.parse_maps(raw)
        self.assertEqual(observed['mapped_file_paths'], ['/usr/lib/libexample.so'])
        self.assertEqual(observed['deleted_file_paths'], ['/tmp/fixture.so'])
        self.assertEqual(observed['maps_sha256'], hashlib.sha256(raw).hexdigest())
        self.assertTrue(observed['not_complete_ELF_closure'])

    def test_35_maps_limits_and_forbidden_mapping(self):
        row = b'1000-2000 r-xp 0000 08:01 1 /usr/lib/fixture.so\n'
        self.reject(c.parse_maps, row, max_bytes=1)
        self.reject(c.parse_maps, row*2, max_rows=1)
        self.reject(c.parse_maps, b'malformed')
        for path in (PROOT+'/datasets/sample.py', '/home/jovyan/.ssh/key', '/tmp/a.npz'):
            self.reject(c.parse_maps, ('1000-2000 r-xp 0000 08:01 1 '+path+'\n').encode())

    def test_36_runtime_origins_current_pid_bounded_read(self):
        row = b'1000-2000 r-xp 0000 08:01 1 /usr/lib/fixture.so\n'
        opened = mock_open(read_data=row)
        with patch('builtins.open', opened), patch.object(sys, 'modules', {'fixture': NS(__file__='/usr/lib/fixture.py')}):
            observed = c.runtime_origins('/proc/%d/maps' % os.getpid())
            self.assertEqual(observed['module_origins'], {'fixture': '/usr/lib/fixture.py'})
            opened().read.assert_called_once_with(1048577)
            self.reject(c.runtime_origins, '/proc/other/maps')
        with patch.object(c, 'runtime_origins', return_value={'mapped_file_paths': ['/usr/lib/fixture.so']}):
            self.assertEqual(self.boundary.observation()['runtime_origins']['mapped_file_paths'], ['/usr/lib/fixture.so'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
