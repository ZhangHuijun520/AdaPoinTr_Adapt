"""Synthetic preflight guards. Importing this module never imports torch/models."""

import hashlib
import json
import math
import os
import re
import socket
import finite_preflight_contract_v5 as finite_reader
from pathlib import Path

PROTOCOL_SHA = '923254dab787341728af9a22031b482f55a45ebd6c2bc62cfcb427511c61456b'
V1_SHA = 'd968143ce8ce39daedc398b85419300a48425c63a3203ad75604bc5f1ba16ffd'
ROOT = Path('/home/jovyan/adapointr_work/PoinTr')
ENV_ROOT = Path('/opt/conda/envs/adapointr-mamba')
TOOL_NAMES = (
    'tools/run_cranial_scqr_v12_rsd_r1b_synthetic_gpu_preflight_finite_v5.py',
    'tools/cranial_scqr_v12_rsd_r1b_synthetic_preflight_contract_finite_v5.py',
    'tools/test_cranial_scqr_v12_rsd_r1b_synthetic_preflight_contract_finite_v5.py',
)
SCALARS = ('alpha_q', 'query_warmup', 'query_rms', 'potential_residual_rms',
           'applied_residual_rms', 'relative_potential_residual_rms',
           'attention_entropy_mean', 'effective_proxy_count_mean', 'attention_max_weight_mean')
IMMUTABLE_FIELDS = ('synthetic_input_contract', 'model_initialization_contract', 'rng_contract',
                    'standalone_outlet_contract', 'full_forward_order', 'success_exact_counts',
                    'numerical_policy', 'equality_contract', 'state_contract', 'permissions',
                    'interpretation_limits', 'future_output_contract', 'acyclic_materialization_contract',
                    'implementation_sha256', 'model_structure_sources', 'parent_query_off_protocol_sha256',
                    'post_implementation_p3', 'formal_gate_status', 'formal_classification')


class ContractError(RuntimeError):
    pass


def require(ok, message):
    if not ok:
        raise ContractError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def sha_string(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def under(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except ValueError:
        return False


def bound(root, binding):
    relative = Path(binding['path'])
    require(not relative.is_absolute() and '..' not in relative.parts and '\\' not in str(relative), 'unsafe binding')
    lexical = Path(root) / relative
    require(all(not p.is_symlink() for p in (lexical, *lexical.parents) if under(p, root)), 'linked binding denied')
    path = lexical.resolve()
    require(not set(path.parts) & {'.codex', '.ssh', '.aws', 'secrets', 'credentials'} and path.name != 'auth.json' and
            path.suffix.lower() not in ('.npz', '.stl', '.pth', '.pt', '.pkl', '.pickle', '.csv', '.jsonl'),
            'payload/secret binding denied before byte access')
    require(under(path, root) and path.is_file(), 'missing/escaped binding')
    # Historical parent P3 has a hash-only binding; new bindings freeze bytes.
    if 'bytes' in binding:
        require(type(binding['bytes']) is int and binding['bytes'] > 0 and path.stat().st_size == binding['bytes'], 'binding bytes drift')
    require(sha_string(binding['sha256']) and digest(path) == binding['sha256'], 'binding hash drift')
    return path


def strict_json(path):
    def pairs(items):
        out = {}
        for key, value in items:
            require(key not in out, 'duplicate JSON key')
            out[key] = value
        return out
    def bad_number(value):
        raise ContractError('nonfinite JSON constant: ' + value)
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=pairs, parse_constant=bad_number)


def validate_request(request, original):
    rebind = strict_json(bound(ROOT, request['resource_rebind_binding']))
    finite_reader.validate_request(request, original, rebind, V1_SHA)
    require(request['resource_rebind_sha256'] == digest(bound(ROOT, request['resource_rebind_binding'])), 'canonical rebind bytes/hash')
    require(request.get('parent_request_v1', {}).get('sha256') == V1_SHA, 'immutable parent request')
    require(request.get('protocol_binding', {}).get('sha256') == PROTOCOL_SHA, 'immutable protocol')
    require(request.get('fixed_future_execution', {}).get('run_id') == finite_reader.RUN, 'finite run')
    require(request['fixed_future_execution']['output_relative'] == finite_reader.PREFIX + 'result', 'finite output')
    require(request.get('finite_scope_binding') and request.get('finite_completion_binding') and request.get('formal_cpu_freeze_binding'), 'finite frozen evidence required')
    bindings = request.get('preflight_implementation_bindings', [])
    require(len(bindings) == 3 and {x['path'] for x in bindings} == set(TOOL_NAMES), 'exact finite tool set')
    for row in bindings:
        require(sha_string(row.get('sha256')) and type(row.get('bytes')) is int and row['bytes'] > 0, 'tool identity')
    expected = finite_reader.PREFIX
    for key, suffix in {'authorization_receipt_relative':'control/authorization_receipt_v5.json',
                        'runtime_relative':'control/runtime_v5.json',
                        'launcher_relative':'control/launcher_once_v5.sh',
                        'control_relative':'control','log_relative':'control/master.log',
                        'pid_relative':'control/pid.txt','exit_code_relative':'control/exit_code.txt'}.items():
        require(request['fixed_future_execution'].get(key) == expected + suffix, 'new finite namespace')
    require(request['environment_runtime_contract']['cuda_version'] == '11.8' and
            type(request['environment_runtime_contract']['cudnn_version']) is int and
            request['environment_runtime_contract']['cudnn_version'] > 0, 'runtime version')
    require(request['resource_binding']['hostname'] == socket.gethostname(), 'current hostname')


def validate_chain(request, original, auth, runtime, request_sha, auth_sha):
    validate_request(request, original)
    finite_reader.validate_chain(request, auth, runtime, request_sha, auth_sha)


class Ledger:
    """One-way attempt ledger; any violation permanently poisons the execution."""
    def __init__(self, expected):
        self.expected = dict(expected)
        self.counts = {key: 0 for key in expected}
        self.failed = False
        self.pending = None

    def check(self, ok, message):
        if self.failed or not ok:
            self.failed = True
            raise ContractError(message)

    def add(self, key):
        self.check(key in self.counts and self.counts[key] < self.expected[key], 'counter limit: ' + key)
        self.counts[key] += 1

    def begin(self, index, item):
        self.check(self.pending is None and index == self.counts['full_model_forward_attempts'] + 1,
                   'forward order/pending failure')
        self.add('full_model_forward_attempts')
        self.add('ls_full_forwards' if item['model'] == 'LS' else 'lsq_full_forwards')
        self.pending = index

    def end(self):
        self.check(self.pending is not None, 'completion without attempt')
        self.add('full_model_forward_completions')
        self.pending = None

    def finish(self):
        self.check(self.pending is None and self.counts == self.expected, 'incomplete/over-budget preflight')


def assert_scalars(values, *, off=False):
    require(set(values) == set(SCALARS) | {'query_applicable', 'query_outlet_calls'}, 'diagnostic schema')
    require(values['query_applicable'] is True and type(values['query_outlet_calls']) is int and values['query_outlet_calls'] == 1,
            'outlet count/applicability')
    require(all(type(values[k]) in (int, float) and math.isfinite(values[k]) for k in SCALARS), 'nonfinite scalar')
    require(values['query_warmup'] == 1.0 and values['applied_residual_rms'] ==
            (0.0 if off else values['potential_residual_rms']), 'residual/warmup contract')


class FileBoundary:
    """Process audit-hook boundary: code/bound text reads, owned output writes only.

    Dependencies are explicit frozen code/binary files, not arbitrary files in
    the environment. No pickle/NPZ/STL reads, dataset directories, subprocesses
    or network are admitted after the hook is installed.
    """
    def __init__(self, read_files, output, *, current_process_maps=None):
        self.read_files = {str(Path(p).resolve()) for p in read_files}
        self.output = Path(output).resolve()
        expected = Path('/proc') / str(os.getpid()) / 'maps'
        require(current_process_maps is None or Path(current_process_maps) == expected, 'only current pid maps exception')
        self.current_process_maps = str(expected) if current_process_maps is not None else None

    def check_open(self, file, mode=None, flags=0):
        require(not isinstance(file, int), 'untracked file-descriptor open denied')
        lexical = Path(os.fsdecode(file))
        path = lexical.resolve()
        require(not lexical.is_symlink() and lexical.absolute() == path, 'linked/noncanonical open denied: ' + str(lexical))
        require(not set(path.parts) & {'.codex', '.ssh', '.aws', 'secrets', 'credentials'} and path.name != 'auth.json',
                'secret access denied: ' + str(path))
        require(path.suffix.lower() not in ('.npz', '.stl', '.pth', '.pt', '.pkl', '.pickle', '.csv', '.jsonl'),
                'real payload/checkpoint/CSV access denied')
        writing = any(c in (mode or '') for c in 'wax+') or bool((flags or 0) & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC))
        if writing:
            require(under(path, self.output) and path != self.output, 'write outside owned output denied')
        else:
            require(str(path) in self.read_files or str(path) == self.current_process_maps or under(path, self.output), 'unbound read denied: ' + str(path))

    def __call__(self, event, args):
        if event == 'open':
            self.check_open(*args)
        elif event.startswith('socket.') or event == 'subprocess.Popen' or event.startswith('os.exec') or event in ('os.system', 'os.fork', 'os.posix_spawn'):
            raise ContractError('network/subprocess forbidden during synthetic execution')
        elif event in ('os.remove', 'os.rmdir', 'os.rename', 'os.chmod', 'os.chown', 'os.link', 'os.symlink'):
            raise ContractError('destructive filesystem action forbidden')
        elif event == 'os.mkdir':
            require(under(args[0], self.output) and Path(args[0]).resolve() != self.output, 'mkdir outside owned output denied')
