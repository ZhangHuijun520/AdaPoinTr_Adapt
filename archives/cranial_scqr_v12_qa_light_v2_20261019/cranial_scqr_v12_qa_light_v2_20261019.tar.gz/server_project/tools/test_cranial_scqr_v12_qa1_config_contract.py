#!/usr/bin/env python
"""Synthetic CPU/pure-text contract tests for Cranial-SCQR v1.2 QA-1 configs."""

from __future__ import annotations

import ast
import copy
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[1]
VALIDATOR_PATH = ROOT / "tools/validate_cranial_scqr_v12_qa1_configs.py"
PROTOCOL_PATH = (
    ROOT
    / "docs/cranial_scqr_v12_qa_research_2026_09_21"
    / "v12_qa1_formal_config_protocol_v1.json"
)


def load_validator():
    spec = importlib.util.spec_from_file_location("qa1_config_validator", VALIDATOR_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot create validator import spec")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class QA1ConfigContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.validator = load_validator()
        cls.protocol = cls.validator.validate_protocol(PROTOCOL_PATH)
        cls.runs = {item["run_key"]: item for item in cls.protocol["runs"]}

    def load_pair(self, run_key):
        item = self.runs[run_key]
        config = self.validator.read_yaml(ROOT / item["config"])
        reference = self.validator.read_yaml(ROOT / item["reference_template"])
        return item, config, reference

    def test_real_protocol_is_frozen_and_training_locked(self):
        self.assertEqual(self.protocol["status"], "FROZEN_IMPLEMENTATION_ONLY")
        self.assertFalse(self.protocol["execution_authorized"])
        self.assertEqual(len(self.protocol["runs"]), 6)
        self.assertTrue(all(not item["training_authorized"] for item in [self.protocol["boundaries"]]))

    def test_exact_matrix_and_frozen_lambdas(self):
        self.assertEqual(set(self.runs), {
            "B0_foldC_seed0", "B0_foldD_seed0",
            "LS_foldC_seed0", "LS_foldD_seed0",
            "LSQ_foldC_seed0", "LSQ_foldD_seed0",
        })
        self.assertIsNone(self.runs["B0_foldC_seed0"]["lambda_scf"])
        self.assertIsNone(self.runs["B0_foldD_seed0"]["lambda_scf"])
        self.assertEqual(self.runs["LS_foldC_seed0"]["lambda_scf"], 0.8912909312609397)
        self.assertEqual(self.runs["LSQ_foldC_seed0"]["lambda_scf"], 0.8912909312609397)
        self.assertEqual(self.runs["LS_foldD_seed0"]["lambda_scf"], 0.8346387037781536)
        self.assertEqual(self.runs["LSQ_foldD_seed0"]["lambda_scf"], 0.8346387037781536)

    def test_each_config_validates_against_v11_reference(self):
        for run_key in sorted(self.runs):
            item, config, reference = self.load_pair(run_key)
            self.validator.validate_config_payload(config, item, reference)

    def test_training_authorization_tamper_is_rejected(self):
        item, config, reference = self.load_pair("LS_foldC_seed0")
        config["cranial_scqr_execution"]["training_authorized"] = True
        with self.assertRaises(self.validator.ContractError):
            self.validator.validate_config_payload(config, item, reference)

    def test_lambda_and_query_tamper_are_rejected(self):
        item, config, reference = self.load_pair("LSQ_foldD_seed0")
        bad_lambda = copy.deepcopy(config)
        bad_lambda["model"]["cranial_scqr"]["auxiliary_loss_weight"] = 0.5
        with self.assertRaises(self.validator.ContractError):
            self.validator.validate_config_payload(bad_lambda, item, reference)
        bad_query = copy.deepcopy(config)
        bad_query["model"]["cranial_scqr"]["query_conditioning_enabled"] = False
        with self.assertRaises(self.validator.ContractError):
            self.validator.validate_config_payload(bad_query, item, reference)

    def test_b0_nonnull_lambda_is_rejected(self):
        item, config, reference = self.load_pair("B0_foldC_seed0")
        config["model"]["cranial_scqr"]["auxiliary_loss_weight"] = 0.1
        with self.assertRaises(self.validator.ContractError):
            self.validator.validate_config_payload(config, item, reference)

    def test_allowlist_and_protected_flag_tamper_are_rejected(self):
        item, config, reference = self.load_pair("LS_foldD_seed0")
        bad_list = copy.deepcopy(config)
        bad_list["dataset"]["train"]["others"]["include_case_ids_file"] = "forbidden.txt"
        with self.assertRaises(self.validator.ContractError):
            self.validator.validate_config_payload(bad_list, item, reference)
        bad_flag = copy.deepcopy(config)
        bad_flag["development_protocol"]["confirmation_allowed"] = True
        with self.assertRaises(self.validator.ContractError):
            self.validator.validate_config_payload(bad_flag, item, reference)

    def test_temporary_artificial_yaml_json_text_only(self):
        item, config, reference = self.load_pair("LS_foldC_seed0")
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            yaml_path = root / "artificial.yaml"
            json_path = root / "artificial.json"
            text_path = root / "artificial.txt"
            yaml_path.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
            json_path.write_text(json.dumps({"run_key": item["run_key"]}), encoding="utf-8")
            text_path.write_text("synthetic-only\n", encoding="utf-8")
            loaded = self.validator.read_yaml(yaml_path)
            self.validator.validate_config_payload(loaded, item, reference)
            self.assertEqual(json.loads(json_path.read_text())["run_key"], item["run_key"])
            self.assertEqual(text_path.read_text(), "synthetic-only\n")

    def test_static_source_has_no_model_dataset_torch_or_cuda_import(self):
        source = VALIDATOR_PATH.read_text(encoding="utf-8")
        tree = ast.parse(source)
        imported = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imported.update(alias.name.split(".")[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                imported.add(node.module.split(".")[0])
        self.assertTrue(imported.isdisjoint({"torch", "datasets", "models", "utils", "extensions"}))


if __name__ == "__main__":
    unittest.main(verbosity=2)
