"""Synthetic preflight guards. Importing this module never imports torch/models."""

import hashlib
import json
import math
import os
import re
import socket
import stat
import sys
from pathlib import Path

PROTOCOL_SHA = '923254dab787341728af9a22031b482f55a45ebd6c2bc62cfcb427511c61456b'
V1_SHA = 'd968143ce8ce39daedc398b85419300a48425c63a3203ad75604bc5f1ba16ffd'
ROOT = Path('/home/jovyan/adapointr_work/PoinTr')
ENV_ROOT = Path('/opt/conda/envs/adapointr-mamba')
TOOL_NAMES = (
    'tools/run_cranial_scqr_v12_rsd_r1b_synthetic_gpu_preflight_finite_v5.py',
    'tools/cranial_scqr_v12_rsd_r1b_synthetic_preflight_contract_finite_v5.py',
    'tools/test_cranial_scqr_v12_rsd_r1b_synthetic_preflight_contract_finite_v5.py',
)
SCALARS = ('alpha_q', 'query_warmup', 'query_rms', 'potential_residual_rms',
           'applied_residual_rms', 'relative_potential_residual_rms',
           'attention_entropy_mean', 'effective_proxy_count_mean', 'attention_max_weight_mean')
IMMUTABLE_FIELDS = ('synthetic_input_contract', 'model_initialization_contract', 'rng_contract',
                    'standalone_outlet_contract', 'full_forward_order', 'success_exact_counts',
                    'numerical_policy', 'equality_contract', 'state_contract', 'permissions',
                    'interpretation_limits', 'future_output_contract', 'acyclic_materialization_contract',
                    'implementation_sha256', 'model_structure_sources', 'parent_query_off_protocol_sha256',
                    'post_implementation_p3', 'formal_gate_status', 'formal_classification')


class ContractError(RuntimeError):
    pass


def require(ok, message):
    if not ok:
        raise ContractError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def sha_string(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def under(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except ValueError:
        return False


def bound(root, binding):
    relative = Path(binding['path'])
    require(not relative.is_absolute() and '..' not in relative.parts and '\\' not in str(relative), 'unsafe binding')
    lexical = Path(root) / relative
    require(all(not p.is_symlink() for p in (lexical, *lexical.parents) if under(p, root)), 'linked binding denied')
    path = lexical.resolve()
    require(not set(path.parts) & {'.codex', '.ssh', '.aws', 'secrets', 'credentials'} and path.name != 'auth.json' and
            path.suffix.lower() not in ('.npz', '.stl', '.pth', '.pt', '.pkl', '.pickle', '.csv', '.jsonl'),
            'payload/secret binding denied before byte access')
    require(under(path, root) and path.is_file(), 'missing/escaped binding')
    # Historical parent P3 has a hash-only binding; new bindings freeze bytes.
    if 'bytes' in binding:
        require(type(binding['bytes']) is int and binding['bytes'] > 0 and path.stat().st_size == binding['bytes'], 'binding bytes drift')
    require(sha_string(binding['sha256']) and digest(path) == binding['sha256'], 'binding hash drift')
    return path


def strict_json(path):
    def pairs(items):
        out = {}
        for key, value in items:
            require(key not in out, 'duplicate JSON key')
            out[key] = value
        return out
    def bad_number(value):
        raise ContractError('nonfinite JSON constant: ' + value)
    return json.loads(Path(path).read_text(encoding='utf-8'), object_pairs_hook=pairs, parse_constant=bad_number)


RUN = 'r1b_synthetic_gpu_pf_minimal_v6_20261018'
PREFIX = 'logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v6_20261018/'
HOST = 'shu-common-25721452-notebook-hwq6lx-0'
GPU_UUID = 'GPU-34a1b996-2bd7-88e6-9dca-164b718caea6'
PROVIDER = ROOT / 'third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider'
NATIVE_SHA = 'e70d00108bacba4a905dc011f4b8c4868f06ec2d44d8e322148e2e452578fbb5'
REQUEST_REL = 'docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_gpu_zero_update_preflight_execution_request_minimal_v6_20261018.json'
TOOL_NAMES = tuple('tools/' + name for name in (
    'run_cranial_scqr_v12_rsd_r1b_synthetic_gpu_preflight_minimal_v6.py',
    'cranial_scqr_v12_rsd_r1b_synthetic_preflight_contract_minimal_v6.py',
    'test_cranial_scqr_v12_rsd_r1b_synthetic_preflight_minimal_v6.py'))
DENIED_SUFFIXES = {'.npz', '.npy', '.stl', '.pth', '.pt', '.ckpt', '.safetensors',
                   '.pkl', '.pickle', '.csv', '.jsonl', '.h5', '.hdf5', '.ply', '.pcd'}
SECRET_PARTS = {'.codex', '.ssh', '.aws', 'secrets', 'credentials'}
PROJECT_DATA_PARTS = {'data', 'datasets', 'dataset', 'checkpoints', 'sealed'}
DEPENDENCY_POLICY = {
    'code_roots': ['/opt/conda/envs/adapointr-mamba/lib/python3.10'],
    'code_suffixes': ['.py', '.so'],
    'resource_root': '/opt/conda/envs/adapointr-mamba/lib/python3.10/site-packages/matplotlib/mpl-data',
    'resource_suffixes': ['.json', '.mplstyle', '.afm'],
    'resource_names': ['matplotlibrc'],
    'font_cache': '/home/jovyan/.cache/matplotlib/fontlist-v390.json',
    'font_cache_sha256': '7809682f5d525257260d3df4db0a8aa1e2ffec0f68ec351439523099dc76b311',
    'metadata_root': '/opt/conda/envs/adapointr-mamba/lib/python3.10/site-packages',
    'metadata_names': ['METADATA', 'WHEEL', 'entry_points.txt', 'top_level.txt'],
    'metadata_file_bytes_max': 1048576,
    'metadata_files_max': 64,
    'metadata_total_bytes_max': 4194304,
    'unused_bytecode_relative': 'bytecode_unused',
    'unused_bytecode_cache_tag': 'cpython-310',
    'unused_bytecode_probe_paths_max': 8192,
    'unused_bytecode_path_bytes_max': 4096,
    'unused_bytecode_total_path_bytes_max': 8388608,
    'native_policy': 'Exact PointNet2 hash/origins; other native libraries version/path recorded, not complete binary closure',
}


def safe_path(value):
    p = Path(value)
    require(p.is_absolute() and '..' not in p.parts and '\\\\' not in str(p), 'noncanonical path: ' + str(p))
    require(not set(p.parts) & SECRET_PARTS and p.name not in ('auth.json', '.env'), 'secret path denied: ' + str(p))
    require(p.suffix.lower() not in DENIED_SUFFIXES, 'payload/checkpoint denied: ' + str(p))
    # Check lexical ancestors, not resolve-then-check; an in-root alias is denied too.
    require(not any(item.is_symlink() for item in (p, *p.parents)), 'linked path denied: ' + str(p))
    require(p.absolute() == p.resolve(), 'noncanonical path: ' + str(p))
    if under(p, ROOT):
        require(not set(p.relative_to(ROOT).parts) & PROJECT_DATA_PARTS, 'project data directory denied: ' + str(p))
    return p


def checked_binding(binding):
    p = Path(binding['path'])
    if not p.is_absolute():
        p = ROOT / p
    p = safe_path(p)
    require(under(p, ROOT) or str(p) == DEPENDENCY_POLICY['font_cache'], 'binding root denied: ' + str(p))
    require(p.is_file() and type(binding.get('bytes')) is int and binding['bytes'] >= 0
            and p.stat().st_size == binding['bytes'], 'binding bytes drift: ' + str(p))
    require(sha_string(binding.get('sha256')) and digest(p) == binding['sha256'], 'binding hash drift: ' + str(p))
    return p


GPU_MEMORY_IDENTITY = {
    'nvidia_smi': {'source': 'nvidia-smi --query-gpu=memory.total', 'total_mib': 24564},
    'cuda_device_properties': {'source': 'torch.cuda.get_device_properties(0).total_memory',
                               'total_bytes': 25261047808},
}


STATIC_DEPENDENCY_RESOURCE = {
    'path': '/opt/conda/envs/adapointr-mamba/lib/python3.10/site-packages/setuptools/_vendor/jaraco/text/Lorem ipsum.txt',
    'bytes': 1335,
    'sha256': '37fedcffbf73c4eb9f058f47677cb33203a436ff9390e4d38a8e01c9dad28e0b',
}


def checked_static_resource(binding):
    """One exact pre-bound installed sample; no suffix or directory exception."""
    require(binding == STATIC_DEPENDENCY_RESOURCE, 'exact static resource binding required')
    path = safe_path(binding['path'])
    before = path.stat()
    require(stat.S_ISREG(before.st_mode) and before.st_size == binding['bytes'],
            'static resource type/size drift: ' + str(path))
    with path.open('rb') as stream:
        raw = stream.read(binding['bytes'] + 1)
    after = path.stat()
    fingerprint = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    require(fingerprint(before) == fingerprint(after), 'static resource changed during check: ' + str(path))
    actual = {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    require(actual == binding, 'static resource content drift: ' +
            json.dumps({'expected': binding, 'actual': actual}, sort_keys=True))
    return path


def validate_request(request, original):
    require(request.get('schema') == 'r1b-synthetic-preflight-minimal-request-v6'
            and request.get('status') == 'AWAITING_EXPLICIT_USER_AUTHORIZATION', 'request schema/status')
    require(request.get('execution_authorized') is False and request.get('implementation_authorized') is False
            and request.get('direct_execution_allowed') is False and request.get('execution_ready') is True
            and request.get('missing_preconditions') == [], 'request cannot self-authorize')
    for key in IMMUTABLE_FIELDS:
        require(key in original and request.get(key) == original[key], 'frozen semantics drift: ' + key)
    require(request.get('parent_request_v1', {}).get('sha256') == V1_SHA
            and request.get('protocol_binding', {}).get('sha256') == PROTOCOL_SHA, 'parent/protocol identity')
    require(request.get('static_dependency_resource_binding') == STATIC_DEPENDENCY_RESOURCE,
            'static dependency resource policy drift')
    resource = request['resource_binding']
    require(resource['hostname'] == HOST and resource['gpu_uuid'] == GPU_UUID, 'resource rebind drift')
    for key in ('minimum_free_gpu_memory_mib_at_launch', 'minimum_free_disk_bytes_at_launch',
                'maximum_peak_allocated_mib', 'maximum_peak_reserved_mib', 'maximum_walltime_seconds'):
        require(resource[key] == original['resource_binding'][key], 'resource budget drift: ' + key)
    require(request.get('gpu_memory_identity_contract') == GPU_MEMORY_IDENTITY, 'GPU memory API/source contract drift')
    require(type(resource.get('gpu_memory_total_mib')) is int and resource['gpu_memory_total_mib'] == 24564
            and type(resource.get('cuda_device_total_memory_bytes')) is int
            and resource['cuda_device_total_memory_bytes'] == 25261047808
            and type(resource.get('gpu_count')) is int and resource['gpu_count'] == 1
            and resource.get('gpu_name') == 'NVIDIA GeForce RTX 4090 D', 'GPU memory/device identity drift')
    require(request['provider_relative'] == str(PROVIDER.relative_to(ROOT))
            and request['provider_native_sha256'] == NATIVE_SHA, 'provider identity drift')
    require(request['dependency_policy'] == DEPENDENCY_POLICY, 'dependency policy drift')
    require(set(x['path'] for x in request['preflight_implementation_bindings']) == set(TOOL_NAMES)
            and len(request['preflight_implementation_bindings']) == 3, 'exact three minimal tools')
    f = request['fixed_future_execution']
    require(f['run_id'] == RUN and f['tmux_session'] == 'r1b-synthetic-gpu-pf-minimal-v6-20261018', 'new run/session')
    for key, suffix in {'output_relative': 'result', 'control_relative': 'control',
            'authorization_receipt_relative': 'control/authorization.json', 'runtime_relative': 'control/runtime.json',
            'launcher_relative': 'control/launcher_once.sh', 'log_relative': 'control/master.log',
            'pid_relative': 'control/pid.txt', 'exit_code_relative': 'control/exit_code.txt',
            'started_relative': 'control/started.json'}.items():
        require(f.get(key) == PREFIX + suffix, 'frozen execution path: ' + key)
    env = request['environment_runtime_contract']
    require(env['torch_version'] == '2.4.1+cu118' and env['numpy_version'] == '2.2.6'
            and env['cuda_version'] == '11.8' and env['cudnn_version'] == 90100, 'runtime version contract')


def validate_chain(request, original, auth, runtime, request_sha, auth_sha):
    validate_request(request, original)
    require(auth == dict(status='AUTHORIZED_ONCE_SYNTHETIC_MINIMAL_PREFLIGHT_V6', request_sha256=request_sha,
                         run_id=RUN, execution_authorized=True, permissions=request['permissions']), 'authorization chain')
    require(runtime == dict(stage='R1B_SYNTHETIC_MINIMAL_PREFLIGHT_V6', request_sha256=request_sha,
                            authorization_receipt_sha256=auth_sha, run_id=RUN), 'one-way runtime chain')


def assert_provider(native, wrapper, adapter):
    require(safe_path(native.__file__) == PROVIDER / 'pointnet2_ops/_ext.cpython-310-x86_64-linux-gnu.so'
            and digest(native.__file__) == NATIVE_SHA, 'native provider drift')
    require(safe_path(wrapper.__file__) == PROVIDER / 'pointnet2_ops/pointnet2_utils.py'
            and safe_path(adapter.__file__) == ROOT / 'utils/pointnet2_utils.py', 'wrapper/adapter origin drift')
    require(adapter.using_fallback() is False and
            all(getattr(adapter, n) is getattr(wrapper, n) for n in ('furthest_point_sample', 'gather_operation')),
            'compiled FPS/gather required; fallback denied')


class Ledger:
    """One-way attempt ledger; any violation permanently poisons the execution."""
    def __init__(self, expected):
        self.expected = dict(expected)
        self.counts = {key: 0 for key in expected}
        self.failed = False
        self.pending = None

    def check(self, ok, message):
        if self.failed or not ok:
            self.failed = True
            raise ContractError(message)

    def add(self, key):
        self.check(key in self.counts and self.counts[key] < self.expected[key], 'counter limit: ' + key)
        self.counts[key] += 1

    def begin(self, index, item):
        self.check(self.pending is None and index == self.counts['full_model_forward_attempts'] + 1,
                   'forward order/pending failure')
        self.add('full_model_forward_attempts')
        self.add('ls_full_forwards' if item['model'] == 'LS' else 'lsq_full_forwards')
        self.pending = index

    def end(self):
        self.check(self.pending is not None, 'completion without attempt')
        self.add('full_model_forward_completions')
        self.pending = None

    def finish(self):
        self.check(self.pending is None and self.counts == self.expected, 'incomplete/over-budget preflight')


def assert_scalars(values, *, off=False):
    require(set(values) == set(SCALARS) | {'query_applicable', 'query_outlet_calls'}, 'diagnostic schema')
    require(values['query_applicable'] is True and type(values['query_outlet_calls']) is int and values['query_outlet_calls'] == 1,
            'outlet count/applicability')
    require(all(type(values[k]) in (int, float) and math.isfinite(values[k]) for k in SCALARS), 'nonfinite scalar')
    require(values['query_warmup'] == 1.0 and values['applied_residual_rms'] ==
            (0.0 if off else values['potential_residual_rms']), 'residual/warmup contract')


class FileBoundary:
    """Synthetic entry's Python audit boundary, not an OS sandbox or ELF closure.

    Project/provider files are exact hash bindings. Installed dependency code
    is read-only, observed on demand; no recursive environment inventory.
    Project datasets are not confused with dependency package subdirectories.
    """
    def __init__(self, read_files, output):
        self.read_files = {str(safe_path(p)) for p in read_files}
        self.output = safe_path(output)
        self.opened = set()
        self.metadata_reads = {}
        self.bytecode_probes = {}
        self.current_process_maps = '/proc/%d/maps' % os.getpid()

    def check_open(self, file, mode=None, flags=0):
        require(not isinstance(file, int), 'untracked fd denied')
        lexical = Path(os.fsdecode(file))
        writing = any(x in (mode or '') for x in 'wax+') or bool((flags or 0) &
                     (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND))
        if self.check_absent_bytecode_probe(lexical, writing):
            return
        require(lexical.suffix.lower() != '.pyc', 'unbound/existing bytecode denied: ' + str(lexical))
        path = safe_path(lexical)
        if writing:
            require(under(path, self.output) and path != self.output, 'write outside result: ' + str(path))
            return
        if str(path) in self.read_files or str(path) == self.current_process_maps or under(path, self.output):
            return
        if metadata_candidate(path):
            s = path.stat()
            require(stat.S_ISREG(s.st_mode) and 0 <= s.st_size <= DEPENDENCY_POLICY['metadata_file_bytes_max'],
                    'metadata type/size limit: ' + str(path))
            name = str(path)
            if name in self.metadata_reads:
                require(self.metadata_reads[name] == s.st_size, 'metadata size changed: ' + name)
            else:
                require(len(self.metadata_reads) < DEPENDENCY_POLICY['metadata_files_max'] and
                        sum(self.metadata_reads.values()) + s.st_size <= DEPENDENCY_POLICY['metadata_total_bytes_max'],
                        'metadata aggregate budget: ' + name)
                self.metadata_reads[name] = s.st_size
            return
        dependency = any(under(path, root) for root in DEPENDENCY_POLICY['code_roots'])
        resource = under(path, DEPENDENCY_POLICY['resource_root'])
        require((dependency and path.suffix in DEPENDENCY_POLICY['code_suffixes']) or
                (resource and (path.suffix in DEPENDENCY_POLICY['resource_suffixes']
                              or path.name in DEPENDENCY_POLICY['resource_names'])),
                'unbound read: ' + str(path))
        self.opened.add(str(path))


    def check_absent_bytecode_probe(self, path, writing):
        """Admit absence checks only; never consume cache bytes or open a dataset."""
        cache = self.output / DEPENDENCY_POLICY['unused_bytecode_relative']
        try:
            relative = path.relative_to(cache)  # lexical, before any resolution
        except ValueError:
            return False
        require(not writing, 'bytecode probe writes denied')
        require(self.output == ROOT / (PREFIX + 'result') and str(cache) == sys.pycache_prefix,
                'exact current unused bytecode namespace required')
        require(path.is_absolute() and '..' not in path.parts and '\\' not in str(path),
                'noncanonical bytecode candidate')
        require(not set(path.parts) & SECRET_PARTS and path.name not in ('auth.json', '.env'),
                'secret bytecode candidate denied')
        require(not any(p.is_symlink() for p in (path, *path.parents)) and path.absolute() == path.resolve(),
                'linked bytecode candidate denied')
        require(len(str(path).encode('utf-8')) <= DEPENDENCY_POLICY['unused_bytecode_path_bytes_max'],
                'bytecode path budget')
        tag = DEPENDENCY_POLICY['unused_bytecode_cache_tag']
        require(sys.implementation.cache_tag == tag, 'bytecode interpreter tag drift')
        suffix = '.' + tag + '.pyc'
        require(len(relative.parts) >= 2 and path.name.endswith(suffix), 'bytecode candidate tag/layout')
        stem = path.name[:-len(suffix)]
        require(stem and '.' not in stem and stem not in ('.', '..'), 'bytecode module stem')
        source = safe_path(Path('/').joinpath(*relative.parts[:-1], stem + '.py'))
        require(str(source) in self.read_files or
                any(under(source, root) for root in DEPENDENCY_POLICY['code_roots']),
                'unbound bytecode source: ' + str(source))
        # A regular cached file is forbidden too. Missing ancestors are normal.
        # Permission/ENOTDIR/other stat failures are not silently treated as absence.
        try:
            os.lstat(path)
        except FileNotFoundError:
            pass
        else:
            raise ContractError('existing bytecode candidate forbidden: ' + str(path))
        name, mapped = str(path), str(source)
        if name not in self.bytecode_probes:
            require(len(self.bytecode_probes) < DEPENDENCY_POLICY['unused_bytecode_probe_paths_max'],
                    'bytecode probe count budget')
            total = sum(len(k.encode()) + len(v.encode()) for k, v in self.bytecode_probes.items())
            require(total + len(name.encode()) + len(mapped.encode()) <=
                    DEPENDENCY_POLICY['unused_bytecode_total_path_bytes_max'], 'bytecode probe total budget')
            self.bytecode_probes[name] = mapped
        # The real open proceeds and gets ENOENT, which SourceLoader catches
        # before reading the independently admitted .py source. No cache is read.
        return True

    def __call__(self, event, args):
        if event == 'open':
            self.check_open(*args)
        elif event == 'import' and len(args) > 1 and args[1]:
            self.check_open(args[1])
        elif event == 'ctypes.dlopen' and args and args[0]:
            name = os.fsdecode(args[0])
            # Bare SONAMEs are resolved by the existing loader, not pip/JIT.
            # Actual mapped origins are recorded; no complete ELF claim.
            if '/' in name:
                p = safe_path(name)
                require(any(under(p, root) for root in (ENV_ROOT, '/usr/lib', '/usr/local/nvidia')),
                        'dynamic loader root denied: ' + str(p))
        elif event.startswith('socket.') or event == 'subprocess.Popen' or event.startswith('os.exec') or event in ('os.system', 'os.fork', 'os.posix_spawn'):
            raise ContractError('network/subprocess forbidden during synthetic execution')
        elif event in ('os.remove', 'os.rmdir', 'os.rename', 'os.chmod', 'os.chown', 'os.link', 'os.symlink'):
            raise ContractError('destructive filesystem action forbidden')
        elif event == 'os.mkdir':
            p = safe_path(args[0])
            require(under(p, self.output) and p != self.output, 'mkdir outside result')

    def observation(self):
        # Code files actually opened are reported, not labeled a pre-frozen
        # binary closure. The separately frozen provider is always rehashed.
        metadata = []
        for name, size in sorted(self.metadata_reads.items()):
            p = safe_path(name)
            require(p.stat().st_size == size, 'metadata changed before observation: ' + name)
            metadata.append({'path': name, 'bytes': size, 'sha256': digest(p)})
        probes = [{'path': name, 'source': source, 'absent_at_guard': True}
                  for name, source in sorted(self.bytecode_probes.items())]
        return {'absent_bytecode_probes': probes, 'dependency_reads': sorted(self.opened), 'dependency_metadata_reads': metadata, 'policy': DEPENDENCY_POLICY,
                'runtime_origins': runtime_origins(self.current_process_maps),
                'not_OS_sandbox': True, 'not_complete_ELF_closure': True}


def parse_maps(raw, max_bytes=1048576, max_rows=8192):
    """Current-process maps only: observed origins, not a transitive ELF audit."""
    require(isinstance(raw, bytes) and len(raw) <= max_bytes, 'maps byte limit')
    lines = raw.decode('utf-8', 'strict').splitlines()
    require(len(lines) <= max_rows, 'maps row limit')
    paths, deleted = set(), set()
    for line in lines:
        fields = line.split(None, 5)
        require(len(fields) >= 5, 'malformed maps row')
        if len(fields) == 5 or not fields[5].startswith('/'):
            continue
        value = fields[5]
        is_deleted = value.endswith(' (deleted)')
        value = value[:-10] if is_deleted else value
        p = Path(value)
        require(not set(p.parts) & SECRET_PARTS and p.suffix.lower() not in DENIED_SUFFIXES
                and p.name not in ('auth.json', '.env'), 'forbidden mapped path')
        require(not (under(p, ROOT) and set(p.relative_to(ROOT).parts) & PROJECT_DATA_PARTS),
                'project data mapping denied')
        (deleted if is_deleted else paths).add(value)
    return {'mapped_file_paths': sorted(paths), 'deleted_file_paths': sorted(deleted),
            'maps_bytes': len(raw), 'maps_rows': len(lines), 'maps_sha256': hashlib.sha256(raw).hexdigest(),
            'not_complete_ELF_closure': True}


def runtime_origins(maps_path):
    expected = '/proc/%d/maps' % os.getpid()
    require(str(maps_path) == expected, 'only own process maps allowed')
    # procfs st_size is zero: bounded read-to-EOF, not a stat-sized read.
    with open(expected, 'rb') as stream:
        raw = stream.read(1048577)
    observed = parse_maps(raw)
    modules = {}
    for name, module in list(sys.modules.items()):
        origin = getattr(module, '__file__', None)
        if origin is not None:
            require(len(modules) < 8192 and isinstance(origin, str) and len(origin) <= 4096,
                    'module origin budget/type')
            # Origin strings only; this does not open data or resolve symlinks.
            p = Path(origin)
            require(not set(p.parts) & SECRET_PARTS and p.suffix.lower() not in DENIED_SUFFIXES,
                    'forbidden module origin')
            modules[name] = origin
    observed['module_origins'] = dict(sorted(modules.items()))
    return observed


def metadata_candidate(path):
    """Only direct installed .dist-info text members, not arbitrary package data."""
    try:
        relative = path.relative_to(Path(DEPENDENCY_POLICY['metadata_root']))
    except ValueError:
        return False
    return (len(relative.parts) == 2 and
            re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.+-]*\.dist-info', relative.parts[0]) is not None and
            relative.parts[1] in DEPENDENCY_POLICY['metadata_names'])


def parse_launcher_pid(raw):
    """Exact numeric LF-terminated PID; reject the prior literal-dollar artifact."""
    require(isinstance(raw, bytes) and re.fullmatch(rb'[1-9][0-9]{0,9}\n', raw) is not None,
            'launcher PID must be numeric ASCII plus LF')
    value = int(raw)
    require(value <= 2147483647, 'launcher PID out of range')
    return value
