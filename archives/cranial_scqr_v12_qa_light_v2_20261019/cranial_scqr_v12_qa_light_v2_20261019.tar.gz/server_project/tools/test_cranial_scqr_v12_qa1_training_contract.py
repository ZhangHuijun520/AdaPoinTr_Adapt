"""Pure-text and CPU-only tests for the v1.2 QA-1 training guard."""

from __future__ import annotations

import copy
import hashlib
import json
import tempfile
from pathlib import Path
from types import SimpleNamespace as NS

from tools import cranial_scqr_v12_qa1_training_audit as audit_mod


REPO_ROOT = Path(__file__).resolve().parents[1]
EXPECTED_V11_AUDIT_SHA256 = (
    "b913eab4e5c779dd22adf029d2ed6f97a0f477e96fb090ca6e4d5975c69bd031"
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, payload: dict) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return sha256(path)


def expect_runtime_error(callback, label: str) -> None:
    try:
        callback()
    except RuntimeError:
        return
    raise AssertionError(f"expected RuntimeError: {label}")


class FakeDataset:
    def __len__(self) -> int:
        return audit_mod.EXPECTED_CASES


class FakeLoader:
    dataset = FakeDataset()

    def __len__(self) -> int:
        return audit_mod.EXPECTED_BATCHES


def build_fixture(root: Path):
    audit_mod.REPO_ROOT = root
    (root / "runtime.yaml").write_text("runtime: synthetic\n", encoding="utf-8")
    static_template = root / "static_template.yaml"
    static_template.write_text("candidate: B0\nfold: C\n", encoding="utf-8")
    static_sha = sha256(static_template)

    train_ids = root / "foldC_train_case_ids.txt"
    train_ids.write_text(
        "".join(f"case_{index:03d}\n" for index in range(audit_mod.EXPECTED_CASES)),
        encoding="utf-8",
    )
    train_ids_sha = sha256(train_ids)

    run_key = "B0_foldC_seed0"
    request_path = root / "training_request.json"
    request_sha = write_json(
        request_path,
        {
            "status": "AWAITING_EXPLICIT_USER_AUTHORIZATION",
            "execution_authorized": False,
            "requested_run_keys": [run_key],
            "resource_binding": {
                "deterministic_algorithms": True,
                "tf32": False,
                "cublas_workspace_config": ":4096:8",
            },
            "training_contract": {
                "optimizer_steps": 3939,
                "epoch_traversals": 101,
                "bncal_authorized": False,
                "development_evaluation_authorized": False,
            },
        },
    )
    authorization_path = root / "authorization_receipt.json"
    authorization_sha = write_json(
        authorization_path,
        {
            "status": "AUTHORIZED",
            "execution_authorized": True,
            "authorized_run_keys": [run_key],
            "training_authorized": True,
            "optimizer_steps_authorized": 3939,
            "bncal_authorized": False,
            "development_payload_access_authorized": False,
            "development_evaluation_authorized": False,
            "automatic_rerun_authorized": False,
            "automatic_resume_authorized": False,
            "automatic_next_run_authorized": False,
            "training_request": {
                "path": "training_request.json",
                "sha256": request_sha,
            },
        },
    )
    formal_path = root / "formal_config_protocol.json"
    formal_sha = write_json(
        formal_path,
        {
            "protocol_id": audit_mod.FORMAL_CONFIG_PROTOCOL_ID,
            "status": "FROZEN_IMPLEMENTATION_ONLY",
            "runs": [
                {
                    "run_key": run_key,
                    "candidate": "B0",
                    "model_variant": "B0",
                    "fold": "C",
                    "seed": 0,
                    "lambda_scf": None,
                    "config": "static_template.yaml",
                    "sha256": static_sha,
                }
            ],
        },
    )
    p3_path = root / "post_implementation_p3.json"
    p3_sha = write_json(
        p3_path,
        {
            "status": "PASS_IMPLEMENTATION_ONLY",
            "training_authorized_by_this_receipt": False,
            "bncal_authorized_by_this_receipt": False,
        },
    )

    execution = NS(
        stage=audit_mod.STAGE,
        training_authorized=True,
        optimizer_steps_authorized=3939,
        loader_batches_expected=39,
        epoch_labels_start=0,
        epoch_labels_end=100,
        epoch_traversals_expected=101,
        seed=0,
        gpu_count=1,
        resume_authorized=False,
        bncal_authorized=False,
        development_payload_access_authorized=False,
        development_evaluation_authorized=False,
        automatic_rerun_authorized=False,
        automatic_next_run_authorized=False,
        checkpoint_initial_state="scratch",
        checkpoint_policy="final_only",
        training_request="training_request.json",
        training_request_sha256=request_sha,
        authorization_receipt="authorization_receipt.json",
        authorization_receipt_sha256=authorization_sha,
        formal_config_protocol="formal_config_protocol.json",
        formal_config_protocol_sha256=formal_sha,
        post_implementation_p3_receipt="post_implementation_p3.json",
        post_implementation_p3_sha256=p3_sha,
        static_template="static_template.yaml",
        static_template_sha256=static_sha,
        train_case_ids="foldC_train_case_ids.txt",
        train_case_ids_sha256=train_ids_sha,
    )
    scqr = NS(
        variant="B0",
        enabled=False,
        local_geometry_enabled=False,
        contact_supervision_enabled=False,
        query_conditioning_enabled=False,
        contact_bias_beta=0.0,
        auxiliary_loss_weight=None,
    )
    config = NS(
        cranial_scqr_execution=execution,
        development_protocol=NS(
            candidate="B0",
            fold="C",
            seed=0,
            confirmation_allowed=False,
            old_monitor_allowed=False,
            official_test_allowed=False,
            mug_payload_allowed=False,
            skullfix_payload_allowed=False,
        ),
        qa1_lock=NS(
            run_key=run_key,
            candidate="B0",
            fold="C",
            seed=0,
            train_case_ids="foldC_train_case_ids.txt",
            train_case_ids_sha256=train_ids_sha,
        ),
        model=NS(cranial_scqr=scqr),
        dataset=NS(
            train=NS(
                others=NS(include_case_ids_file="foldC_train_case_ids.txt")
            )
        ),
        optimizer=NS(type="AdamW", kwargs=NS(lr=1.0e-4, weight_decay=5.0e-4)),
        total_bs=8,
        step_per_update=1,
        max_epoch=100,
        grad_norm_clip=10,
        save_best_checkpoint=False,
        save_final_epoch_checkpoints=False,
    )
    args = NS(
        seed=0,
        resume=False,
        start_ckpts=None,
        config=str(root / "runtime.yaml"),
        experiment_path=str(root / "experiment"),
    )
    return args, config, FakeLoader()


def test_valid_and_rejections() -> None:
    with tempfile.TemporaryDirectory(prefix="v12_qa1_guard_") as temporary:
        root = Path(temporary)
        args, config, loader = build_fixture(root)
        result = audit_mod.validate_v12_qa1_training_contract(args, config, loader)
        assert result is config.cranial_scqr_execution

        bad_bncal = copy.deepcopy(config)
        bad_bncal.cranial_scqr_execution.bncal_authorized = True
        expect_runtime_error(
            lambda: audit_mod.validate_v12_qa1_training_contract(
                args, bad_bncal, loader
            ),
            "BNCal must stay false",
        )

        bad_dev = copy.deepcopy(config)
        bad_dev.cranial_scqr_execution.development_payload_access_authorized = True
        expect_runtime_error(
            lambda: audit_mod.validate_v12_qa1_training_contract(
                args, bad_dev, loader
            ),
            "development access must stay false",
        )

        bad_request = copy.deepcopy(config)
        request_path = root / "training_request.json"
        request = json.loads(request_path.read_text(encoding="utf-8"))
        request["requested_run_keys"] = ["B0_foldD_seed0"]
        bad_request.cranial_scqr_execution.training_request_sha256 = write_json(
            request_path, request
        )
        expect_runtime_error(
            lambda: audit_mod.validate_v12_qa1_training_contract(
                args, bad_request, loader
            ),
            "wrong requested run must fail",
        )


def test_step_cap() -> None:
    instance = object.__new__(audit_mod.ScqrV12QA1TrainingAudit)
    instance.enabled = True
    instance.steps = audit_mod.EXPECTED_STEPS - 1
    original_assert = audit_mod.assert_v12_qa1_numeric_policy
    try:
        audit_mod.assert_v12_qa1_numeric_policy = lambda: {}
        instance.authorize_next_step()
    finally:
        audit_mod.assert_v12_qa1_numeric_policy = original_assert
    instance.record_completed_step()
    assert instance.steps == audit_mod.EXPECTED_STEPS
    try:
        audit_mod.assert_v12_qa1_numeric_policy = lambda: {}
        expect_runtime_error(instance.authorize_next_step, "3939-step cap")
    finally:
        audit_mod.assert_v12_qa1_numeric_policy = original_assert


def test_runner_dispatch_and_v11_identity() -> None:
    runner_text = (REPO_ROOT / "tools" / "runner.py").read_text(encoding="utf-8")
    assert "from tools.cranial_scqr_l4_audit import ScqrL4Audit" in runner_text
    assert "ScqrV12QA1TrainingAudit, configure_v12_qa1_numeric_policy" in runner_text
    assert "execution_stage in {'L4_roundA_training', 'V12_QA1_training'}" in runner_text
    assert "if execution_stage == 'V12_QA1_training'" in runner_text
    assert "else ScqrL4Audit(args, config, train_dataloader)" in runner_text
    assert sha256(REPO_ROOT / "tools" / "cranial_scqr_l4_audit.py") == (
        EXPECTED_V11_AUDIT_SHA256
    )


def main() -> None:
    test_valid_and_rejections()
    test_step_cap()
    test_runner_dispatch_and_v11_identity()
    print(
        json.dumps(
            {
                "status": "PASS",
                "tests": 3,
                "real_dataset_constructions": 0,
                "manifest_files_opened": 0,
                "npz_payload_files_opened": 0,
                "checkpoint_files_opened": 0,
                "cuda_calls": 0,
                "optimizer_steps": 0,
                "training_runs": 0,
                "bncal_runs": 0,
                "development_evaluations": 0,
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
