"""R1-B pure-text guards and one-case access state machine (no torch import)."""

import csv
import hashlib
import json
import math
import socket
import stat
from pathlib import Path


PROTOCOL_SHA = "30eeb37fcc6e0172849c5dd4a5a457180d59b9cc0e521a9234b81158bc88b035"
SCHEMA = "cranial-scqr-v1.2-RSD-R1B-fold-request-v1"
CONDITIONS = ("LS_native", "LSQ_native", "LSQ_query_off")
DEFECTS = ("bilateral", "frontoorbital", "parietotemporal", "random_1", "random_2")
CONTINUOUS = (
    "implant_cd_l1_mm", "implant_pred_to_ref_mean_mm", "implant_ref_to_pred_mean_mm",
    "implant_hd95_mm", "implant_nsd_at_1mm", "final_cd_l1_mm", "final_hd95_mm",
    "final_nsd_at_1mm", "rim_gt_rim_to_pred_mean_mm", "rim_gt_rim_to_pred_p95_mm",
    "rim_contact_cd_l1_mm", "rim_contact_hd95_mm", "rim_contact_precision", "rim_contact_recall",
)
EXACT_METRICS = ("rim_reference_rim_points", "rim_predicted_rim_points", "zero_contact_2mm", "disaster")
CORE = ("implant_cd_l1_mm", "implant_hd95_mm", "final_cd_l1_mm", "final_hd95_mm", "rim_gt_rim_to_pred_p95_mm")
CHECKPOINT_SHA = {
    "LS_foldC_seed0": "47d21ab4e5e577515eec314b21695166c5af0fa3c02ed29c9756fe85f80cbb7e",
    "LS_foldD_seed0": "bdc2bf228e9aa57bcad58f2aecf06481aab367f308a6cae9629ba91462ca9c57",
    "LSQ_foldC_seed0": "5c2f39f029b019843ae403103933d93b6061f127ac1a95d355940e8eb6a3befa",
    "LSQ_foldD_seed0": "71da7f3b68c3dc5b97aba4530480cc9e7622b75e74b1802f2200dce99bf788ad",
}
FROZEN_REFERENCE_SHA = {
    "LS_foldC_seed0": "444fccc60f67b8773b07eca7d84d721f39b69e60fc0e15ae03a3d2b19e18fed3",
    "LS_foldD_seed0": "5c0bd80f45047132c813fcf702008c70d91036963f7553953e9d52902d3fc34a",
    "LSQ_foldC_seed0": "3c951a9b58288eb5c96216fe47d6a6beb9a2b9bad6f51820e86fa09251cfb78c",
    "LSQ_foldD_seed0": "04423809048e28700d7458407f38bb75e982b40c7c34870cadf835a0cee8482c",
}
IMMUTABLE_SOURCES = {
    "models/cranial_scqr/query_conditioning.py": "e631f6649b3a218e63c39f15f6232607469106ae63b0c7cdf578636b110d9057",
    "tools/run_cranial_scqr_v12_qa1_development_eval.py": "5d3e92094cc1eeec8788dbec4543735d95947dcbdd0449541516242dcad5d808",
    "tools/run_cranial_scqr_v11_l4_round_a_dev_eval.py": "6be1c38b46270eff278ea7a54805ba0d572e8aef81a103350308072380c38798",
    "utils/skullfix_metrics.py": "0c4342cd19fb19a659302b0e350c3be34bd21447d2034bdc9d2e81a180174ee5",
}
FALSE_PERMISSIONS = (
    "training", "bncal", "automatic_retry", "resume", "automatic_next_fold",
    "formal_gate", "bootstrap", "predictions_saved", "train", "other_fold",
    "confirmation20", "official_test", "old_monitor", "MUG", "SkullFix",
)


class ContractError(RuntimeError):
    pass


def require(ok, message):
    if not ok:
        raise ContractError(message)


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def checked_path(root, relative):
    relative = Path(relative)
    require(not relative.is_absolute() and relative.parts and ".." not in relative.parts, "unsafe relative binding")
    root = Path(root).absolute()
    # Reject links at every component, including ancestors of the project root.
    cursor = Path(root.anchor)
    for part in root.parts[1:] + relative.parts:
        cursor = cursor / part
        require(not cursor.is_symlink(), "linked path: " + str(cursor))
    require(cursor.is_file(), "missing regular file: " + str(cursor))
    require(cursor.resolve().is_relative_to(root.resolve()), "binding escapes project")
    return cursor


def bound_path(root, binding, *, verify=True):
    path = checked_path(root, binding["path"])
    before = path.stat()
    require(stat.S_ISREG(before.st_mode), "nonregular binding")
    if verify:
        require(before.st_size == binding["bytes"], "bound byte count mismatch")
        require(sha256_file(path) == binding["sha256"], "bound SHA256 mismatch")
    after = path.stat()
    require((before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
            (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), "binding changed during read")
    return path


def validate_legacy_request(request):
    require(request.get("schema") == SCHEMA, "R1-B request schema mismatch")
    require(request.get("status") == "AWAITING_EXPLICIT_USER_AUTHORIZATION", "request status")
    require(request.get("execution_authorized") is False, "request may not self-authorize")
    require(request.get("protocol_sha256") == PROTOCOL_SHA, "protocol SHA mismatch")
    require(request.get("fold") in ("C", "D") and type(request.get("seed")) is int and request["seed"] == 0, "fold/seed")
    require(request.get("conditions") == list(CONDITIONS), "condition order")
    for name in FALSE_PERMISSIONS:
        require(request.get("permissions", {}).get(name) is False, "forbidden or unspecified permission: " + name)
    require(all(type(v) is int for v in request.get("budget", {}).values()), "budget counts must be integers")
    require(request.get("budget") == {
        "cases": 105, "forwards": 315, "npz_opens": 105, "checkpoint_loads": 2, "checkpoint_hash_verifications": 4,
        "member_partial": 105, "member_implant": 105, "member_gt": 105,
        "optimizer_steps": 0, "parameter_updates": 0, "buffer_updates": 0,
        "bncal_forwards": 0,
    }, "R1-B budget mismatch")
    require(request.get("forward_epoch", "MISSING") is None, "native epoch must remain None (warmup=1)")
    require(request.get("rng_contract") == "candidate-isolated-native-progression-v1", "RNG contract")
    require(request.get("empty_contact_policy") == "STOP_KEEP_ORIGINAL_FLAGS", "empty contact policy")
    require(request.get("output_limit_bytes") == 16 * 1024 * 1024, "output budget")
    require(type(request.get("max_wall_seconds")) is int and request["max_wall_seconds"] > 0, "wall-time budget missing")
    require(type(request.get("max_vram_mib")) is int and 0 < request["max_vram_mib"] < 24576, "VRAM budget missing")
    environment = request.get("environment_contract", {})
    for name in ("python_version", "torch_version", "numpy_version", "scipy_version", "cuda_version", "gpu_driver"):
        require(isinstance(environment.get(name), str) and environment[name], "environment version missing: " + name)
    require(type(environment.get("cudnn_version")) is int and environment["cudnn_version"] > 0 and environment.get("cpu_threads") == 1,
            "cuDNN/thread contract")
    require(isinstance(environment.get("binary_bindings"), list) and environment["binary_bindings"] and
            isinstance(environment.get("extension_source_bindings"), list) and environment["extension_source_bindings"], "extension source/binary hashes missing")
    require(request.get("data_root") == "/home/jovyan/datasets/SkullBreakPC_out8192", "data root")
    require(request.get("resource", {}).get("hostname") == socket.gethostname(), "resource hostname mismatch")
    require(isinstance(request.get("resource", {}).get("gpu_uuid"), str) and request["resource"]["gpu_uuid"].startswith("GPU-"), "GPU resource binding")
    require(set(request.get("models", {})) == {"LS", "LSQ"}, "exactly two frozen models")
    for candidate, model in request["models"].items():
        run = candidate + "_fold" + request["fold"] + "_seed0"
        require(model.get("run_key") == run, "model run key")
        require(model.get("checkpoint", {}).get("sha256") == CHECKPOINT_SHA[run], "checkpoint matrix changed")
        require(model.get("reference_csv", {}).get("sha256") == FROZEN_REFERENCE_SHA[run], "native CSV changed")
    require(isinstance(request.get("implementation_bindings"), list) and request["implementation_bindings"], "implementation bindings missing")
    by_path = {b["path"]: b["sha256"] for b in request["implementation_bindings"]}
    require(len(by_path) == len(request["implementation_bindings"]), "duplicate implementation binding")
    for name, digest in IMMUTABLE_SOURCES.items():
        require(by_path.get(name) == digest, "immutable source binding: " + name)
    for name in ("models/AdaPoinTr.py", "models/cranial_scqr/rsd_query_bypass.py",
                 "tools/cranial_scqr_v12_rsd_r1b_contract.py", "tools/run_cranial_scqr_v12_rsd_r1b.py"):
        require(name in by_path, "new implementation unbound: " + name)


def validate_chain(request, authorization, runtime, request_sha, auth_sha):
    validate_request(request)
    require(authorization.get("status") == "AUTHORIZED_ONCE" and authorization.get("execution_authorized") is True, "execution not authorized")
    require(authorization.get("request_sha256") == request_sha and authorization.get("request_id") == request.get("request_id"), "authorization request binding")
    require(authorization.get("fold") == request["fold"], "authorization fold")
    for name in FALSE_PERMISSIONS:
        require(authorization.get("permissions", {}).get(name) is False, "authorization permission: " + name)
    require(not any("runtime" in key for key in authorization), "reverse runtime binding forbidden")
    require(runtime == {
        "stage": "V12_RSD_R1B_SAME_PROCESS_PAIRED_FOLD", "request_sha256": request_sha,
        "authorization_receipt_sha256": auth_sha, "fold": request["fold"],
        "runs_authorized": 1,
    }, "runtime single-way binding mismatch")


def validate_legacy_tolerances(value):
    require(value.get("status") == "FROZEN_CONFIRMED_BEFORE_DEV", "replay tolerance not frozen/confirmed")
    require(value.get("basis_scope") == "ARTIFICIAL_ONLY", "first-round tolerances require artificial-only evidence")
    require(value.get("rule") == "abs_difference <= atol + rtol * abs(reference)", "tolerance rule")
    fields = value.get("fields", {})
    require(set(fields) == set(CONTINUOUS), "every continuous metric must have a tolerance")
    for tolerances in fields.values():
        require(set(tolerances) == {"atol", "rtol"}, "tolerance fields")
        for number in tolerances.values():
            require(type(number) in (int, float) and math.isfinite(number) and number >= 0, "invalid tolerance")


def assert_native_replay(observed, reference, tolerances):
    validate_tolerances(tolerances)
    for name in ("case_id", "source_skull_id", "skull_id", "defect_type", "fold", "seed"):
        require(str(observed[name]) == str(reference[name]), "native identity mismatch: " + name)
    for name in EXACT_METRICS:
        require(float(observed[name]) == float(reference[name]), "native count/flag mismatch: " + name)
    for name in CONTINUOUS:
        actual, expected = float(observed[name]), float(reference[name])
        require(math.isfinite(actual) and math.isfinite(expected), "nonfinite native field: " + name)
        t = tolerances["fields"][name]
        if not abs(actual - expected) <= t["atol"] + t["rtol"] * abs(expected):
            raise ContractError(json.dumps({"error": "native replay tolerance exceeded",
                "case_id": observed["case_id"], "condition": observed.get("condition"),
                "field": name, "reference": expected, "observed": actual,
                "absolute_difference": abs(actual-expected), "atol": t["atol"], "rtol": t["rtol"]},
                sort_keys=True, allow_nan=False))


def audit_metric_flags(row):
    for name in EXACT_METRICS:
        number = float(row[name])
        require(math.isfinite(number) and number == int(number) and number >= 0, "noninteger count/flag")
    core_nonfinite = [name for name in CORE if not math.isfinite(float(row[name]))]
    hd = float(row["rim_contact_hd95_mm"])
    expected = int(bool(core_nonfinite) or (math.isfinite(hd) and hd > 50.0))
    require(int(row["disaster"]) == expected, "disaster flag mismatch")
    require(int(row["zero_contact_2mm"]) == int(int(row["rim_predicted_rim_points"]) == 0), "zero flag mismatch")
    require(not core_nonfinite, "nonfinite core stopped")
    require(int(row["rim_reference_rim_points"]) > 0 and int(row["rim_predicted_rim_points"]) > 0,
            "R1B_NONFINITE_CONTACT_OR_EMPTY_FOOTPRINT")
    require(all(math.isfinite(float(row[name])) for name in CONTINUOUS), "nonfinite metric stopped")


class AccessLedger:
    """Count attempts before effects, completions after; stop has no retry API."""

    def __init__(self, case_ids, fold):
        require(fold in ("C", "D"), "ledger fold")
        require(len(case_ids) == 105 and len(set(case_ids)) == 105, "105 unique cases required")
        self.case_ids, self.fold = tuple(case_ids), fold
        self.counts = dict(checkpoint_loads=0, checkpoint_hash_verifications=0, npz_open_events=0, member_partial=0,
                           member_implant=0, member_gt=0, forward_attempts=0,
                           model_case_forward_calls=0, optimizer_steps=0,
                           parameter_updates=0, buffer_updates=0, bncal_forwards=0)
        self.loaded = set()
        self.closed = 0
        self.active = None
        self.members = set()
        self.completed = []
        self.pending = None
        self.failed = False

    def _require(self, condition, message):
        if self.failed or not condition:
            self.failed = True
            raise ContractError(message)

    def record_checkpoint_load(self, run_key):
        allowed = {c + "_fold" + self.fold + "_seed0" for c in ("LS", "LSQ")}
        self._require(run_key in allowed and run_key not in self.loaded and self.active is None, "checkpoint load budget/order")
        self.loaded.add(run_key)
        self.counts["checkpoint_loads"] += 1

    def record_checkpoint_hash(self):
        self._require(self.active is None and self.counts["checkpoint_hash_verifications"] < 4,
                      "checkpoint byte verification budget/order")
        self.counts["checkpoint_hash_verifications"] += 1

    def begin_case(self, case_id):
        self._require(self.active is None and self.closed < 105 and len(self.loaded) == 2 and
                      case_id == self.case_ids[self.closed], "case order/duplicate/allowlist")
        self.active, self.members, self.completed = case_id, set(), []
        self.counts["npz_open_events"] += 1

    def read_member(self, member):
        self._require(self.active is not None and member in ("partial", "implant", "gt") and
                      member not in self.members, "forbidden/duplicate member")
        if member == "partial":
            self._require(not self.completed and self.pending is None, "partial timing")
        else:
            self._require(self.completed == list(CONDITIONS) and self.pending is None, "GT must follow three successful forwards")
        self.members.add(member)
        self.counts["member_" + member] += 1

    def begin_forward(self, condition):
        self._require(self.active is not None and "partial" in self.members and self.pending is None and
                      len(self.completed) < 3 and condition == CONDITIONS[len(self.completed)] and
                      self.counts["forward_attempts"] < 315, "forward condition/order/budget")
        self.pending = condition
        self.counts["forward_attempts"] += 1

    def end_forward(self):
        self._require(self.pending is not None, "forward completion without attempt")
        self.completed.append(self.pending)
        self.pending = None
        self.counts["model_case_forward_calls"] += 1

    def end_case(self):
        self._require(self.members == {"partial", "implant", "gt"} and self.completed == list(CONDITIONS) and self.pending is None, "incomplete case")
        self.closed += 1
        self.active = None

    def assert_final(self):
        self._require(self.closed == 105 and self.active is None, "incomplete fold")
        expected = {"checkpoint_loads": 2, "checkpoint_hash_verifications": 4, "npz_open_events": 105, "member_partial": 105,
                    "member_implant": 105, "member_gt": 105, "forward_attempts": 315,
                    "model_case_forward_calls": 315, "optimizer_steps": 0,
                    "parameter_updates": 0, "buffer_updates": 0, "bncal_forwards": 0}
        self._require(self.counts == expected, "final ledger mismatch")


def read_native_csv(path, case_ids):
    with Path(path).open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    require(len(rows) == 105 and [row["case_id"] for row in rows] == list(case_ids), "native CSV order/cardinality")
    for row in rows:
        require(all(key in row and row[key] not in (None, "") for key in
                    ("case_id", "source_skull_id", "skull_id", "defect_type", "fold", "seed")),
                "historical reference identity missing")
        require(row["fold"] == "D" and str(row["seed"]) == "0" and
                row["defect_type"] in DEFECTS, "historical reference fold/seed/defect")
        audit_metric_flags(row)
    return {row["case_id"]: row for row in rows}


# Fixed v7 evidence identities; no runtime file reads at import.
LEGACY_MAP = json.loads("{\"models/AdaPoinTr.py\":\"06fafe4fb9a7a2d9d3d8c4c50ca44ddcec6c1935eb6630737d70fceaf4aced1d\",\"models/cranial_scqr/query_conditioning.py\":\"e631f6649b3a218e63c39f15f6232607469106ae63b0c7cdf578636b110d9057\",\"models/cranial_scqr/rsd_query_bypass.py\":\"c4b55acfdaa41127b7f1c34b62af5b5ce68f70f8b198390dce05eff9ae98591c\",\"tools/cranial_scqr_v12_rsd_r1b_contract.py\":\"ba5379efc48aa9bf420041e196e18ed6c322491cd3b176e07d5199c12f5230e0\",\"tools/run_cranial_scqr_v11_l4_round_a_dev_eval.py\":\"6be1c38b46270eff278ea7a54805ba0d572e8aef81a103350308072380c38798\",\"tools/run_cranial_scqr_v12_qa1_development_eval.py\":\"5d3e92094cc1eeec8788dbec4543735d95947dcbdd0449541516242dcad5d808\",\"tools/run_cranial_scqr_v12_rsd_r1b.py\":\"8423a8496ec26810a1503443aaf26e66b2d3d042b185447c201284612afb34e0\",\"tools/test_cranial_scqr_v12_rsd_r1b_contract.py\":\"3e3b4506ffaac5f8daedee61d43f35100f018ab24375d87e684a73a9d96f83c6\",\"utils/skullfix_metrics.py\":\"0c4342cd19fb19a659302b0e350c3be34bd21447d2034bdc9d2e81a180174ee5\"}")
RESOURCE = json.loads("{\"hostname\":\"shu-common-25721452-notebook-hwq6lx-0\",\"user\":\"jovyan\",\"python_executable\":\"/opt/conda/envs/adapointr-mamba/bin/python\",\"python_realpath\":\"/opt/conda/envs/adapointr-mamba/bin/python3.10\",\"python_version\":\"3.10.20\",\"python_binary_sha256\":\"01b4275dc374dcae51d245bda004daad6d7882d3f5de7f9852567bb7ab83180d\",\"package_metadata_versions\":{\"torch\":\"2.4.1+cu118\",\"numpy\":\"2.2.6\",\"scipy\":\"1.15.3\",\"timm\":\"1.0.27\",\"einops\":\"0.8.2\",\"PyYAML\":\"6.0.3\",\"easydict\":\"1.13\",\"matplotlib\":\"3.10.9\",\"torchvision\":\"0.19.1+cu118\",\"nvidia-cudnn-cu11\":\"9.1.0.70\"},\"gpu_count\":1,\"gpu_index\":0,\"device\":\"cuda:0\",\"gpu_name\":\"NVIDIA GeForce RTX 4090 D\",\"gpu_uuid\":\"GPU-34a1b996-2bd7-88e6-9dca-164b718caea6\",\"gpu_memory_total_mib\":24564,\"driver_version\":\"570.190\",\"cuda_runtime_expected_from_torch_metadata\":\"11.8\",\"cudnn_runtime_observed\":true,\"minimum_free_gpu_memory_mib_at_launch\":22000,\"minimum_free_disk_bytes_at_launch\":2147483648,\"maximum_peak_allocated_mib\":20000,\"maximum_peak_reserved_mib\":20000,\"maximum_walltime_seconds\":600,\"require_no_other_compute_pid\":true,\"require_gpu_utilization_zero_before_launch\":true,\"recheck_before_launch\":true,\"drift_policy\":\"STOP_RESOURCE_REBIND_AND_NEW_REQUEST_NOT_SILENT_UPDATE\",\"cuda_runtime_observed_in_CPU_load\":true,\"cuda_device_total_memory_bytes\":25261047808}")
COUNTS = json.loads("{\"model_constructions\":2,\"full_model_forward_attempts\":8,\"full_model_forward_completions\":8,\"ls_full_forwards\":2,\"lsq_full_forwards\":6,\"standalone_select_rsd_queries_calls\":8,\"full_forward_lsq_conditioner_calls\":6,\"traced_full_forward_lsq_query_outlet_calls\":4,\"full_forward_ls_query_conditioner_calls\":0,\"real_payload_reads\":0,\"real_checkpoint_byte_reads\":0,\"checkpoint_deserializations\":0,\"checkpoint_writes\":0,\"optimizer_constructions\":0,\"optimizer_steps\":0,\"loss_calls\":0,\"backward_calls\":0,\"training_forwards\":0,\"bncal_forwards\":0,\"parameter_updates_after_initial_construction\":0,\"buffer_updates_after_initial_construction\":0,\"development_evaluation_forwards\":0,\"extra_warmup_forwards\":0,\"formal_timing_iterations\":0}")
PROVIDER_BINDINGS = json.loads("[{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/__init__.py\",\"bytes\":123,\"sha256\":\"d8a0921aeb90349a0659799a22ccf00ccd31707b226426ff4118eeb65ae0ada2\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext.cpython-310-x86_64-linux-gnu.so\",\"bytes\":301640,\"sha256\":\"e70d00108bacba4a905dc011f4b8c4868f06ec2d44d8e322148e2e452578fbb5\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_version.py\",\"bytes\":22,\"sha256\":\"10f9a05ce7562a4b394bffd9307ecdbbac6901e56b6697f1685cb8a7292ec9e2\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/pointnet2_modules.py\",\"bytes\":6530,\"sha256\":\"3c8e6570ce7dcf56e25870fc2888fc13bbc0a592ea25bf66382ecd3256e633e4\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/pointnet2_utils.py\",\"bytes\":9943,\"sha256\":\"ec597d77b1215fbc87bdb452b8ce04b85eb0b816d5e39e7696fc792a2f61ea5b\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext-src/include/ball_query.h\",\"bytes\":163,\"sha256\":\"595e651f7ac88e14248199cba61e9d0ddd3e18f8535e1ce38d471b30a246427a\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext-src/include/cuda_utils.h\",\"bytes\":1303,\"sha256\":\"de26c10e6748e61da7f6516863f2a20d923ccd78e539efdfe18db8a0aeb0a288\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext-src/include/group_points.h\",\"bytes\":183,\"sha256\":\"e702934ff68b3030b052af38b469f00786ea7b3620e017ef58bcc4cf5f0d6325\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext-src/include/interpolate.h\",\"bytes\":386,\"sha256\":\"9d96cc311411e9e95cc03e47ea6d63269a1b888342d54d074348b967c96d07c8\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext-src/include/sampling.h\",\"bytes\":260,\"sha256\":\"e1b919a8bacf4c077dff6d86d2226df4eeb041e5d135be2a2d829c5de933d068\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext-src/include/utils.h\",\"bytes\":983,\"sha256\":\"e0f94d69288a2010d12aa35494f127b7e3dccd154d9aebdecef84f05a6fc6fbe\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext-src/src/ball_query.cpp\",\"bytes\":1037,\"sha256\":\"ff4b6076cfc3299faed905927391144511fdbfe807b14ae2970f26c1756f6aaa\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext-src/src/ball_query_gpu.cu\",\"bytes\":1784,\"sha256\":\"7253c10da9db4b02d25e43b7a713ee956dae27b4ec25220f1b2abbaccc79530f\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext-src/src/bindings.cpp\",\"bytes\":570,\"sha256\":\"542241ad191246365594c3861e93b1e1d625fb0fd1fd95eec113fed98c66d8b5\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext-src/src/group_points.cpp\",\"bytes\":1952,\"sha256\":\"c8079fe09e1a35a6142545f3277c71c483b54e19653930378e2f2f1d3b9d7971\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext-src/src/group_points_gpu.cu\",\"bytes\":2885,\"sha256\":\"cf0bc3c20f709ed5be113c5d2618d3d61dcc49fb2449d53323596c5d1d4857fb\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext-src/src/interpolate.cpp\",\"bytes\":3304,\"sha256\":\"0fb9ca45eb12d9998618b69d42272f6a58814437a1a2803941e6b496944411a1\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext-src/src/interpolate_gpu.cu\",\"bytes\":5141,\"sha256\":\"e4a327f15d49bcefe62bd72adc407157f97039c3b34037f8fc767b9a15936173\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext-src/src/sampling.cpp\",\"bytes\":2894,\"sha256\":\"eb800bdb22cc5b2a3742eae1c125cd6883969c329a3e36c8c4d3d9de98246312\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops/_ext-src/src/sampling_gpu.cu\",\"bytes\":7019,\"sha256\":\"a1ec92aabdb6e4ab3ad0b982ebb28fa79b1b1fc95e3accbfaa511ef9bc317fe4\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops-3.0.0.dist-info/METADATA\",\"bytes\":94,\"sha256\":\"588c437f21aac8ce2ee5a7428f6e8ca86b4ebb1dcd438e02999c84b0b98be4c6\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops-3.0.0.dist-info/WHEEL\",\"bytes\":104,\"sha256\":\"2a82caad1e573e5d036e9be26a7b0fdd6e63bf3d0faf62a4005331c0752301bc\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops-3.0.0.dist-info/top_level.txt\",\"bytes\":14,\"sha256\":\"b88f822efaefe234d87a8ad854c64138ae3bf1be98d3149bbbb1a29670253126\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops-3.0.0.dist-info/RECORD\",\"bytes\":2255,\"sha256\":\"3c4bfb6ca2ea246709eb0d0d3421140241cee9af23cf4ee16e80b822a9c3a415\"},{\"path\":\"third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/wheelhouse/pointnet2_ops-3.0.0-cp310-cp310-linux_x86_64.whl\",\"bytes\":123291,\"sha256\":\"530496a0d1d5dea6151a466b7c0874632322223308a7016910fb1bfbaaaab1e5\"}]")
PROJECT_BINDINGS = json.loads("[{\"path\":\"models/AdaPoinTr.py\",\"bytes\":103580,\"sha256\":\"06fafe4fb9a7a2d9d3d8c4c50ca44ddcec6c1935eb6630737d70fceaf4aced1d\"},{\"path\":\"models/FoldingNet.py\",\"bytes\":3363,\"sha256\":\"5ec33fdf99814e2af67604443f355bb3b3ab20066bf09e0bf93206f4251cd0ff\"},{\"path\":\"models/GRNet.py\",\"bytes\":8880,\"sha256\":\"d3f76e7009971f5822d4942627f701aeaa59062db984bb0d5e0d1de5797c4f87\"},{\"path\":\"models/PCN.py\",\"bytes\":3347,\"sha256\":\"11688aaea4bcbe33d0bec95f16440e4d22e48938e4e051c17fc72cd0b8ff8143\"},{\"path\":\"models/PoinTr.py\",\"bytes\":4816,\"sha256\":\"cb479819c42cf9215e815cd8146b84074718f075e178847691b2b2b388c8f5d5\"},{\"path\":\"models/SnowFlakeNet.py\",\"bytes\":11186,\"sha256\":\"31f5cf75828cb74be5cd77199833033fc9b26bbef8b487c09e2cbe9ac1970ac6\"},{\"path\":\"models/SnowFlakeNet_utils.py\",\"bytes\":15721,\"sha256\":\"3e51b3025008c66ea3e74d6c0e558c39b4bc8ded5d0677dca0691ec86d9f2d4d\"},{\"path\":\"models/TopNet.py\",\"bytes\":4366,\"sha256\":\"49a1e24cc715b6f9bdae604a9c90d053e34ed1822548965e9c01b6cbc9944c31\"},{\"path\":\"models/Transformer.py\",\"bytes\":16797,\"sha256\":\"69ef466e1102fc95c29cb0d83468fae1542dbb15ef59442e1fdbbfa3965e0f98\"},{\"path\":\"models/Transformer_utils.py\",\"bytes\":52824,\"sha256\":\"9f272b42ce3374dd70b37a3758d26584801680e947a5bdd93b22faf9f3d086b4\"},{\"path\":\"models/__init__.py\",\"bytes\":427,\"sha256\":\"72e5306c514605a1d05ae38c90b879d20103cd90f079286ec8988d9097fdd3d1\"},{\"path\":\"models/build.py\",\"bytes\":342,\"sha256\":\"9c85271220ba992d56d4285b1ef51de939f7471b0712028af8d07880fed9680f\"},{\"path\":\"models/dgcnn_group.py\",\"bytes\":5008,\"sha256\":\"4503abfdc2350451ce51dd1dd8c9089c21c996781978085f603d39937e48caee\"},{\"path\":\"models/cranial_scqr/__init__.py\",\"bytes\":5693,\"sha256\":\"d2d85b33cff9689dd06f2c2a0845a6aebccba03b6e706904afc8f4d97851cc5b\"},{\"path\":\"models/cranial_scqr/contact_support.py\",\"bytes\":6570,\"sha256\":\"358ea31017344fa4905aac7e495dc87ed7f74496954fd34d7390cd0ea579028f\"},{\"path\":\"models/cranial_scqr/local_geometry.py\",\"bytes\":6255,\"sha256\":\"b533efead76c38ff7bc83a5245a88c98e275a37e0523cbbfb793a63b4d645665\"},{\"path\":\"models/cranial_scqr/query_conditioning.py\",\"bytes\":4610,\"sha256\":\"e631f6649b3a218e63c39f15f6232607469106ae63b0c7cdf578636b110d9057\"},{\"path\":\"models/cranial_scqr/rsd_query_bypass.py\",\"bytes\":3369,\"sha256\":\"c4b55acfdaa41127b7f1c34b62af5b5ce68f70f8b198390dce05eff9ae98591c\"},{\"path\":\"utils/config.py\",\"bytes\":2429,\"sha256\":\"2058b26feff2e513f3f9d9d0d350ebce13f5035d94b4ef5e3ef27a8142578a91\"},{\"path\":\"utils/dist_utils.py\",\"bytes\":1529,\"sha256\":\"e42b975951df9af48050e33f99a31525201f2005d12d749a040d898a5e786446\"},{\"path\":\"utils/logger.py\",\"bytes\":5048,\"sha256\":\"12e50962ca4594ddd573d9a76524ac912ddf55bfc297fa8008a30b20dca28e0c\"},{\"path\":\"utils/misc.py\",\"bytes\":12202,\"sha256\":\"4f04379f07e192ed0f47030a08f9bd03dbc2024116d5fc99f549c3548a2bbef6\"},{\"path\":\"utils/pointnet2_utils.py\",\"bytes\":4170,\"sha256\":\"6c31da5fbe57cb06a7f6107dd90e9f30d66ba534447cd238acb27bd872ce1e8e\"},{\"path\":\"utils/registry.py\",\"bytes\":11111,\"sha256\":\"a7c49418d587ae84778390b67a50c2bd98cbc93da2e0a506e6d309b5c159ecf7\"},{\"path\":\"utils/skullfix_metrics.py\",\"bytes\":9242,\"sha256\":\"0c4342cd19fb19a659302b0e350c3be34bd21447d2034bdc9d2e81a180174ee5\"},{\"path\":\"extensions/chamfer_dist/__init__.py\",\"bytes\":6449,\"sha256\":\"af9e43582b034dd9e62da8e4774b8953702562b288f41286c29525173019b423\"},{\"path\":\"extensions/gridding/__init__.py\",\"bytes\":2601,\"sha256\":\"fa02fd8c13fbf7b12c0d60d5afc6467c71b50bab19959773dafad82fcafc71ab\"},{\"path\":\"extensions/cubic_feature_sampling/__init__.py\",\"bytes\":1726,\"sha256\":\"105c1cc3f448ecbec37a64cd64d0839b7a7052d8645a3e76b41ba6b7fbd1dbb9\"},{\"path\":\"extensions/gridding_loss/__init__.py\",\"bytes\":5011,\"sha256\":\"de0d7797aa23d06077d9c92eeb4a5930d2ada88063ebeddc3fa19a8fe430b14d\"},{\"path\":\"tools/cranial_scqr_v12_rsd_r1b_contract.py\",\"bytes\":15431,\"sha256\":\"ba5379efc48aa9bf420041e196e18ed6c322491cd3b176e07d5199c12f5230e0\"},{\"path\":\"tools/run_cranial_scqr_v12_rsd_r1b.py\",\"bytes\":25934,\"sha256\":\"8423a8496ec26810a1503443aaf26e66b2d3d042b185447c201284612afb34e0\"},{\"path\":\"tools/test_cranial_scqr_v12_rsd_r1b_contract.py\",\"bytes\":19651,\"sha256\":\"3e3b4506ffaac5f8daedee61d43f35100f018ab24375d87e684a73a9d96f83c6\"},{\"path\":\"tools/run_cranial_scqr_v11_l4_round_a_dev_eval.py\",\"bytes\":32853,\"sha256\":\"6be1c38b46270eff278ea7a54805ba0d572e8aef81a103350308072380c38798\"},{\"path\":\"tools/run_cranial_scqr_v12_qa1_development_eval.py\",\"bytes\":34243,\"sha256\":\"5d3e92094cc1eeec8788dbec4543735d95947dcbdd0449541516242dcad5d808\"},{\"path\":\"utils/mamba_d22_geometry.py\",\"bytes\":12174,\"sha256\":\"06a962d651f742b7bd5d862e687e5fe78e2a81910bee8d79487095be8fbca111\"},{\"path\":\"utils/mamba_d3_contact.py\",\"bytes\":10746,\"sha256\":\"cd571985e9e1f135b912e649784635e1c9321b61edf454f948d00ccb89ef9972\"}]")
NUMERICAL = json.loads("{\"deterministic_algorithms\":true,\"warn_only\":false,\"cudnn_deterministic\":true,\"cudnn_benchmark\":false,\"matmul_allow_tf32\":false,\"cudnn_allow_tf32\":false,\"float32_matmul_precision\":\"highest\",\"CUBLAS_WORKSPACE_CONFIG\":\":4096:8\",\"OMP_NUM_THREADS\":\"1\",\"MKL_NUM_THREADS\":\"1\",\"torch_num_threads\":1,\"torch_num_interop_threads\":1}")

V7_SHA = "9b845598585aa594e80e2cf087b4ce41b7069e32bbc844f4da16f0e72719d1a9"
AUDIT_SHA = "3163a04f3f1541c19e1e606bd33aa4d4cfac4285e7da9d7e4ec30fc2fbb81cac"
PLAN_SHA = "c023b25ac428f53d54ab0658586299b4db0197c5024cbdbf5697c08a331763c4"
DRAFT_SHA = "1934e05501f4f78587a7c8e0ab0d148bd0051f8762c140acf30ab16be02dfcdf"
SHARED = tuple(p for p in LEGACY_MAP if p.startswith("models/") or p.startswith("utils/") or
               p in ("tools/run_cranial_scqr_v11_l4_round_a_dev_eval.py", "tools/run_cranial_scqr_v12_qa1_development_eval.py"))
ENTRY_NAMES = ("tools/cranial_scqr_v12_rsd_r1b_contract_foldD_v1.py",
               "tools/run_cranial_scqr_v12_rsd_r1b_foldD_v1.py",
               "tools/test_cranial_scqr_v12_rsd_r1b_entry_foldD_v1.py")
RESULT_RELATIVE = "logs/cranial_scqr_v12_rsd_r1b/synthetic_gpu_preflight_minimal_v7_20261018/result"
PROVIDER_RELATIVE = "third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider"


def binding_map(bindings):
    require(isinstance(bindings, list), "binding list missing")
    result = {}
    for b in bindings:
        require(b["path"] not in result and type(b["bytes"]) is int and b["bytes"] > 0, "duplicate/empty binding")
        require(len(b["sha256"]) == 64 and all(ch in "0123456789abcdef" for ch in b["sha256"]), "invalid SHA")
        result[b["path"]] = b["sha256"]
    return result


def validate_request(request):
    require(request.get("schema") == "cranial-scqr-v1.2-RSD-R1B-fold-request-v3", "v3 schema required")
    legacy = dict(request, schema=SCHEMA)
    validate_legacy_request(legacy)
    require(request["fold"] == "D", "this entry is Fold D only")
    require(request.get("historical_policy") == "REPORT_EXACT_DIFFERENCES_NOT_PAIRED_STOP", "historical policy")
    require(request.get("supplement", {}).get("sha256") == SUPPLEMENT_SHA, "supplement binding")
    require(request.get("prior_exposure") == FOLD_D_EXPOSURE, "prior exposure/accounting")
    require(request.get("allowlist", {}).get("sha256") ==
            "7afc9edc6654891cc8593ab2ce172657e1227e4583ed3281b159ab3ae2be68ac",
            "Fold D allowlist binding")
    require(request.get("request_id") not in ("r1b_foldC_seed0_real_intervention_v1_20261019",
            "r1b_paired_foldC_seed0_v1_20261019"),
            "consumed request identity")
    require(request.get("output_relative", "").startswith(
            "logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldD_seed0_"), "new branch namespace")
    require(binding_map(request["implementation_bindings"]) == LEGACY_MAP, "legacy nine bindings changed")
    require(set(binding_map(request["entry_bindings"])) == set(ENTRY_NAMES), "exact three entry bindings required")
    require(request["max_wall_seconds"] == 7200 and request["max_vram_mib"] == 20000, "resource budget drift")
    require(request["resource"] == {"hostname": RESOURCE["hostname"], "gpu_uuid": RESOURCE["gpu_uuid"]}, "resource identity")
    require(request["launch_contract"] == launch_contract(), "launch contract drift")
    require(request["preflight_evidence"]["request"]["sha256"] == V7_SHA and
            request["preflight_evidence"]["audit"]["sha256"] == AUDIT_SHA, "frozen preflight parent drift")


def validate_tolerances(value):
    validate_legacy_tolerances(value)
    require(value.get("user_confirmed") is True and value.get("draft_sha256") == DRAFT_SHA and
            value.get("plan_sha256") == PLAN_SHA, "tolerance confirmation binding missing")
    require(value.get("policy") == "STRICT_ZERO_SLACK_REPLAY_ADMISSION", "tolerance policy drift")
    require(all(type(t[k]) in (int, float) and t[k] == 0 for t in value["fields"].values()
                for k in ("atol", "rtol")), "zero-slack required")


def validate_tolerance_confirmation(value, receipt):
    validate_tolerances(value)
    require(receipt.get("status") == "CONFIRMED_PROTOCOL_AND_IMPLEMENTATION_ONLY" and
            receipt.get("draft_sha256") == DRAFT_SHA and receipt.get("plan_sha256") == PLAN_SHA and
            receipt.get("execution_authorized") is False and
            receipt.get("user_confirmation_text") == "确认草案并授权实施", "confirmation receipt mismatch")


def small_json(root, b):
    path = bound_path(root, b)
    require(path.stat().st_size <= 4*1024*1024, "JSON too large")
    return json.loads(path.read_text(encoding="utf-8"))


def validate_entry_p3(bindings, p3):
    require(p3.get("status") == "PASS_LOCAL_IMPLEMENTATION_ONLY" and p3.get("fold") == "D" and
            p3.get("entry_sha256") == binding_map(bindings) and
            p3.get("legacy_implementation_sha256") == LEGACY_MAP and
            p3.get("tests_passed") == 24 and p3.get("tests_failed") == 0 and
            p3.get("gpu_used") is False and p3.get("scientific_delta_scoped") is True and p3.get("old_entry_unchanged") is True and
            p3.get("supplement_sha256") == SUPPLEMENT_SHA,
            "entry P3/binding mismatch")


def validate_resource_evidence(v7, gpu):
    r = v7["resource_binding"]
    require(r == RESOURCE, "v7 resource changed")
    smi, cuda = gpu["nvidia_smi"], gpu["cuda"]["actual"]
    require(smi["name"] == r["gpu_name"] and smi["uuid"] == r["gpu_uuid"] and
            smi["driver"] == r["driver_version"] and smi["total_mib"] == r["gpu_memory_total_mib"], "smi identity")
    require(cuda["visible_count"] == r["gpu_count"] and cuda["name"] == r["gpu_name"] and
            cuda["total_memory_bytes"] == r["cuda_device_total_memory_bytes"], "CUDA identity")


def validate_preflight_values(v7, audit, blobs, original_p3):
    require(audit.get("status") == "PASS_FORMAL_READONLY_POST_PREFLIGHT_FREEZE_AUDIT" and
            audit.get("request_sha256") == V7_SHA and audit.get("final_manifest_equal_initial") is True,
            "formal preflight freeze missing")
    require(v7["implementation_sha256"] == LEGACY_MAP and
            original_p3["implementation_sha256"] == LEGACY_MAP and
            original_p3["status"] == "PASS_IMPLEMENTATION_ONLY", "original implementation/P3 mismatch")
    completion = blobs["completion_receipt.json"]
    require(completion.get("status") == "PASS_SYNTHETIC_R1B_ZERO_UPDATE" and
            completion.get("synthetic_only") is True and completion["counts"] == COUNTS and
            completion["implementation_sha256"] == LEGACY_MAP, "completion identity/count mismatch")
    for name in ("real_payload_open_events", "real_checkpoint_loads", "real_checkpoint_byte_reads",
                 "optimizer_steps", "parameter_updates", "buffer_updates"):
        require(type(completion.get(name)) is int and completion[name] == 0, "forbidden preflight effect")
    validate_resource_evidence(v7, blobs["gpu_identity.json"])
    env = blobs["environment_input_identity.json"]
    require(env["environment"] == v7["environment_runtime_contract"] and
            env["provider_wheel_sha256"] == v7["provider_wheel_sha256"] and
            env["input_cpu_gpu_exact"] is True and env["shape"] == [1,8192,3] and env["synthetic_only"] is True,
            "input/environment identity")
    memory = blobs["numerical_memory.json"]
    require(memory["before"] == memory["after"] == NUMERICAL, "numerical policy")
    require(audit["summary"]["exit_code"] == 0 and audit["summary"]["full_forward_completions"] == 8 and
            audit["summary"]["exact_tensor_comparisons"] == 11 and
            audit["summary"]["state_parameter_buffer_schema_equal_all8"] is True and
            audit["summary"]["RNG_hash_equal_all8"] is True and
            audit["summary"]["peak_allocated_bytes"] <= 20000*1024*1024 and
            audit["summary"]["peak_reserved_bytes"] <= 20000*1024*1024, "freeze summary")
    seq = blobs["equality_scalar_state.json"]["full_sequence"]
    require(seq["state_before"] == seq["state_after"] and len(seq["records"]) == 8 and
            len(seq["comparisons"]) == 11, "state/equality schema")
    require(all(row["state_after"] == seq["state_before"] for row in seq["records"]) and
            len({row["rng_after_hash"] for row in seq["records"]}) == 1, "state/RNG drift")
    require(all(row["exact_equal"] is True and row["max_abs_difference"] == 0
                for row in seq["comparisons"]), "tensor equality drift")


def validate_result_inventory(rows, payloads, manifest):
    require(len(rows) == 16 and len({r["path"] for r in rows}) == 16, "exact result set")
    require(set(payloads) == {r["path"] for r in rows}, "missing/extra result")
    require(sum(len(b) for b in payloads.values()) <= 16*1024*1024, "result total cap")
    for row in rows:
        b = payloads[row["path"]]
        require(0 < len(b) <= 4*1024*1024 and len(b) == row["bytes"] and
                hashlib.sha256(b).hexdigest() == row["sha256"], "result size/hash mismatch")
    entries = {}
    for line in manifest.decode("ascii").splitlines():
        pair = line.split("  ")
        require(len(pair) == 2 and pair[1] not in entries, "duplicate/malformed manifest")
        entries[pair[1]] = pair[0]
    require(entries == {r["path"]: r["sha256"] for r in rows if r["path"] != "files.sha256"}, "manifest set/hash")


def read_preflight_chain(root, request):
    evidence = request["preflight_evidence"]
    v7, audit = (small_json(root, evidence[key]) for key in ("request", "audit"))
    require(evidence["request"]["sha256"] == V7_SHA and evidence["audit"]["sha256"] == AUDIT_SHA, "parent SHA")
    require(v7["fixed_future_execution"]["output_relative"] == RESULT_RELATIVE, "preflight namespace")
    rows = audit["manifest"]["files"]
    require(len(rows) == 16 and audit["manifest"]["total_bytes"] == 3052912, "frozen inventory")
    payloads = {}
    for row in rows:
        p = bound_path(root, dict(row, path=RESULT_RELATIVE + "/" + row["path"]), verify=False)
        require(0 < p.stat().st_size <= 4*1024*1024, "result cap")
        payloads[row["path"]] = p.read_bytes()
    result_root = Path(root) / RESULT_RELATIVE
    actual = set()
    for p in result_root.rglob("*"):
        require(not p.is_symlink(), "result link")
        if p.is_file():
            actual.add(p.relative_to(result_root).as_posix())
        else:
            require(p.is_dir() and p.relative_to(result_root).as_posix() == "mplconfig", "extra result directory")
        require(len(actual) <= 64, "result inventory cap")
    require(actual == set(payloads), "extra result file")
    validate_result_inventory(rows, payloads, payloads["files.sha256"])
    blobs = {p: json.loads(b) for p,b in payloads.items() if p.endswith(".json")}
    original_p3 = small_json(root, request["post_implementation_p3"])
    validate_preflight_values(v7, audit, blobs, original_p3)
    for b in PROJECT_BINDINGS + PROVIDER_BINDINGS:
        bound_path(root, b)
    require(v7["provider_bindings"] == PROVIDER_BINDINGS and
            v7["project_source_bindings"] == PROJECT_BINDINGS, "provider/project identity")
    for b in request["entry_bindings"]:
        bound_path(root, b)
    validate_entry_p3(request["entry_bindings"], small_json(root, request["entry_p3"]))
    return v7


def validate_provider_origins(root, origins, fallback, operators_match):
    expected = {"native": str(Path(root)/PROVIDER_RELATIVE/"pointnet2_ops/_ext.cpython-310-x86_64-linux-gnu.so"),
                "wrapper": str(Path(root)/PROVIDER_RELATIVE/"pointnet2_ops/pointnet2_utils.py"),
                "adapter": str(Path(root)/"utils/pointnet2_utils.py")}
    require(origins == expected and fallback is False and operators_match is True, "provider/fallback mismatch")


def launch_contract():
    return {"wall_seconds":7200, "kill_grace_seconds":5, "allocated_mib":20000, "reserved_mib":20000,
            "minimum_free_mib":22000, "minimum_disk_bytes":2147483648, "log_bytes":33554432,
            "output_bytes":16777216, "retry":False, "resume":False, "next_fold":False,
            "transport":"WSL_EXEC_RAW_BYTES", "max_command_bytes_with_CR":2048,
            "create_parents_before_redirection":True, "pid_literal":"$$", "explicit_exit":True}


def validate_memory(allocated, reserved):
    require(type(allocated) is int and type(reserved) is int and
            0 <= allocated <= 20000*1024*1024 and 0 <= reserved <= 20000*1024*1024, "memory exceeded")

# This is a new, explicitly confirmed protocol branch, not widened v2 tolerances.
SUPPLEMENT_SHA = "2740564568231035e37e561f28ce88c3eae729d90c8bbdf5c5b1df6e87a1143c"
CONSUMED_REQUEST_SHA = "69c10ecbae5189c6934c5502d1ea5f5f498ee8977183f4c86fc802c8538974b0"
HISTORICAL_IDENTITY = ("case_id", "source_skull_id", "skull_id", "defect_type", "fold", "seed")
HISTORY_FIELDS = HISTORICAL_IDENTITY + ("condition", "historical_numeric_status",
    "historical_event_or_count_status") + tuple(
    prefix + name for name in CONTINUOUS + EXACT_METRICS
    for prefix in ("historical_", "current_", "signed_difference_", "absolute_difference_"))


def validate_supplement_confirmation(value):
    require(value.get("status") == "CONFIRMED_SUPPLEMENT_IMPLEMENTATION_ONLY" and
            value.get("supplement_sha256") == SUPPLEMENT_SHA and
            value.get("selected_option") == "B_NEW_SAME_PROCESS_DIAGNOSTIC" and
            value.get("execution_authorized") is False and
            value.get("old_zero_tolerance_unchanged") is True and
            value.get("prior_request_consumed") is True,
            "supplement is not confirmed for this new branch")


def historical_comparison(observed, reference):
    """No epsilon. Identity/reference integrity block; numeric differences report."""
    for key in HISTORICAL_IDENTITY:
        require(str(observed[key]) == str(reference[key]), "historical identity mismatch: " + key)
    require(observed.get("condition") in ("LS_native", "LSQ_native"), "not a native reference comparison")
    # Same original event semantics and finite/footprint requirements for both rows.
    audit_metric_flags(observed)
    audit_metric_flags(reference)
    result = {key: observed[key] for key in HISTORICAL_IDENTITY}
    result["condition"] = observed["condition"]
    numeric_different = event_different = False
    for key in CONTINUOUS + EXACT_METRICS:
        actual, old = float(observed[key]), float(reference[key])
        require(math.isfinite(actual) and math.isfinite(old), "nonfinite historical/current value: " + key)
        delta = actual - old
        require(math.isfinite(delta), "historical difference overflow")
        for prefix, value in (("historical_", old), ("current_", actual),
                              ("signed_difference_", delta), ("absolute_difference_", abs(delta))):
            result[prefix + key] = value
        if key in CONTINUOUS:
            numeric_different |= actual != old
        else:
            event_different |= actual != old
    result["historical_numeric_status"] = ("HISTORICAL_NUMERIC_DIFFERENCE" if numeric_different
                                            else "EXACT_NATIVE_METRIC_REPLAY")
    result["historical_event_or_count_status"] = ("HISTORICAL_EVENT_OR_COUNT_DIFFERENCE" if event_different
                                                  else "EXACT_NATIVE_EVENT_AND_COUNT_REPLAY")
    return result


class HistoricalLedger:
    """Two native rows per case, exact allowlist order, no filtering or retries."""
    def __init__(self, case_ids):
        require(len(case_ids) == 105 and len(set(case_ids)) == 105, "historical case cardinality")
        self.expected = tuple((case, condition) for case in case_ids
                              for condition in ("LS_native", "LSQ_native"))
        self.index = self.numeric_differences = self.event_differences = 0

    def compare(self, observed, reference):
        require(self.index < len(self.expected) and
                (observed["case_id"], observed["condition"]) == self.expected[self.index],
                "historical row duplicate/order/missing")
        row = historical_comparison(observed, reference)
        self.numeric_differences += int(row["historical_numeric_status"] == "HISTORICAL_NUMERIC_DIFFERENCE")
        self.event_differences += int(row["historical_event_or_count_status"] == "HISTORICAL_EVENT_OR_COUNT_DIFFERENCE")
        self.index += 1
        return row

    def receipt(self, complete=False):
        if complete:
            require(self.index == 210, "historical comparison incomplete")
        return {"scope": "COMPLETE_FOLD" if complete else "PARTIAL_ONLY",
                "native_case_rows": self.index, "numeric_difference_rows": self.numeric_differences,
                "event_or_count_difference_rows": self.event_differences,
                "numeric_status": ("HISTORICAL_NUMERIC_DIFFERENCE" if self.numeric_differences
                                   else "EXACT_NATIVE_METRIC_REPLAY" if complete else "NOT_ADJUDICATED_PARTIAL"),
                "event_status": ("HISTORICAL_EVENT_OR_COUNT_DIFFERENCE" if self.event_differences
                                 else "EXACT_NATIVE_EVENT_AND_COUNT_REPLAY" if complete else "NOT_ADJUDICATED_PARTIAL"),
                "environment_status": "HISTORICAL_ENVIRONMENT_NOT_FULLY_MATCHED",
                "old_zero_tolerance_request_passed": False}


def validate_paired_rng(value):
    require(set(value) == {"case_id", "pre_native", "pre_off", "post_native", "post_off"},
            "paired RNG evidence fields")
    for key in ("pre_native", "pre_off", "post_native", "post_off"):
        digest = value[key]
        require(isinstance(digest, str) and len(digest) == 64 and
                all(ch in "0123456789abcdef" for ch in digest), "RNG digest")
    require(value["pre_native"] == value["pre_off"], "paired pre-RNG mismatch")
    require(value["post_native"] == value["post_off"], "paired post-RNG mismatch")


def validate_paired_outlet(diagnostic):
    require(diagnostic.get("query_outlet_calls") == 1 and
            diagnostic.get("applied_residual_rms") == 0 and
            math.isfinite(float(diagnostic.get("potential_residual_rms", float("nan")))),
            "off outlet/finite residual mismatch")

# Fixed historical exposure; no Fold D data have been run by implementation tests.
FOLD_D_EXPOSURE = json.loads("{\"failed_cases\":1,\"failed_forwards\":3,\"completed_foldC_cases\":105,\"completed_foldC_forwards\":315,\"foldD_prior_cases\":0,\"foldD_prior_forwards\":0,\"new_forwards\":315,\"cumulative_forwards_after_success\":633,\"consumed_request_sha256\":\"69c10ecbae5189c6934c5502d1ea5f5f498ee8977183f4c86fc802c8538974b0\",\"completed_foldC_request_sha256\":\"4e36c6bfaecce3c9ae15c412f6079d8e9d9f0635f1de8df8c13c2493e121b0ca\",\"completed_foldC_freeze_audit_sha256\":\"ab57f970c6c70eb5a509ce742bd251d07c62238507443f40b2a017aca17fc813\"}")
