"""Exactly24 standard-library/artificial checks. No WSL, CUDA, model or real data."""
import ast
import copy
import csv
import hashlib
import io
import json
import math
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import cranial_scqr_v12_rsd_r1b_contract_v2 as c
import run_cranial_scqr_v12_rsd_r1b_v2 as run


def tolerance():
    return {"status":"FROZEN_CONFIRMED_BEFORE_DEV", "basis_scope":"ARTIFICIAL_ONLY",
        "rule":"abs_difference <= atol + rtol * abs(reference)", "policy":"STRICT_ZERO_SLACK_REPLAY_ADMISSION",
        "draft_sha256":c.DRAFT_SHA,"plan_sha256":c.PLAN_SHA,"user_confirmed":True,
        "fields":{k:{"atol":0,"rtol":0} for k in c.CONTINUOUS}}


def metric():
    return {**{k:1.0 for k in c.CONTINUOUS}, "rim_reference_rim_points":3,"rim_predicted_rim_points":3,
        "zero_contact_2mm":0,"disaster":0,"case_id":"fake","source_skull_id":"fake","skull_id":"fake",
        "defect_type":"bilateral","fold":"C","seed":0}


def bind(path, digest="a"*64):
    return {"path":path,"bytes":1,"sha256":digest}


def request():
    return {"schema":"cranial-scqr-v1.2-RSD-R1B-fold-request-v2",
        "status":"AWAITING_EXPLICIT_USER_AUTHORIZATION","execution_authorized":False,"request_id":"artificial",
        "protocol_sha256":c.PROTOCOL_SHA,"fold":"C","seed":0,"conditions":list(c.CONDITIONS),
        "permissions":{k:False for k in c.FALSE_PERMISSIONS},
        "budget":{"cases":105,"forwards":315,"npz_opens":105,"checkpoint_loads":2,"checkpoint_hash_verifications":4,
            "member_partial":105,"member_implant":105,"member_gt":105,"optimizer_steps":0,"parameter_updates":0,
            "buffer_updates":0,"bncal_forwards":0},
        "forward_epoch":None,"rng_contract":"candidate-isolated-native-progression-v1",
        "empty_contact_policy":"STOP_KEEP_ORIGINAL_FLAGS","output_limit_bytes":16777216,
        "max_wall_seconds":7200,"max_vram_mib":20000,
        "environment_contract":{**{k:"fake" for k in ("python_version","torch_version","numpy_version",
            "scipy_version","cuda_version","gpu_driver")},"cudnn_version":90100,"cpu_threads":1,
            "binary_bindings":[bind("fake.so")],"extension_source_bindings":[bind("fake.cpp")]},
        "data_root":"/home/jovyan/datasets/SkullBreakPC_out8192",
        "resource":{"hostname":c.RESOURCE["hostname"],"gpu_uuid":c.RESOURCE["gpu_uuid"]},
        "models":{k:{"run_key":k+"_foldC_seed0","checkpoint":{"sha256":c.CHECKPOINT_SHA[k+"_foldC_seed0"]},
            "reference_csv":{"sha256":c.FROZEN_REFERENCE_SHA[k+"_foldC_seed0"]}} for k in ("LS","LSQ")},
        "implementation_bindings":[bind(k,v) for k,v in c.LEGACY_MAP.items()],
        "entry_bindings":[bind(k) for k in c.ENTRY_NAMES],
        "launch_contract":c.launch_contract(),
        "output_relative":"logs/cranial_scqr_v12_rsd_r1b/artificial_foldC/result",
        "launch_paths":{"request":"docs/artificial_request.json","authorization":"logs/cranial_scqr_v12_rsd_r1b/artificial_foldC/control/auth.json",
            "runtime":"logs/cranial_scqr_v12_rsd_r1b/artificial_foldC/control/runtime.json",
            "entry":"tools/run_cranial_scqr_v12_rsd_r1b_v2.py","control":"logs/cranial_scqr_v12_rsd_r1b/artificial_foldC/control"},
        "preflight_evidence":{"request":bind("fake_request.json",c.V7_SHA),"audit":bind("fake_audit.json",c.AUDIT_SHA)}}


def preflight():
    state = {"LS":{"parameters":"fake","buffers":"fake"},"LSQ":{"parameters":"fake","buffers":"fake"}}
    v7={"resource_binding":copy.deepcopy(c.RESOURCE),"implementation_sha256":dict(c.LEGACY_MAP),
        "environment_runtime_contract":{"torch_version":"2.4.1+cu118","numpy_version":"2.2.6",
            "cuda_version":"11.8","cudnn_version":90100},"provider_wheel_sha256":"fake"}
    audit={"status":"PASS_FORMAL_READONLY_POST_PREFLIGHT_FREEZE_AUDIT","request_sha256":c.V7_SHA,
        "final_manifest_equal_initial":True,"summary":{"exit_code":0,"full_forward_completions":8,
            "exact_tensor_comparisons":11,"state_parameter_buffer_schema_equal_all8":True,"RNG_hash_equal_all8":True,
            "peak_allocated_bytes":835195904,"peak_reserved_bytes":859832320}}
    comp={"status":"PASS_SYNTHETIC_R1B_ZERO_UPDATE","synthetic_only":True,"counts":dict(c.COUNTS),
        "implementation_sha256":dict(c.LEGACY_MAP),**{k:0 for k in ("real_payload_open_events","real_checkpoint_loads",
            "real_checkpoint_byte_reads","optimizer_steps","parameter_updates","buffer_updates")}}
    blobs={"completion_receipt.json":comp,
        "gpu_identity.json":{"nvidia_smi":{"name":c.RESOURCE["gpu_name"],"uuid":c.RESOURCE["gpu_uuid"],
            "driver":c.RESOURCE["driver_version"],"total_mib":24564},
            "cuda":{"actual":{"visible_count":1,"name":c.RESOURCE["gpu_name"],"total_memory_bytes":25261047808}}},
        "environment_input_identity.json":{"environment":v7["environment_runtime_contract"],
            "provider_wheel_sha256":"fake","input_cpu_gpu_exact":True,"shape":[1,8192,3],"synthetic_only":True},
        "numerical_memory.json":{"before":dict(c.NUMERICAL),"after":dict(c.NUMERICAL)},
        "equality_scalar_state.json":{"full_sequence":{"state_before":state,"state_after":state,
            "records":[{"state_after":state,"rng_after_hash":"fake"} for _ in range(8)],
            "comparisons":[{"exact_equal":True,"max_abs_difference":0} for _ in range(11)]}}}
    return v7,audit,blobs,{"status":"PASS_IMPLEMENTATION_ONLY","implementation_sha256":dict(c.LEGACY_MAP)}


def inventory():
    data={("fake_%02d.json"%i):b'{}' for i in range(15)}
    manifest="".join(hashlib.sha256(b).hexdigest()+"  "+p+"\n" for p,b in data.items()).encode()
    data["files.sha256"]=manifest
    rows=[{"path":p,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()} for p,b in data.items()]
    return rows,data,manifest


class Contracts(unittest.TestCase):
    def test_T01_unconfirmed(self):
        t=tolerance()
        t["status"]="DRAFT_AWAITING_USER_CONFIRMATION_NOT_EXECUTABLE"
        with self.assertRaises(c.ContractError): c.validate_tolerances(t)
        t=tolerance();t["user_confirmed"]=False
        with self.assertRaises(c.ContractError): c.validate_tolerances(t)

    def test_T02_fields(self):
        for change in ("missing","extra"):
            t=tolerance()
            if change=="missing": t["fields"].pop(c.CONTINUOUS[0])
            else: t["fields"]["fake"]={"atol":0,"rtol":0}
            with self.assertRaises(c.ContractError): c.validate_tolerances(t)

    def test_T03_invalid_numbers(self):
        for value in (float("nan"),float("inf"),-1,True,0.001):
            t=tolerance();t["fields"][c.CONTINUOUS[0]]["atol"]=value
            with self.assertRaises(c.ContractError): c.validate_tolerances(t)

    def test_T04_zero_slack(self):
        row=metric(); c.assert_native_replay(row,row,tolerance())
        changed=dict(row);changed[c.CONTINUOUS[0]]=math.nextafter(1.0,2.0)
        with self.assertRaises(c.ContractError): c.assert_native_replay(changed,row,tolerance())

    def test_T05_exact_fields(self):
        for key in ("case_id",)+c.EXACT_METRICS:
            x=metric(); x[key]="other" if key=="case_id" else 4
            with self.assertRaises(c.ContractError): c.assert_native_replay(x,metric(),tolerance())

    def test_T06_roundtrip(self):
        for v in (0.0,0.1,math.nextafter(1.0,2.0),1e-300,1e300):
            self.assertEqual(json.loads(json.dumps(v)),v)
            buf=io.StringIO();csv.writer(buf).writerow([v]);buf.seek(0)
            self.assertEqual(float(next(csv.reader(buf))[0]),v)

    def test_T07_event_boundary(self):
        for hd,flag in ((50.0,0),(math.nextafter(50.0,math.inf),1)):
            row=metric();row["rim_contact_hd95_mm"]=hd;row["disaster"]=flag;c.audit_metric_flags(row)
        row=metric();row.update(rim_predicted_rim_points=0,zero_contact_2mm=1)
        with self.assertRaises(c.ContractError): c.audit_metric_flags(row)

    def test_T08_failure_diagnostic(self):
        row=metric();row["condition"]="LSQ_native";row[c.CONTINUOUS[0]]=2
        with self.assertRaises(c.ContractError) as e: c.assert_native_replay(row,metric(),tolerance())
        out=json.loads(str(e.exception))
        self.assertEqual((out["field"],out["case_id"],out["condition"],out["absolute_difference"]),(c.CONTINUOUS[0],"fake","LSQ_native",1))

    def test_T09_v7_chain(self):
        c.validate_preflight_values(*preflight())
        c.validate_result_inventory(*inventory())

    def test_T10_tamper(self):
        for mode in ("hash","size","content"):
            rows,data,m=inventory()
            if mode=="hash":rows[0]["sha256"]="0"*64
            elif mode=="size":rows[0]["bytes"]+=1
            else:data[rows[0]["path"]]=b'[]'
            with self.assertRaises(c.ContractError):c.validate_result_inventory(rows,data,m)

    def test_T11_inventory_set(self):
        for mode in ("missing","extra","duplicate","duplicate_manifest"):
            rows,data,m=inventory()
            if mode=="missing":data.pop(rows[0]["path"])
            elif mode=="extra":data["extra"]=b'{}'
            elif mode=="duplicate":rows[-1]=rows[0]
            else:m+=m.splitlines(keepends=True)[0]
            with self.assertRaises(c.ContractError):c.validate_result_inventory(rows,data,m)

    def test_T12_formal_freeze(self):
        vals=preflight();vals[1]["status"]="PASS"
        with self.assertRaises(c.ContractError):c.validate_preflight_values(*vals)
        vals=preflight();vals[2]["completion_receipt.json"]["counts"]["full_model_forward_completions"]=9
        with self.assertRaises(c.ContractError):c.validate_preflight_values(*vals)

    def test_T13_legacy_nine(self):
        vals=preflight();vals[3]["implementation_sha256"].pop(next(iter(c.LEGACY_MAP)))
        with self.assertRaises(c.ContractError):c.validate_preflight_values(*vals)

    def test_T14_shared_drift(self):
        self.assertEqual(len(c.SHARED),6)
        vals=preflight();vals[0]["implementation_sha256"][c.SHARED[0]]="0"*64
        with self.assertRaises(c.ContractError):c.validate_preflight_values(*vals)

    def test_T15_entry_p3(self):
        b=request()["entry_bindings"]
        p3={"status":"PASS_LOCAL_IMPLEMENTATION_ONLY","entry_sha256":c.binding_map(b),
            "legacy_implementation_sha256":dict(c.LEGACY_MAP),"tests_passed":24,"tests_failed":0,
            "gpu_used":False,"scientific_AST_preserved":True}
        c.validate_entry_p3(b,p3)
        p3["entry_sha256"]={}
        with self.assertRaises(c.ContractError):c.validate_entry_p3(b,p3)

    def test_T16_resource_domains(self):
        vals=preflight();gpu=vals[2]["gpu_identity.json"];c.validate_resource_evidence(vals[0],gpu)
        gpu["cuda"]["actual"]["total_memory_bytes"]=24564*1024*1024
        with self.assertRaises(c.ContractError):c.validate_resource_evidence(vals[0],gpu)

    def test_T17_provider(self):
        root=Path("fake_root")
        origins={"native":str(root/c.PROVIDER_RELATIVE/"pointnet2_ops/_ext.cpython-310-x86_64-linux-gnu.so"),
            "wrapper":str(root/c.PROVIDER_RELATIVE/"pointnet2_ops/pointnet2_utils.py"),
            "adapter":str(root/"utils/pointnet2_utils.py")}
        c.validate_provider_origins(root,origins,False,True)
        with self.assertRaises(c.ContractError):c.validate_provider_origins(root,origins,True,True)
        origins["native"]="elsewhere"
        with self.assertRaises(c.ContractError):c.validate_provider_origins(root,origins,False,True)

    def test_T18_no_authorized_IO(self):
        calls=[]
        with patch.object(c,"sha256_file",side_effect=lambda *a:calls.append(a)),patch.object(c,"bound_path",side_effect=AssertionError("payload IO")):
            with self.assertRaises(c.ContractError):run.text_execution_preconditions(SimpleNamespace())
        self.assertEqual(calls,[])
        self.assertNotIn("torch",sys.modules);self.assertNotIn("numpy",sys.modules)

    def test_T19_exact_budget(self):
        cases=["fake_%03d"%i for i in range(105)];ledger=c.AccessLedger(cases,"C")
        for k in ("LS","LSQ"):ledger.record_checkpoint_load(k+"_foldC_seed0")
        for _ in range(4):ledger.record_checkpoint_hash()
        for case in cases:
            ledger.begin_case(case);ledger.read_member("partial")
            for condition in c.CONDITIONS:ledger.begin_forward(condition);ledger.end_forward()
            ledger.read_member("implant");ledger.read_member("gt");ledger.end_case()
        ledger.assert_final()
        with self.assertRaises(c.ContractError):ledger.begin_case(cases[0])

    def test_T20_GT_order(self):
        ledger=c.AccessLedger(["fake_%03d"%i for i in range(105)],"C")
        for k in ("LS","LSQ"):ledger.record_checkpoint_load(k+"_foldC_seed0")
        ledger.begin_case("fake_000")
        with self.assertRaises(c.ContractError):ledger.read_member("gt")
        with self.assertRaises(c.ContractError):ledger.read_member("partial")

    def test_T21_rng_static(self):
        parent=ast.parse(os.environ["R1B_FC_PARENT_RUNNER_SOURCE"])
        child=ast.parse(os.environ["R1B_FC_CHILD_RUNNER_SOURCE"])
        def functions(tree):return {n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
        p,q=functions(parent),functions(child)
        for k in ("snapshot_rng","restore_rng","state_hashes","canonical_tensor_hash","points_member","extra_geometry"):
            self.assertEqual(ast.dump(p[k]),ast.dump(q[k]))
        def rng_calls(node):
            return [ast.dump(n) for n in ast.walk(node) if isinstance(n,ast.Call) and
                    isinstance(n.func,ast.Name) and n.func.id in ("snapshot_rng","restore_rng")]
        self.assertEqual(rng_calls(p["run_authorized"]),rng_calls(q["run_authorized"]))

    def test_T22_raw_and_launcher(self):
        result=run.caller_capture_contract(b'abc',b'\xff',7)
        self.assertEqual(result["exit_code"],7)
        self.assertEqual(result["powershell_terminal_statement"],"exit $LASTEXITCODE")
        self.assertEqual(result["wsl_entry"],"--exec")
        with patch.object(c.socket,"gethostname",return_value=c.RESOURCE["hostname"]):
            text=run.render_launcher(request(),"a"*64,"b"*64,"c"*64)
        self.assertIn('"$$"',text);self.assertIn('exit "$code"',text)
        self.assertIn("-I -S -B",text);self.assertIn("\n",text)

    def test_T23_parent_before_output(self):
        # Existing parent/noclobber checks remain; all path operations below are
        # artificial mocks: no fixture directories, links or JSON files exist.
        with patch.object(c.socket,"gethostname",return_value=c.RESOURCE["hostname"]):
            text=run.render_launcher(request(),"a"*64,"b"*64,"c"*64)
        self.assertLess(text.index("mkdir -p"),text.index("exec 3>"))
        self.assertIn("set -euC",text)
        with self.assertRaises(c.ContractError):c.checked_path(Path.cwd(),"../escape")
        root=Path.cwd()/"__r1b_authpath_memory_only__"
        names=("request","authorization","runtime")
        values={k:root/(k+"_parent")/(k+".json") for k in names}
        args=SimpleNamespace(**values,**{k+"_sha256":"a"*64 for k in names})
        events=[]
        def resolve(path,*a,**kw):
            events.append(("resolve",path))
            return path
        def run_case(linked=None):
            events.clear()
            def is_link(path):
                events.append(("link_check",path))
                return path==linked
            with patch.object(run,"ROOT",root),patch.object(Path,"is_symlink",is_link),\
                 patch.object(Path,"is_file",return_value=True),patch.object(Path,"resolve",resolve),\
                 patch.object(c,"sha256_file",side_effect=AssertionError("hash before guard complete")),\
                 patch.object(run,"json_read",side_effect=AssertionError("JSON before guard complete")):
                return run.checked_authorization_paths(args)
        checked=run_case()
        self.assertEqual(checked,[(values[k],"a"*64) for k in names])
        # Check file, immediate parent and root aliases for each argument.
        # A linked root ancestor is additionally rejected in every role matrix.
        for role in names:
            for linked in (values[role],values[role].parent,root,root.parent):
                with self.subTest(role=role,linked=str(linked)):
                    with self.assertRaises(c.ContractError) as caught:run_case(linked)
                    self.assertIn(str(linked),str(caught.exception))
                    self.assertFalse(any(kind=="resolve" and
                        (p==linked or linked in p.parents) for kind,p in events))
        # Relative safe arguments retain cwd semantics; lexical escape, outside
        # root and dangling/final aliases fail without hash/JSON reads.
        args.request=Path("request_parent")/"request.json"
        with patch.object(Path,"cwd",return_value=root):
            self.assertEqual(run_case()[0][0],values["request"])
        for bad in (root/"sub"/".."/"request.json",root.parent/"outside.json"):
            args.request=bad
            with self.assertRaises(c.ContractError):run_case()
        args.request=values["request"]
        self.assertEqual(run_case()[0][0],values["request"])

    def test_T24_fail_stop_limits(self):
        c.validate_memory(1,1)
        for x in (-1,20000*1024*1024+1,True):
            with self.assertRaises(c.ContractError):c.validate_memory(x,1)
        req=request();req["launch_contract"]["retry"]=True
        with patch.object(c.socket,"gethostname",return_value=c.RESOURCE["hostname"]):
            with self.assertRaises(c.ContractError):c.validate_request(req)
        self.assertEqual(c.launch_contract()["wall_seconds"],7200)
        self.assertFalse(c.launch_contract()["next_fold"])


if __name__ == "__main__":
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Contracts)
    if suite.countTestCases()!=24:raise SystemExit("expected exactly24")
    result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
    print(json.dumps({"tests_run":result.testsRun,"failures":len(result.failures),"errors":len(result.errors),
        "passed":result.wasSuccessful() and result.testsRun==24,"gpu_used":False,"model_forwards":0,
        "real_payload_reads":0,"checkpoint_loads":0},sort_keys=True))
    raise SystemExit(0 if result.wasSuccessful() and result.testsRun==24 else 1)
