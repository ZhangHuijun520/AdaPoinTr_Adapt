#!/usr/bin/env python
"""Fold C/D train-only gradient calibration for Cranial-SCQR v1.2 QA-1.

This module is deliberately inert without a separately frozen execution
authorization.  Project model/dataset modules are imported only after the
protocol, authorization, paths, hashes, and environment gates all pass.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import statistics
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

ROOT = PROJECT_ROOT
PROTOCOL_ID = "cranial-scqr-v1.2-QA1-CD-gradient-calibration-v1"
FOLDS = ("C", "D")
DEFECT_ORDER = (
    "bilateral",
    "frontoorbital",
    "parietotemporal",
    "random_1",
    "random_2",
)
MODEL_SEED = 31002
BATCHES_PER_FOLD = 5
BATCH_SIZE = 4
CASES_PER_FOLD = 20
FORWARD_WARMUP_EPOCH = 20
TARGET_GRADIENT_RATIO = 0.1
WEIGHT_MIN = 1.0e-6
WEIGHT_MAX = 1.0
EXECUTION_ENV_GATE = "V12_QA1_CD_CALIBRATION_EXECUTION_AUTHORIZED"


class ContractError(RuntimeError):
    """Raised when a frozen protocol or execution contract is violated."""


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_lines(values: Iterable[str]) -> str:
    payload = "".join(f"{value}\n" for value in values).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ContractError(f"cannot read JSON contract {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise ContractError(f"JSON contract must be an object: {path}")
    return payload


def load_case_ids(path: Path, expected_count: int | None = None) -> list[str]:
    values = [
        line.strip()
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]
    if len(values) != len(set(values)):
        raise ContractError(f"duplicate case ID in {path}")
    if expected_count is not None and len(values) != expected_count:
        raise ContractError(
            f"expected {expected_count} case IDs in {path}, found {len(values)}"
        )
    return values


def skull_token(skull_id: str) -> str:
    parts = skull_id.split(":", 1)
    if len(parts) != 2 or not all(parts):
        raise ContractError(f"invalid skull ID: {skull_id}")
    return f"{parts[0]}__{parts[1]}"


def expected_selection(selected_skulls: list[str]) -> list[str]:
    if len(selected_skulls) != BATCH_SIZE or len(set(selected_skulls)) != BATCH_SIZE:
        raise ContractError("selected_skulls must contain four unique values")
    tokens = [skull_token(value) for value in selected_skulls]
    return [
        f"{token}__{defect}"
        for defect in DEFECT_ORDER
        for token in tokens
    ]


def validate_selection(
    fold: str,
    fold_spec: dict[str, Any],
    selection_path: Path,
    train_allowlist_path: Path,
) -> list[str]:
    if fold not in FOLDS:
        raise ContractError(f"unauthorized fold: {fold}")
    train_ids = load_case_ids(train_allowlist_path, expected_count=315)
    selected_ids = load_case_ids(selection_path, expected_count=CASES_PER_FOLD)
    expected_ids = expected_selection(fold_spec["selected_skulls"])
    if selected_ids != expected_ids:
        raise ContractError(f"fold {fold}: selection order/content drift")
    if not set(selected_ids).issubset(set(train_ids)):
        raise ContractError(f"fold {fold}: selection is outside train allowlist")
    if sha256_file(train_allowlist_path) != fold_spec["train_allowlist_sha256"]:
        raise ContractError(f"fold {fold}: train allowlist SHA256 mismatch")
    if sha256_lines(selected_ids) != fold_spec["selection_sha256"]:
        raise ContractError(f"fold {fold}: selection SHA256 mismatch")
    return selected_ids


def validate_template(payload: dict[str, Any], fold: str) -> None:
    expected_train = (
        "logs/skullbreak_mamba_v12_development/protocol_v1/"
        f"fold{fold}_train_case_ids.txt"
    )
    expected_dev = (
        "logs/skullbreak_mamba_v12_development/protocol_v1/"
        f"fold{fold}_dev_case_ids.txt"
    )
    execution = payload.get("cranial_scqr_execution", {})
    model = payload.get("model", {}).get("cranial_scqr", {})
    development = payload.get("development_protocol", {})
    dataset = payload.get("dataset", {})
    required_execution = {
        "stage": "V12_QA1_CD_gradient_calibration_locked_template",
        "status": "calibration_locked_pending_separate_execution_authorization",
        "training_authorized": False,
        "optimizer_steps_authorized": 0,
        "bncal_authorized": False,
        "formal_timing_authorized": False,
        "development_evaluation_authorized": False,
    }
    if execution != required_execution:
        raise ContractError(f"fold {fold}: locked execution fields drifted")
    required_model = {
        "variant": "A1",
        "enabled": True,
        "local_geometry_enabled": True,
        "contact_supervision_enabled": True,
        "query_conditioning_enabled": False,
        "contact_bias_beta": 0.0,
        "auxiliary_loss_weight": None,
    }
    for key, value in required_model.items():
        if model.get(key) != value:
            raise ContractError(f"fold {fold}: model field {key} drifted")
    if development.get("name") != "cranial-scqr-v1.2":
        raise ContractError(f"fold {fold}: wrong development protocol")
    if development.get("candidate") != "LS" or development.get("v11_alias") != "A1":
        raise ContractError(f"fold {fold}: wrong candidate alias")
    if development.get("fold") != fold or development.get("seed") != 0:
        raise ContractError(f"fold {fold}: fold/seed drifted")
    for key in (
        "protected_splits_accessed",
        "confirmation_allowed",
        "old_monitor_allowed",
        "official_test_allowed",
        "mug_payload_allowed",
    ):
        if development.get(key) is not False:
            raise ContractError(f"fold {fold}: protected access field {key} drifted")
    if dataset.get("train", {}).get("others", {}).get("include_case_ids_file") != expected_train:
        raise ContractError(f"fold {fold}: train allowlist path drifted")
    for split in ("val", "test"):
        if dataset.get(split, {}).get("others", {}).get("include_case_ids_file") != expected_dev:
            raise ContractError(f"fold {fold}: {split} allowlist path drifted")


def validate_protocol(protocol_path: Path) -> dict[str, Any]:
    payload = read_json(protocol_path)
    if payload.get("protocol_id") != PROTOCOL_ID:
        raise ContractError("unexpected calibration protocol_id")
    if payload.get("status") != "FROZEN_IMPLEMENTATION_ONLY_PENDING_EXECUTION_AUTHORIZATION":
        raise ContractError("calibration protocol is not in its frozen pending state")
    if payload.get("execution_authorized") is not False:
        raise ContractError("implementation protocol must not authorize execution")
    expected_contract = {
        "folds": list(FOLDS),
        "candidate": "LS",
        "v11_alias": "A1",
        "model_seed": MODEL_SEED,
        "skulls_per_fold": 4,
        "cases_per_fold": CASES_PER_FOLD,
        "batches_per_fold": BATCHES_PER_FOLD,
        "batch_size": BATCH_SIZE,
        "full_model_forward_calls": 10,
        "autograd_calls": 20,
        "optimizer_constructions": 0,
        "optimizer_steps": 0,
        "model_parameter_updates": 0,
        "model_buffer_updates": 0,
        "checkpoint_loads": 0,
        "checkpoint_writes": 0,
        "bncal_runs": 0,
        "forward_mode": "eval_with_autograd",
        "temporary_residual_warmup_factor": 1.0,
        "target_gradient_ratio": TARGET_GRADIENT_RATIO,
        "weight_clip": [WEIGHT_MIN, WEIGHT_MAX],
    }
    if payload.get("calibration_contract") != expected_contract:
        raise ContractError("calibration contract differs from runner constants")
    for item in payload.get("sha256_bindings", []):
        bound_path = ROOT / item["path"]
        if not bound_path.is_file() or sha256_file(bound_path) != item["sha256"]:
            raise ContractError(f"SHA256 binding mismatch: {item['path']}")
    if not payload.get("sha256_bindings"):
        raise ContractError("protocol has no SHA256 bindings")
    try:
        import yaml
    except ImportError as exc:
        raise ContractError("PyYAML is required for template validation") from exc
    for fold in FOLDS:
        spec = payload["folds"][fold]
        selection_path = ROOT / spec["selection_file"]
        train_path = ROOT / spec["train_allowlist"]
        validate_selection(fold, spec, selection_path, train_path)
        template_path = ROOT / spec["template"]
        template = yaml.safe_load(template_path.read_text(encoding="utf-8"))
        if not isinstance(template, dict):
            raise ContractError(f"fold {fold}: template must be a YAML mapping")
        validate_template(template, fold)
    return payload


def validate_execution_authorization(
    authorization_path: Path,
    protocol_path: Path,
    output_dir: Path,
) -> dict[str, Any]:
    payload = read_json(authorization_path)
    if payload.get("authorization_id") != (
        "cranial-scqr-v1.2-QA1-CD-gradient-calibration-execution-v1"
    ):
        raise ContractError("unexpected execution authorization_id")
    if payload.get("status") != "AUTHORIZED" or payload.get("execution_authorized") is not True:
        raise ContractError("C/D calibration execution is not authorized")
    if payload.get("allowed_runs") != 1:
        raise ContractError("execution authorization must allow exactly one run")
    protocol_binding = payload.get("protocol", {})
    expected_protocol_rel = str(protocol_path.relative_to(ROOT))
    if protocol_binding.get("path") != expected_protocol_rel:
        raise ContractError("execution authorization binds a different protocol path")
    if protocol_binding.get("sha256") != sha256_file(protocol_path):
        raise ContractError("execution authorization protocol SHA256 mismatch")
    expected_output = str(output_dir.relative_to(ROOT))
    if payload.get("output_dir") != expected_output:
        raise ContractError("output directory differs from execution authorization")
    if payload.get("python_executable") != "/opt/conda/envs/adapointr-mamba/bin/python":
        raise ContractError("Python executable differs from execution authorization schema")
    if payload.get("device") != "cuda:0":
        raise ContractError("device differs from execution authorization schema")
    expected_counts = {
        "folds": 2,
        "payload_open_events": 40,
        "selected_unique_cases": 30,
        "full_model_forward_calls": 10,
        "autograd_calls": 20,
        "optimizer_constructions": 0,
        "optimizer_steps": 0,
        "checkpoint_loads": 0,
        "checkpoint_writes": 0,
        "bncal_runs": 0,
    }
    if payload.get("execution_counts") != expected_counts:
        raise ContractError("execution authorization counts drifted")
    return payload


def calibrated_lambda(ratios: Iterable[float]) -> dict[str, float | bool]:
    values = [float(value) for value in ratios]
    if len(values) != BATCHES_PER_FOLD:
        raise ContractError("exactly five gradient ratios are required")
    if not all(math.isfinite(value) and value > 0.0 for value in values):
        raise ContractError("gradient ratios must be finite and positive")
    median_ratio = float(statistics.median(values))
    unclipped = TARGET_GRADIENT_RATIO * median_ratio
    final = min(max(unclipped, WEIGHT_MIN), WEIGHT_MAX)
    return {
        "median_g_rec_over_g_scf": median_ratio,
        "lambda_unclipped": unclipped,
        "lambda_scf": final,
        "lambda_clipped": final != unclipped,
    }


def gradient_rms(loss: Any, encoder_features: Any, retain_graph: bool) -> float:
    import torch

    gradient = torch.autograd.grad(
        loss,
        encoder_features,
        retain_graph=retain_graph,
        create_graph=False,
        allow_unused=False,
    )[0]
    value = float(torch.sqrt(torch.mean(gradient.detach().double().square())).cpu())
    if not math.isfinite(value) or value <= 0.0:
        raise ContractError("nonfinite or zero encoder-feature gradient RMS")
    return value


def tensor_sha256(tensor: Any) -> str:
    import torch

    value = tensor.detach().cpu().contiguous()
    digest = hashlib.sha256()
    digest.update(str(value.dtype).encode("ascii"))
    digest.update(str(tuple(value.shape)).encode("ascii"))
    digest.update(value.reshape(-1).view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


def state_sha256(module: Any) -> str:
    digest = hashlib.sha256()
    for name, value in sorted(module.state_dict().items()):
        digest.update(name.encode("utf-8"))
        digest.update(tensor_sha256(value).encode("ascii"))
    return digest.hexdigest()


def import_runtime_components() -> dict[str, Any]:
    import torch

    from datasets import build_dataset_from_cfg
    from models import build_model_from_cfg
    from models.cranial_scqr import (
        build_contact_support_labels,
        case_balanced_binary_cross_entropy,
    )
    from tools.run_cranial_scqr_v11_l3_benchmark import model_dense_output
    from utils.config import cfg_from_yaml_file

    return {
        "torch": torch,
        "build_dataset_from_cfg": build_dataset_from_cfg,
        "build_model_from_cfg": build_model_from_cfg,
        "build_contact_support_labels": build_contact_support_labels,
        "case_balanced_binary_cross_entropy": case_balanced_binary_cross_entropy,
        "model_dense_output": model_dense_output,
        "cfg_from_yaml_file": cfg_from_yaml_file,
    }


def build_fold_dataset_and_model(
    fold: str,
    protocol: dict[str, Any],
    components: dict[str, Any],
) -> tuple[Any, Any, Path, list[str]]:
    if fold not in FOLDS:
        raise ContractError(f"unauthorized fold: {fold}")
    spec = protocol["folds"][fold]
    config_path = ROOT / spec["template"]
    selection_path = ROOT / spec["selection_file"]
    config = components["cfg_from_yaml_file"](str(config_path))
    execution = config.cranial_scqr_execution
    if (
        execution.training_authorized is not False
        or execution.optimizer_steps_authorized != 0
        or execution.bncal_authorized is not False
        or execution.development_evaluation_authorized is not False
    ):
        raise ContractError("calibration must consume a fully locked template")
    if config.model.cranial_scqr.auxiliary_loss_weight is not None:
        raise ContractError("locked template auxiliary_loss_weight must be null")
    config.model.cranial_scqr.auxiliary_loss_weight = 1.0
    config.dataset.train.others.include_case_ids_file = str(selection_path)
    dataset = components["build_dataset_from_cfg"](
        config.dataset.train._base_, config.dataset.train.others
    )
    if len(dataset) != CASES_PER_FOLD:
        raise ContractError(f"fold {fold}: expected exactly 20 calibration cases")
    requested = load_case_ids(selection_path, expected_count=CASES_PER_FOLD)
    actual = {str(record["case_id"]) for record in dataset.records}
    if actual != set(requested):
        raise ContractError(f"fold {fold}: selected dataset differs from case list")
    torch = components["torch"]
    torch.manual_seed(MODEL_SEED)
    torch.cuda.manual_seed_all(MODEL_SEED)
    model = components["build_model_from_cfg"](config.model).eval()
    return dataset, model, config_path, requested


def fetch_batch(dataset: Any, ordered_case_ids: list[str], device: Any, torch: Any):
    index_by_id = {
        str(record["case_id"]): index
        for index, record in enumerate(dataset.records)
    }
    samples = [dataset[index_by_id[case_id]] for case_id in ordered_case_ids]
    partial = torch.stack([sample[2][0] for sample in samples]).to(device)
    target = torch.stack([sample[2][1] for sample in samples]).to(device)
    scale = dataset.get_normalization_scales(
        ordered_case_ids, device=device, dtype=partial.dtype
    )
    return partial, target, scale


def run_fold(
    fold: str,
    protocol: dict[str, Any],
    components: dict[str, Any],
    device: Any,
    log: Any,
    row_sink: Any,
) -> dict[str, Any]:
    torch = components["torch"]
    log(f"fold {fold}: construct LS/A1 seed0 initial copy on CPU")
    dataset, model, config_path, case_ids = build_fold_dataset_and_model(
        fold, protocol, components
    )
    state_before = state_sha256(model)
    model = model.to(device).eval()
    captured: dict[str, Any] = {}

    def capture_encoder_features(_module: Any, _inputs: Any, output: Any) -> None:
        captured["features"] = output

    hook = model.base_model.encoder.register_forward_hook(capture_encoder_features)
    rows: list[dict[str, Any]] = []
    try:
        for batch_index in range(BATCHES_PER_FOLD):
            start = batch_index * BATCH_SIZE
            batch_case_ids = case_ids[start : start + BATCH_SIZE]
            log(f"fold {fold}: batch {batch_index + 1}/5 load 4 authorized cases")
            partial, target, scale = fetch_batch(dataset, batch_case_ids, device, torch)
            captured.clear()
            query_features, coarse, denoise_length, auxiliary = model.base_model(
                partial, epoch=FORWARD_WARMUP_EPOCH
            )
            if denoise_length != 0 or auxiliary is None:
                raise ContractError("LS/A1 calibration forward contract failed")
            fine = components["model_dense_output"](model, query_features, coarse)
            reconstruction_loss = model.loss_func(coarse, target)
            reconstruction_loss = reconstruction_loss + model.get_fine_loss_components(
                coarse, fine, target
            )[2]
            labels = components["build_contact_support_labels"](
                partial,
                target,
                scale,
                auxiliary["knn32_indices"],
                rim_band_mm=2.0,
            )
            auxiliary_loss = components["case_balanced_binary_cross_entropy"](
                auxiliary["contact_logits"], labels.proxy_labels
            )
            encoder_features = captured.get("features")
            if encoder_features is None:
                raise ContractError("public encoder output F was not captured")
            g_rec = gradient_rms(reconstruction_loss, encoder_features, True)
            g_scf = gradient_rms(auxiliary_loss, encoder_features, False)
            ratio = g_rec / g_scf
            values = (
                float(reconstruction_loss.detach().cpu()),
                float(auxiliary_loss.detach().cpu()),
                g_rec,
                g_scf,
                ratio,
            )
            if not all(math.isfinite(value) and value > 0.0 for value in values):
                raise ContractError(f"fold {fold} batch {batch_index}: invalid value")
            row = {
                "fold": fold,
                "batch_index": batch_index,
                "case_ids": "|".join(batch_case_ids),
                "case_ids_sha256": sha256_lines(batch_case_ids),
                "partial_sha256": tensor_sha256(partial),
                "implant_sha256": tensor_sha256(target),
                "scale_sha256": tensor_sha256(scale),
                "reconstruction_loss": values[0],
                "scf_loss": values[1],
                "g_rec_rms_at_encoder_F": g_rec,
                "g_scf_rms_at_encoder_F": g_scf,
                "g_rec_over_g_scf": ratio,
                "raw_positive_count": int(labels.raw_positive_counts.sum().item()),
                "positive_proxy_count": int(labels.positive_proxy_counts.sum().item()),
            }
            rows.append(row)
            row_sink(row)
            log(f"fold {fold}: batch {batch_index + 1} complete ratio={ratio:.9g}")
            del (
                partial,
                target,
                scale,
                query_features,
                coarse,
                auxiliary,
                fine,
                reconstruction_loss,
                labels,
                auxiliary_loss,
                encoder_features,
            )
    finally:
        hook.remove()
    if any(parameter.grad is not None for parameter in model.parameters()):
        raise ContractError("autograd calibration populated parameter.grad")
    model = model.cpu()
    torch.cuda.synchronize()
    torch.cuda.empty_cache()
    state_after = state_sha256(model)
    if state_before != state_after:
        raise ContractError(f"fold {fold}: model parameters or buffers changed")
    result: dict[str, Any] = {
        "fold": fold,
        "candidate": "LS",
        "v11_alias": "A1",
        "template": str(config_path.relative_to(ROOT)),
        "template_sha256": sha256_file(config_path),
        "selection_file": protocol["folds"][fold]["selection_file"],
        "selection_sha256": sha256_lines(case_ids),
        "selected_case_ids": case_ids,
        "selected_case_ids_sha256": sha256_lines(case_ids),
        "selected_skulls": protocol["folds"][fold]["selected_skulls"],
        "gradient_ratios": [row["g_rec_over_g_scf"] for row in rows],
        "model_state_sha256_before": state_before,
        "model_state_sha256_after": state_after,
        "model_state_unchanged": True,
        "parameter_grad_tensors_after": 0,
        "payload_open_events": CASES_PER_FOLD,
        "full_model_forward_calls": BATCHES_PER_FOLD,
        "autograd_calls": 2 * BATCHES_PER_FOLD,
    }
    result.update(calibrated_lambda(result["gradient_ratios"]))
    return result


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def write_report(path: Path, receipt: dict[str, Any]) -> None:
    lines = [
        "# Cranial-SCQR v1.2 QA-1 Fold C/D train-only 梯度量级校准",
        "",
        f"- 状态：**{receipt['status']}**",
        f"- run ID：`{receipt['run_id']}`",
        "- optimizer 构造/step：0/0；checkpoint：0；BNCal：0。",
        "- 仅访问 Fold C/D train 入选 case 的 partial/implant 和 normalization scale。",
        "- eval + autograd，临时 residual warmup factor=1；不是训练。",
        "",
        "## 每折结果",
        "",
        "| fold | median g_rec/g_scf | unclipped λ | final λ | clipped |",
        "|---|---:|---:|---:|---:|",
    ]
    for fold in FOLDS:
        value = receipt.get("folds", {}).get(fold)
        if value is not None:
            lines.append(
                f"| {fold} | {value['median_g_rec_over_g_scf']:.9g} | "
                f"{value['lambda_unclipped']:.9g} | {value['lambda_scf']:.9g} | "
                f"{value['lambda_clipped']} |"
            )
    if receipt["status"] == "ERROR":
        lines.extend(["", "## 错误", "", "```text", receipt["error"], "```"])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def execute(
    protocol_path: Path,
    authorization_path: Path,
    output_dir: Path,
    protocol: dict[str, Any],
) -> int:
    if output_dir.exists():
        raise FileExistsError(f"refusing to reuse calibration output: {output_dir}")
    if os.environ.get(EXECUTION_ENV_GATE) != "1":
        raise ContractError(f"{EXECUTION_ENV_GATE}=1 is required")
    if os.environ.get("CUBLAS_WORKSPACE_CONFIG") != ":4096:8":
        raise ContractError("CUBLAS_WORKSPACE_CONFIG=:4096:8 is required")
    components = import_runtime_components()
    torch = components["torch"]
    if torch.cuda.is_initialized():
        raise ContractError("CUDA was initialized before all authorization gates passed")
    if not torch.cuda.is_available():
        raise ContractError("CUDA is required")
    output_dir.mkdir(parents=True)
    progress_path = output_dir / "progress.log"
    csv_path = output_dir / "batch_gradient_metrics.csv"
    fieldnames = (
        "fold",
        "batch_index",
        "case_ids",
        "case_ids_sha256",
        "partial_sha256",
        "implant_sha256",
        "scale_sha256",
        "reconstruction_loss",
        "scf_loss",
        "g_rec_rms_at_encoder_F",
        "g_scf_rms_at_encoder_F",
        "g_rec_over_g_scf",
        "raw_positive_count",
        "positive_proxy_count",
    )
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        csv.DictWriter(handle, fieldnames=fieldnames).writeheader()

    def log(message: str) -> None:
        line = f"[{utc_now()}] {message}"
        print(line, flush=True)
        with progress_path.open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")

    def row_sink(row: dict[str, Any]) -> None:
        with csv_path.open("a", encoding="utf-8", newline="") as handle:
            csv.DictWriter(handle, fieldnames=fieldnames).writerow(row)

    receipt: dict[str, Any] = {
        "protocol_id": protocol["protocol_id"],
        "protocol": str(protocol_path.relative_to(ROOT)),
        "protocol_sha256": sha256_file(protocol_path),
        "execution_authorization": str(authorization_path.relative_to(ROOT)),
        "execution_authorization_sha256": sha256_file(authorization_path),
        "run_id": output_dir.name,
        "started_at_utc": utc_now(),
        "optimizer_constructions": 0,
        "optimizer_steps": 0,
        "checkpoints_loaded": 0,
        "checkpoints_written": 0,
        "bncal_runs": 0,
        "confirmation20_payload_opened": 0,
        "official_test_payload_opened": 0,
        "old_monitor_payload_opened": 0,
        "mug_payload_opened": 0,
    }
    try:
        torch.use_deterministic_algorithms(True)
        torch.backends.cudnn.benchmark = False
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        device = torch.device("cuda:0")
        fold_results = {
            fold: run_fold(fold, protocol, components, device, log, row_sink)
            for fold in FOLDS
        }
        unique_cases = set(fold_results["C"]["selected_case_ids"]) | set(
            fold_results["D"]["selected_case_ids"]
        )
        if len(unique_cases) != 30:
            raise ContractError("expected exactly 30 unique cases across folds C/D")
        receipt.update(
            {
                "status": "PASS",
                "finished_at_utc": utc_now(),
                "folds": fold_results,
                "execution_counts": {
                    "folds": 2,
                    "payload_open_events": 40,
                    "selected_unique_cases": 30,
                    "full_model_forward_calls": 10,
                    "autograd_calls": 20,
                    "optimizer_constructions": 0,
                    "optimizer_steps": 0,
                    "checkpoint_loads": 0,
                    "checkpoint_writes": 0,
                    "bncal_runs": 0,
                },
                "training_authorized_by_this_receipt": False,
            }
        )
    except Exception as exc:  # freeze evidence; never retry here
        receipt.update(
            {
                "status": "ERROR",
                "finished_at_utc": utc_now(),
                "error": f"{type(exc).__name__}: {exc}",
                "traceback": traceback.format_exc(),
                "training_authorized_by_this_receipt": False,
            }
        )
    write_json(output_dir / "calibration_receipt.json", receipt)
    write_json(
        output_dir / "calibration_summary.json",
        {
            "status": receipt["status"],
            "folds": receipt.get("folds", {}),
            "training_authorized": False,
        },
    )
    write_report(output_dir / "calibration_report_zh.md", receipt)
    files = (
        progress_path,
        csv_path,
        output_dir / "calibration_summary.json",
        output_dir / "calibration_receipt.json",
        output_dir / "calibration_report_zh.md",
    )
    with (output_dir / "files.sha256").open("w", encoding="ascii") as handle:
        for path in files:
            handle.write(f"{sha256_file(path)}  {path.name}\n")
    print(f"[{receipt['status']}] {output_dir}", flush=True)
    return 0 if receipt["status"] == "PASS" else 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--execution-authorization", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    protocol_path = args.protocol.resolve()
    authorization_path = args.execution_authorization.resolve()
    output_dir = args.output_dir.resolve()
    try:
        protocol_path.relative_to(ROOT)
        authorization_path.relative_to(ROOT)
        output_dir.relative_to(ROOT)
    except ValueError as exc:
        raise ContractError("all paths must remain under the project root") from exc
    protocol = validate_protocol(protocol_path)
    validate_execution_authorization(authorization_path, protocol_path, output_dir)
    return execute(protocol_path, authorization_path, output_dir, protocol)


if __name__ == "__main__":
    raise SystemExit(main())
