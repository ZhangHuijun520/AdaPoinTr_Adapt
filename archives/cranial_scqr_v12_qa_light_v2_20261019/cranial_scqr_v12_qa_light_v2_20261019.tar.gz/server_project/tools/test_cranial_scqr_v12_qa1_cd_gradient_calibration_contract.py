#!/usr/bin/env python
"""Synthetic CPU contract suite for the QA-1 Fold C/D calibration tools."""

from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

import torch
import yaml


ROOT = Path(__file__).resolve().parents[1]
RUNNER_PATH = ROOT / "tools/run_cranial_scqr_v12_qa1_cd_gradient_calibration.py"
PROTOCOL_PATH = (
    ROOT
    / "docs/cranial_scqr_v12_qa_research_2026_09_21"
    / "v12_qa1_cd_gradient_calibration_protocol_v1.json"
)


def load_runner():
    spec = importlib.util.spec_from_file_location("qa1_cd_calibration_runner", RUNNER_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot create runner import spec")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class CalibrationContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if torch.cuda.is_initialized():
            raise AssertionError("synthetic suite must begin before CUDA initialization")
        cls.runner = load_runner()

    def test_frozen_protocol_and_all_bindings(self):
        payload = self.runner.validate_protocol(PROTOCOL_PATH)
        self.assertEqual(payload["folds"]["C"]["selection_sha256"],
                         "ea2302d73932ad4e95c15849bd1b553537b2e230687317977e0b23fcf7141609")
        self.assertEqual(payload["folds"]["D"]["selection_sha256"],
                         "aad630032369c24072c92fc2fd8de8be12f431ca5f83df835796cbfecaf3097b")
        self.assertFalse(payload["execution_authorized"])

    def test_exact_selection_rule_and_order(self):
        protocol = json.loads(PROTOCOL_PATH.read_text(encoding="utf-8"))
        for fold in ("C", "D"):
            spec = protocol["folds"][fold]
            selected = self.runner.load_case_ids(ROOT / spec["selection_file"], 20)
            self.assertEqual(selected, self.runner.expected_selection(spec["selected_skulls"]))
            self.assertEqual(self.runner.sha256_lines(selected), spec["selection_sha256"])
            for batch_index, defect in enumerate(self.runner.DEFECT_ORDER):
                batch = selected[batch_index * 4 : (batch_index + 1) * 4]
                self.assertTrue(all(value.endswith("__" + defect) for value in batch))

    def test_selection_rejects_order_drift_and_non_train_case(self):
        selected_skulls = ["train:113", "train:002", "train:062", "train:017"]
        expected = self.runner.expected_selection(selected_skulls)
        fillers = [f"train__synthetic_{index:03d}__bilateral" for index in range(295)]
        train_ids = expected + fillers
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            train_path = root / "train.txt"
            selection_path = root / "selection.txt"
            train_path.write_text("\n".join(train_ids) + "\n", encoding="utf-8")
            selection_path.write_text("\n".join(expected) + "\n", encoding="utf-8")
            spec = {
                "selected_skulls": selected_skulls,
                "train_allowlist_sha256": self.runner.sha256_file(train_path),
                "selection_sha256": self.runner.sha256_lines(expected),
            }
            self.assertEqual(
                self.runner.validate_selection("C", spec, selection_path, train_path),
                expected,
            )
            drifted = expected.copy()
            drifted[0], drifted[1] = drifted[1], drifted[0]
            selection_path.write_text("\n".join(drifted) + "\n", encoding="utf-8")
            with self.assertRaises(self.runner.ContractError):
                self.runner.validate_selection("C", spec, selection_path, train_path)
            selection_path.write_text(
                "\n".join(expected[:-1] + ["train__999__random_2"]) + "\n",
                encoding="utf-8",
            )
            with self.assertRaises(self.runner.ContractError):
                self.runner.validate_selection("C", spec, selection_path, train_path)

    def test_calibration_formula_and_clip(self):
        value = self.runner.calibrated_lambda([1.0, 3.0, 2.0, 5.0, 4.0])
        self.assertEqual(value["median_g_rec_over_g_scf"], 3.0)
        self.assertAlmostEqual(value["lambda_unclipped"], 0.3)
        self.assertAlmostEqual(value["lambda_scf"], 0.3)
        self.assertFalse(value["lambda_clipped"])
        clipped = self.runner.calibrated_lambda([20.0] * 5)
        self.assertEqual(clipped["lambda_scf"], 1.0)
        self.assertTrue(clipped["lambda_clipped"])
        with self.assertRaises(self.runner.ContractError):
            self.runner.calibrated_lambda([1.0, 2.0])
        with self.assertRaises(self.runner.ContractError):
            self.runner.calibrated_lambda([1.0, 1.0, 0.0, 1.0, 1.0])

    def test_cpu_autograd_rms_and_no_parameter_grad(self):
        feature = torch.tensor([[1.0, 2.0], [3.0, 4.0]], requires_grad=True)
        rec = feature.square().mean()
        aux = (feature * 3.0).sum()
        g_rec = self.runner.gradient_rms(rec, feature, retain_graph=True)
        g_scf = self.runner.gradient_rms(aux, feature, retain_graph=False)
        self.assertAlmostEqual(g_rec, (30.0 / 16.0) ** 0.5, places=12)
        self.assertAlmostEqual(g_scf, 3.0, places=12)
        self.assertIsNone(feature.grad)
        self.assertFalse(torch.cuda.is_initialized())

    def test_templates_are_locked_and_lambda_is_null(self):
        protocol = json.loads(PROTOCOL_PATH.read_text(encoding="utf-8"))
        for fold in ("C", "D"):
            path = ROOT / protocol["folds"][fold]["template"]
            payload = yaml.safe_load(path.read_text(encoding="utf-8"))
            self.runner.validate_template(payload, fold)
            self.assertIsNone(payload["model"]["cranial_scqr"]["auxiliary_loss_weight"])
            self.assertFalse(payload["cranial_scqr_execution"]["training_authorized"])
            self.assertEqual(payload["cranial_scqr_execution"]["optimizer_steps_authorized"], 0)

    def test_execution_authorization_is_a_required_second_key(self):
        protocol_sha = self.runner.sha256_file(PROTOCOL_PATH)
        relative_protocol = str(PROTOCOL_PATH.relative_to(ROOT))
        relative_output = "logs/cranial_scqr_v12_qa1/synthetic_never_created"
        base = {
            "authorization_id": "cranial-scqr-v1.2-QA1-CD-gradient-calibration-execution-v1",
            "status": "AUTHORIZED",
            "execution_authorized": True,
            "allowed_runs": 1,
            "protocol": {"path": relative_protocol, "sha256": protocol_sha},
            "output_dir": relative_output,
            "python_executable": "/opt/conda/envs/adapointr-mamba/bin/python",
            "device": "cuda:0",
            "execution_counts": {
                "folds": 2,
                "payload_open_events": 40,
                "selected_unique_cases": 30,
                "full_model_forward_calls": 10,
                "autograd_calls": 20,
                "optimizer_constructions": 0,
                "optimizer_steps": 0,
                "checkpoint_loads": 0,
                "checkpoint_writes": 0,
                "bncal_runs": 0,
            },
        }
        with tempfile.TemporaryDirectory(dir=ROOT) as tmp:
            auth_path = Path(tmp) / "authorization.json"
            auth_path.write_text(json.dumps(base), encoding="utf-8")
            output_path = ROOT / relative_output
            validated = self.runner.validate_execution_authorization(
                auth_path, PROTOCOL_PATH, output_path
            )
            self.assertTrue(validated["execution_authorized"])
            base["execution_authorized"] = False
            auth_path.write_text(json.dumps(base), encoding="utf-8")
            with self.assertRaises(self.runner.ContractError):
                self.runner.validate_execution_authorization(
                    auth_path, PROTOCOL_PATH, output_path
                )
        self.assertFalse((ROOT / relative_output).exists())

    def test_static_import_and_optimizer_guards(self):
        source = RUNNER_PATH.read_text(encoding="utf-8")
        ast.parse(source)
        prefix = source.split("def import_runtime_components", 1)[0]
        self.assertNotIn("from datasets", prefix)
        self.assertNotIn("from models", prefix)
        self.assertNotIn("from utils", prefix)
        self.assertNotIn("torch.optim", source)
        self.assertNotIn(".step(", source)
        self.assertFalse(torch.cuda.is_initialized())

    def test_sha256_lines_is_newline_canonical(self):
        values = ["alpha", "beta"]
        expected = hashlib.sha256(b"alpha\nbeta\n").hexdigest()
        self.assertEqual(self.runner.sha256_lines(values), expected)


if __name__ == "__main__":
    unittest.main(verbosity=2)
