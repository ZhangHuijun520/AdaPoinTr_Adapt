#!/usr/bin/env python
"""Pure-text validator for the six training-locked Cranial-SCQR v1.2 QA-1 configs."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

import yaml


ROOT = Path(__file__).resolve().parents[1]
PROTOCOL_ID = "cranial-scqr-v1.2-QA1-formal-config-v1"
LOCK_PATH = "docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_cd_lambda_lock_protocol_v1.json"
LOCK_SHA256 = "ae2953071d8e7d7fe4153be49fcb294ce9024c922cc4130633dd8f6d9c5a23c7"
CONFIG_DIR = "cfgs/SkullBreak_models/cranial_scqr_v12_qa1_authorized_v1"
FOLD_DATA = {
    "C": {
        "train": "logs/skullbreak_mamba_v12_development/protocol_v1/foldC_train_case_ids.txt",
        "train_sha256": "3c5883d1f582b90533ffed3ae61b1bbe8b88c39b75f40faddf25b63d8f93836d",
        "dev": "logs/skullbreak_mamba_v12_development/protocol_v1/foldC_dev_case_ids.txt",
        "dev_sha256": "0bc9286bea354c60870818e47207a9da7f156704557f366ef27847d589f5c0b0",
        "lambda_scf": 0.8912909312609397,
    },
    "D": {
        "train": "logs/skullbreak_mamba_v12_development/protocol_v1/foldD_train_case_ids.txt",
        "train_sha256": "682067ea877e8370e5c3d0ac7b2cdd7ae3b2b372a146829b42491899aa1c0aa1",
        "dev": "logs/skullbreak_mamba_v12_development/protocol_v1/foldD_dev_case_ids.txt",
        "dev_sha256": "7afc9edc6654891cc8593ab2ce172657e1227e4583ed3281b159ab3ae2be68ac",
        "lambda_scf": 0.8346387037781536,
    },
}
CANDIDATES = {
    "B0": {"variant": "B0", "alias": None, "reference": "B0", "lambda": None},
    "LS": {"variant": "A1", "alias": "A1", "reference": "A1", "lambda": "fold"},
    "LSQ": {"variant": "Q0", "alias": "Q0", "reference": "Q0", "lambda": "fold"},
}
EXECUTION_LOCK = {
    "stage": "V12_P1_QA1_static_template",
    "status": "training_locked_pending_P2_and_per_run_authorization",
    "training_authorized": False,
    "optimizer_steps_authorized": 0,
    "bncal_authorized": False,
    "development_payload_access_authorized": False,
    "development_evaluation_authorized": False,
    "formal_timing_authorized": False,
    "resume_authorized": False,
    "automatic_rerun_authorized": False,
    "checkpoint_initial_state": "scratch",
}
TOP_LEVEL_KEYS = {
    "optimizer",
    "scheduler",
    "bnmscheduler",
    "dataset",
    "model",
    "total_bs",
    "step_per_update",
    "max_epoch",
    "consider_metric",
    "save_freq",
    "save_best_checkpoint",
    "save_final_epoch_checkpoints",
    "cranial_scqr_execution",
    "qa1_lock",
    "development_protocol",
}


class ContractError(RuntimeError):
    """Raised when a static QA-1 configuration contract is violated."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ContractError(f"cannot read JSON {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise ContractError(f"JSON root must be an object: {path}")
    return payload


def read_yaml(path: Path) -> dict[str, Any]:
    try:
        payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, yaml.YAMLError) as exc:
        raise ContractError(f"cannot read YAML {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise ContractError(f"YAML root must be a mapping: {path}")
    return payload


def expected_runs() -> list[dict[str, Any]]:
    runs = []
    for candidate in ("B0", "LS", "LSQ"):
        for fold in ("C", "D"):
            meta = CANDIDATES[candidate]
            value = None if meta["lambda"] is None else FOLD_DATA[fold]["lambda_scf"]
            item = {
                "run_key": f"{candidate}_fold{fold}_seed0",
                "candidate": candidate,
                "model_variant": meta["variant"],
                "fold": fold,
                "seed": 0,
                "lambda_scf": value,
                "config": f"{CONFIG_DIR}/CranialSCQRV12QA1_{candidate}_fold{fold}_seed0.yaml",
                "reference_template": (
                    "cfgs/SkullBreak_models/cranial_scqr_v11_l4_round_a_authorized_v1/"
                    f"CranialSCQRV11_{meta['reference']}_foldA_seed0.yaml"
                ),
            }
            if meta["alias"] is not None:
                item["v11_alias"] = meta["alias"]
            runs.append(item)
    return runs


def _expected_dataset(reference: dict[str, Any], fold: str) -> dict[str, Any]:
    expected = copy.deepcopy(reference["dataset"])
    expected["train"]["others"]["include_case_ids_file"] = FOLD_DATA[fold]["train"]
    for split in ("val", "test"):
        expected[split]["others"]["include_case_ids_file"] = FOLD_DATA[fold]["dev"]
    return expected


def _expected_qa1_lock(run: dict[str, Any]) -> dict[str, Any]:
    fold = run["fold"]
    expected = {
        "lambda_lock_protocol": LOCK_PATH,
        "lambda_lock_protocol_sha256": LOCK_SHA256,
        "run_key": run["run_key"],
        "candidate": run["candidate"],
        "fold": fold,
        "seed": 0,
        "lambda_scf": run["lambda_scf"],
        "train_case_ids": FOLD_DATA[fold]["train"],
        "train_case_ids_sha256": FOLD_DATA[fold]["train_sha256"],
        "dev_case_ids": FOLD_DATA[fold]["dev"],
        "dev_case_ids_sha256": FOLD_DATA[fold]["dev_sha256"],
        "configuration_only": True,
    }
    alias = CANDIDATES[run["candidate"]]["alias"]
    if alias is not None:
        expected["v11_alias"] = alias
    return expected


def _expected_development(run: dict[str, Any]) -> dict[str, Any]:
    expected = {
        "name": "cranial-scqr-v1.2",
        "candidate": run["candidate"],
        "fold": run["fold"],
        "qa_stage": "QA-1",
        "seed": 0,
        "development84_reused": True,
        "protected_splits_accessed": False,
        "confirmation_allowed": False,
        "old_monitor_allowed": False,
        "official_test_allowed": False,
        "mug_payload_allowed": False,
        "skullfix_payload_allowed": False,
    }
    alias = CANDIDATES[run["candidate"]]["alias"]
    if alias is not None:
        expected["v11_alias"] = alias
    return expected


def validate_config_payload(
    payload: dict[str, Any],
    run: dict[str, Any],
    reference: dict[str, Any],
) -> None:
    label = run["run_key"]
    if set(payload) != TOP_LEVEL_KEYS:
        raise ContractError(f"{label}: unexpected top-level key set")
    for key in ("optimizer", "scheduler", "bnmscheduler"):
        if payload[key] != reference[key]:
            raise ContractError(f"{label}: {key} differs from frozen v1.1 reference")
    expected_scalars = {
        "total_bs": 8,
        "step_per_update": 1,
        "max_epoch": 100,
        "consider_metric": "CDL2",
        "save_freq": 10,
        "save_best_checkpoint": False,
        "save_final_epoch_checkpoints": False,
    }
    for key, value in expected_scalars.items():
        if payload.get(key) != value:
            raise ContractError(f"{label}: scalar field {key} drifted")
    if payload["dataset"] != _expected_dataset(reference, run["fold"]):
        raise ContractError(f"{label}: dataset contract drifted")
    expected_model = copy.deepcopy(reference["model"])
    expected_model["cranial_scqr"]["auxiliary_loss_weight"] = run["lambda_scf"]
    if payload["model"] != expected_model:
        raise ContractError(f"{label}: normalized model semantics drifted")
    if payload["cranial_scqr_execution"] != EXECUTION_LOCK:
        raise ContractError(f"{label}: execution lock drifted")
    if payload["qa1_lock"] != _expected_qa1_lock(run):
        raise ContractError(f"{label}: QA-1 lock metadata drifted")
    if payload["development_protocol"] != _expected_development(run):
        raise ContractError(f"{label}: development metadata drifted")


def verify_binding(root: Path, item: dict[str, Any]) -> None:
    path = root / item["path"]
    if not path.is_file():
        raise ContractError(f"bound file missing: {item['path']}")
    if "bytes" in item and path.stat().st_size != item["bytes"]:
        raise ContractError(f"bound size mismatch: {item['path']}")
    if sha256_file(path) != item["sha256"]:
        raise ContractError(f"bound SHA256 mismatch: {item['path']}")


def validate_protocol(protocol_path: Path, root: Path = ROOT) -> dict[str, Any]:
    protocol = read_json(protocol_path)
    if protocol.get("protocol_id") != PROTOCOL_ID:
        raise ContractError("unexpected formal config protocol_id")
    if protocol.get("status") != "FROZEN_IMPLEMENTATION_ONLY":
        raise ContractError("formal config protocol is not frozen implementation-only")
    if protocol.get("execution_authorized") is not False:
        raise ContractError("formal config protocol must not authorize execution")
    for item in protocol.get("sha256_bindings", []):
        verify_binding(root, item)
    if not protocol.get("sha256_bindings"):
        raise ContractError("formal config protocol has no SHA256 bindings")
    runs = protocol.get("runs")
    expected = expected_runs()
    if not isinstance(runs, list) or len(runs) != 6:
        raise ContractError("formal config protocol must contain exactly six runs")
    comparable = [
        {key: value for key, value in item.items() if key not in {"bytes", "sha256"}}
        for item in runs
    ]
    if comparable != expected:
        raise ContractError("formal config run matrix drifted")
    if len({item["config"] for item in runs}) != 6:
        raise ContractError("formal config paths are not unique")
    for item in runs:
        config_path = root / item["config"]
        if config_path.stat().st_size != item["bytes"]:
            raise ContractError(f"config size mismatch: {item['config']}")
        if sha256_file(config_path) != item["sha256"]:
            raise ContractError(f"config SHA256 mismatch: {item['config']}")
        reference = read_yaml(root / item["reference_template"])
        validate_config_payload(read_yaml(config_path), item, reference)
    c_values = {item["lambda_scf"] for item in runs if item["fold"] == "C" and item["candidate"] != "B0"}
    d_values = {item["lambda_scf"] for item in runs if item["fold"] == "D" and item["candidate"] != "B0"}
    if c_values != {FOLD_DATA["C"]["lambda_scf"]} or d_values != {FOLD_DATA["D"]["lambda_scf"]}:
        raise ContractError("within-fold LS/LSQ lambda equality failed")
    if any(item["lambda_scf"] is not None for item in runs if item["candidate"] == "B0"):
        raise ContractError("B0 lambda_scf must remain null")
    boundaries = protocol.get("boundaries", {})
    required_false = (
        "npz_payload_access_authorized",
        "checkpoint_access_authorized",
        "gpu_or_cuda_authorized",
        "preflight_authorized",
        "training_authorized",
        "bncal_authorized",
        "development_evaluation_authorized",
        "automatic_advance_authorized",
    )
    if any(boundaries.get(key) is not False for key in required_false):
        raise ContractError("formal config protocol boundary drifted")
    if boundaries.get("optimizer_steps_authorized") != 0:
        raise ContractError("formal config protocol authorizes optimizer steps")
    return protocol


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, required=True)
    args = parser.parse_args()
    protocol_path = args.protocol.resolve()
    try:
        protocol_path.relative_to(ROOT)
    except ValueError as exc:
        raise ContractError("protocol must remain under project root") from exc
    protocol = validate_protocol(protocol_path)
    print(
        json.dumps(
            {
                "status": "PASS",
                "protocol_id": protocol["protocol_id"],
                "configs_verified": 6,
                "training_authorized": False,
                "optimizer_steps_authorized": 0,
                "bncal_authorized": False,
            },
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
