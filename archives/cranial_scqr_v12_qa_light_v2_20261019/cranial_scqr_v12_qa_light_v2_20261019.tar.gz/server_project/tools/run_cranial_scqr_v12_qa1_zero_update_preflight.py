#!/usr/bin/env python
"""Cranial-SCQR v1.2 QA-1 six-run synthetic zero-update preflight.

The module is inert without a separately frozen execution authorization.  It
validates every control-plane binding before importing torch or project model
code.  It never constructs a dataset or optimizer and never opens a manifest,
NPZ payload, or checkpoint.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

ROOT = PROJECT_ROOT
PROTOCOL_ID = "cranial-scqr-v1.2-QA1-six-run-zero-update-preflight-v1"
AUTHORIZATION_ID = (
    "cranial-scqr-v1.2-QA1-six-run-zero-update-preflight-execution-v1"
)
EXECUTION_ENV_GATE = "V12_QA1_ZERO_UPDATE_PREFLIGHT_EXECUTION_AUTHORIZED"
MODEL_SEED = 31002
SYNTHETIC_SEED = 20260921
INPUT_POINTS = 8192
OUTPUT_POINTS = 8192
TRAIN_EPOCH = 20
RUN_KEYS = (
    "B0_foldC_seed0",
    "B0_foldD_seed0",
    "LS_foldC_seed0",
    "LS_foldD_seed0",
    "LSQ_foldC_seed0",
    "LSQ_foldD_seed0",
)
EXECUTION_COUNTS = {
    "preflight_runs": 6,
    "model_initializations_from_scratch": 6,
    "deterministic_artificial_input_batches": 1,
    "full_model_eval_forward_calls": 6,
    "full_model_training_forward_calls": 6,
    "full_model_forward_calls_total": 12,
    "full_model_backward_calls": 6,
    "autograd_calls": 6,
    "optimizer_constructions": 0,
    "optimizer_steps": 0,
    "parameter_or_buffer_updates": 0,
    "dataset_constructions": 0,
    "manifest_files_opened": 0,
    "npz_payload_files_opened": 0,
    "checkpoint_files_loaded": 0,
    "checkpoint_files_written": 0,
    "bncal_runs": 0,
    "development_evaluator_calls": 0,
    "formal_timing_iterations": 0,
}


class ContractError(RuntimeError):
    """Raised when a frozen preflight contract is violated."""


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_lines(values: Iterable[str]) -> str:
    payload = "".join(f"{value}\n" for value in values).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ContractError(f"cannot read JSON contract {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise ContractError(f"JSON contract must be an object: {path}")
    return payload


def ensure_project_path(path: Path, *, must_exist: bool = False) -> Path:
    resolved = path.resolve(strict=must_exist)
    try:
        resolved.relative_to(ROOT)
    except ValueError as exc:
        raise ContractError(f"path escapes fixed project root: {path}") from exc
    return resolved


def ensure_absent_output(path: Path) -> None:
    if path.exists():
        raise FileExistsError(f"refusing to reuse preflight output: {path}")


def load_case_ids(path: Path, expected_count: int) -> list[str]:
    values = [
        line.strip()
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]
    if len(values) != expected_count:
        raise ContractError(
            f"expected {expected_count} case IDs in {path}, found {len(values)}"
        )
    if len(values) != len(set(values)):
        raise ContractError(f"duplicate case ID in {path}")
    return values


def validate_fold_lists(
    fold: str,
    spec: dict[str, Any],
    train_path: Path,
    dev_path: Path,
) -> dict[str, Any]:
    if fold not in ("C", "D"):
        raise ContractError(f"unauthorized fold: {fold}")
    train = load_case_ids(train_path, 315)
    dev = load_case_ids(dev_path, 105)
    if sha256_file(train_path) != spec.get("train_sha256"):
        raise ContractError(f"fold {fold}: train allowlist SHA256 mismatch")
    if sha256_file(dev_path) != spec.get("dev_sha256"):
        raise ContractError(f"fold {fold}: dev allowlist SHA256 mismatch")
    overlap = sorted(set(train) & set(dev))
    if overlap:
        raise ContractError(f"fold {fold}: train/dev overlap: {overlap[:3]}")
    if len(train) // 8 != 39 or len(train) % 8 != 3:
        raise ContractError(f"fold {fold}: loader arithmetic drifted")
    return {
        "train_count": len(train),
        "dev_count": len(dev),
        "train_dev_overlap": 0,
        "batch_size": 8,
        "drop_last": True,
        "loader_batches": 39,
    }


def expected_run_specs() -> list[dict[str, Any]]:
    base = "cfgs/SkullBreak_models/cranial_scqr_v12_qa1_authorized_v1"
    return [
        {
            "run_key": "B0_foldC_seed0", "candidate": "B0",
            "model_variant": "B0", "fold": "C", "seed": 0,
            "lambda_scf": None,
            "config": f"{base}/CranialSCQRV12QA1_B0_foldC_seed0.yaml",
            "config_sha256": "b2f2b7426062598f9e9b189ef4a31a0bbd9cb64c0d724945d0d73bd4f7cfcaa3",
        },
        {
            "run_key": "B0_foldD_seed0", "candidate": "B0",
            "model_variant": "B0", "fold": "D", "seed": 0,
            "lambda_scf": None,
            "config": f"{base}/CranialSCQRV12QA1_B0_foldD_seed0.yaml",
            "config_sha256": "7687254ff35a84706b34a1595a677ae4a66382081a0ae6cf22b62f189d4c0934",
        },
        {
            "run_key": "LS_foldC_seed0", "candidate": "LS",
            "model_variant": "A1", "fold": "C", "seed": 0,
            "lambda_scf": 0.8912909312609397,
            "config": f"{base}/CranialSCQRV12QA1_LS_foldC_seed0.yaml",
            "config_sha256": "9610941f0f74d339fa64304fe1c0660945def0cca10efc49e9092815cba95569",
        },
        {
            "run_key": "LS_foldD_seed0", "candidate": "LS",
            "model_variant": "A1", "fold": "D", "seed": 0,
            "lambda_scf": 0.8346387037781536,
            "config": f"{base}/CranialSCQRV12QA1_LS_foldD_seed0.yaml",
            "config_sha256": "e6fa3c43f26b00a570d76c71c262012d1fa9c3e2c5511dd745570af4ba4c4d85",
        },
        {
            "run_key": "LSQ_foldC_seed0", "candidate": "LSQ",
            "model_variant": "Q0", "fold": "C", "seed": 0,
            "lambda_scf": 0.8912909312609397,
            "config": f"{base}/CranialSCQRV12QA1_LSQ_foldC_seed0.yaml",
            "config_sha256": "343b84a46d7418072aea2d647041c825cafba7a22e178b961d54fb7397d6a76d",
        },
        {
            "run_key": "LSQ_foldD_seed0", "candidate": "LSQ",
            "model_variant": "Q0", "fold": "D", "seed": 0,
            "lambda_scf": 0.8346387037781536,
            "config": f"{base}/CranialSCQRV12QA1_LSQ_foldD_seed0.yaml",
            "config_sha256": "39b5a658d88402f97c8998a52628177c73d485339f514be7d4bb81dbbc03ef6a",
        },
    ]


def validate_config_payload(payload: dict[str, Any], run: dict[str, Any]) -> None:
    execution = payload.get("cranial_scqr_execution", {})
    required_execution = {
        "stage": "V12_P1_QA1_static_template",
        "status": "training_locked_pending_P2_and_per_run_authorization",
        "training_authorized": False,
        "optimizer_steps_authorized": 0,
        "bncal_authorized": False,
        "development_payload_access_authorized": False,
        "development_evaluation_authorized": False,
        "formal_timing_authorized": False,
        "resume_authorized": False,
        "automatic_rerun_authorized": False,
        "checkpoint_initial_state": "scratch",
    }
    if execution != required_execution:
        raise ContractError(f"{run['run_key']}: execution lock drifted")
    lock = payload.get("qa1_lock", {})
    for key in ("run_key", "candidate", "fold", "seed", "lambda_scf"):
        if lock.get(key) != run[key]:
            raise ContractError(f"{run['run_key']}: qa1_lock.{key} drifted")
    candidate = run["candidate"]
    expected_alias = {"B0": None, "LS": "A1", "LSQ": "Q0"}[candidate]
    if expected_alias is not None and lock.get("v11_alias") != expected_alias:
        raise ContractError(f"{run['run_key']}: v11 alias drifted")
    model = payload.get("model", {}).get("cranial_scqr", {})
    expected_model = {
        "B0": ("B0", False, False, False, False, 0.0, None),
        "LS": ("A1", True, True, True, False, 0.0, run["lambda_scf"]),
        "LSQ": ("Q0", True, True, True, True, 0.0, run["lambda_scf"]),
    }[candidate]
    observed_model = (
        model.get("variant"), model.get("enabled"),
        model.get("local_geometry_enabled"),
        model.get("contact_supervision_enabled"),
        model.get("query_conditioning_enabled"),
        model.get("contact_bias_beta"),
        model.get("auxiliary_loss_weight"),
    )
    if observed_model != expected_model:
        raise ContractError(f"{run['run_key']}: candidate model switches drifted")
    fold = run["fold"]
    expected_train = (
        "logs/skullbreak_mamba_v12_development/protocol_v1/"
        f"fold{fold}_train_case_ids.txt"
    )
    expected_dev = (
        "logs/skullbreak_mamba_v12_development/protocol_v1/"
        f"fold{fold}_dev_case_ids.txt"
    )
    dataset = payload.get("dataset", {})
    if dataset.get("train", {}).get("others", {}).get("include_case_ids_file") != expected_train:
        raise ContractError(f"{run['run_key']}: train allowlist path drifted")
    for split in ("val", "test"):
        if dataset.get(split, {}).get("others", {}).get("include_case_ids_file") != expected_dev:
            raise ContractError(f"{run['run_key']}: {split} allowlist path drifted")
    if payload.get("total_bs") != 8 or payload.get("step_per_update") != 1:
        raise ContractError(f"{run['run_key']}: batch/update metadata drifted")
    if payload.get("max_epoch") != 100:
        raise ContractError(f"{run['run_key']}: max_epoch drifted")
    development = payload.get("development_protocol", {})
    if (
        development.get("candidate") != candidate
        or development.get("fold") != fold
        or development.get("seed") != 0
        or development.get("qa_stage") != "QA-1"
    ):
        raise ContractError(f"{run['run_key']}: development identity drifted")
    for key in (
        "protected_splits_accessed", "confirmation_allowed",
        "old_monitor_allowed", "official_test_allowed",
        "mug_payload_allowed", "skullfix_payload_allowed",
    ):
        if development.get(key) is not False:
            raise ContractError(f"{run['run_key']}: protected flag {key} drifted")


def validate_protocol_payload(payload: dict[str, Any]) -> None:
    if payload.get("protocol_id") != PROTOCOL_ID:
        raise ContractError("unexpected preflight protocol_id")
    if payload.get("status") != "FROZEN_IMPLEMENTATION_ONLY_PENDING_EXECUTION_AUTHORIZATION":
        raise ContractError("preflight protocol is not frozen pending authorization")
    if payload.get("execution_authorized") is not False:
        raise ContractError("implementation protocol must not authorize execution")
    if payload.get("runs") != expected_run_specs():
        raise ContractError("six-run matrix drifted")
    if payload.get("execution_count_contract") != EXECUTION_COUNTS:
        raise ContractError("execution count contract drifted")
    boundary = payload.get("data_boundary", {})
    expected_boundary = {
        "synthetic_seed": SYNTHETIC_SEED,
        "synthetic_batch_size": 1,
        "synthetic_partial_points": INPUT_POINTS,
        "synthetic_implant_points": INPUT_POINTS,
        "allowlist_text_metadata_read": True,
        "dataset_constructions": 0,
        "manifest_files_opened": 0,
        "npz_payload_files_opened": 0,
        "checkpoint_files_loaded": 0,
        "development_payload_read": False,
        "confirmation20_read": False,
        "official_test_read": False,
        "old_monitor_read": False,
        "MUG_payload_read": False,
        "SkullFix_payload_read": False,
    }
    if boundary != expected_boundary:
        raise ContractError("data boundary drifted")


def validate_protocol(protocol_path: Path) -> dict[str, Any]:
    payload = read_json(protocol_path)
    validate_protocol_payload(payload)
    bindings = payload.get("sha256_bindings", [])
    if not bindings:
        raise ContractError("protocol has no SHA256 bindings")
    for item in bindings:
        bound = ensure_project_path(ROOT / item["path"], must_exist=True)
        if not bound.is_file() or sha256_file(bound) != item["sha256"]:
            raise ContractError(f"SHA256 binding mismatch: {item['path']}")
        if "bytes" in item and bound.stat().st_size != item["bytes"]:
            raise ContractError(f"size binding mismatch: {item['path']}")
    try:
        import yaml
    except ImportError as exc:
        raise ContractError("PyYAML is required for config validation") from exc
    for run in payload["runs"]:
        path = ensure_project_path(ROOT / run["config"], must_exist=True)
        if sha256_file(path) != run["config_sha256"]:
            raise ContractError(f"config SHA256 mismatch: {run['run_key']}")
        config = yaml.safe_load(path.read_text(encoding="utf-8"))
        if not isinstance(config, dict):
            raise ContractError(f"{run['run_key']}: config must be a mapping")
        validate_config_payload(config, run)
    for fold in ("C", "D"):
        spec = payload["folds"][fold]
        validate_fold_lists(
            fold,
            spec,
            ensure_project_path(ROOT / spec["train_allowlist"], must_exist=True),
            ensure_project_path(ROOT / spec["dev_allowlist"], must_exist=True),
        )
    return payload


def validate_execution_authorization(
    authorization_path: Path,
    protocol_path: Path,
    output_dir: Path,
) -> dict[str, Any]:
    payload = read_json(authorization_path)
    if payload.get("authorization_id") != AUTHORIZATION_ID:
        raise ContractError("unexpected execution authorization_id")
    if payload.get("status") != "AUTHORIZED" or payload.get("execution_authorized") is not True:
        raise ContractError("six-run preflight execution is not authorized")
    if payload.get("allowed_runs") != 1:
        raise ContractError("execution authorization must permit exactly one job")
    binding = payload.get("protocol", {})
    if binding.get("path") != str(protocol_path.relative_to(ROOT)):
        raise ContractError("execution authorization binds a different protocol path")
    if binding.get("sha256") != sha256_file(protocol_path):
        raise ContractError("execution authorization protocol SHA256 mismatch")
    runner_binding = payload.get("runner", {})
    runner_path = Path(__file__).resolve()
    if runner_binding.get("path") != str(runner_path.relative_to(ROOT)):
        raise ContractError("execution authorization binds a different runner")
    if runner_binding.get("sha256") != sha256_file(runner_path):
        raise ContractError("execution authorization runner SHA256 mismatch")
    if payload.get("output_dir") != str(output_dir.relative_to(ROOT)):
        raise ContractError("output directory differs from execution authorization")
    if payload.get("python_executable") != "/opt/conda/envs/adapointr-mamba/bin/python":
        raise ContractError("Python executable differs from authorization schema")
    if payload.get("device") != "cuda:0":
        raise ContractError("device differs from authorization schema")
    if payload.get("execution_counts") != EXECUTION_COUNTS:
        raise ContractError("execution authorization counts drifted")
    required_false = (
        "training_authorized", "bncal_authorized",
        "development_evaluation_authorized", "automatic_retry_authorized",
        "resume_authorized",
    )
    if any(payload.get(key) is not False for key in required_false):
        raise ContractError("execution authorization boundary drifted")
    return payload


def import_runtime_components() -> dict[str, Any]:
    import torch
    import torch.nn as nn
    import yaml
    from easydict import EasyDict
    from models import build_model_from_cfg

    return {
        "torch": torch,
        "nn": nn,
        "yaml": yaml,
        "EasyDict": EasyDict,
        "build_model_from_cfg": build_model_from_cfg,
    }


def tensor_sha256(tensor: Any, torch: Any) -> str:
    value = tensor.detach().cpu().contiguous()
    digest = hashlib.sha256()
    digest.update(str(value.dtype).encode("ascii"))
    digest.update(str(tuple(value.shape)).encode("ascii"))
    digest.update(value.reshape(-1).view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


def state_sha256(module: Any, torch: Any, exclude_scqr: bool = False) -> str:
    digest = hashlib.sha256()
    for name, value in sorted(module.state_dict().items()):
        if exclude_scqr and name.startswith("base_model.scqr_"):
            continue
        digest.update(name.encode("utf-8"))
        digest.update(tensor_sha256(value, torch).encode("ascii"))
    return digest.hexdigest()


def state_snapshot(module: Any) -> dict[str, Any]:
    return {
        name: value.detach().cpu().clone()
        for name, value in module.state_dict().items()
    }


def changed_state_names(module: Any, before: dict[str, Any], torch: Any) -> list[str]:
    after = module.state_dict()
    if set(after) != set(before):
        raise ContractError("state_dict key set changed")
    return sorted(
        name for name, old in before.items()
        if not torch.equal(old, after[name].detach().cpu())
    )


def trainable_membership(module: Any) -> dict[str, Any]:
    names = [name for name, parameter in module.named_parameters() if parameter.requires_grad]
    if not names or len(names) != len(set(names)):
        raise ContractError("trainable parameter membership is empty or duplicated")
    all_trainable = sum(1 for parameter in module.parameters() if parameter.requires_grad)
    if len(names) != all_trainable:
        raise ContractError("trainable parameter membership omitted a parameter")
    ordered = sorted(names)
    return {
        "group_count": 1,
        "trainable_tensor_count": len(ordered),
        "trainable_names_sha256": sha256_lines(ordered),
    }


def synthetic_case(device: Any, torch: Any) -> tuple[Any, Any, Any]:
    index = torch.arange(INPUT_POINTS, dtype=torch.float64)
    z = 1.0 - 2.0 * (index + 0.5) / float(INPUT_POINTS)
    azimuth = index * (math.pi * (3.0 - math.sqrt(5.0)))
    radius = torch.sqrt(torch.clamp(1.0 - z.square(), min=0.0))
    partial = torch.stack(
        (radius * torch.cos(azimuth), radius * torch.sin(azimuth), z), dim=-1
    ).float()
    implant = partial[:2048].repeat(4, 1).contiguous()
    return (
        partial.unsqueeze(0).to(device),
        implant.unsqueeze(0).to(device),
        torch.tensor([100.0], device=device, dtype=torch.float32),
    )


def assert_finite(value: Any, name: str, torch: Any) -> None:
    if not torch.is_tensor(value) or not torch.isfinite(value).all():
        raise ContractError(f"{name} is not a finite tensor")


def instrumentation_summary(records: dict[str, Any], candidate: str, torch: Any) -> dict[str, Any]:
    backbone = records["backbone"]
    logits = backbone["scqr_contact_logits"]
    attention = backbone["scqr_query_attention"]
    if candidate == "B0":
        if logits is not None or attention is not None:
            raise ContractError("B0 unexpectedly produced SCQR instrumentation")
        return {"contact_logits": None, "query_attention": None}
    assert_finite(logits, f"{candidate} contact logits", torch)
    if tuple(logits.shape) != (1, 256):
        raise ContractError(f"{candidate} contact logit shape mismatch")
    result = {"contact_logits_shape": list(logits.shape)}
    if candidate == "LS":
        if attention is not None:
            raise ContractError("LS unexpectedly used query conditioning")
        result["query_attention"] = None
    else:
        assert_finite(attention, "LSQ query attention", torch)
        if tuple(attention.shape) != (1, 256, 256):
            raise ContractError("LSQ query attention shape mismatch")
        result["query_attention_shape"] = list(attention.shape)
        result["attention_row_sum_max_error"] = float(
            (attention.sum(-1) - 1.0).abs().max().cpu()
        )
    return result


def build_model(run: dict[str, Any], components: dict[str, Any], device: Any) -> tuple[Any, Any]:
    path = ROOT / run["config"]
    payload = components["yaml"].safe_load(path.read_text(encoding="utf-8"))
    validate_config_payload(payload, run)
    config = components["EasyDict"](payload)
    torch = components["torch"]
    torch.manual_seed(MODEL_SEED)
    torch.cuda.manual_seed_all(MODEL_SEED)
    model = components["build_model_from_cfg"](config.model).to(device)
    return model, config


def run_one(
    run: dict[str, Any],
    components: dict[str, Any],
    device: Any,
    partial: Any,
    implant: Any,
    scale: Any,
) -> dict[str, Any]:
    torch = components["torch"]
    nn = components["nn"]
    model, config = build_model(run, components, device)
    initial_full_hash = state_sha256(model, torch)
    initial_common_hash = state_sha256(model, torch, exclude_scqr=True)
    membership = trainable_membership(model)
    before = state_snapshot(model)

    model.eval()
    model.enable_full_instrumentation(True)
    with torch.no_grad():
        eval_output = model(partial)
    records = model.pop_full_instrumentation()
    model.enable_full_instrumentation(False)
    if len(eval_output) != 2:
        raise ContractError(f"{run['run_key']}: eval output arity mismatch")
    coarse, fine = eval_output
    assert_finite(coarse, f"{run['run_key']} coarse", torch)
    assert_finite(fine, f"{run['run_key']} fine", torch)
    if tuple(coarse.shape) != (1, 256, 3):
        raise ContractError(f"{run['run_key']}: coarse shape mismatch")
    if tuple(fine.shape) != (1, OUTPUT_POINTS, 3):
        raise ContractError(f"{run['run_key']}: fine shape mismatch")
    instrumentation = instrumentation_summary(records, run["candidate"], torch)

    model.train()
    frozen_bn = []
    for name, module in model.named_modules():
        if isinstance(module, nn.modules.batchnorm._BatchNorm):
            module.eval()
            frozen_bn.append(name)
    model.zero_grad(set_to_none=True)
    train_output = model(partial, epoch=TRAIN_EPOCH)
    expected_arity = 4 if run["candidate"] == "B0" else 5
    if len(train_output) != expected_arity:
        raise ContractError(f"{run['run_key']}: training output arity mismatch")
    sparse_loss, dense_loss = model.get_loss(
        train_output,
        implant,
        epoch=TRAIN_EPOCH,
        partial=partial,
        normalization_scale=scale,
    )
    total_loss = sparse_loss + dense_loss
    assert_finite(total_loss, f"{run['run_key']} total loss", torch)
    total_loss.backward()
    gradient_names = []
    nonfinite = []
    for name, parameter in model.named_parameters():
        if parameter.grad is not None:
            gradient_names.append(name)
            if not torch.isfinite(parameter.grad).all():
                nonfinite.append(name)
    if nonfinite:
        raise ContractError(f"{run['run_key']}: nonfinite gradients: {nonfinite}")
    if not gradient_names:
        raise ContractError(f"{run['run_key']}: no gradients were produced")
    changed = changed_state_names(model, before, torch)
    if changed:
        raise ContractError(f"{run['run_key']}: zero-update state changed: {changed}")
    result = {
        "run_key": run["run_key"],
        "candidate": run["candidate"],
        "fold": run["fold"],
        "lambda_scf": run["lambda_scf"],
        "config": run["config"],
        "config_sha256": sha256_file(ROOT / run["config"]),
        "initial_full_state_sha256": initial_full_hash,
        "initial_common_state_sha256": initial_common_hash,
        "trainable_parameter_membership": membership,
        "coarse_shape": list(coarse.shape),
        "fine_shape": list(fine.shape),
        "coarse_sha256": tensor_sha256(coarse, torch),
        "fine_sha256": tensor_sha256(fine, torch),
        "instrumentation": instrumentation,
        "training_output_arity": len(train_output),
        "sparse_loss": float(sparse_loss.detach().cpu()),
        "dense_loss": float(dense_loss.detach().cpu()),
        "total_loss": float(total_loss.detach().cpu()),
        "gradient_tensor_count": len(gradient_names),
        "nonfinite_gradient_count": 0,
        "frozen_batchnorm_modules": frozen_bn,
        "changed_state_names": [],
        "state_unchanged": True,
        "optimizer_constructions": 0,
        "optimizer_steps": 0,
    }
    del records, eval_output, coarse, fine, train_output, model, config
    torch.cuda.empty_cache()
    return result


def verify_initialization_identity(results: list[dict[str, Any]]) -> dict[str, Any]:
    if len({item["initial_common_state_sha256"] for item in results}) != 1:
        raise ContractError("cross-candidate shared initialization hash differs")
    candidate_pairs: dict[str, set[str]] = {}
    membership_pairs: dict[str, set[str]] = {}
    for item in results:
        candidate_pairs.setdefault(item["candidate"], set()).add(
            item["initial_full_state_sha256"]
        )
        membership_pairs.setdefault(item["candidate"], set()).add(
            item["trainable_parameter_membership"]["trainable_names_sha256"]
        )
    if any(len(values) != 1 for values in candidate_pairs.values()):
        raise ContractError("same-candidate Fold C/D full initialization differs")
    if any(len(values) != 1 for values in membership_pairs.values()):
        raise ContractError("same-candidate Fold C/D parameter membership differs")
    return {
        "cross_candidate_shared_initialization_equal": True,
        "same_candidate_fold_cd_full_initialization_equal": True,
        "same_candidate_fold_cd_parameter_membership_equal": True,
        "common_state_sha256": results[0]["initial_common_state_sha256"],
    }


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def write_report(path: Path, receipt: dict[str, Any]) -> None:
    lines = [
        "# Cranial-SCQR v1.2 QA-1 六-run 零更新 preflight",
        "",
        f"- 状态：**{receipt['status']}**",
        f"- run ID：`{receipt['run_id']}`",
        "- 输入：固定人工点云；真实 manifest/NPZ/checkpoint 访问均为 0。",
        "- 精确计数：12 forward、6 backward、0 optimizer construct/step、0 更新。",
        "- 本结果不是训练、BNCal、development 评估或正式计时授权。",
    ]
    if receipt["status"] == "PASS":
        lines.extend(["", "## 六个 run", "", "| run | loss | gradients | state |", "|---|---:|---:|---|"])
        for item in receipt["result"]["runs"]:
            lines.append(
                f"| {item['run_key']} | {item['total_loss']:.9g} | "
                f"{item['gradient_tensor_count']} | unchanged |"
            )
    else:
        lines.extend(["", "## 错误", "", "```text", receipt.get("error", ""), "```"])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def execute(
    protocol_path: Path,
    authorization_path: Path,
    output_dir: Path,
    protocol: dict[str, Any],
    authorization: dict[str, Any],
) -> int:
    ensure_absent_output(output_dir)
    if os.environ.get(EXECUTION_ENV_GATE) != "1":
        raise ContractError(f"{EXECUTION_ENV_GATE}=1 is required")
    if os.environ.get("CUBLAS_WORKSPACE_CONFIG") != ":4096:8":
        raise ContractError("CUBLAS_WORKSPACE_CONFIG=:4096:8 is required")
    components = import_runtime_components()
    torch = components["torch"]
    if torch.cuda.is_initialized():
        raise ContractError("CUDA initialized before all authorization gates passed")
    if not torch.cuda.is_available():
        raise ContractError("CUDA is required for formal preflight")
    if torch.cuda.get_device_name(0) != authorization.get("gpu_name"):
        raise ContractError("runtime GPU name differs from authorization")
    output_dir.mkdir(parents=True)
    progress_path = output_dir / "progress.log"

    def log(message: str) -> None:
        line = f"[{utc_now()}] {message}"
        print(line, flush=True)
        with progress_path.open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")

    receipt: dict[str, Any] = {
        "protocol_id": protocol["protocol_id"],
        "protocol": str(protocol_path.relative_to(ROOT)),
        "protocol_sha256": sha256_file(protocol_path),
        "execution_authorization": str(authorization_path.relative_to(ROOT)),
        "execution_authorization_sha256": sha256_file(authorization_path),
        "run_id": output_dir.name,
        "started_at_utc": utc_now(),
        "execution_counts": dict(EXECUTION_COUNTS),
        "training_authorized_by_this_receipt": False,
        "bncal_authorized_by_this_receipt": False,
    }
    try:
        torch.use_deterministic_algorithms(True)
        torch.backends.cudnn.benchmark = False
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        device = torch.device("cuda:0")
        partial, implant, scale = synthetic_case(device, torch)
        input_hashes = {
            "partial_sha256": tensor_sha256(partial, torch),
            "implant_sha256": tensor_sha256(implant, torch),
            "normalization_scale_sha256": tensor_sha256(scale, torch),
        }
        results = []
        for index, run in enumerate(protocol["runs"], start=1):
            log(f"run {index}/6 {run['run_key']} start")
            results.append(
                run_one(run, components, device, partial, implant, scale)
            )
            log(f"run {index}/6 {run['run_key']} PASS")
        identity = verify_initialization_identity(results)
        receipt.update(
            {
                "status": "PASS",
                "finished_at_utc": utc_now(),
                "result": {
                    "runs": results,
                    "initialization_identity": identity,
                    "synthetic_input": input_hashes,
                    "fold_metadata": protocol["fold_metadata_expected"],
                },
            }
        )
    except Exception as exc:
        receipt.update(
            {
                "status": "ERROR",
                "finished_at_utc": utc_now(),
                "error": f"{type(exc).__name__}: {exc}",
                "traceback": traceback.format_exc(),
            }
        )
    receipt_path = output_dir / "preflight_receipt.json"
    report_path = output_dir / "preflight_report_zh.md"
    write_json(receipt_path, receipt)
    write_report(report_path, receipt)
    files = (progress_path, receipt_path, report_path)
    with (output_dir / "files.sha256").open("w", encoding="ascii") as handle:
        for path in files:
            handle.write(f"{sha256_file(path)}  {path.name}\n")
    print(f"[{receipt['status']}] {output_dir}", flush=True)
    return 0 if receipt["status"] == "PASS" else 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--execution-authorization", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    protocol_path = ensure_project_path(args.protocol, must_exist=True)
    authorization_path = ensure_project_path(
        args.execution_authorization, must_exist=True
    )
    output_dir = ensure_project_path(args.output_dir, must_exist=False)
    ensure_absent_output(output_dir)
    protocol = validate_protocol(protocol_path)
    authorization = validate_execution_authorization(
        authorization_path, protocol_path, output_dir
    )
    return execute(
        protocol_path, authorization_path, output_dir, protocol, authorization
    )


if __name__ == "__main__":
    raise SystemExit(main())
