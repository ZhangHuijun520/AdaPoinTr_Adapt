#!/usr/bin/env python3
"""Pure-text and CPU synthetic contracts for the v1.2 QA-1 evaluator."""

from __future__ import annotations

import copy
import ast
import hashlib
import importlib.util
import os
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch
from pathlib import Path

import numpy as np


# Hide CUDA before importing the implementation under test.
os.environ["CUDA_VISIBLE_DEVICES"] = ""
TOOLS_DIR = Path(__file__).resolve().parent
if str(TOOLS_DIR) not in sys.path:
    sys.path.insert(0, str(TOOLS_DIR))

import run_cranial_scqr_v12_qa1_development_eval as runner  # noqa: E402


def synthetic_request() -> dict:
    return {
        "request_schema_version": runner.REQUEST_SCHEMA,
        "request_id": "synthetic-request-v2",
        "status": "AWAITING_EXPLICIT_USER_AUTHORIZATION",
        "execution_authorized": False,
        "run_key": "LS_foldC_seed0",
        "candidate": "LS",
        "fold": "C",
        "seed": 0,
        "requested_run_keys": ["LS_foldC_seed0"],
        "data_scope": {
            "dev_cases": 105,
            "dev_sources": 21,
            "authorized_model_input_members": ["partial"],
            "authorized_metric_only_members_after_forward": ["implant", "gt"],
            "train_payload_access_authorized": False,
            "other_fold_payload_access_authorized": False,
            "confirmation20_access_authorized": False,
            "official_test_access_authorized": False,
            "old_monitor_access_authorized": False,
            "mug_payload_access_authorized": False,
            "skullfix_payload_access_authorized": False,
        },
        "single_evaluation_contract": {
            "checkpoint_loads": 1,
            "model_case_forward_calls": 105,
            "batch_size": 1,
            "num_workers": 0,
            "optimizer_constructions": 0,
            "optimizer_steps": 0,
            "parameter_updates": 0,
            "buffer_updates": 0,
            "training": False,
            "bncal": False,
            "prediction_pointcloud_files_saved": False,
            "formal_qa1_gate_application": False,
            "automatic_retry": False,
            "automatic_resume": False,
            "automatic_next_run": False,
        },
        "implementation_bindings": [
            {
                "path": runner.V11_RUNNER_PATH,
                "bytes": 32853,
                "sha256": runner.V11_RUNNER_SHA256,
            }
        ],
        "post_implementation_p3": {
            "required_status": "PASS_IMPLEMENTATION_ONLY",
        },
    }


def synthetic_authorization(request_sha: str = "1" * 64) -> dict:
    return {
        "status": "AUTHORIZED",
        "authorization_effective": True,
        "execution_authorized": True,
        "authorized_once": True,
        "request_id": "synthetic-request-v2",
        "request_sha256": request_sha,
        "authorized_run_keys": ["LS_foldC_seed0"],
        "training_authorized": False,
        "bncal_authorized": False,
        "automatic_rerun_authorized": False,
        "automatic_resume_authorized": False,
        "automatic_next_run_authorized": False,
        "formal_qa1_gate_authorized": False,
        "runtime_config_sha256_present": False,
        "protected_payload_access": {
            "train": False,
            "other_fold": False,
            "confirmation20": False,
            "official_test": False,
            "old_monitor": False,
            "MUG": False,
            "SkullFix": False,
        },
    }


def synthetic_runtime(request_sha: str = "1" * 64, receipt_sha: str = "2" * 64) -> dict:
    return {
        "cranial_scqr_execution": {
            "stage": runner.RUNTIME_STAGE,
            "status": "authorized_single_evaluation_pending_execution",
            "run_key": "LS_foldC_seed0",
            "candidate": "LS",
            "fold": "C",
            "seed": 0,
            "execution_request_sha256": request_sha,
            "authorization_receipt_sha256": receipt_sha,
            "development_evaluation_authorized": True,
            "development_evaluation_runs_authorized": 1,
            "development_cases_expected": 105,
            "model_forward_calls_expected": 105,
            "checkpoint_loads_expected": 1,
            "optimizer_steps_authorized": 0,
            "training_authorized": False,
            "bncal_authorized": False,
            "resume_authorized": False,
            "automatic_rerun_authorized": False,
            "automatic_next_run_authorized": False,
            "formal_qa1_gate_authorized": False,
        }
    }


def synthetic_case_rows() -> list[dict]:
    rows: list[dict] = []
    for source_index in range(21):
        source = f"source_{source_index:02d}"
        for defect_index, defect in enumerate(runner.DEFECTS):
            base = 1.0 + source_index * 0.01 + defect_index * 0.001
            row = {
                "run_key": "LS_foldC_seed0",
                "candidate": "LS",
                "fold": "C",
                "seed": 0,
                "case_id": f"case_{source_index:02d}_{defect_index}",
                "skull_id": source,
                "source_skull_id": source,
                "defect_type": defect,
                "zero_contact_2mm": 0,
                "disaster": 0,
            }
            for name in runner.SOURCE_MEAN_FIELDS:
                row[name] = base
            rows.append(row)
    return rows


class ImportAndIdentityTests(unittest.TestCase):
    def test_import_is_cpu_only_and_repo_imports_resolve(self) -> None:
        self.assertEqual(os.environ["CUDA_VISIBLE_DEVICES"], "")
        self.assertIn(str(runner.REPO_ROOT), sys.path)
        specification = importlib.util.find_spec("models")
        self.assertIsNotNone(specification)
        self.assertEqual(
            Path(specification.origin).resolve(),
            (runner.REPO_ROOT / "models" / "__init__.py").resolve(),
        )

    def test_v11_evaluator_is_byte_identical(self) -> None:
        path = runner.REPO_ROOT / runner.V11_RUNNER_PATH
        self.assertEqual(runner.sha256_file(path), runner.V11_RUNNER_SHA256)

    def test_source_has_no_optimizer_or_training_entrypoint(self) -> None:
        source = Path(runner.__file__).read_text(encoding="utf-8")
        self.assertNotIn("optimizer.step(", source)
        self.assertNotIn("loss.backward(", source)
        self.assertNotIn("model.train(", source)
        self.assertNotIn("run_net(", source)


class AuthorizationContractTests(unittest.TestCase):
    def test_request_contract_passes_and_fails_closed(self) -> None:
        request = synthetic_request()
        runner.validate_request_contract(request)
        for path, value in (
            (("execution_authorized",), True),
            (("data_scope", "train_payload_access_authorized"), True),
            (("single_evaluation_contract", "model_case_forward_calls"), 104),
            (("single_evaluation_contract", "formal_qa1_gate_application"), True),
        ):
            bad = copy.deepcopy(request)
            target = bad
            for key in path[:-1]:
                target = target[key]
            target[path[-1]] = value
            with self.subTest(path=path), self.assertRaises(runner.ContractError):
                runner.validate_request_contract(bad)

    def test_authorization_is_separate_exact_once_and_acyclic(self) -> None:
        request = synthetic_request()
        request_sha = "1" * 64
        good = synthetic_authorization(request_sha)
        runner.validate_execution_authorization(good, request, request_sha)
        for key in ("authorization_effective", "execution_authorized", "authorized_once"):
            bad = copy.deepcopy(good)
            bad[key] = False
            with self.subTest(key=key), self.assertRaises(runner.ContractError):
                runner.validate_execution_authorization(bad, request, request_sha)
        bad = copy.deepcopy(good)
        bad["protected_payload_access"]["official_test"] = True
        with self.assertRaises(runner.ContractError):
            runner.validate_execution_authorization(bad, request, request_sha)
        bad = copy.deepcopy(good)
        bad["runtime_config_sha256_present"] = True
        with self.assertRaises(runner.ContractError):
            runner.validate_execution_authorization(bad, request, request_sha)

    def test_runtime_is_one_way_bound_and_zero_update(self) -> None:
        request = synthetic_request()
        request_sha, receipt_sha = "1" * 64, "2" * 64
        good = synthetic_runtime(request_sha, receipt_sha)
        execution = runner.validate_runtime_config(good, request, request_sha, receipt_sha)
        self.assertEqual(execution["model_forward_calls_expected"], 105)
        for key, value in (
            ("authorization_receipt_sha256", "3" * 64),
            ("optimizer_steps_authorized", 1),
            ("automatic_next_run_authorized", True),
        ):
            bad = copy.deepcopy(good)
            bad["cranial_scqr_execution"][key] = value
            with self.subTest(key=key), self.assertRaises(runner.ContractError):
                runner.validate_runtime_config(bad, request, request_sha, receipt_sha)


class FileAndAccessTests(unittest.TestCase):
    def test_path_traversal_and_hash_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory(dir="/tmp") as directory:
            root = Path(directory)
            payload = root / "bound.txt"
            payload.write_bytes(b"synthetic binding\n")
            digest = hashlib.sha256(payload.read_bytes()).hexdigest()
            self.assertEqual(runner.resolve_under(root, "bound.txt"), payload.resolve())
            runner.verify_file(payload, digest, payload.stat().st_size)
            with self.assertRaises(runner.ContractError):
                runner.resolve_under(root, "../escape", must_exist=False)
            with self.assertRaises(runner.ContractError):
                runner.resolve_under(root, str(payload))
            with self.assertRaises(runner.ContractError):
                runner.verify_file(payload, "0" * 64)

    def test_bncal_sidecar_requires_exact_two_bindings(self) -> None:
        with tempfile.TemporaryDirectory(dir="/tmp") as directory:
            sidecar = Path(directory) / "files.sha256"
            checkpoint_sha, receipt_sha = "a" * 64, "b" * 64
            sidecar.write_text(
                f"{checkpoint_sha}  ckpt-last-bncal.pth\n"
                f"{receipt_sha}  v12_qa1_bncal_receipt.json\n",
                encoding="utf-8",
            )
            runner.validate_sha256_sidecar(
                sidecar,
                {
                    "ckpt-last-bncal.pth": checkpoint_sha,
                    "v12_qa1_bncal_receipt.json": receipt_sha,
                },
            )
            sidecar.write_text(sidecar.read_text(encoding="utf-8") + f"{'c' * 64}  extra\n", encoding="utf-8")
            with self.assertRaises(runner.ContractError):
                runner.validate_sha256_sidecar(
                    sidecar,
                    {
                        "ckpt-last-bncal.pth": checkpoint_sha,
                        "v12_qa1_bncal_receipt.json": receipt_sha,
                    },
                )

    def test_single_run_access_ledger(self) -> None:
        ledger = runner.AccessLedger()
        ledger.record_checkpoint_load("LS_foldC_seed0")
        for index in range(105):
            ledger.record_npz_open("LS_foldC_seed0", f"case_{index:03d}")
            for member in runner.ALLOWED_NPZ_MEMBERS:
                ledger.record_member(member)
            ledger.record_forward()
        ledger.assert_final()
        self.assertEqual(ledger.receipt_counts()["optimizer_steps"], 0)
        with self.assertRaises(runner.ContractError):
            ledger.record_npz_open("LS_foldC_seed0", "case_000")
        with self.assertRaises(runner.ContractError):
            runner.AccessLedger().assert_final()

    def test_partial_only_forward_precedes_metric_targets(self) -> None:
        events: list[str] = []
        partial, implant, gt = object(), object(), object()

        def forward(value):
            self.assertIs(value, partial)
            events.append("forward")
            return "prediction"

        def metric(prediction, seen_partial, seen_implant, seen_gt):
            self.assertEqual(events, ["forward"])
            self.assertEqual(prediction, "prediction")
            self.assertIs(seen_partial, partial)
            self.assertIs(seen_implant, implant)
            self.assertIs(seen_gt, gt)
            events.append("metric")
            return 7

        self.assertEqual(runner.forward_then_metrics(forward, partial, implant, gt, metric), 7)
        self.assertEqual(events, ["forward", "metric"])

    def test_parameter_and_buffer_immutability(self) -> None:
        before = {
            "parameters": runner.hash_tensor_mapping({"p": np.asarray([1.0], dtype=np.float32)}),
            "buffers": runner.hash_tensor_mapping({"b": np.asarray([2.0], dtype=np.float32)}),
        }
        runner.assert_state_unchanged(before, dict(before))
        changed = dict(before)
        changed["buffers"] = runner.hash_tensor_mapping({"b": np.asarray([3.0], dtype=np.float32)})
        with self.assertRaises(runner.ContractError):
            runner.assert_state_unchanged(before, changed)


class AggregationAndCliTests(unittest.TestCase):
    def test_single_run_aggregation_is_source_grouped_and_non_authorizing(self) -> None:
        sources = runner.aggregate_source_rows(synthetic_case_rows())
        self.assertEqual(len(sources), 21)
        self.assertTrue(all(row["case_count"] == 5 for row in sources))
        summary = runner.single_run_summary(sources)
        self.assertEqual(summary["status"], "DESCRIPTIVE_SINGLE_RUN_ONLY")
        self.assertFalse(summary["formal_qa1_gate_applied"])
        self.assertFalse(summary["candidate_comparison_performed"])
        self.assertFalse(summary["automatic_next_run"])

    def test_missing_case_or_defect_fails_aggregation(self) -> None:
        rows = synthetic_case_rows()
        with self.assertRaises(runner.ContractError):
            runner.aggregate_source_rows(rows[:-1])
        bad = copy.deepcopy(rows)
        bad[0]["defect_type"] = "other"
        with self.assertRaises(runner.ContractError):
            runner.aggregate_source_rows(bad)

    def test_cli_requires_all_hash_bound_inputs(self) -> None:
        args = runner.parse_args(
            [
                "--execution-request", "request.json",
                "--execution-request-sha256", "1" * 64,
                "--authorization-receipt", "receipt.json",
                "--authorization-receipt-sha256", "2" * 64,
                "--runtime-config", "runtime.yaml",
                "--runtime-config-sha256", "3" * 64,
                "--manifest", "manifest.jsonl",
                "--manifest-sha256", "4" * 64,
                "--data-root", "data",
                "--output-dir", "output",
            ]
        )
        self.assertEqual(args.device, "cuda:0")


class NumericalPolicyTests(unittest.TestCase):
    def test_policy_call_precedes_all_cuda_model_and_payload_work(self) -> None:
        source = Path(runner.__file__).read_text(encoding="utf-8")
        tree = ast.parse(source)
        function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "run_evaluation")
        assignment = function.body[1]
        self.assertIsInstance(assignment, ast.Assign)
        self.assertIsInstance(assignment.value, ast.Call)
        self.assertEqual(assignment.value.func.id, "configure_numerical_policy")

    def test_real_torch_cpu_flags_are_set_without_cuda_initialization(self) -> None:
        import torch

        prior = {
            "enabled": torch.are_deterministic_algorithms_enabled(),
            "warn_only": torch.is_deterministic_algorithms_warn_only_enabled(),
            "matmul": torch.backends.cuda.matmul.allow_tf32,
            "cudnn_tf32": torch.backends.cudnn.allow_tf32,
            "cudnn_deterministic": torch.backends.cudnn.deterministic,
            "benchmark": torch.backends.cudnn.benchmark,
        }
        self.assertFalse(torch.cuda.is_initialized())
        try:
            torch.use_deterministic_algorithms(False)
            torch.backends.cuda.matmul.allow_tf32 = True
            torch.backends.cudnn.allow_tf32 = True
            torch.backends.cudnn.deterministic = False
            torch.backends.cudnn.benchmark = True
            with patch.object(torch.cuda, "_lazy_init", side_effect=AssertionError("CUDA forbidden")):
                policy = runner.configure_numerical_policy(torch)
                self.assertTrue(policy["deterministic_algorithms"])
                self.assertFalse(policy["deterministic_warn_only"])
                self.assertFalse(policy["cuda_matmul_allow_tf32"])
                self.assertFalse(policy["cudnn_allow_tf32"])
                self.assertTrue(policy["cudnn_deterministic"])
                self.assertFalse(policy["cudnn_benchmark"])
                runner.assert_numerical_policy(torch)
            self.assertFalse(torch.cuda.is_initialized())
        finally:
            torch.use_deterministic_algorithms(prior["enabled"], warn_only=prior["warn_only"])
            torch.backends.cuda.matmul.allow_tf32 = prior["matmul"]
            torch.backends.cudnn.allow_tf32 = prior["cudnn_tf32"]
            torch.backends.cudnn.deterministic = prior["cudnn_deterministic"]
            torch.backends.cudnn.benchmark = prior["benchmark"]

    def test_every_numerical_flag_drift_fails_closed(self) -> None:
        for flag in ("enabled", "warn_only", "matmul", "cudnn_tf32", "deterministic", "benchmark"):
            values = {"enabled": True, "warn_only": False, "matmul": False, "cudnn_tf32": False, "deterministic": True, "benchmark": False}
            values[flag] = not values[flag]
            api = SimpleNamespace(
                are_deterministic_algorithms_enabled=lambda: values["enabled"],
                is_deterministic_algorithms_warn_only_enabled=lambda: values["warn_only"],
                backends=SimpleNamespace(
                    cuda=SimpleNamespace(matmul=SimpleNamespace(allow_tf32=values["matmul"])),
                    cudnn=SimpleNamespace(allow_tf32=values["cudnn_tf32"], deterministic=values["deterministic"], benchmark=values["benchmark"]),
                ),
            )
            with self.subTest(flag=flag), self.assertRaises(runner.ContractError):
                runner.assert_numerical_policy(api)

    def test_silent_setter_failure_is_rejected(self) -> None:
        api = SimpleNamespace(
            use_deterministic_algorithms=lambda *args, **kwargs: None,
            are_deterministic_algorithms_enabled=lambda: False,
            is_deterministic_algorithms_warn_only_enabled=lambda: False,
            backends=SimpleNamespace(
                cuda=SimpleNamespace(matmul=SimpleNamespace(allow_tf32=True)),
                cudnn=SimpleNamespace(allow_tf32=True, deterministic=False, benchmark=True),
            ),
        )
        with self.assertRaises(runner.ContractError):
            runner.configure_numerical_policy(api)


if __name__ == "__main__":
    unittest.main(verbosity=2)
