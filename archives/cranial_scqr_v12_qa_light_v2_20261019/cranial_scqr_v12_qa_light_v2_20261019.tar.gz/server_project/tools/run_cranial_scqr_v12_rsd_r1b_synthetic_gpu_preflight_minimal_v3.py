#!/usr/bin/env python3
"""Inert synthetic-only adapter; authorization and every file hash precede torch.

No real checkpoint loader, dataset builder, loss, optimizer or evaluation entry
point is called. CPU contracts exercise pure guards and tiny fake models only.
"""

import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
import random
import shutil
import shlex
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))
import cranial_scqr_v12_rsd_r1b_synthetic_preflight_contract_minimal_v3 as c


def write_json(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def load_file_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def synthetic_input(torch):
    return torch.tensor([[((i % 32) - 15.5) / 32,
                          (((i // 32) % 16) - 7.5) / 16,
                          ((i // 512) - 7.5) / 16] for i in range(8192)],
                        dtype=torch.float32, device='cpu').unsqueeze(0).contiguous()


def model_mapping(document, candidate):
    """Never merge dataset bases or honor historical runtime authorization."""
    require = c.require
    require(isinstance(document, dict) and isinstance(document.get('model'), dict), 'model submapping missing')
    model = document['model']
    require('_base_' not in model and model.get('NAME') == 'AdaPoinTr', 'model-only YAML contract')
    require(model.get('num_query') == 256 and model.get('num_points') == 8192 and model.get('center_num') == [512, 256], 'model shape drift')
    for key, depth in (('encoder_config', 6), ('decoder_config', 8)):
        require(model.get(key, {}).get('embed_dim') == 384 and model[key].get('depth') == depth, 'network architecture drift')
    scqr = model.get('cranial_scqr', {})
    require(candidate in ('LS', 'LSQ') and scqr.get('variant') == {'LS': 'A1', 'LSQ': 'Q0'}[candidate], 'candidate variant')
    require(scqr.get('enabled') is True and scqr.get('local_geometry_enabled') is True and
            scqr.get('contact_supervision_enabled') is True and
            scqr.get('query_conditioning_enabled') is (candidate == 'LSQ'), 'SCQR component contract')
    require(scqr.get('initialization_seed') == 31001 and scqr.get('alpha_query_init') == 0.01 and
            scqr.get('alpha_local_init') == 0.01 and scqr.get('contact_bias_beta') == 0.0 and
            scqr.get('warmup_epochs') == 20 and scqr.get('attention_dropout') == 0.0 and
            model.get('mamba_adapter', {}).get('enabled') is False, 'initialization/module drift')
    return model


def numerical_values(torch):
    return {'deterministic_algorithms': torch.are_deterministic_algorithms_enabled(),
            'warn_only': torch.is_deterministic_algorithms_warn_only_enabled(),
            'cudnn_deterministic': torch.backends.cudnn.deterministic,
            'cudnn_benchmark': torch.backends.cudnn.benchmark,
            'matmul_allow_tf32': torch.backends.cuda.matmul.allow_tf32,
            'cudnn_allow_tf32': torch.backends.cudnn.allow_tf32,
            'float32_matmul_precision': torch.get_float32_matmul_precision(),
            'CUBLAS_WORKSPACE_CONFIG': os.environ.get('CUBLAS_WORKSPACE_CONFIG'),
            'OMP_NUM_THREADS': os.environ.get('OMP_NUM_THREADS'),
            'MKL_NUM_THREADS': os.environ.get('MKL_NUM_THREADS'),
            'torch_num_threads': torch.get_num_threads(),
            'torch_num_interop_threads': torch.get_num_interop_threads()}


def assert_numerical(torch):
    expected = {'deterministic_algorithms': True, 'warn_only': False, 'cudnn_deterministic': True,
                'cudnn_benchmark': False, 'matmul_allow_tf32': False, 'cudnn_allow_tf32': False,
                'float32_matmul_precision': 'highest', 'CUBLAS_WORKSPACE_CONFIG': ':4096:8',
                'OMP_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1', 'torch_num_threads': 1, 'torch_num_interop_threads': 1}
    actual = numerical_values(torch)
    c.require(actual == expected, 'numerical/TF32/thread policy drift')
    return actual


def configure_numerical(torch):
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True, warn_only=False)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.set_float32_matmul_precision('highest')
    return assert_numerical(torch)


def state_record(model, hash_fn):
    c.require(all(not module.training for module in model.modules()), 'all modules must remain eval')
    c.require(not getattr(model, 'full_instrumentation_enabled', False) and
              not getattr(model.base_model, 'full_instrumentation_enabled', False), 'full instrumentation forbidden')
    return {'parameters': hash_fn(dict(model.named_parameters())), 'buffers': hash_fn(dict(model.named_buffers())),
            'schema': [(name, str(t.dtype), list(t.shape)) for name, t in sorted(model.state_dict().items())]}


def rng_snapshot(torch, np, *, cuda=True):
    return (random.getstate(), np.random.get_state(), torch.random.get_rng_state().clone(),
            [item.clone() for item in torch.cuda.get_rng_state_all()] if cuda else [])


def rng_restore(torch, np, states, *, cuda=True):
    random.setstate(states[0]); np.random.set_state(states[1]); torch.random.set_rng_state(states[2])
    if cuda:
        torch.cuda.set_rng_state_all(states[3])


def rng_hash(states):
    h = hashlib.sha256(b'R1B-synthetic-rng-v1\0')
    h.update(json.dumps(states[0], separators=(',', ':')).encode())
    n = states[1]
    h.update(n[0].encode()); h.update(n[1].tobytes()); h.update(json.dumps(n[2:]).encode())
    h.update(states[2].cpu().numpy().tobytes())
    for state in states[3]:
        h.update(state.cpu().numpy().tobytes())
    return h.hexdigest()


def compare_tensor(torch, left, right, label):
    same = left.shape == right.shape and left.dtype == right.dtype and left.device == right.device
    equal = same and torch.equal(left, right)
    c.require(equal, 'exact tensor mismatch: ' + label)
    return {'label': label, 'exact_equal': True, 'max_abs_difference': float((left - right).abs().max().cpu().item())}


def standalone_outlets(torch, select, hash_fn, ledger, device, sync, policy):
    records = []
    for magnitude in (0.0, 0.25):
        q = torch.ones(1, 2, 384, dtype=torch.float32, device=device)
        residual = torch.full_like(q, magnitude)
        out = SimpleNamespace(queries=q + residual, residual=residual,
                              attention=torch.tensor([[[1., 0.], [.5, .5]]], dtype=torch.float32, device=device), warmup=1.0)
        alpha = torch.tensor([0.01], dtype=torch.float32, device=device)
        tensors = {'q': q, 'residual': residual, 'conditioned': out.queries, 'attention': out.attention, 'alpha': alpha}
        before = hash_fn(tensors)
        results, diagnostics = [], []
        for condition, traced in (('LSQ_native', False), ('LSQ_native', True), ('LSQ_query_off', True), ('LSQ_native', True)):
            policy()
            ledger.add('standalone_select_rsd_queries_calls')
            diag = {} if traced else None
            result = select(q, out, alpha, condition, diag)
            sync()
            c.require(result is (q if condition == 'LSQ_query_off' else out.queries), 'outlet object identity')
            if diag is not None:
                c.assert_scalars(diag, off=condition == 'LSQ_query_off')
                c.require(diag['query_rms'] == 1.0 and diag['potential_residual_rms'] == magnitude and
                          diag['relative_potential_residual_rms'] == magnitude and diag['alpha_q'] == float(alpha.item()) and
                          diag['effective_proxy_count_mean'] == 1.5 and diag['attention_max_weight_mean'] == .75 and
                          abs(diag['attention_entropy_mean'] - math.log(2) / 2) <= 1e-6, 'artificial scalar expectation')
                diagnostics.append(diag)
            results.append(result)
        c.require(torch.equal(results[0], results[1]) and torch.equal(results[1], results[3]), 'native trace/restore')
        c.require(torch.equal(results[1] - results[2], torch.full_like(q, magnitude)), 'known residual difference')
        c.require(torch.equal(results[1], results[2]) == (magnitude == 0.0), 'zero/nonzero outlet control')
        c.require(diagnostics[0] == diagnostics[2], 'restored scalar exact equality')
        c.require(before == hash_fn(tensors), 'outlet fixture mutated')
        records.append({'residual_magnitude': magnitude, 'fixture_hash': before, 'diagnostics': diagnostics,
                        'native_restored_exact': True, 'known_residual_exact': True})
    return records


def run_sequence(models, x, torch, np, hash_fn, ledger, order, *, cuda, sync, policy, memory, progress):
    """Same sequence for authorized CUDA and tiny artificial CPU contract doubles."""
    before = {key: state_record(model, hash_fn) for key, model in models.items()}
    input_hash = hash_fn({'partial': x})
    snapshot = rng_snapshot(torch, np, cuda=cuda)
    hooks, results, records, comparisons = [], {}, [], []
    for candidate, model in models.items():
        conditioner = model.base_model.scqr_query_conditioner
        if candidate == 'LS':
            c.require(conditioner is None, 'LS conditioner must be absent')
        else:
            c.require(conditioner is not None, 'LSQ conditioner missing')
            def hook(_module, _inputs, _output):
                ledger.add('full_forward_lsq_conditioner_calls')
            hooks.append(conditioner.register_forward_hook(hook))
    try:
        with torch.no_grad():
            for item in order:
                index, candidate = item['index'], item['model']
                policy(); memory()
                c.require({key: state_record(model, hash_fn) for key, model in models.items()} == before, 'state changed before forward')
                c.require(input_hash == hash_fn({'partial': x}), 'input mutated before forward')
                rng_restore(torch, np, snapshot, cuda=cuda)
                ledger.begin(index, item)
                diagnostics = {} if item['diagnostics'] == 'FRESH_EMPTY_DICT' else None
                if item['rsd_condition'] is None:
                    returned = models[candidate](x, epoch=None)
                else:
                    returned = models[candidate](x, epoch=None, rsd_condition=item['rsd_condition'], rsd_diagnostics=diagnostics)
                sync(); memory(); policy()
                c.require(isinstance(returned, tuple) and len(returned) >= 2, 'model return schema')
                coarse, dense = returned[:2]
                for value, shape in ((coarse, (1, 256, 3)), (dense, (1, 8192, 3))):
                    c.require(tuple(value.shape) == shape and value.dtype == torch.float32 and value.device == x.device and
                              bool(torch.isfinite(value).all()), 'invalid output shape/dtype/finite/device')
                after = {key: state_record(model, hash_fn) for key, model in models.items()}
                c.require(after == before and input_hash == hash_fn({'partial': x}), 'state/input mutation after forward')
                if diagnostics is not None:
                    if candidate == 'LS':
                        c.require(diagnostics == {'query_applicable': False, 'query_outlet_calls': 0}, 'LS missing semantics')
                        diagnostics = {**{name: None for name in c.SCALARS}, **diagnostics, 'missing_reason': 'not_applicable'}
                    else:
                        c.assert_scalars(diagnostics, off=item['rsd_condition'] == 'LSQ_query_off')
                        ledger.add('traced_full_forward_lsq_query_outlet_calls')
                row = {'index': index, 'candidate': candidate, 'condition': item['rsd_condition'],
                       'diagnostics': diagnostics, 'state_after': after,
                       'rng_after_hash': rng_hash(rng_snapshot(torch, np, cuda=cuda))}
                # Fail at the first comparable condition, before any later call.
                anchor = 1 if index == 2 else 3 if index in (4, 5, 7, 8) else None
                if anchor is not None:
                    for axis, label in enumerate(('coarse', 'dense')):
                        comparisons.append(compare_tensor(torch, results[anchor][axis], (coarse, dense)[axis],
                                                          '%s:%d=%d' % (label, anchor, index)))
                    c.require(records[anchor-1]['rng_after_hash'] == row['rng_after_hash'], 'native RNG drift')
                if index in (7, 8):
                    c.require(records[4]['diagnostics'] == diagnostics, 'repeat diagnostic scalar drift')
                if index == 6:
                    comparisons.append(compare_tensor(torch, results[5][0], coarse, 'coarse:5=6 negative control'))
                    c.require(records[4]['rng_after_hash'] == row['rng_after_hash'], 'off RNG side effect')
                    native = records[4]['diagnostics']
                    c.require(all(native[name] == diagnostics[name] for name in c.SCALARS if name != 'applied_residual_rms'),
                              'off potential/attention drift')
                ledger.end()
                results[index] = (coarse.detach(), dense.detach())
                records.append(row)
                progress({'completed_forward': index, 'counts': dict(ledger.counts), 'state_verified': True})
        policy(); memory()
        return {'state_before': before, 'state_after': {key: state_record(m, hash_fn) for key, m in models.items()},
                'input_hash': input_hash, 'records': records, 'comparisons': comparisons,
                'full_dense_off_minus_native_max_abs': float((results[6][1] - results[5][1]).abs().max().cpu().item())}
    except Exception:
        ledger.failed = True
        raise
    finally:
        for handle in hooks:
            handle.remove()


def gpu_observation():
    command = ['nvidia-smi', '--query-gpu=name,uuid,driver_version,memory.total,memory.used,utilization.gpu', '--format=csv,noheader,nounits']
    result = subprocess.run(command, check=True, capture_output=True, text=True, timeout=10)
    lines = result.stdout.strip().splitlines()
    c.require(len(lines) == 1, 'exactly one GPU')
    fields = [field.strip() for field in lines[0].split(',')]
    processes = subprocess.run(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader,nounits'],
                               check=True, capture_output=True, text=True, timeout=10)
    return {'name': fields[0], 'uuid': fields[1], 'driver': fields[2], 'total_mib': int(fields[3]),
            'used_mib': int(fields[4]), 'utilization': int(fields[5]), 'compute_pid_text': processes.stdout.strip()}


def text_preconditions(args):
    root = c.ROOT
    c.require(HERE.parent == root and Path.cwd() == root, 'canonical project cwd required')
    expected = {'request': c.REQUEST_REL, 'authorization': c.PREFIX + 'control/authorization.json',
                'runtime': c.PREFIX + 'control/runtime.json'}
    paths = []
    for key, relative in expected.items():
        p = c.safe_path(getattr(args, key))
        c.require(p == root / relative and c.sha_string(getattr(args, key + '_sha256'))
                  and c.digest(p) == getattr(args, key + '_sha256'), 'chain path/hash drift: ' + key)
        paths.append(p)
    request, auth, runtime = [c.strict_json(p) for p in paths]
    parent = c.checked_binding(request['parent_request_v1'])
    original = c.strict_json(parent)
    c.validate_chain(request, original, auth, runtime, args.request_sha256, args.authorization_sha256)
    resource = request['resource_binding']
    c.require(socket.gethostname() == c.HOST and os.getuid() == 1000 and
              sys.version.split()[0] == resource['python_version'] and
              str(Path(sys.executable).resolve()) == resource['python_realpath'] and
              c.digest(Path(sys.executable).resolve()) == resource['python_binary_sha256'], 'host/user/Python drift')
    bindings = request['project_source_bindings'] + request['provider_bindings'] + request['model_structure_sources']
    bindings += request['preflight_implementation_bindings'] + request['evidence_bindings']
    extra = [c.checked_binding(row) for row in bindings]
    project = {row['path']: row['sha256'] for row in request['project_source_bindings']}
    c.require(all(project.get(name) == sha for name, sha in request['implementation_sha256'].items()),
              'R1-B source map missing/drift')
    p3 = c.strict_json(c.checked_binding(request['preflight_implementation_p3_binding']))
    c.require(p3['status'] == 'PASS_MINIMAL_ENTRY_IMPLEMENTATION_ONLY' and p3['gpu_used'] is False and
              p3['preflight_implementation_bindings'] == request['preflight_implementation_bindings'],
              'minimal implementation P3 mismatch')
    extra += [c.checked_binding(request['preflight_implementation_p3_binding']), parent]
    site = c.ENV_ROOT / 'lib/python3.10/site-packages'
    # -I -S launch: no site startup hooks or external PYTHONPATH. Process-only
    # precedence, never a global install/.pth; both roots hash checked above.
    sys.path[:0] = [str(c.PROVIDER), str(root), str(site)]
    for package, version in request['required_package_metadata_versions'].items():
        c.require(importlib.metadata.version(package) == version, 'package metadata drift: ' + package)
    observed = gpu_observation()
    c.require(observed['name'] == resource['gpu_name'] and observed['uuid'] == c.GPU_UUID and
              observed['driver'] == resource['driver_version'] and observed['total_mib'] == resource['gpu_memory_total_mib'] and
              observed['utilization'] == 0 and not observed['compute_pid_text'] and
              observed['total_mib'] - observed['used_mib'] >= resource['minimum_free_gpu_memory_mib_at_launch'], 'GPU drift/busy')
    c.require(shutil.disk_usage(root).free >= resource['minimum_free_disk_bytes_at_launch'], 'disk budget')
    output = c.safe_path(root / request['fixed_future_execution']['output_relative'])
    c.require(not output.exists() and output.parent.is_dir(), 'fresh result required')
    return request, output, paths + extra, observed



def result_files(output):
    """Only owned root files and one exact mplconfig child; no environment walk."""
    files, directories = [], []
    for p in output.iterdir():
        c.safe_path(p)
        if p.is_dir():
            c.require(p.name == 'mplconfig' and not directories, 'unexpected result directory: ' + str(p))
            directories.append(p)
        else:
            c.require(p.is_file(), 'nonregular result artifact: ' + str(p))
            if p.name != 'files.sha256':
                files.append(p)
        c.require(len(files) + len(directories) <= 64, 'result entry budget')
    for directory in directories:
        for p in directory.iterdir():
            c.safe_path(p)
            c.require(p.is_file() and p.name == 'fontlist-v390.json', 'unexpected nested result artifact: ' + str(p))
            files.append(p)
            c.require(len(files) <= 64, 'result file budget')
    return sorted(files)


def freeze_result(output):
    files = result_files(output)
    # Fixed relative POSIX names so independently verifiable on any host.
    lines = [c.digest(p) + '  ' + p.relative_to(output).as_posix() + '\n' for p in files]
    manifest = ''.join(lines)
    total = sum(p.stat().st_size for p in files) + len(manifest.encode('utf-8'))
    c.require(total <= 16 * 1024**2, 'entire result size cap')
    with (output / 'files.sha256').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(manifest)
    c.require(result_files(output) == files, 'result file set changed during freeze')
    for p, line in zip(files, lines):
        c.require(c.digest(p) == line.split('  ', 1)[0], 'result changed during freeze: ' + str(p))
    return {'files': len(files), 'bytes_including_manifest': total}



def render_launcher(request, request_sha256, authorization_sha256, runtime_sha256):
    """Pure byte rendering; materialization calls this function, never substitutes $$ ."""
    for value in (request_sha256, authorization_sha256, runtime_sha256):
        c.require(c.sha_string(value), 'launcher requires actual frozen hashes')
    root = request['project_root']
    c.require(root == '/home/jovyan/adapointr_work/PoinTr', 'launcher root')
    f = request['fixed_future_execution']
    lc = request['future_materialization_contract']['launcher_contract']
    c.require(f['run_id'] == c.RUN and f['control_relative'] == c.PREFIX + 'control'
              and lc['entry'] == c.TOOL_NAMES[0], 'launcher run/entry drift')
    values = {'<REQUEST_SHA256>': request_sha256, '<AUTH_SHA256>': authorization_sha256,
              '<RUNTIME_SHA256>': runtime_sha256}
    args = [values.get(arg, arg) for arg in lc['argument_template']]
    c.require(not any('<' in arg or '>' in arg for arg in args), 'launcher unfilled hash')
    bootstrap = ('import resource,runpy,sys;resource.setrlimit(resource.RLIMIT_FSIZE,(33554432,33554432));'
                 'entry=sys.argv.pop(1);sys.argv[0]=entry;runpy.run_path(entry,run_name="__main__")')
    command = ['/usr/bin/timeout', '-k', '5', '600', lc['python'], '-I', '-S', '-B', '-c',
               bootstrap, root + '/' + lc['entry']] + args
    quote = lambda key: shlex.quote(root + '/' + f[key])
    lines = ['#!/bin/bash', 'set -u -o pipefail', 'umask 077', 'cd -- ' + shlex.quote(root) + ' || exit 90',
             'set -C', 'test -d ' + quote('control_relative') + ' || exit 91',
             'launcher_pid=$$', 'case "$launcher_pid" in ""|*[!0-9]*) exit 96 ;; esac']
    for key in ('output_relative', 'started_relative', 'log_relative', 'pid_relative', 'exit_code_relative'):
        lines.append('test ! -e ' + quote(key) + ' && test ! -L ' + quote(key) + ' || exit 92')
    lines += ['exec 3>' + quote('log_relative') + ' || exit 93',
              'printf \'%s\\n\' "$launcher_pid" >' + quote('pid_relative') + ' || exit 94']
    lines += ['export ' + key + '=' + shlex.quote(value) for key, value in lc['export_before_python'].items()]
    lines += [shlex.join(command) + ' >&3 2>&1', 'rc=$?',
              'printf \'%s\\n\' "$rc" >' + quote('exit_code_relative') + ' || exit 95', 'exit "$rc"']
    return ('\n'.join(lines) + '\n').encode('utf-8')


def authorized_run(args):
    process_started = time.monotonic()
    request, output, read_files, observed = text_preconditions(args)
    c.require(time.monotonic() - process_started < 600, 'pre-execution hash audit exceeded walltime')
    ledger = c.Ledger(request['success_exact_counts'])
    models, hooks = {}, []
    owned_output = False
    timer_armed = False
    phase = 'STARTUP_MARKER'
    try:
        write_json(c.ROOT / (c.PREFIX + 'control/started.json'), {'pid': os.getpid(), 'request_sha256': args.request_sha256, 'retry': False})
        phase = 'CREATE_OWNED_RESULT'
        output.mkdir(exist_ok=False)
        owned_output = True
        # misc imports pyplot but never plots. Reuse only the exact-bound existing
        # font cache in owned output, avoiding font discovery subprocesses or writes
        # to the user's home cache. No dependency/environment modification.
        phase = 'FONT_CACHE_PREPARATION'
        mpl = output / 'mplconfig'
        mpl.mkdir()
        cached = Path(c.DEPENDENCY_POLICY['font_cache'])
        c.require(c.digest(cached) == c.DEPENDENCY_POLICY['font_cache_sha256'], 'font cache drift')
        with (mpl / cached.name).open('xb') as stream:
            stream.write(cached.read_bytes())
        os.environ.update(MPLCONFIGDIR=str(mpl), MPLBACKEND='Agg')
        # Execution is already separately authorized. No directories/control files
        # outside this newly owned output may be written by this process.
        os.environ.update(CUBLAS_WORKSPACE_CONFIG=':4096:8', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
        sys.dont_write_bytecode = True
        # Ignore existing external .pyc files without admitting unauthenticated
        # cache bytes; writes remain disabled. Only the new owned namespace is used.
        sys.pycache_prefix = str(output / 'bytecode_unused')
        timeout = lambda _sig, _frame: (_ for _ in ()).throw(c.ContractError('600-second walltime budget exceeded'))
        signal.signal(signal.SIGALRM, timeout)
        started = process_started
        signal.signal(signal.SIGTERM, timeout)
        signal.setitimer(signal.ITIMER_REAL, 600 - (time.monotonic() - started))
        timer_armed = True
        write_json(output / 'invocation.json', {'pid': os.getpid(), 'request_sha256': args.request_sha256,
                   'authorization_sha256': args.authorization_sha256, 'runtime_sha256': args.runtime_sha256, 'synthetic_only': True})
        phase = 'AUDIT_HOOK_INSTALLATION'
        boundary = c.FileBoundary(read_files, output)
        sys.addaudithook(boundary)
        phase = 'IMPORT_AND_SYNTHETIC_EXECUTION'
        import torch
        import numpy as np
        import yaml
        from easydict import EasyDict
        numerical_before = configure_numerical(torch)
        env = request['environment_runtime_contract']
        c.require(torch.__version__ == env['torch_version'] and np.__version__ == env['numpy_version'] and
                  torch.version.cuda == env['cuda_version'] and torch.backends.cudnn.version() == env['cudnn_version'], 'CUDA/cuDNN runtime drift')
        c.require(torch.cuda.device_count() == 1 and torch.cuda.get_device_name(0) == request['resource_binding']['gpu_name'] and
                  torch.cuda.get_device_properties(0).total_memory // (1024**2) == request['resource_binding']['gpu_memory_total_mib'],
                  'CUDA-visible GPU contract')
        import pointnet2_ops._ext as native
        from pointnet2_ops import pointnet2_utils as wrapper
        from utils import pointnet2_utils as adapter
        c.assert_provider(native, wrapper, adapter)
        from models import build_model_from_cfg
        support = load_file_module(c.ROOT / 'tools/run_cranial_scqr_v12_rsd_r1b.py', 'rsd_preflight_hash_support')
        bypass = load_file_module(c.ROOT / 'models/cranial_scqr/rsd_query_bypass.py', 'rsd_preflight_outlet_support')
        cpu_input = synthetic_input(torch)
        expected_input = request['input_identity']
        cpu_input_hash = support.canonical_tensor_hash({'partial': cpu_input})
        c.require(cpu_input_hash == expected_input['canonical_input_hash'], 'frozen artificial CPU input identity')
        torch.cuda.reset_peak_memory_stats(0)
        for candidate, binding in zip(('LS', 'LSQ'), request['model_structure_sources']):
            random.seed(0); np.random.seed(0); torch.random.default_generator.manual_seed(0)
            config = model_mapping(yaml.safe_load((c.ROOT / binding['path']).read_text()), candidate)
            ledger.add('model_constructions')
            model = build_model_from_cfg(EasyDict(config)).float().eval()
            cpu_state = state_record(model, support.canonical_tensor_hash)
            models[candidate] = model.to('cuda:0')
            c.require(state_record(model, support.canonical_tensor_hash) == cpu_state, 'CPU-to-CUDA model state change')
        x = cpu_input.to('cuda:0')
        c.require(support.canonical_tensor_hash({'partial': x}) == cpu_input_hash and torch.equal(cpu_input, x.cpu()), 'CPU/CUDA input identity')
        random.seed(0); np.random.seed(0); torch.manual_seed(0); torch.cuda.manual_seed_all(0)
        initial_states = {key: state_record(model, support.canonical_tensor_hash) for key, model in models.items()}
        memory_records = []
        def memory():
            allocated, reserved = torch.cuda.max_memory_allocated(0), torch.cuda.max_memory_reserved(0)
            c.require(allocated <= 20000 * 1024**2 and reserved <= 20000 * 1024**2, 'peak VRAM cap exceeded')
            memory_records.append({'peak_allocated_bytes': allocated, 'peak_reserved_bytes': reserved})
        def policy():
            assert_numerical(torch)
            c.assert_provider(native, wrapper, adapter)
        sync = lambda: torch.cuda.synchronize(0)
        def progress(value):
            number = value['completed_forward']
            c.assert_provider(native, wrapper, adapter)
            write_json(output / ('progress_%02d.json' % number), value)
            print('SYNTHETIC_PROGRESS:' + json.dumps(value), flush=True)
        with torch.no_grad():
            outlet = standalone_outlets(torch, bypass.select_rsd_queries, support.canonical_tensor_hash,
                                        ledger, 'cuda:0', sync, policy)
        c.require({key: state_record(model, support.canonical_tensor_hash) for key, model in models.items()} == initial_states,
                  'state changed during standalone outlets')
        sequence = run_sequence(models, x, torch, np, support.canonical_tensor_hash, ledger, request['full_forward_order'],
                                cuda=True, sync=sync, policy=policy, memory=memory, progress=progress)
        c.require(time.monotonic() - started <= 600, 'walltime cap')
        ledger.finish()
        c.require(support.canonical_tensor_hash({'partial': cpu_input}) == cpu_input_hash, 'CPU input mutated during run')
        for name, expected in request['implementation_sha256'].items():
            c.require(c.digest(c.ROOT / name) == expected, 'R1-B source changed during preflight')
        for binding in request['preflight_implementation_bindings'] + request['model_structure_sources'] + request['project_source_bindings'] + request['provider_bindings']:
            c.checked_binding(binding)
        write_json(output / 'equality_scalar_state.json', {'standalone': outlet, 'full_sequence': sequence})
        write_json(output / 'environment_input_identity.json', {'resource_before': observed, 'environment': env,
                   'provider_wheel_sha256': request['provider_wheel_sha256'], 'dependency_observation': boundary.observation(), 'input_cpu_cuda_hash': cpu_input_hash,
                   'input_cpu_gpu_exact': True, 'shape': [1,8192,3], 'synthetic_only': True})
        write_json(output / 'numerical_memory.json', {'before': numerical_before, 'after': assert_numerical(torch), 'memory_records': memory_records})
        receipt = {'status': 'PASS_SYNTHETIC_R1B_ZERO_UPDATE', 'synthetic_only': True, 'counts': ledger.counts,
                   'implementation_sha256': request['implementation_sha256'],
                   'preflight_implementation_bindings': request['preflight_implementation_bindings'],
                   'model_forwards': 8, 'real_payload_open_events': 0, 'real_checkpoint_loads': 0,
                   'real_checkpoint_byte_reads': 0, 'optimizer_steps': 0, 'parameter_updates': 0, 'buffer_updates': 0,
                   'formal_gate': False, 'global_cuda_equivalence_proven': False, 'automatic_retry': False,
                   'wall_elapsed_seconds': time.monotonic()-started, 'state_hash_format': 'RSD-canonical-state-v1'}
        write_json(output / 'completion_receipt.json', receipt)
        phase = 'FREEZE_RESULT'
        freeze_result(output)
        print('SYNTHETIC_RECEIPT:' + json.dumps(receipt), flush=True)
        return 0
    except Exception as exc:
        ledger.failed = True
        after = {}
        if models:
            try:
                after = {key: state_record(model, support.canonical_tensor_hash) for key, model in models.items()}
            except Exception:
                after = {'unavailable': True}
        failure = {'status': 'FAILED_STOPPED_NO_RETRY', 'phase': phase,
                   'error_type': type(exc).__name__, 'error': str(exc),
                   'counts': ledger.counts, 'state_after_failure': after, 'automatic_retry': False,
                   'state_before': locals().get('initial_states', {'unavailable': True}),
                   'counts_are_attempt_ledger_not_a_claim_of_no_mutation_after_failure': True,
                   'formal_gate': False, 'synthetic_only': True}
        # Never write to a raced/pre-existing result. Pre-result errors use the
        # frozen, already authorized control namespace; no mutation on auth failure.
        destination = output / 'failure_receipt.json' if owned_output else c.ROOT / (c.PREFIX + 'control/entry_failure.json')
        try:
            write_json(destination, failure)
        except Exception as secondary:
            # Keep the original exception primary, including when receipt IO fails.
            print('SYNTHETIC_FAILURE_RECEIPT_IO:' + json.dumps({
                'first_error': failure, 'secondary_error_type': type(secondary).__name__,
                'secondary_error': str(secondary)}), file=sys.stderr, flush=True)
        raise
    finally:
        if timer_armed:
            signal.setitimer(signal.ITIMER_REAL, 0)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('request', 'authorization', 'runtime'):
        parser.add_argument('--' + name, required=True, type=Path)
        parser.add_argument('--' + name + '-sha256', required=True)
    return authorized_run(parser.parse_args(argv))


if __name__ == '__main__':
    raise SystemExit(main())
