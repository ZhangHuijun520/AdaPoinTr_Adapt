"""Fail-closed accounting for Cranial-SCQR v1.2 QA-1 training-only runs."""

from __future__ import annotations

import atexit
import hashlib
import json
import math
import os
from datetime import datetime, timezone
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
VERSION = "cranial-scqr-v1.2-QA1-training-execution-state-v1"
STAGE = "V12_QA1_training"
FORMAL_CONFIG_PROTOCOL_ID = "cranial-scqr-v1.2-QA1-formal-config-v1"
EXPECTED_STEPS = 3939
EXPECTED_BATCHES = 39
EXPECTED_CASES = 315
EXPECTED_TRAVERSALS = 101


def assert_v12_qa1_numeric_policy(torch_api=None) -> dict:
    """Inspect backend flags only; never initialize CUDA or load a model."""
    if torch_api is None:
        import torch as torch_api
    policy = {
        "deterministic_algorithms": torch_api.are_deterministic_algorithms_enabled(),
        "deterministic_warn_only": torch_api.is_deterministic_algorithms_warn_only_enabled(),
        "cuda_matmul_allow_tf32": torch_api.backends.cuda.matmul.allow_tf32,
        "cudnn_allow_tf32": torch_api.backends.cudnn.allow_tf32,
        "cudnn_deterministic": torch_api.backends.cudnn.deterministic,
        "cudnn_benchmark": torch_api.backends.cudnn.benchmark,
        "cublas_workspace_config": os.environ.get("CUBLAS_WORKSPACE_CONFIG"),
    }
    expected = {
        "deterministic_algorithms": True,
        "deterministic_warn_only": False,
        "cuda_matmul_allow_tf32": False,
        "cudnn_allow_tf32": False,
        "cudnn_deterministic": True,
        "cudnn_benchmark": False,
        "cublas_workspace_config": ":4096:8",
    }
    if policy != expected:
        raise RuntimeError(f"Cranial-SCQR v1.2 QA-1 numeric policy drifted: {policy}")
    return policy


def configure_v12_qa1_numeric_policy(args, config, torch_api=None):
    """Apply strict numerical policy to QA-1 only, before dataset/model construction."""
    execution = getattr(config, "cranial_scqr_execution", None)
    if execution is None or str(getattr(execution, "stage", "")) != STAGE:
        return None
    if not bool(getattr(execution, "training_authorized", False)):
        raise RuntimeError("QA-1 numerical policy requires authorized training")
    if getattr(args, "deterministic", False) is not True:
        raise RuntimeError("QA-1 requires --deterministic")
    if os.environ.get("CUBLAS_WORKSPACE_CONFIG") != ":4096:8":
        raise RuntimeError("QA-1 requires CUBLAS_WORKSPACE_CONFIG=:4096:8 before launch")
    if torch_api is None:
        import torch as torch_api
    torch_api.use_deterministic_algorithms(True, warn_only=False)
    torch_api.backends.cuda.matmul.allow_tf32 = False
    torch_api.backends.cudnn.allow_tf32 = False
    torch_api.backends.cudnn.deterministic = True
    torch_api.backends.cudnn.benchmark = False
    return assert_v12_qa1_numeric_policy(torch_api)


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resolve_repo_path(value: str) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = REPO_ROOT / path
    return path.resolve()


def atomic_json(path: Path, payload: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def _peak_allocated_bytes() -> int:
    import torch

    return int(torch.cuda.max_memory_allocated())


def _require_false(value, label: str) -> None:
    if bool(value):
        raise RuntimeError(f"Cranial-SCQR v1.2 QA-1 {label} must remain false")


def _require_hash_binding(execution, path_key: str, hash_key: str) -> Path:
    path = resolve_repo_path(str(getattr(execution, path_key, "")))
    if not path.is_file():
        raise RuntimeError(
            f"Cranial-SCQR v1.2 QA-1 binding is missing: {path_key}={path}"
        )
    expected = str(getattr(execution, hash_key, ""))
    actual = sha256_file(path)
    if not expected or actual != expected:
        raise RuntimeError(
            f"Cranial-SCQR v1.2 QA-1 binding hash mismatch: {path_key}"
        )
    return path


def _load_bound_json(execution, path_key: str, hash_key: str) -> tuple[Path, dict]:
    path = _require_hash_binding(execution, path_key, hash_key)
    return path, json.loads(path.read_text(encoding="utf-8"))


def _run_identity(config) -> tuple[str, str, int, str]:
    development = config.development_protocol
    candidate = str(development.candidate)
    fold = str(development.fold)
    seed = int(development.seed)
    return candidate, fold, seed, f"{candidate}_fold{fold}_seed{seed}"


def _validate_candidate_contract(config, protocol_run: dict) -> None:
    candidate, fold, seed, run_key = _run_identity(config)
    qa1_lock = config.qa1_lock
    scqr = config.model.cranial_scqr
    expected_variant = {"B0": "B0", "LS": "A1", "LSQ": "Q0"}.get(candidate)
    if expected_variant is None:
        raise RuntimeError(f"Unsupported QA-1 candidate: {candidate}")
    if (
        str(qa1_lock.run_key) != run_key
        or str(qa1_lock.candidate) != candidate
        or str(qa1_lock.fold) != fold
        or int(qa1_lock.seed) != seed
    ):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 qa1_lock identity drifted")
    if (
        protocol_run.get("run_key") != run_key
        or protocol_run.get("candidate") != candidate
        or protocol_run.get("fold") != fold
        or int(protocol_run.get("seed", -1)) != seed
        or protocol_run.get("model_variant") != expected_variant
        or str(scqr.variant) != expected_variant
    ):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 candidate identity drifted")

    configured_weight = getattr(scqr, "auxiliary_loss_weight", None)
    protocol_weight = protocol_run.get("lambda_scf")
    if candidate == "B0":
        if bool(scqr.enabled) or configured_weight is not None or protocol_weight is not None:
            raise RuntimeError("Cranial-SCQR v1.2 QA-1 B0 contract drifted")
        if any(
            bool(getattr(scqr, key))
            for key in (
                "local_geometry_enabled",
                "contact_supervision_enabled",
                "query_conditioning_enabled",
            )
        ):
            raise RuntimeError("Cranial-SCQR v1.2 QA-1 B0 path must stay inactive")
    else:
        if configured_weight is None or protocol_weight is None or not math.isclose(
            float(configured_weight),
            float(protocol_weight),
            rel_tol=0.0,
            abs_tol=1.0e-15,
        ):
            raise RuntimeError("Cranial-SCQR v1.2 QA-1 lambda_scf drifted")
        if not bool(scqr.enabled):
            raise RuntimeError("Cranial-SCQR v1.2 QA-1 candidate must be enabled")
        if not bool(scqr.local_geometry_enabled) or not bool(
            scqr.contact_supervision_enabled
        ):
            raise RuntimeError("Cranial-SCQR v1.2 QA-1 LS/LSQ local contract drifted")
        expected_query = candidate == "LSQ"
        if bool(scqr.query_conditioning_enabled) != expected_query:
            raise RuntimeError("Cranial-SCQR v1.2 QA-1 query contract drifted")
    if not math.isclose(float(scqr.contact_bias_beta), 0.0, abs_tol=0.0):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 contact bias must remain zero")


def _validate_external_bindings(config, execution) -> None:
    request_path, request = _load_bound_json(
        execution, "training_request", "training_request_sha256"
    )
    authorization_path, authorization = _load_bound_json(
        execution, "authorization_receipt", "authorization_receipt_sha256"
    )
    _, formal_protocol = _load_bound_json(
        execution, "formal_config_protocol", "formal_config_protocol_sha256"
    )
    _, p3_receipt = _load_bound_json(
        execution, "post_implementation_p3_receipt", "post_implementation_p3_sha256"
    )
    static_template = _require_hash_binding(
        execution, "static_template", "static_template_sha256"
    )
    train_ids = _require_hash_binding(
        execution, "train_case_ids", "train_case_ids_sha256"
    )

    candidate, fold, seed, run_key = _run_identity(config)
    if (
        request.get("status") != "AWAITING_EXPLICIT_USER_AUTHORIZATION"
        or request.get("execution_authorized") is not False
        or request.get("requested_run_keys") != [run_key]
    ):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 training request is invalid")
    request_contract = request.get("training_contract", {})
    numerical = request.get("resource_binding", {})
    if (
        numerical.get("deterministic_algorithms") is not True
        or numerical.get("tf32") is not False
        or numerical.get("cublas_workspace_config") != ":4096:8"
    ):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 request numerical contract drifted")
    if (
        int(request_contract.get("optimizer_steps", -1)) != EXPECTED_STEPS
        or int(request_contract.get("epoch_traversals", -1)) != EXPECTED_TRAVERSALS
        or request_contract.get("bncal_authorized") is not False
        or request_contract.get("development_evaluation_authorized") is not False
    ):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 request contract drifted")

    if (
        authorization.get("status") != "AUTHORIZED"
        or authorization.get("execution_authorized") is not True
        or authorization.get("authorized_run_keys") != [run_key]
        or authorization.get("training_authorized") is not True
        or int(authorization.get("optimizer_steps_authorized", -1))
        != EXPECTED_STEPS
        or authorization.get("bncal_authorized") is not False
        or authorization.get("development_payload_access_authorized") is not False
        or authorization.get("development_evaluation_authorized") is not False
        or authorization.get("automatic_rerun_authorized") is not False
        or authorization.get("automatic_resume_authorized") is not False
        or authorization.get("automatic_next_run_authorized") is not False
    ):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 authorization receipt is invalid")
    authorization_request = authorization.get("training_request", {})
    if (
        authorization_request.get("path") != str(getattr(execution, "training_request"))
        or authorization_request.get("sha256")
        != str(getattr(execution, "training_request_sha256"))
        or request_path != resolve_repo_path(authorization_request.get("path", ""))
    ):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 request receipt binding drifted")

    if (
        formal_protocol.get("protocol_id") != FORMAL_CONFIG_PROTOCOL_ID
        or formal_protocol.get("status") != "FROZEN_IMPLEMENTATION_ONLY"
    ):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 formal protocol is invalid")
    matches = [
        item for item in formal_protocol.get("runs", [])
        if item.get("run_key") == run_key
    ]
    if len(matches) != 1:
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 run is absent from formal protocol")
    protocol_run = matches[0]
    if (
        resolve_repo_path(str(protocol_run.get("config", ""))) != static_template
        or protocol_run.get("sha256")
        != str(getattr(execution, "static_template_sha256"))
    ):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 static template binding drifted")
    _validate_candidate_contract(config, protocol_run)

    if (
        p3_receipt.get("status") != "PASS_IMPLEMENTATION_ONLY"
        or p3_receipt.get("training_authorized_by_this_receipt") is not False
        or p3_receipt.get("bncal_authorized_by_this_receipt") is not False
    ):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 implementation P3 is invalid")

    configured_ids = resolve_repo_path(
        str(config.dataset.train.others.include_case_ids_file)
    )
    qa1_ids = resolve_repo_path(str(config.qa1_lock.train_case_ids))
    if configured_ids != train_ids or qa1_ids != train_ids:
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 train allowlist path drifted")
    if str(config.qa1_lock.train_case_ids_sha256) != str(
        getattr(execution, "train_case_ids_sha256")
    ):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 allowlist hash drifted")
    case_ids = [line for line in train_ids.read_text(encoding="utf-8").splitlines() if line]
    if len(case_ids) != EXPECTED_CASES or len(set(case_ids)) != EXPECTED_CASES:
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 train allowlist count drifted")

    if authorization_path == request_path:
        raise RuntimeError("Request and authorization receipt must be distinct files")
    if candidate not in {"B0", "LS", "LSQ"} or fold not in {"C", "D"} or seed != 0:
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 run identity is outside the matrix")


def validate_v12_qa1_training_contract(args, config, train_dataloader):
    execution = getattr(config, "cranial_scqr_execution", None)
    if execution is None or str(getattr(execution, "stage", "")) != STAGE:
        return None

    expected = {
        "optimizer_steps_authorized": EXPECTED_STEPS,
        "loader_batches_expected": EXPECTED_BATCHES,
        "epoch_labels_start": 0,
        "epoch_labels_end": 100,
        "epoch_traversals_expected": EXPECTED_TRAVERSALS,
        "seed": 0,
        "gpu_count": 1,
    }
    for key, value in expected.items():
        if int(getattr(execution, key, -1)) != value:
            raise RuntimeError(f"Cranial-SCQR v1.2 QA-1 {key} must equal {value}")
    if not bool(getattr(execution, "training_authorized", False)):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 training is not authorized")
    if int(args.seed) != 0 or bool(args.resume) or args.start_ckpts is not None:
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 requires seed=0, scratch, no resume")
    _require_false(getattr(execution, "resume_authorized", True), "resume_authorized")
    _require_false(getattr(execution, "bncal_authorized", True), "bncal_authorized")
    _require_false(
        getattr(execution, "development_payload_access_authorized", True),
        "development_payload_access_authorized",
    )
    _require_false(
        getattr(execution, "development_evaluation_authorized", True),
        "development_evaluation_authorized",
    )
    _require_false(
        getattr(execution, "automatic_rerun_authorized", True),
        "automatic_rerun_authorized",
    )
    _require_false(
        getattr(execution, "automatic_next_run_authorized", True),
        "automatic_next_run_authorized",
    )
    if str(getattr(execution, "checkpoint_initial_state", "")) != "scratch":
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 must initialize from scratch")
    if str(getattr(execution, "checkpoint_policy", "")) != "final_only":
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 checkpoint policy must be final_only")

    development = config.development_protocol
    for key in (
        "confirmation_allowed",
        "old_monitor_allowed",
        "official_test_allowed",
        "mug_payload_allowed",
        "skullfix_payload_allowed",
    ):
        _require_false(getattr(development, key, True), key)
    if config.total_bs != 8 or config.step_per_update != 1 or config.max_epoch != 100:
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 batch/epoch contract drifted")
    if str(config.optimizer.type) != "AdamW":
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 optimizer must be AdamW")
    if not math.isclose(float(config.optimizer.kwargs.lr), 1.0e-4):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 learning rate drifted")
    if not math.isclose(float(config.optimizer.kwargs.weight_decay), 5.0e-4):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 weight decay drifted")
    if int(getattr(config, "grad_norm_clip", 10)) != 10:
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 gradient clipping drifted")
    if bool(getattr(config, "save_best_checkpoint", True)):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 best checkpoint is forbidden")
    if bool(getattr(config, "save_final_epoch_checkpoints", True)):
        raise RuntimeError("Cranial-SCQR v1.2 QA-1 duplicate final checkpoints are forbidden")
    if len(train_dataloader) != EXPECTED_BATCHES or len(train_dataloader.dataset) != EXPECTED_CASES:
        raise RuntimeError(
            "Cranial-SCQR v1.2 QA-1 loader identity drifted: "
            f"cases={len(train_dataloader.dataset)} batches={len(train_dataloader)}"
        )
    _validate_external_bindings(config, execution)
    return execution


class ScqrV12QA1TrainingAudit:
    def __init__(self, args, config, train_dataloader):
        self.execution = validate_v12_qa1_training_contract(
            args, config, train_dataloader
        )
        self.enabled = self.execution is not None
        self.finished = False
        if not self.enabled:
            return
        numerical_policy = assert_v12_qa1_numeric_policy()
        candidate, fold, seed, run_key = _run_identity(config)
        self.steps = 0
        self.completed_epochs = 0
        self.current_epoch = None
        self.path = Path(args.experiment_path) / "v12_qa1_training_execution_state.json"
        self.payload = {
            "receipt_version": VERSION,
            "numerical_policy": numerical_policy,
            "status": "running",
            "run_key": run_key,
            "candidate": candidate,
            "fold": fold,
            "seed": seed,
            "runtime_config_sha256": sha256_file(args.config),
            "training_request_sha256": str(self.execution.training_request_sha256),
            "authorization_receipt_sha256": str(
                self.execution.authorization_receipt_sha256
            ),
            "formal_config_protocol_sha256": str(
                self.execution.formal_config_protocol_sha256
            ),
            "post_implementation_p3_sha256": str(
                self.execution.post_implementation_p3_sha256
            ),
            "static_template_sha256": str(self.execution.static_template_sha256),
            "train_case_ids_sha256": str(self.execution.train_case_ids_sha256),
            "start_time_utc": datetime.now(timezone.utc).isoformat(),
            "end_time_utc": None,
            "train_cases": EXPECTED_CASES,
            "loader_batches_actual": len(train_dataloader),
            "epoch_traversals_completed": 0,
            "optimizer_steps": 0,
            "optimizer_steps_authorized": EXPECTED_STEPS,
            "model_updates": 0,
            "development_dataloader_constructed": False,
            "development_payload_accessed": False,
            "bncal_authorized": False,
            "bncal_updates": 0,
            "checkpoint_sha256": None,
            "peak_allocated_bytes": 0,
            "failure_or_interruption_requires_new_authorization": True,
            "resume_authorized": False,
            "automatic_rerun_authorized": False,
            "automatic_next_run_authorized": False,
        }
        atomic_json(self.path, self.payload)
        atexit.register(self._write_exit_state)

    def begin_epoch(self, epoch: int) -> None:
        if self.enabled:
            assert_v12_qa1_numeric_policy()
            self.current_epoch = int(epoch)

    def authorize_next_step(self) -> None:
        if self.enabled:
            assert_v12_qa1_numeric_policy()
        if self.enabled and self.steps >= EXPECTED_STEPS:
            raise RuntimeError(
                "Cranial-SCQR v1.2 QA-1 optimizer-step authorization exhausted"
            )

    def record_completed_step(self) -> None:
        if not self.enabled:
            return
        self.steps += 1
        if self.steps > EXPECTED_STEPS:
            raise AssertionError(
                "Cranial-SCQR v1.2 QA-1 recorded an unauthorized optimizer step"
            )

    def end_epoch(self) -> None:
        if not self.enabled:
            return
        self.completed_epochs += 1
        self.payload.update(
            current_epoch_label=self.current_epoch,
            epoch_traversals_completed=self.completed_epochs,
            optimizer_steps=self.steps,
            model_updates=self.steps,
            peak_allocated_bytes=_peak_allocated_bytes(),
        )
        atomic_json(self.path, self.payload)

    def finish(self, checkpoint_path: str | Path) -> None:
        if not self.enabled:
            return
        self.payload["numerical_policy_at_completion"] = assert_v12_qa1_numeric_policy()
        checkpoint_path = Path(checkpoint_path)
        if self.steps != EXPECTED_STEPS or self.completed_epochs != EXPECTED_TRAVERSALS:
            raise RuntimeError(
                "Cranial-SCQR v1.2 QA-1 completion mismatch: "
                f"steps={self.steps} epochs={self.completed_epochs}"
            )
        if not checkpoint_path.is_file():
            raise RuntimeError("Cranial-SCQR v1.2 QA-1 final checkpoint is missing")
        self.payload.update(
            status="training_complete_pending_separate_bncal_authorization",
            end_time_utc=datetime.now(timezone.utc).isoformat(),
            optimizer_steps=self.steps,
            model_updates=self.steps,
            epoch_traversals_completed=self.completed_epochs,
            checkpoint_sha256=sha256_file(checkpoint_path),
            peak_allocated_bytes=_peak_allocated_bytes(),
        )
        atomic_json(self.path, self.payload)
        self.finished = True

    def _write_exit_state(self) -> None:
        if not self.enabled or self.finished:
            return
        self.payload.update(
            status="terminated_before_training_completion",
            end_time_utc=datetime.now(timezone.utc).isoformat(),
            current_epoch_label=self.current_epoch,
            epoch_traversals_completed=self.completed_epochs,
            optimizer_steps=self.steps,
            model_updates=self.steps,
            peak_allocated_bytes=_peak_allocated_bytes(),
        )
        try:
            atomic_json(self.path, self.payload)
        except Exception:
            pass
