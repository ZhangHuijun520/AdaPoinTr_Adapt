"""Explicit inference-only residual outlet; no persistent switches or imports."""

import math


CONDITIONS = ("LS_native", "LSQ_native", "LSQ_query_off")


def validate_rsd_condition(condition, variant, training):
    if training:
        raise ValueError("R1-B is inference-only; training is forbidden")
    expected = {"LS_native": "A1", "LSQ_native": "Q0", "LSQ_query_off": "Q0"}
    if condition not in expected or variant != expected[condition]:
        raise ValueError("R1-B condition/SCQR variant mismatch")


def select_rsd_queries(queries, conditioned, alpha_q, condition, diagnostics=None):
    """Return the untouched native tensor or pre-add query; compute no new add."""
    if condition not in ("LSQ_native", "LSQ_query_off"):
        raise ValueError("query outlet accepts LSQ conditions only")
    if diagnostics is not None:
        if not isinstance(diagnostics, dict) or diagnostics:
            raise ValueError("query diagnostics must be an empty per-forward dict")
        values = query_scalars(queries, conditioned, alpha_q, condition)
        diagnostics.update(values, query_applicable=True, query_outlet_calls=1)
    return queries if condition == "LSQ_query_off" else conditioned.queries


def query_scalars(queries, conditioned, alpha_q, condition):
    """FP32 Bxqueryxd RMS and per-query natural-log attention reductions."""
    import torch

    q = queries.detach().float()
    residual = conditioned.residual.detach().float()
    attention = conditioned.attention.detach().float()
    if q.ndim != 3 or q.shape != residual.shape or q.numel() == 0:
        raise ValueError("query/residual shape mismatch")
    if attention.ndim != 3 or attention.shape[:2] != q.shape[:2] or attention.shape[-1] < 1:
        raise ValueError("attention shape mismatch")
    if not all(bool(torch.isfinite(x).all()) for x in (q, residual, attention, alpha_q)):
        raise ValueError("nonfinite query diagnostics")
    if bool((attention < 0).any()) or not torch.allclose(
        attention.sum(dim=-1), torch.ones_like(attention[..., 0]), rtol=0.0, atol=1e-6
    ):
        raise ValueError("invalid attention distribution")
    if alpha_q.numel() != 1 or not math.isfinite(float(conditioned.warmup)):
        raise ValueError("invalid scalar alpha/warmup")
    # log(1) for zero entries makes their entropy contribution exactly zero.
    positive_or_one = torch.where(attention > 0, attention, torch.ones_like(attention))
    entropy = -(attention * positive_or_one.log()).sum(dim=-1)
    qrms = float(q.square().mean().sqrt().cpu().item())
    rrms = float(residual.square().mean().sqrt().cpu().item())
    result = {
        "alpha_q": float(alpha_q.detach().float().cpu().item()),
        "query_warmup": float(conditioned.warmup),
        "query_rms": qrms,
        "potential_residual_rms": rrms,
        "applied_residual_rms": 0.0 if condition == "LSQ_query_off" else rrms,
        "relative_potential_residual_rms": rrms / max(qrms, 1e-12),
        "attention_entropy_mean": float(entropy.mean().cpu().item()),
        "effective_proxy_count_mean": float(entropy.exp().mean().cpu().item()),
        "attention_max_weight_mean": float(attention.max(dim=-1).values.mean().cpu().item()),
    }
    if not all(math.isfinite(value) for value in result.values()):
        raise ValueError("nonfinite reduced query diagnostics")
    return result
