"""One-purpose v1.2-QA lightweight archival utility; never imports model code."""
import argparse, base64, csv, hashlib, io, json, os, re, shutil, socket, stat, tarfile, time
from pathlib import Path, PurePosixPath

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def js(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":")).encode()

def emit(value):
    print("EVIDENCE_B64:" + base64.b64encode(js(value)).decode(), flush=True)

def safe_name(name):
    p = PurePosixPath(name)
    require(name and not p.is_absolute() and ".." not in p.parts and "\\" not in name, "unsafe member")
    return p

def checked(path):
    require(all(not p.is_symlink() for p in (path, *path.parents)), "linked path: " + str(path))
    return path

def read_file(path, cap):
    checked(path)
    a = path.stat()
    require(stat.S_ISREG(a.st_mode) and a.st_nlink == 1 and 0 <= a.st_size <= cap, "file bounds: " + str(path))
    data = path.read_bytes()
    b = path.stat()
    fp = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
    require(fp(a) == fp(b) and len(data) == a.st_size, "file changed: " + str(path))
    return data

def secret_guard(data, label):
    patterns = (rb"-----BEGIN [A-Z ]*PRIVATE KEY-----",
                rb"eyJ[A-Za-z0-9_-]{30,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}",
                rb"(?i)authorization:\s*bearer\s+[A-Za-z0-9_.-]{30,}")
    require(not any(re.search(p, data) for p in patterns), "possible secret; content suppressed: " + label)

def run(args):
    bundle = checked(Path(args.bundle))
    require(digest(read_file(bundle, 67108864)) == args.bundle_sha256, "input bundle SHA256")
    with tarfile.open(bundle, "r:gz") as incoming:
        members = incoming.getmembers()
        require(len({m.name for m in members}) == len(members), "duplicate input member")
        require(all(m.isfile() and m.size <= 33554432 for m in members), "nonregular input")
        for m in members:
            safe_name(m.name)
        require(sum(m.size for m in members) <= 67108864, "input expansion limit")
        scope = json.loads(incoming.extractfile("archive_scope_v1.json").read())
        root = checked(Path(scope["project_root"]))
        os.chdir(root)
        require(socket.gethostname() == scope["hostname"] and os.getuid() == scope["uid"], "resource identity")
        require(shutil.disk_usage(root).free >= scope["budget"]["minimum_free_bytes"], "free disk budget")
        started = time.monotonic()
        def budget():
            require(time.monotonic() - started <= scope["budget"]["wall_seconds"], "wall budget")
        allowed = set(scope["include_suffixes"])
        forbidden = set(scope["forbidden_content_suffixes"])
        selected, excluded = set(), []
        def consider(p):
            checked(p)
            require(p.is_file(), "not a regular candidate")
            rel = p.relative_to(root).as_posix()
            require(not any(x.startswith(".") for x in Path(rel).parts), "hidden candidate")
            if p.suffix.lower() in forbidden:
                excluded.append(dict(path=rel, reason="WEIGHT_OR_PAYLOAD_NOT_READ", bytes=p.stat().st_size))
            elif (p.suffix.lower() in allowed or p.name.startswith(scope["include_training_curves_name_prefix"])
                  or rel in (
                      "third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops-3.0.0.dist-info/METADATA",
                      "third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops-3.0.0.dist-info/RECORD",
                      "third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider/pointnet2_ops-3.0.0.dist-info/WHEEL",
                  )):
                selected.add(rel)
            else:
                excluded.append(dict(path=rel, reason="UNSELECTED_SUFFIX_NO_READ", bytes=p.stat().st_size))
        def scan(p):
            checked(p)
            require(p.is_dir(), "missing scope directory: " + str(p))
            for d, dirs, files in os.walk(p, followlinks=False):
                budget()
                require(len(dirs) + len(files) <= 4096, "directory entry budget")
                for n in dirs:
                    checked(Path(d) / n)
                dirs[:] = [n for n in dirs if n != "__pycache__"]
                for n in files:
                    if n.endswith(".pyc"):
                        continue
                    consider(Path(d) / n)
                    require(len(selected) <= scope["budget"]["max_server_files"], "file count budget")
        for rel in scope["roots"]:
            scan(root / rel)
        for rel in scope["extra_files"]:
            consider(root / rel)
        for dirname in ("tools", "scripts"):
            for p in (root / dirname).iterdir():
                if p.is_file() and scope["discovery"][dirname + "_top_level_name_contains"] in p.name:
                    consider(p)
        cfg = root / scope["discovery"]["cfgs_root"]
        for p in cfg.iterdir():
            if any(p.name.startswith(prefix) for prefix in scope["discovery"]["cfgs_name_prefixes"]):
                scan(p) if p.is_dir() else consider(p)
        critical = {b["path"]: b for b in scope["critical_bindings"]}
        records = []
        for rel in sorted(selected):
            budget()
            raw = read_file(root / rel, scope["budget"]["max_single_file_bytes"])
            if Path(rel).suffix.lower() not in {".so", ".whl"} and not Path(rel).name.startswith("events.out.tfevents"):
                secret_guard(raw, rel)
            row = dict(path="server_project/" + rel, bytes=len(raw), sha256=digest(raw))
            if rel in critical:
                expected = critical[rel]
                require(row["sha256"] == expected["sha256"] and row["bytes"] == expected["bytes"], "critical binding mismatch: " + rel)
            records.append(row)
        require(set(critical).issubset(selected), "critical source missing")
        local_records = []
        require(len(scope["local_files"]) <= scope["budget"]["max_local_files"], "local count cap")
        expected_members = {"archive_scope_v1.json", "archive_once_v1.py"}
        for row in scope["local_files"]:
            n = row["member"]
            safe_name(n)
            raw = incoming.extractfile(n).read()
            require(len(raw) == row["bytes"] and digest(raw) == row["sha256"], "local input mismatch: " + n)
            secret_guard(raw, n)
            local_records.append(dict(path=n, bytes=len(raw), sha256=digest(raw)))
            expected_members.add(n)
        require({m.name for m in members} == expected_members, "input exact member set")
        server_bytes = sum(r["bytes"] for r in records)
        local_bytes = sum(r["bytes"] for r in local_records)
        require(server_bytes <= scope["budget"]["max_server_bytes"] and local_bytes <= scope["budget"]["max_local_bytes"]
                and server_bytes + local_bytes <= scope["budget"]["max_combined_bytes"], "payload byte caps")
        fingerprint = digest(js(records + local_records))
        summary = dict(status="PASS_READONLY_ARCHIVE_INPUT_INVENTORY", fingerprint=fingerprint,
                       server_files=len(records), server_bytes=server_bytes, local_files=len(local_records),
                       local_bytes=local_bytes, weight_files_excluded=sum(r["path"].endswith(".pth") for r in excluded),
                       exclusions=excluded, model_or_payload_reads=0)
        if args.mode == "inspect":
            emit(summary)
            return
        require(args.expected_inventory == fingerprint, "inventory changed since readonly freeze")
        out = checked(root / "archives" / scope["archive_id"])
        require(not out.exists(), "archive destination exists; no overwrite or retry")
        out.mkdir()
        stage = out / "restore_verified"
        archive = out / (scope["archive_id"] + ".tar.gz")
        all_rows = []
        with archive.open("xb") as output:
            with tarfile.open(fileobj=output, mode="w:gz", compresslevel=6) as tar:
                def add(n, raw):
                    safe_name(n)
                    item = tarfile.TarInfo(n)
                    item.size, item.mode, item.mtime = len(raw), 0o644, 0
                    tar.addfile(item, io.BytesIO(raw))
                    all_rows.append(dict(path=n, bytes=len(raw), sha256=digest(raw)))
                for row in records:
                    budget()
                    raw = read_file(root / row["path"].split("/", 1)[1], scope["budget"]["max_single_file_bytes"])
                    require(len(raw) == row["bytes"] and digest(raw) == row["sha256"], "source drift during archive")
                    add(row["path"], raw)
                for row in local_records:
                    add(row["path"], incoming.extractfile(row["path"]).read())
                add("meta/archive_scope_v1.json", js(scope))
                add("meta/archive_once_v1.py", incoming.extractfile("archive_once_v1.py").read())
                add("meta/source_inventory.json", js(dict(summary=summary, files=records + local_records)))
                add("meta/recovery_limits.json", js(dict(weights_included=False, data_included=False,
                    mode_policy="Archive restores regular files as 0644; no code is executed.",
                    scope="Analysis/provenance reconstruction, not model or full environment restoration.",
                    formal_gate_status=scope["formal_gate_status"])))
                manifest = "".join(r["sha256"] + "  " + r["path"] + "\n" for r in sorted(all_rows, key=lambda x:x["path"])).encode()
                add("files.sha256", manifest)
            output.flush()
            os.fsync(output.fileno())
        stage.mkdir()
        with tarfile.open(archive, "r:gz") as tar:
            ms = tar.getmembers()
            require(len(ms) == len(all_rows) == len({m.name for m in ms}), "archive exact member count")
            require(all(m.isfile() and m.mode == 0o644 for m in ms), "archive member type/mode")
            by_name = {r["path"]: r for r in all_rows}
            require(set(by_name) == {m.name for m in ms}, "archive exact member set")
            for member in ms:
                budget()
                rel = safe_name(member.name)
                raw = tar.extractfile(member).read()
                row = by_name[member.name]
                require(len(raw) == row["bytes"] and digest(raw) == row["sha256"], "archive member hash")
                dest = stage.joinpath(*rel.parts)
                dest.parent.mkdir(parents=True, exist_ok=True)
                with dest.open("xb") as stream:
                    stream.write(raw)
                require(digest(read_file(dest, scope["budget"]["max_single_file_bytes"])) == row["sha256"], "restored member hash")
        eval_root = stage / "server_project/logs/cranial_scqr_v12_qa1/qa1_development_evaluation"
        summaries = list(eval_root.glob("*/single_run_summary.json"))
        require(len(summaries) == 6, "six evaluation summaries missing")
        for p in summaries:
            v = json.loads(p.read_bytes())
            require(v["case_count"] == 105 and v["source_count"] == 21, "evaluation semantic check")
        for fold in ("C", "D"):
            p = stage / ("server_project/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_fold" + fold + "_seed0_v1_20261019/result/execution_receipt.json")
            v = json.loads(p.read_bytes())
            require(v["status"] == "PASS_CURRENT_PAIRED_DIAGNOSTIC_ONLY" and v["counts"]["forward_attempts"] == 315, "paired diagnostic semantic check")
        for row in records:
            budget()
            raw = read_file(root / row["path"].split("/", 1)[1], scope["budget"]["max_single_file_bytes"])
            require(digest(raw) == row["sha256"], "source drift after archive")
        sha = digest(read_file(archive, scope["budget"]["max_combined_bytes"]))
        sidecars = {
            archive.name + ".sha256": (sha + "  " + archive.name + "\n").encode(),
            scope["archive_id"] + ".bytes": (str(archive.stat().st_size) + "\n").encode(),
            scope["archive_id"] + ".tar_contents.txt": "".join(r["path"] + "\n" for r in all_rows).encode()}
        for name, raw in sidecars.items():
            with (out / name).open("xb") as stream:
                stream.write(raw)
        result = dict(status="PASS_ARCHIVE_RESTORE_HASH_AND_LIMITED_SEMANTIC_VERIFICATION",
                      archive=str(archive), bytes=archive.stat().st_size, sha256=sha,
                      payload_files=len(all_rows), source_inventory=fingerprint,
                      server_files=len(records), local_files=len(local_records),
                      restore_dir=str(stage), no_weights=True, no_payloads=True,
                      local_download_confirmed=False, deletion_authorized=False)
        with (out / "restore_verification_receipt.json").open("x") as stream:
            json.dump(result, stream, indent=2)
        emit(result)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", required=True)
    parser.add_argument("--bundle-sha256", required=True)
    parser.add_argument("--mode", choices=("inspect", "build"), required=True)
    parser.add_argument("--expected-inventory", default="")
    run(parser.parse_args())

