# QA-1 安全性与历史数值证据复盘报告 v1

_冻结日期：2026-10-10（Asia/Shanghai）；本机版本化报告；不构成执行授权或正式 gate 裁决。_

---

## 📋 摘要与授权

LSQ 相对 LS 的 RimCover-P95 在 C/D 两折具有描述性改善，但病例安全性没有随均值一致改善：两折均存在 LSQ 独有 disaster，Fold D 的总数增加；Fold D Implant CD-L1 的恶化涉及多数 source，并有明显尾部病例。LS Fold C 训练与 BNCal 的完整运行时数值策略快照仍缺失，不能追溯认证。

用户先明确授权只读复盘 request 完整 SHA256，再授权将已完成复盘冻结为本机报告并讨论新协议；本轮不重新计算结果、不重训、不上传服务器、不修改历史产物。

- 复盘 request：[v12_qa1_safety_historical_evidence_review_request_v1.json](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_10/v12_qa1_safety_historical_evidence_review_request_v1.json)
- Request SHA256：`a17f87adc4d9fec71423a9edd8c0a261a187a8da05609c18952d39fdd545bbd7`
- 已确认统计补充协议 SHA256：`85751899ec1c9d274c6f899049e45823e4acf9c41fe50504efae60561cbf0b8f`
- 复盘时服务器：`shu-common-25721452-notebook-h4cmio-0`；项目根：`/home/jovyan/adapointr_work/PoinTr`；用户：`jovyan`
- Request 内全部输入、历史文本及统计结果绑定已在复盘前核验通过；完整路径、bytes、SHA256 以该不可变 request 为准

## 📊 固定 checkpoint 描述性结果

配对差值定义为 LSQ−LS。先对每 skull 五种 defect 等权平均，再对 skull 等权平均；bootstrap 为 C/D 分层 source-skull 重采样、各折等权、10,000 次、seed 20260910。以下为已冻结分析结果，不是本报告新计算。

| 指标（距离单位 mm） | Fold C | Fold D | Pooled | Pooled 95% CI |
|---|---:|---:|---:|---|
| RimCover-P95 | -0.572073 | -0.402413 | -0.487243 | [-0.894924, -0.088829] |
| Implant CD-L1 | -0.336513 | +0.250150 | -0.043182 | [-0.331009, +0.215501] |
| Final CD-L1 | -0.025346 | +0.052849 | +0.013752 | [-0.011417, +0.041837] |
| Final HD95 | -0.109615 | +0.282961 | +0.086673 | [-0.058518, +0.245725] |

来源：服务器 `logs/cranial_scqr_v12_qa1/qa1_descriptive_statistics_v1_20261010/descriptive_summary.json`，SHA256 `660adb3310532d5a4d8f08d9adde61f0a3961ce4676978e9ff9050da22774e89`。

CI 条件于固定 checkpoint 和数据表示；它不消除早期数值策略混杂，也不量化训练 seed 波动。不能由主指标均值改善推导总体质量获益或可进入 QA-2。

## ⚠️ 病例级安全性

事件沿用冻结 CSV 的 binary flags，未从几何 payload 重算。病例名的 `train__` 前缀不改变其属于相应 fold-dev allowlist 的事实。

| Fold | LS disaster | LSQ disaster | LSQ 独有 | LS 独有 |
|---|---:|---:|---|---|
| C | 3 | 1 | 025/random_2 | 025/bilateral；051/frontoorbital；072/random_2 |
| D | 4 | 5 | 008/random_1；010/random_1；087/parietotemporal | 004/random_2；087/random_1 |

完整 LSQ 独有 case ID：`train__025__random_2`、`train__008__random_1`、`train__010__random_1`、`train__087__parietotemporal`。C/D 的 LS 与 LSQ zero-contact 均为 0。

| LSQ 独有 disaster case | LS RimCover-P95 | LSQ RimCover-P95 | Implant CD-L1 差值 |
|---|---:|---:|---:|
| C：025/random_2 | 14.619335 | 12.882486 | -0.438840 |
| D：008/random_1 | 8.088278 | 7.509196 | +2.366935 |
| D：010/random_1 | 14.912389 | 14.509678 | +0.456272 |
| D：087/parietotemporal | 17.363256 | 14.310884 | +4.109551 |

这些病例的 RimCover-P95 均改善，却仍有新的 disaster 标记。因此该指标不充分代表植入体其他质量维度。本复盘不分析 disaster 具体触发分量，不作几何机制推断，不赋予 `SAFETY_FAIL` 等正式分类。

## 🔍 Fold D Implant CD-L1 恶化分布

21 个 source 中，17 个 source 均值差值为正、4 个为负；差值符号只用于描述，不新增门槛。每 source 均值基于全部五种 defect，未剔除任何病例。

| Source（恶化降序） | 差值 mm | Source（续） | 差值 mm |
|---|---:|---|---:|
| 087 | +2.750441 | 060 | +0.115204 |
| 008 | +0.942893 | 101 | +0.089327 |
| 079 | +0.525093 | 062 | +0.076169 |
| 010 | +0.359232 | 052 | +0.075470 |
| 033 | +0.233964 | 054 | +0.064765 |
| 069 | +0.228346 | 068 | +0.060164 |
| 004 | +0.205670 | 037 | -0.075352 |
| 044 | +0.201488 | 095 | -0.344338 |
| 046 | +0.174803 | 093 | -0.358941 |
| 029 | +0.164887 | 022 | -0.393239 |
| 005 | +0.157104 | — | — |

表按左列自上至下，再右列自上至下读取。

| Defect | Case 数 | 差值均值 mm |
|---|---:|---:|
| bilateral | 21 | +0.192107 |
| frontoorbital | 21 | +1.071901 |
| parietotemporal | 21 | +0.308653 |
| random_1 | 21 | -0.360813 |
| random_2 | 21 | +0.038902 |

已核对全部 105 个 Fold D case 差值，而非只选择恶化病例。尾部示例：`087/frontoorbital` Implant CD-L1 差值为 `+20.496147 mm`，同 source 的 `087/random_1` 为 `-11.875353 mm`；两者都保留。因此 source 均值包含显著相反方向变化，不能简单称为单病例驱动，也不能靠删除该 source 改善结论。

逐病例全表未另行持久化；精确来源是 request 中绑定的 LS/LSQ C/D `per_model_case_metrics.csv`，配对键为 `(fold, case_id, seed)`，source 与 defect 必须匹配。本报告仅冻结已观察摘要；未执行新的删点敏感性分析、bootstrap 或 p-value。

## 📚 LS Fold C 历史数值证据

以下路径均相对于服务器项目根，引用行号来自已冻结历史文本，不来自当前训练实现。

| 来源 | 精确锚点 | 能支持的证据 |
|---|---|---|
| `scripts/launch_cranial_scqr_v12_qa1_ls_foldc_seed0_once_v1.sh` | 192–193 行：CUBLAS 与 NVIDIA TF32 override；202 行：`--deterministic` | 启动配置意图 |
| `logs/cranial_scqr_v12_qa1/qa1_training/cranial_scqr_v12_qa1_LS_foldC_seed0_v1_20261008T082520Z.launcher.log` | 30 行：`args.deterministic : True`；260 行：seed/deterministic 日志 | 当时参数/seed 日志，非完整 backend flags 断言 |
| `scripts/launch_cranial_scqr_v12_qa1_ls_foldc_seed0_bncal_once_v3.sh` | 246–247 行：CUDA_VISIBLE_DEVICES、CUBLAS | BNCal 启动环境意图 |
| `prelaunch_environment.json`（上述训练 run 目录内） | 环境版本、LAUNCH_READY；无完整数值 flags | 不足以认证严格数值策略 |
| 历史 training state 与最终 BNCal receipt | 未包含完整 numerical policy snapshot | 证据缺失，非已证实违规 |
| 后期 `launch_cranial_scqr_v12_qa1_ls_foldc_seed0_development_eval_once_v3.sh` | 72 行检查 evaluator 前后 policy 相同 | 只支持后期 evaluation，不能补证训练/BNCal |

训练 launcher SHA256：`88479c2e9440f5fc13fb060699ea1bcc3fd1db936d6d965f38a3e7d9d1765d6e`。训练日志 SHA256：`5052efabed103d762f14626019a75e26712069095e5fb44438262345ecf6d7d5`。其余精确绑定见复盘 request。

`NVIDIA_TF32_OVERRIDE=0` 不能单独认证所有 PyTorch TF32/determinism backend flags；deterministic CLI 参数也不是运行前后完整断言。本复盘未发现足以补齐缺口的同期快照，结论为“配置意图可见，完整严格数值合规证据不足”，不是“违规已证实”。较早 BNCal v1 授权回执仅是旧尝试记录，不能混同完成的 v3 授权链。

## 🎯 是否制定新复核协议

建议可以讨论一个独立的新诊断协议，但不把它当作延续原 QA-1 的自动重试，更不能替换或隐藏当前负面安全证据。数值快照缺失与病例级风险是两件事；统一数值条件未必消除安全问题。

| 选择 | 可回答问题 | 限制 |
|---|---|---|
| 先暂停该路线，保留本次结论 | 避免在安全风险未解释时扩展模块 | 无新增数值条件证据 |
| 起草 LS/LSQ × C/D 的匹配数值诊断协议 | 在统一严格数值合同下重新观察边界收益及病例风险 | 是新实验，非原结果补证；需新预算与逐运行授权 |
| 只重跑 LS Fold C | 局部缺口复核 | 不提供平衡的新比较矩阵，不推荐作为整体通过证据 |

若决定起草，优先保持模型、loss、数据、指标及既有阈值不变，冻结独立版本与完整运行前后数值 snapshots、共同初始化合同、训练/BNCal/evaluator 代码身份。新 seed 的选择要预先固定；seed0 matched replication 和 seed1 stability 回答不同问题，不能事后择优，不能将旧 LSQ 与新 LS 拼接为“完全匹配比较”。最小平衡设计是 LS/LSQ × C/D 四个新运行，是否执行以及 seed 选择尚未授权。

同时需要明确它与原计划 safety 停止边界的关系：不能因主指标改善而自动越过已有病例风险；任何新复核应由用户明确批准其诊断目的和停止规则，不能默认进入 QA-2 或 Mamba。confirmation20 继续封存。

## 🔐 冻结与权限

本报告仅在 Windows 项目管理目录创建，未把它宣称为服务器结果归档或长期备份。完整原始数据/日志仍在服务器；未据此允许删除服务器文件。

正式 gate 状态保持 `NOT_ADJUDICATED_HISTORICAL_NUMERICAL_EVIDENCE_GAP`。本报告不计算 gate 布尔检查、不作五类正式科学分类、不计算 LSQ−B0，不授权重训、BNCal、evaluation、GPU、payload、代码变更或任何执行 request。

文档技能用于区分证据、解释、讨论和授权边界。修订请新增 v2，不覆盖本 v1。SHA256 以同目录 `.md.sha256` 文件及交付消息为准。
