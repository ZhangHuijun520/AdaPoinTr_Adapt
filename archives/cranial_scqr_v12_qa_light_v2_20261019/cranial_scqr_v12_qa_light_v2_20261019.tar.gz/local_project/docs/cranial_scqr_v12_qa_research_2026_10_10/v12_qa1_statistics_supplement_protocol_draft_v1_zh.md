# QA-1 六运行统计补充协议草案 v1

_2026-10-10（Asia/Shanghai）；状态：AWAITING_EXPLICIT_USER_CONFIRMATION；仅供确认，不是 execution request。_

---

## 📋 范围与来源

本草案只补充统计执行歧义及历史证据限制，不修改父文件、既有数值阈值或模型结果。用户确认草案不等于授权实施、分析或正式 gate。后续仍须分别完成实现合同验证、输入哈希冻结、待授权 execution request 和单独执行授权。

服务器根目录为 `/home/jovyan/adapointr_work/PoinTr`。本次只读观察 hostname 为 `shu-common-25721452-notebook-h4cmio-0`、用户为 `jovyan`；不同于此前执行容器。这不是资源重绑定凭据，也不是六运行迁移完整性认证。本机草案不自动同步到服务器。

以下路径均相对于服务器项目根；来源不是本机副本承诺：

| 材料 | SHA256 | 本次核对性质 |
|---|---|---|
| `docs/cranial_scqr_v12_qa_research_2026_09_21/v12_qa1_preregistered_protocol_v1.json` | `10878972310ced7ddad1188a29b233686c17b5dd5cee72f27593846cef16c8b8` | 前一轮完整阅读并核验 |
| `docs/cranial_scqr_v12_qa_research_2026_09_21/cranial_scqr_v12_qa_formal_experiment_plan_zh_v1.md` | `7c0b5a40c6a263e0b256dbe4fe7d895083c196d7db3482358601c7928054ed0b` | 前一轮统计相关章节核对并核验 |
| `docs/cranial_scqr_v1_research_2026_09_10/l4_round_a_development_evaluation_protocol_v1.json` | `04077152848c055c76fbc64f4427301af9809e2fda6cd2117d644088bad7e8ae` | 本轮分析合同章节及哈希核验 |
| `tools/analyze_cranial_scqr_v11_l4_round_a.py` | `3a54206a950c5d6825373ca6364d41feacca44bac28e62b505a7d3d35d47985d` | 本轮 bootstrap 函数、分类片段及哈希核验；未运行 |

旧 Round A 的 QC 比较、PASS/NO_GO 分类和 A/B gate 不整体继承为 QA-1。

## 📌 保持不变的冻结规则

唯一主比较为 `LSQ - LS`，主指标为 `rim_gt_rim_to_pred_p95_mm`，负值更好。先对每个 source skull 的五种 defect 等权平均，再对 skull 等权平均。只在主比较通过后解释关键次比较 `LSQ - B0`，不因结果选择其他比较。

| 冻结项目 | 原有规则 |
|---|---|
| Bootstrap | source skull；10,000 次；seed `20260910`；双侧 95% percentile CI |
| 方向 | Fold C、Fold D 的主差值均 `<= 0` |
| 实际幅度 | pooled 主差值 `<= -0.10 mm` |
| CI | pooled CI 上界 `< 0` |
| Disaster | LSQ 独有新 disaster case 为 0；每折计数不高于 LS |
| Zero-contact | 任一折计数高于 LS，进入 review zone，不能直接通过 |
| Implant / Final CD-L1 | 差值分别 `<= +0.10 mm` |
| Final HD95 / NSD@1mm | 差值分别 `<= +0.50 mm`、`>= -0.01` |

`0.10 mm` 是冻结采样表示下的工程资源阈值，不是临床容差。C/D 只称内部 OOF 复核，不称独立外部验证。

## 📊 分层 bootstrap 适配提案

旧协议明确规定分别重采样 A、B 各 21 skull，再等权合并。旧实现采用 `numpy.random.default_rng(20260910)`，按每块 1,000 次抽样、先 A 后 B 的顺序抽取 `(count, 21)` 索引，对 pooled draws 取 2.5/97.5 percentile。

拟保持上述算法，仅将折顺序映射为 C、D。配对键为 `(fold, case_id, seed)`；先计算配对 case 差值，再形成 source-skull 差值。候选使用相同重采样索引；每个折保持 21 skull，pooled 权重固定各 0.5。不从 42 skull 无分层抽样，不将五种 defect 独立 bootstrap，不产生训练 seed 不确定性解释。

拟将 source 顺序固定为 fold 内 `source_skull_id` 字符串升序；所有数值必须有限、配对完整、每 skull 五个冻结 defect，缺失即停止，禁止静默剔除。后续实现需绑定 NumPy 版本、RNG 类型、排序和 percentile 的 linear 方法，并通过人工数据 CPU 合同测试。本草案未创建该实现。

护栏的 fold/pooled 作用域拟沿用旧协议的“每折及 pooled”，但 QA-1 文本未完全展开此作用域，因此这是待确认解释，不能冒称新增更严格作用域已预注册。

## ⚠️ 历史数值证据限制提案

此前审计发现 B0 Fold C、B0 Fold D、LS Fold C 的训练与 BNCal 回执缺少数值策略快照。缺失不等于已证实违规，但无法追溯认证；后续严格 evaluator 不能补证早期训练/BNCal。新容器上还须重新核验这些源文件的哈希与授权链，本草案不代替该核验。

拟采用双层报告：统计量是固定 checkpoint 的条件性描述；数值可比性为独立证据状态。后续另行授权后可以计算 LSQ-LS 的配对差值与 CI，但必须显式标注 Fold C 的历史数值条件证据不完整。不得把 bootstrap CI 解释为已消除数值策略混杂，或把它解释为跨训练 seed 稳定性证据。

在证据限制未被单独裁决前，`formal_gate_status` 保持 `NOT_ADJUDICATED_HISTORICAL_NUMERICAL_EVIDENCE_GAP`；禁止赋予正式 `CONFIRMED_INTERNAL_REPLICATION` 或自动推进 QA-2。该状态是证据状态，不添加或替换预注册五类科学分类。原阈值的逐项布尔检查也属于 gate 计算，需要未来明确授权，本次不进行。

不自动重跑、补做 BNCal、修改历史回执或改变阈值。未通过主比较的情况下不解释 LSQ-B0；主比较因证据限制未裁决时，次比较解释同样锁定。

## 🎯 分类优先级待确认提案

仅在未来正式 gate 获得单独授权且证据充分时适用。所有 gate 原始检查均应保留，不能只输出一个标签。

| 顺序 | 条件 | 拟处理 |
|---:|---|---|
| 0 | 完整性/授权/配对检查失败 | 停止；不作科学分类、不自动修复 |
| 1 | 历史数值证据限制未裁决 | 正式分类不裁决；允许的描述范围以新授权为准 |
| 2 | 任一硬安全门失败 | `SAFETY_FAIL`，覆盖均值改善 |
| 3 | C/D 主差值严格异号 | `HETEROGENEOUS`，优先于幅度未达标 |
| 4 | 方向、幅度、CI、安全均通过，且无 review zone | `CONFIRMED_INTERNAL_REPLICATION` |
| 5 | 方向与幅度达到，但 CI 不通过或存在零接触 review zone | `PROMISING_UNCERTAIN`；不升级通过 |
| 6 | 无上述情况且幅度未达到 | `NO_REPLICATION` |

CI 上界恰好为 0 按原 `< 0` 门视为未通过，不引入容差。零差值按原 `<= 0` 方向门处理，不当作严格异号。任何未被上述条件唯一覆盖的组合应输出 `UNRESOLVED_CLASSIFICATION_RULE` 并停止人工裁决，不能事后发明规则。

原文中的“强 source sensitivity”“轻微 review-zone”没有冻结量化定义。本草案不新增影响点阈值或以逐一删除 source 结果自动改类；如未来需要该诊断，应另行冻结诊断协议，作为探索性证据而非隐性 gate。

## ✍️ 待确认与权限边界

- [ ] 确认 C/D 分层 bootstrap 映射、固定排序与 RNG/percentile 约定
- [ ] 确认护栏在每折及 pooled 的作用域解释
- [ ] 确认历史快照缺失采用描述性分析与正式裁决分离，不追溯认证或自动推进
- [ ] 确认分类优先级及未覆盖组合停止规则
- [ ] 后续在新容器重新核验六运行源证据，再决定 implementation-only 或 request 创建阶段

本轮只读访问协议/代码文本及其字节哈希；只新增本机这份草案。未读取指标 CSV 以计算结果、未执行 bootstrap/gate、未读取 NPZ、未反序列化 checkpoint、未使用 GPU、未生成 runtime config/launcher/request，也未上传服务器或执行 Git 操作。

技能的文档规范用于将上下文、证据、提案与确认项分开；本文件中的表格是规则映射，不是实验结果。
