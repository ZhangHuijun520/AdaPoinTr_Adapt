# R1-B 四文件路径／哈希／版本重绑定收尾方案 v1 草案

_2026-10-16，Asia/Shanghai；DRAFT_AWAITING_USER_REVIEW。仅起草；未授权实施、WSL、副本准备或测试。_

---

## 📋 背景与决策范围

返回合同两文件候选已完成一次八项内存检查，记录为8/8、退出码0。正式只读审计确认现有文件与哈希记录一致，但不证明原24项、真实Linux第7项、完整P3或科研preflight通过。stdout已从既有工具输出追溯补存，1197字节的解码哈希与原记录一致；其来源仍是事后对话工具输出副本，不是运行时文件捕获。

本草案仅解决人工运输测试链的路径、角色哈希、版本和读写绑定。它不授权实施，不连接自强5000，不扩大依赖审计，不改变研究模型、数据、checkpoint或GPU行为。

### 方案选择

| 选择 | 代价与风险 | 建议 |
| --- | --- | --- |
| 原地替换旧目录常量 | 历史基线被覆盖，多处固定值易遗漏 | 不采用 |
| 新目录只改LINUX_ROOT | 内嵌reader、case12及旧回执仍不匹配 | 不采用 |
| 新四文件候选＋外部单向绑定 | 需要有限接口适配，但可先完成源码再冻结后续证据 | 拟采用 |

采用ADR决策记录结构，先冻结选择、依赖关系、止损与验收条件。确认草案不等于执行授权。

## 📚 已核验基线与历史限制

当前本机源码目录为：
`E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution\local_tools\r1b_launch_transport_v2_20261016`。

| 文件 | bytes | 当前SHA256 |
| --- | ---: | --- |
| transport_adapter_v2.py | 35472 | `046f37562ffa75ce5ddceb93ca07ebe9ab7022fd793701aa87f1ab806b6122ac` |
| transport_contract_tests_v2.py | 33638 | `390d7290624d5edc22d5adb451ad869e997a2a3dc19f84ec0f35892ee23753e3` |
| transport_cpu_once_driver_v2.py | 45304 | `497117cd49690aa028b9d399dae72c69e867d809bd905f57d4c94d9f06d42654` |
| transport_entry_v2.ps1 | 1002 | `e8405762162cf1d713aee9ec330952282c69617188ebb66295a5a237ac8ab483` |

旧driver的PREPARED_SOURCES绑定的Linux driver为17128字节，SHA256为
`f87bc2fb6b5cb451a409fb0376fae111eb564274186feb8619d75bfafc773d98`，
并非当前45304字节的Windows orchestrator。旧两端角色差异是历史事实，不能把两者混为同一文件或直接互换哈希。

旧request `803dee0cfbe4093380ce2df8a4dd568a0a376f57720df02edbbe42497fab35a1` 已消耗，结果6通过、1错误、17未执行。旧Linux根
`/home/zhj/.local/share/r1b_transport_v2_once_20261016`
及旧Windows运行证据保持原样；不覆盖、不删除、不补跑、不resume。

## 📦 候选布局与四文件变更清单

拟新建本机候选目录：
`E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution\local_tools\r1b_transport_return_contract_v1_20261016`。

拟使用全新Linux人工根：
`/home/zhj/.local/share/r1b_transport_return_contract_v1_20261016`，
其下仅允许source四文件、空fixtures与preparation.json；执行前不得有evidence。

拟新Windows运行目录：
`E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution\docs\cranial_scqr_v12_qa_research_2026_10_11\v12_rsd_r1b_return_contract_original24_once_v1_20261016`。

以上均为候选路径；本次未检查其不存在，未创建、复制或查询Linux状态。以后若任一要求全新的目标已存在，停止，不覆盖、不自动改名。

四文件保留现有basename，避免无必要的import与case18动态加载改名；发布身份由新目录、绑定版本和完整哈希决定，不把文件名中的v2解释为旧发布仍可执行。

| 文件 | 限定适配点 | 不得改变 |
| --- | --- | --- |
| adapter | LOCAL_EXT4_ROOT；明确候选发布身份 | 三值结果合同、授权拒绝边界、Frames、受信字节与live fail-closed |
| tests | WINDOWS_SOURCE、case12入口路径及所需发布绑定断言 | 原24名称与顺序、case07修订、八项内存检查、其他测试语义 |
| PowerShell | 固定adapter新Linux路径 | ValidateOffline、固定argv、stdin数据、输入守卫、exit $LASTEXITCODE |
| driver | SOURCE/OUT/PREPARED_OUT、全部根路径、readers、角色绑定、元数据合同与错误留存 | 先消耗再分派、失败即停、禁止重试、预算与精确集合守卫 |

driver中必须逐项处理：顶部常量、legacy准备脚本中的硬编码assert、PREPARED_VERIFY_READER、PREPARED_EXPORT_READER、PREPARED_SOURCES、旧PREPARED_*哈希、ENTRY_REPORT、PreparedIO.bindings、validate_prepared_authority、人工entry fixtures及所有报告引用。旧路径可仅作为“拒绝旧版本”的负例或历史注释出现；不得留在新入口的有效读写或执行目标内。legacy prepare-and-run在新候选默认入口应明确拒绝，不允许旁路单独准备／授权流程。

不把Windows路径转换为猜测的Linux路径；本机候选与Linux副本必须分别绑定。Linux Python继续候选为
`/home/zhj/.local/opt/r1b-cpu-contract-python310-20261012/venv/bin/python`，
发行版为Ubuntu-20.04；本次不核验它们的当前可用性。

## 🔗 单向哈希合同与版本策略

### 角色与无循环顺序

建议新发布采用同一份最终driver源码支持Windows orchestration与Linux internal worker，两端四文件按相同最终字节准备；两端角色仍分别记录，不能以Windows核验代替Linux核验。此为待实施设计，不是已实现事实。若需要两份不同driver，停止重新确认，不临时派生第五实现文件。

为避免driver自身哈希或后生成回执倒灌到源码，新增绑定数据只能是非可执行JSON文档，不是第五程序。顺序如下：

| 顺序 | 冻结对象 | 允许绑定的前置对象 |
| --- | --- | --- |
| 1 | 确认后的收尾方案 | 历史证据 |
| 2 | 四文件最终源码 | 已确认方案、固定路径／版本 |
| 3 | source-binding文档 | 四文件各自bytes与SHA256、两端角色、case集合 |
| 4 | 准备清单 | source-binding、最终源码、固定元数据序列化规则 |
| 5 | preparation.json及准备回执 | 已冻结清单、四文件；回执绑定元数据 |
| 6 | 就绪审查／entry检查报告 | 源码绑定及准备证据 |
| 7 | 待授权request | 上述既有证据、预算、路径、精确字段 |
| 8 | 授权回执 → runtime | 回执绑定request；runtime绑定request与回执SHA256 |

任何对象不得绑定自身SHA256或未来报告SHA256；授权回执不反向绑定runtime哈希。后续证据形成后不再改driver重新“填哈希”。

driver改为从精确固定DOCS路径读取版本化绑定文档，由request完整SHA256作为执行授权锚，逐项核对driver自身、四文件、两端角色、metadata、准备回执、审查及entry报告。不能只信source-binding自报的verified=true，不能读取任意调用者路径，不能把PREPARED_NOT_EXECUTED当成执行授权。

准备阶段和执行阶段分开：准备清单冻结四文件和元数据；request在准备回执及就绪证据形成之后创建。entry人工检查以外部报告绑定driver，driver不得嵌入该未来报告哈希，否则会形成“driver→报告→driver”循环。

### 精确元数据合同

替换旧reader的硬编码1850字节，不放宽为“任意大小JSON”。新清单在复制前用确定性UTF-8、无BOM、固定字段／键序与末尾换行规则算出preparation.json的精确bytes及SHA256，reader以该精确值读n+1并核验，仍保留正大小及上限。

新preparation.json采用精确字段：schema、status、tests_authorized、root、sources、cases、source_binding_sha256；schema为r1b-return-contract-preparation-v1，status为PREPARED_NOT_EXECUTED，tests_authorized为false。source_binding已先于元数据冻结。删除旧元数据中的binding_review_sha256与preparation_plan_sha256；它们改由后生成的准备回执／request绑定，不在元数据内回指清单或未来审查，避免“清单含metadata哈希、metadata又含清单哈希”的循环。source-binding、清单、reader与writer必须采用同一份明确合同；字段缺失、额外字段、旧hash、错误角色均拒绝。不沿用旧元数据的大小或审查哈希。

沿用不变的运输帧schema、bootstrap／PROGRAM、r1b-controller-result-v3及语义；核心PROPOSAL_SHA256等历史内核绑定不因包装版本而随意改写。新包装发布身份建议独立命名
`r1b-return-contract-release-v1`、
`r1b-return-contract-source-binding-v1`。
新增元数据字段或请求字段须reader/writer同时采用新schema；结构未变的内部结果不为改名而改名。

## 🔐 保留的守卫与产物合同

bootstrap SHA256保持
`d5d04f960751c3908a16f905d6fcad7212721dc96fa457172f56148287128ea5`；
PROGRAM SHA256保持
`cf3414a334121438ba457e72a837dad4d278c9c28ac0481b9c913184a81169fc`。
两文件运输、终端命令≤2048字节、bootstrap≤768字节及原身份／输入／帧顺序绑定不变。

保留秘密、真实payload、checkpoint、越界、链接／reparse拒绝，uid与权限检查，精确目录集合，排他创建、限量读取和先落盘attempt再执行。无真实hpc5000、网络、凭据代理或GPU。服务器PROJECT、STAGING、REMOTE_PYTHON不属于本机路径迁移范围。

原Linux五文件证据合同保持：attempt.json、events.jsonl、partial_output.bin、result.json、files.sha256。Windows精确证据集合及各文件上限应逐项冻结，不能为新增文档任意扩大运行目录集合。独立追溯材料保存在DOCS版本化路径，不混入Linux五文件目录。

新运行须在执行时保存实际stdout／stderr字节或可无损解码载体并记录bytes、hash、来源；若只保留partial，必须明确它不等于完整stdout。不得用摘要重建原始输出。首错在发生时记录，后错按顺序追加；失败路径与属性差异限于安全诊断，不输出秘密。

## 🧪 验证范围、预算与止损

本草案不执行下列检查。后续建议一次独立implementation-only授权最多新增四个候选实现文件，原目录不改；另可生成非可执行版本化审查证据。先静态门，不准备Linux副本。

### 静态S0/S1门

S0：基线哈希、候选恰四实现文件、UTF-8读取与AST、原24集合、受信字节、八项入口、所有旧有效路径清除、两端角色与无循环绑定图。

S1：逐项对照真实reader/writer字段、argv／stdin、request／回执／runtime、metadata精确大小／hash、reader允许路径、预算与出口；不以文本存在几个函数代替合同复核。完成限定读者全链人工接口检查前不得宣称接口就绪。

### 建议一次十项纯内存接口检查

检查置于现有候选driver内独立入口，使用内存IO，实际WSL／进程／网络调用均拒绝；不运行原24项、原八项或已有十项entry批次。若需改变该范围，先报告，不追加测试。

| 编号 | 场景 |
| --- | --- |
| B01 | 精确四文件及两端角色匹配，缺项／额外项／角色错均拒绝 |
| B02 | 固定路径与新发布schema，旧根／旧版本拒绝 |
| B03 | reader/writer元数据往返；错bytes／hash／字段拒绝 |
| B04 | 源码→绑定→清单→回执→request无循环，未来引用拒绝 |
| B05 | request／授权回执／runtime单向绑定与完整hash拒绝分支 |
| B06 | PREPARED_NOT_EXECUTED不是授权；授权前不分派 |
| B07 | attempt先消耗，已有目录／旧request拒绝 |
| B08 | verify／batch／export argv固定，stdin数据不成为代码 |
| B09 | 批次失败＋后续export失败，首错不变、次错可追溯 |
| B10 | 新报告完整读者解析、精确证据集合、日志字节hash及限额 |

人工检查单批≤30秒、每项≤2秒，首个失败即停，不自动修复重跑；内存mock通过不证明WSL或Linux可用。B04的源码静态依赖复核与人工拒绝分支必须分别记录，不能凭单个mock结果证明无环。

以后原24批次预算继续为outer180秒，verify15、普通case5、case12为20、export10、freeze5、termination3；分配受剩余总预算约束，不能将所有case上限相加后越过总限。所有失败均停止，不增时、不resume；后续阶段不得调用legacy自动准备并运行入口。

## 📍 验收门、完成标准与授权边界

| 门 | 完成标准 | 本次是否执行 |
| --- | --- | --- |
| 草案 | 用户审核路径、角色、无环方案与有限检查 | 仅起草 |
| implementation-only | 最多四新文件，S0/S1及一次限定十项；失败即停 | 否 |
| 正式冻结／缺口复核 | 独立核验新证据，更新有限P3差距 | 否 |
| 准备清单 | 最终四文件hash、精确元数据及新路径冻结 | 否 |
| Linux准备＋就绪审查 | 单独授权，PREPARED_NOT_EXECUTED | 否 |
| 新request | 绑定最终实现与就绪证据，保持待授权 | 否 |
| 原24执行 | 单独完整SHA256授权后唯一一次 | 否 |
| post-test／P3 | 按实际24项结果独立冻结；不宣称科研preflight通过 | 否 |

收尾完成标准是：四文件候选静态合同一致、十项有限人工检查通过并独立冻结，所有后续绑定数据不反向修改源码；仍明确列出Linux准备、原24和P3未完成项。不得把“新hash尚未生成”或“Linux尚未授权”当成需要继续补源码的失败。

实现止损：最多四个候选实现文件、一次静态门、一次十项人工批次；不引入通用框架、第五工具或扩大环境扫描。需要修改受信字节、放宽数据禁区、增加真实I/O或改变元数据授权锚时停止。目标路径存在、基线漂移或任一门失败时保存证据并等待方向。

建议下一条授权仅为：确认本草案并单独授权implementation-only，最多新增四个本机候选文件，完成S0/S1后执行一次限定十项纯内存接口检查；不调用WSL、不准备副本、不运行原24项或其他已消耗批次。本段是建议，不是已获得权限。

## 🔗 证据与本次实际交付

- [返回合同确认方案](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_return_contract_case07_revision_proposal_v1_draft_20261016_zh.md)，SHA256：`e7b79e499ce4c700f950d9cbffe1383e4164a686cd341a656318e2b4261cdb52`
- [实施报告](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_return_contract_memory_implementation_v1_20261016.json)，SHA256：`c8a44135e38ff10c12627043c60c8513fdf961cab233e538773c4ca0223f27b8`
- [正式只读审计](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_return_contract_post_test_freeze_audit_v1_20261016.json)，SHA256：`86ccd4ddfc4b46b90e76f79ad6a4f1cf9365913cecb9d7bda477c96f4012a7ef`
- [stdout追溯核验](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_return_contract_stdout_retention_verification_v1_20261016.json)，SHA256：`df365e1c96a6ea71e3083d045b4e4c80da23fae5f0976e321e369729e5182c7e`

本次仅新增本文及SHA256清单，读取四文件与既有证据，使用文档技能的决策结构及关系表列明完整绑定范围。源码编辑、模块导入、人工检查、测试、WSL、复制、服务器操作、request／runtime／launcher材料化与GPU均为0。文中候选目录及新schema尚未实施。
