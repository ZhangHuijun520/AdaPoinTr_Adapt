# R1-B 最小执行链收敛审查与修订方案草案 v1

_Cranial-SCQR v1.2-RSD · 2026-10-13 · 仅方案，不实施_

| 项目 | 状态 |
|---|---|
| 本文状态 | `AWAITING_USER_CONFIRMATION` |
| 本轮授权 | 本机只读源码审查、起草方案 |
| 服务器操作 | 0 |
| 代码修改／测试／库存审计／GPU | 均未执行 |
| 旧 v7 CPU request | 已消耗，失败，不可复用 |
| 本文是否 execution request | 否 |

---

## 📋 1. 背景、事实与决策边界

近期研究目标仍是：验证 query-off 工程合同，再决定是否开展冻结 checkpoint 的 R1-B 机制干预；不是构建通用环境审计平台。QA-1 的边界收益与尾部风险是科研信号；最近路径、fixture、链接和库存扫描失败是工程问题，两者不得混为算法失败。

此前只读观测确认 v7 CPU 工作流三组测试计数 99／27／99、退出码均为 0；库存扫描在 ENUMERATE 阶段抛出 `forbidden nested directory`，主退出码 1，无最终成功 P3。失败日志未保存精确触发路径；随后有界名称调查发现依赖目录 `timm/data`、`transformers/data`、`sklearn/datasets` 等会命中规则，但该调查超时且清单不完整，不能认证哪个目录首先触发。本文沿用这些历史观测，本轮未重连服务器或重新核验。

本机 v7 审计源码的 `worker` 扫描 models、utils、extensions 和整个 ENV/lib；`enumerate_files` 对所有实体目录使用统一 basename 禁止集合，且异常没有路径 detail。这解释了规则冲突，但不构成对精确历史失败路径的重建。

建议将“遍历整个环境所选后缀”改为“从固定执行入口形成可审核的有限依赖集合”。这是新的证据合同，不是给旧 v7 补一次扫描或降低旧验收门槛。所有旧失败、原协议、request 和实现保留；本文确认后仍须单独 implementation-only 授权。

## 🎯 2. 选项与推荐决策

| 选项 | 成本／优势 | 主要风险 | 建议 |
|---|---|---|---|
| 继续 ENV/lib 广扫，仅增加排除项 | 复用现有框架 | 新无关目录继续阻断，排除表不断膨胀 | 不推荐作为当前主线 |
| 只绑定 AdaPoinTr 与 torch | 范围很小 | 漏掉注册导入、工具支持及 CUDA 扩展 | 拒绝 |
| 固定入口依赖闭包＋核心二进制闭包 | 范围与本实验对应 | 需显式处理动态导入与导入副作用 | 推荐，先验证完整性 |

不承诺“缩小范围即能运行”。缩小后的闭包必须足以支持固定执行入口，并声明静态／CPU 观测的局限；不能使用“完全证明 CUDA 动态加载闭包”的表述。

```mermaid
flowchart TB
    accTitle: Minimal Preflight Evidence Chain
    accDescr: A proposed dependency boundary is reviewed and implemented only after authorization; CPU evidence and a separate GPU request precede synthetic preflight and real diagnosis.
    review_draft["审阅有限依赖方案"] --> scope_confirm["确认范围与预算"]
    scope_confirm --> implementation_gate["单独授权实现与 CPU tests"]
    implementation_gate --> evidence_freeze["有限清单及新 P3 冻结"]
    evidence_freeze --> gpu_request["新人工 GPU request 待授权"]
    gpu_request --> gpu_preflight["单独授权人工 GPU preflight"]
    gpu_preflight --> diagnostic_gate["冻结后另议真实诊断"]
```

## 🔗 3. 代码与依赖绑定范围

### 3.1 已从本机文本确认的入口

专用 preflight 先执行纯文本授权／哈希检查，随后导入 torch、numpy、yaml、EasyDict，再通过 `from models import build_model_from_cfg` 构造 LS／LSQ。两份 YAML 只使用 model 子映射，不合并 dataset base。AdaPoinTr 导入 Transformer_utils、misc、SCQR、几何／接触工具及 Chamfer 包。

本机 `work/PoinTr/models/__init__.py` 还尝试导入 TopNet、PoinTr、GRNet、PCN、FoldingNet、SnowFlakeNet；`utils/misc.py` 导入 matplotlib 和 pointnet2_utils。故 “Mamba disabled” 不等于模型入口完全没有额外导入。上述 work/PoinTr 文本是本机参考，未经本轮服务器同哈希认证；不得假定它完整等于当前服务器。

推荐第一版不改模型注册机制、不重构训练／模型 forward；把实际入口的导入副作用纳入有限清单。若其闭包超预算，停止并提交独立的专用入口设计审查，不能在授权执行中临时绕过注册或屏蔽 ImportError。

### 3.2 必须绑定的项目文件类别

| 类别 | 范围 | 验收方式 |
|---|---|---|
| 专用执行与守卫 | synthetic_gpu_preflight、synthetic_preflight_contract、相应测试 | 最终实现 bytes／SHA256 |
| R1-B 支持 | run_cranial_scqr_v12_rsd_r1b、R1-B contract、canonical_tensor_hash 相关实现 | 继承 parent9，扩展文件有调用理由 |
| 模型 | AdaPoinTr、SCQR query bypass／conditioning／local/contact、Transformer_utils | 传递源码引用＋父哈希 |
| 构造与导入入口 | models/__init__、build、registry、实际导入模型／工具 | 全部导入副作用纳入，不按模型配置猜测 |
| 工具 | pointnet2_utils、misc、logger、几何／接触依赖 | 模块来源与文件身份 |
| 模型配置 | LS／LSQ Fold C seed0 两个已有 YAML | 全文件哈希，只解析 model |
| 运维执行 | 新 inventory、installer、supervisor、contract tests、冻结模板 | 新版本 bindings，与模型代码分开 |

保留 parent9／canonical3／旧协议与旧失败证据身份核验。只核验，不执行其真实 evaluator 或展开其数据／checkpoint 引用。父哈希漂移一律阻断。

### 3.3 依赖分层与必要 CUDA 扩展

| 层 | 候选依赖 | 是否阻断 |
|---|---|---|
| 实际 forward／数值层 | Python、torch、numpy、timm、einops、PointNet2 | 必须冻结路径、版本及相关源码／binary；缺失阻断 |
| 配置与构造层 | PyYAML、easydict、registry 等 | 绑定导入代码及必要资源；缺失阻断 |
| 导入副作用层 | Chamfer、matplotlib 及注册入口额外模型依赖 | 实际被入口导入者必须覆盖；不等同本次调用其算子 |
| 当前关闭功能 | mamba-ssm、causal-conv1d | 如仅版本记录则不因无关漂移阻断；实际导入／加载则升级为必绑定 |
| 无关环境包 | 不在闭包中的 tilelang、z3 等 | 不递归扫描或要求其目录全部合规 |

PointNet2：确认包装源码、实际 `pointnet2_ops` 源模块及已安装扩展 `.so`，冻结真实来源；禁止纯 torch fallback 被悄然采用。Chamfer：虽然 preflight 不计算 loss，AdaPoinTr 的 import 仍可能加载其扩展，需核对 wrapper、扩展模块、加载方式。若注册入口加载其他扩展，同样纳入。

torch 核心：Python binary、torch Python 分发代码、`_C`、libtorch／c10 CPU/CUDA 库、所需 CUDA/cuDNN/cuBLAS 库及其静态 loader 递归目标；numpy 的实际 binary 与相关 loader 依赖也须覆盖。路径从当前安装元数据／包装源码／受限 CPU 观测取得，不猜测 `.so` 名称或系统路径。不得因为旧 inventory 只选择少数 ldd target 就声称所有自定义扩展已覆盖。

标准库：绑定 Python binary 和本次入口涉及的标准库源码、动态模块及 loader 目标，不遍历全部标准库测试树。包：以预先审核的有限 distribution 代码／binary 集合为保守边界；只选 `.py/.pyi/.so`、明确加载资源和 allowlisted 元数据，禁止根据 RECORD 自动打开所有文件。`.pth`／sitecustomize 导入副作用也要明确核验，未知执行 hook 阻断。

当前只完成文本级候选识别，未生成最终闭包；当前服务器额外模块、扩展路径、动态资源和 loader 哈希仍待独立只读范围核对。未知项须列为 `UNRESOLVED_BLOCKER`，不可填猜测值创建 READY request。

## 🔐 4. 项目禁区与依赖目录的分域策略

### 4.1 所有域都不得放宽的规则

- `.ssh/.codex/.aws/credentials/secrets/auth.json` 禁止读取；不打印内容。日志必要时仅记录脱敏类别与安全域，不暴露秘密值
- NPZ／STL、checkpoint／序列化权重、真实 prediction／CSV 等 payload 不进入清单、不读取字节；任何显式 required binding 命中它们都失败
- 先检查原始路径与每层链接，再检查 canonical target；`..`、越界、循环、未知目录链接、文件通过未授权目录链接均拒绝
- 代码／binary 不凭文件名自动获准；必须处于冻结允许根与有限清单，大小和内容指纹前后稳定，atime 不作内容身份判据
- 不安装、不 JIT 编译、不下载、不 fallback、不更改 sys.path 以遮蔽缺失依赖；不声称 Python 守卫是原生 C I/O 的操作系统沙箱

### 4.2 分域分类

| 域 | 规则 | 碰到同名目录 |
|---|---|---|
| PROJECT_CODE | 精确代码根／文件，研究 data/logs/results/checkpoints 不作依赖根 | 意外 nested 目录按研究边界拒绝并记录，不遍历 |
| DEPENDENCY_CODE | 预注册 distribution root 与代码文件种类 | `timm/data` 等名称不是独立禁令；只选审核代码，禁止 payload 字节读取 |
| DEPENDENCY_NONCODE | 样例、测试数据、文档资源等非必需集合 | metadata-only 排除，不进入内容清单，不需遍历内部 |
| SYSTEM_LOADER | 由必需 ELF 解析得到的精确库 | 不递归整个 /usr/lib 或驱动目录 |

`data` 名称从 DEPENDENCY_CODE 域的粗 basename 禁令中移出，不从项目真实数据边界中移出。所选包内未知文件种类默认不读取；若 required resource 未被覆盖则阻断，而不是自动忽略。依赖目录名 `checkpoints` 不因位于环境就可以装载权重。

原两个 ENV 目录链接策略可在新语义合同中明确继承：python3.1 仅 alias、canonical 覆盖一次；terminfo 仅 metadata 排除。若新有限范围完全不访问这些路径，则注明 not_in_scope，不伪造“已覆盖”；未知相关链接仍 fail closed。别名去重按 canonical 实体及链接链记录，不靠删掉重复项掩盖冲突。

## 🔍 5. 必须阻断与仅记录的信息

| 必须阻断 | 理由 |
|---|---|
| request／授权／runtime／实现／父证据哈希或 bytes 不一致 | 执行身份失配 |
| 必需模块／资源／binary 缺失、来源或 loader 目标未解析 | 闭包不完整 |
| 必需依赖版本／内容／CUDA/cuDNN 合同漂移 | 数值解释受影响 |
| 当前 hostname／uid／Python／GPU UUID 不匹配冻结 request | 需新资源绑定，不修改旧 request |
| 禁区、秘密、payload、越界、循环、未知链接、文件变动 | 权限或完整性失效 |
| deterministic／TF32／线程／AMP 设置不符 | 原数值合同失效 |
| GPU busy、显存／磁盘不足、输出存在、超预算 | 不允许启动或继续 |
| native invariance／恢复／零计数失败 | 干预不可解释 |

仅记录：无关安装包版本、全环境大小、非必需文档／测试目录的存在、OS 描述性版本、空闲显存的实际值。仅记录不等于掩盖：实际进入相关闭包的项目立即升级为 required gate；输出 `record_only_reason`。OS loader 内容、driver 绑定和资源最低值仍是 blocker，不能把“OS 信息”笼统降为记录。

后续人工 GPU preflight 要在已授权的固定调用过程中记录实际模块来源／动态库路径，并核对它们属于事先冻结清单；不新增 warmup 或额外 forward。CPU 静态清单不证明 CUDA dlopen 完整性。无法预先解析的 required library 会阻断新 request；运行中发现未绑定加载则失败保留，不现场加白名单继续。

## 📝 6. 精确失败路径与一次性错误证据

新增结构化 detail 建议字段：`phase`、`operation`、`entry_path`、`relative_path`、`scope_domain`、`rule_id`、`entry_kind`、`raw_target`、`resolved_target`、`link_chain`、`scan_root`、`parent_path`、`entry_index`、`counts`、`elapsed_seconds`、`first_error_type`。

先在每个拒绝点构造 detail，再 raise；不能从最后心跳 current_path 猜触发路径。无链接字段明确 null；无法读取 stat/readlink 时记录失败操作，不伪造属性。目录排序若用于诊断需写明是新版本顺序，不假称重建 v7 的 os.scandir 历史顺序。

failure JSON、progress FAIL、controller 子进程回执与 supervisor failure 都保留同一 first_error/detail，secondary logging／fsync 错误另列，不能覆盖根因。对于非秘密代码目录打印精确路径；秘密路径只记录脱敏匹配与 rule_id。日志上限到达也终止，不截断后 PASS。

## 📊 7. 人工 fixture 与回归范围

保留现有适用的 99 项人工契约及 canonical27 的不变性回归；不重演本机 Native18，仅当进程守卫有实际改动才另议其必要场景。新增下列 16 类 fixture，每类一个或更多用例，最终精确测试数必须在实现完成后、执行 request 创建前冻结，本文不假报已存在测试。

| 编号 | 人工场景 | 期望 |
|---:|---|---|
| 1 | ENV/timm/data 合法 `.py` | required 代码有哈希 |
| 2 | ENV/sklearn/datasets 合法 `.py` | 不因名称拒绝 |
| 3 | PROJECT/data 嵌套目录 | 打开子内容前拒绝，精确路径 |
| 4 | dependency data 内人工 NPZ／STL／权重 | 读取 spy 计数 0；required binding 必须失败 |
| 5 | package 测试数据树 | 精确排除、无 target content open |
| 6 | 秘密目录／auth.json | 禁读、脱敏日志 |
| 7 | 合法 alias 与 canonical | 一实体覆盖，链接证据完整 |
| 8 | 未知／越界／循环目录链接 | 全部失败，各 rule_id 明确 |
| 9 | 文件经禁止目录链接 | pre-open 拒绝 |
| 10 | missing module／required resource | 不得变成 optional PASS |
| 11 | binary 或元数据来源冲突 | 不允许 basename 替代完整路径 |
| 12 | loader 的未知目标／解析失败 | 闭包 incomplete，停止 |
| 13 | 读取前后变动／只变 atime | 内容变动拒绝，atime 不误拒 |
| 14 | phase／entries／bytes 上限 | 有界失败，无自动扩大预算 |
| 15 | path detail 跨四级回执传递 | first error 一致，secondary 分开 |
| 16 | 无关包与实际被导入包 | 前者 record-only，后者 required gate |

所有输入人工构造，使用 read/open spy 验证禁止字节未访问，不读取真实 NPZ/checkpoint、不使用 GPU。不能通过缩小 fixture、删除守卫断言或跳过原测试来取得成功。

## ⏰ 8. 有限预算、完成标准与停止条件

### 8.1 建议预算（待确认，不是运行授权）

| 活动 | 建议上限 | 依据与限制 |
|---|---|---|
| 当前方案 | 1 版＋最多 1 次审阅修订 | 不生成实现／request |
| 未来依赖范围核对 | 合计 120 秒、每命令≤30秒 | 定向路径／元数据，不 ENV 广扫；超限记录 unknown 停止 |
| 未来有限库存 | 900 秒、200000 entries、50000 files、8 GiB bytes | 沿用既有保守上限，不凭未测数据压缩或增加 |
| loader | ≤32 根 targets、单次≤10秒 | 传递库精确集合；超 cap 停止，不截掉剩余库 |
| 未来人工 CPU 阶段 | 单组≤60秒 | 历史99／27／99约14／30／11秒支持现有级别；新增数另冻结 |
| 集成 CPU 工作流 | 1300秒、cleanup15秒 | 保留独立 deadline／收尾，不新增无限重试 |
| 人工 GPU preflight | 600秒，原固定8完整 forwards＋8出口调用 | 原协议不变，CPU准备不消耗 GPU 调用 |

当前有限依赖集合尚未测量大小，8 GiB/900 秒不是保证能完成。若必要集合超过上限，先停止提交范围与成本报告，不能执行时丢库或偷偷扩大预算。不要为“节省时间”取消关联 binary 哈希。

### 8.2 收敛完成标准

- 执行入口及所有 required import／资源／binary 有“为什么需要”来源；unknown required 数量=0
- 必需源码／binary／loader／元数据清单有完整 path、bytes、SHA256、域、版本及选择理由；纯记录项分表
- project 与 dependency 的数据规则已分域；payload／checkpoint／秘密／链接／越界守卫未放松
- 人工回归全部通过；原 canonical 合同不变；失败路径与权限零计数证据可传递
- 新 CPU P3 与单次流程终态正式冻结，旧失败不覆盖；不把 CPU 通过称为 CUDA 通过
- 然后才有资格创建新的待授权人工 GPU request；不自动材料化或启动

建议设置一次 implementation-only 批次、一次冻结 CPU 集成尝试。若失败，先做只读根因复盘；最多提出一次合并修订方案，由用户决定新授权。若再次遇到不同环境问题或必须扩大范围，回到研究预算决策，不自动滚动到 v9/v10，也不强制放弃科研。

## 📦 9. 未来改动范围与兼容性

拟新增版本化库存工具／测试和对应 installer/supervisor 静态分派，仅调整相关 inventory 域、有限集合和 detail 传递。尽量保持 v7 已验证的 handshake、PID-start、deadline、一次性、publication、cleanup 逻辑不变；涉及它们必须显式列出 diff 和新增合同。

preflight 守卫现有 `validate_request`、`IMMUTABLE_FIELDS` 以及工具 `text_preconditions` 绑定旧 inventory/P3 schema、固定 request namespace 和版本策略。范围改变不能仅换一份 JSON 冒充兼容：implementation-only 前必须逐项审阅 reader/writer 和 schema migration，决定新增并行版本或显式适配。模型/训练/v1.1 默认不修改；新读者只能接受新 schema，不将旧 failed v7 视为 PASS。

不以模型入口重构、原 evaluator 修改、Mamba 路径升级、库安装、数据／checkpoint 访问、训练作为本批次顺带事项。资源身份使用新 request 的新鲜审计值，不照抄旧容器。

## 🔗 10. 来源、限制与下一步

本次只读来源：

- [正式后续计划](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/cranial_scqr_v12_qa_followup_formal_experiment_plan_zh_v1.md)
- [人工 GPU 协议](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_gpu_zero_update_preflight_protocol_v1_zh.md)
- [v7 审计源码](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/r1b_synthetic_pf_impl_v7_20261013/audit_synthetic_pf_dependencies_v7.py)
- [专用 preflight 源码](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/r1b_synthetic_pf_impl_v1_20261011/tools/run_cranial_scqr_v12_rsd_r1b_synthetic_gpu_preflight.py)
- [preflight contract](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/r1b_synthetic_pf_impl_v1_20261011/tools/cranial_scqr_v12_rsd_r1b_synthetic_preflight_contract.py)
- [R1-B AdaPoinTr overlay](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/v12_rsd_r1b_impl_v1_20261011/models/AdaPoinTr.py)
- 本机参考 `work/PoinTr/models/{__init__,build,Transformer_utils}.py`、`utils/{misc,pointnet2_utils}.py`；不是本轮服务器证据
- 本对话上一轮正式失败审计及只读目录匹配结果：历史观测，不声称本轮重新认证

没有外部性能／文献主张；没有最终依赖清单、实际二进制哈希或 CUDA 动态闭包证据。现阶段仅提出可审核的缩界方法和明确停点。

下一步仅请用户审核方案、预算与范围变更；确认不等于实施或执行授权。若确认，建议先单独授权定向依赖／reader-writer 只读核对，产出最终候选文件清单和 unresolved 表，再单独 implementation-only。不得直接启动新 CPU 或 GPU request。

本机只新增本草案和独立 SHA256 侧文件。markdown-mermaid-writing 技能用于决策记录、范围矩阵和授权依赖图；未借其提交建议执行 Git。生产代码、既有测试、旧结果、运输包不变；未部署、准备 ext4 副本、测试、安装、清理、统计、gate 或使用 GPU。
