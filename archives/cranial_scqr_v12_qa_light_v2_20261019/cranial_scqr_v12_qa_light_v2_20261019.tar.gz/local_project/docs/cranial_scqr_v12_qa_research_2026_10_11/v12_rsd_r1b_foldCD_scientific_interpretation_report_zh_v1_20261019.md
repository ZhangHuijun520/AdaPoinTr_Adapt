# Cranial-SCQR v1.2-RSD：Fold C／D 冻结配对干预结果解读

_2026-10-19 · R1-B 科研复盘 v1 · 仅解读已冻结标量，不新增模型实验或正式统计裁决_

---

## 🎯 1. 结论摘要

R1-B 的既定 C/D 同进程配对诊断已经完成，两个成功运行各 105 病例、315 次 forward，正式只读冻结审计均通过。成功运行合计 630 次 forward；另保留旧失败尝试的 3 次，真实干预阶段累计实际 633 次，人工 GPU preflight 另计。

核心结果是：**在这两个固定已训练 LSQ checkpoint 和当前执行条件下，移除 Query 残差加法没有解除任何 disaster；几何指标响应幅度较小且方向混合。** 当前推理出口的直接作用，不能充分解释 LSQ 相对 LS 的全部均值差距和这些风险病例。

研究建议：结束当前 R1-B，不重复 preflight、重跑干预或扩展审计框架；当前 LSQ 不晋级，不默认开启 R2 四次训练或 Query-Mamba。下一步先选择一个可证伪研究问题，优先讨论 Local/SCF 的独立增量，而非把修复当前 Query 当默认目标。这是研究资源分配建议，不是原 QA-1 正式 gate 或五类分类。

## 📋 2. 设计、证据与估计对象

依据：[C 冻结审计](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_same_process_foldC_formal_post_intervention_freeze_audit_v1_20261019.json)、[D 冻结审计](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_same_process_foldD_formal_post_intervention_freeze_audit_v1_20261019.json)、[既有 C 标量提取](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_foldC_scientific_interpretation_evidence_v1_20261019.json)及[本次 C/D 解读证据](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_foldCD_scientific_interpretation_evidence_v1_20261019.json)。D 本次仅有 3 次有界只读调用，读取 5 个精确哈希绑定的标量文件；C 复用已有冻结提取，没有重跑。

每折 21 个 source，各含 5 类缺损。每病例三个条件：

| 条件 | 权重来源 | 对比角色 |
| --- | --- | --- |
| LS native | 该折 LS checkpoint | 不同训练产物的参考 |
| LSQ native | 该折 LSQ checkpoint | 配对基准 |
| LSQ query-off | 同一个 LSQ checkpoint | 仅旁路残差加法 |

主干预差值为 off − native。距离指标负值表示 off 距离较低；NSD、precision、recall 方向相反。下方主表只展示距离，完整 14 项冻结差值保存在证据中。

两折均保持参数与 buffers 不变，optimizer steps、BNCal 为 0；native/off 配对 RNG 前后证据相等。Coarse anchors 相等是运行时强制守卫。Off 保留潜在分支计算和诊断，只将实际加入的残差置零，不是重新训练的无 Query 模型，不等于 LS，也不能识别训练全过程中 Query 的总贡献。

```mermaid
flowchart LR
    accTitle: Paired Intervention Interpretation Boundaries
    accDescr: The same trained LSQ checkpoint supports a native-versus-bypass contrast. The separately trained LS checkpoint is a reference, not the counterfactual without Query training.
    lsq_checkpoint["固定 LSQ checkpoint"] --> native["Native 残差加法"]
    lsq_checkpoint --> bypass["Off 旁路加法"]
    native --> paired_effect["当前固定权重下即时效应"]
    bypass --> paired_effect
    ls_checkpoint["独立训练 LS checkpoint"] -.-> reference["跨模型参考差距"]
    native -.-> reference
```

均值采用 source 内五缺损平均，再对 21 个 source 等权平均。两折训练集重叠、同 skull 五缺损相关；210 病例不是 210 个独立 source，两个 fold 也不是两个独立训练 seed。本次不生成 pooled 效应、CI、p 值、bootstrap 或新阈值。

## 📊 3. 几何结果：直接效应较小，跨折方向混合

### 3.1 两折即时干预差值

单位均为 mm。九位小数用于展示微小响应，不代表该精度具有临床意义。

| 指标：off − native | Fold C | Fold D |
| --- | ---: | ---: |
| Implant CD-L1 | +0.000014758 | -0.000009221 |
| Implant HD95 | +0.000019617 | +0.000138153 |
| Final CD-L1 | -0.000002522 | +0.000010490 |
| Final HD95 | -0.000008357 | +0.000088714 |
| RimCover-P95 | -0.000043794 | +0.000002122 |
| Contact CD-L1 | +0.000511945 | -0.000232668 |
| Contact HD95 | +0.002451941 | -0.002353919 |

Implant CD 在 C 略变差、D 略变好；Final CD/HD95 在 C 略变好、D 略变差；contact 均值在 C 略变差、D 略变好。不存在一致的“关掉 Query 全面改善”或“保留 Query 全面改善”。

相对当前 LS 与 LSQ 的均值差距，上述即时效应幅度小。这支持“这个推理残差出口不是全部差距的充分解释”，不能进一步断言差距必然全部来自训练塑形、SCF、初始化或其他单一因素。没有冻结等效性界限、测量噪声模型或临床可接受阈值，故不使用“统计等效”“完全无影响”“临床可忽略”等结论。

### 3.2 Fold D 的均值权衡未被关闭残差修复

| 指标，mm | LS native | LSQ native | LSQ off |
| --- | ---: | ---: | ---: |
| Implant CD-L1 | 2.921849 | 3.178437 | 3.178427 |
| Implant HD95 | 7.306361 | 7.839167 | 7.839306 |
| Final CD-L1 | 2.285854 | 2.339563 | 2.339573 |
| Final HD95 | 5.031684 | 5.320835 | 5.320924 |
| RimCover-P95 | 9.048962 | 8.652883 | 8.652885 |
| Contact CD-L1 | 4.475590 | 5.044181 | 5.043949 |
| Contact HD95 | 18.028555 | 19.312503 | 19.310149 |

当前 D 中，LSQ 的 RimCover-P95 低于 LS，但 Implant CD/HD95、Final CD/HD95、contact CD/HD95 均值更高。Off 基本保留这种权衡，没有把 LSQ 变成 LS。C 中 LSQ 相对 LS 的这些距离均值总体较好；D 的不同方向体现跨折异质性，不能只用 C 或 RimCover 一项给候选作总体背书。

### 3.3 均值接近零，不等于每个病例不变

D 的 off−native 病例范围为：Implant CD −0.000518 至 +0.000250 mm；Implant HD95 −0.002920 至 +0.004175 mm；RimCover-P95 −0.002502 至 +0.003521 mm；contact CD −0.111899 至 +0.075684 mm；contact HD95 −0.216860 至 +0.074304 mm。D contact CD/HD95 的中位差值均为 0。

C contact HD95 范围为 −0.024906 至 +0.138765 mm。尾部响应不能被平均值消去，但本次尾部变化没有造成 native/off disaster 转换。标量差值为零也不证明所有输出坐标相同。

## 🛡️ 4. 风险结果：四个 LSQ 独有风险均未被旁路解除

沿用冻结 disaster 定义；当前所有 core 指标有限，观测 disaster 均由 contact HD95 严格大于 50 mm 触发。它是工程异常标签，不是临床并发症终点。

| 折 | LS disaster | LSQ native disaster | LSQ off disaster | Native/off 转换 |
| --- | ---: | ---: | ---: | --- |
| C | 3/105 | 1/105 | 1/105 | 无新增、无解除 |
| D | 3/105 | 5/105 | 5/105 | 无新增、无解除 |

三条件、两折 zero-contact 均为 0，但不等于整体安全。C 有 104 个 native/off 双非事件、1 个双事件；D 为 100 个双非事件、5 个双事件。

D 当前完整事件集合：

- LS：022/frontoorbital、087/frontoorbital、087/random_1
- LSQ native 与 off：008/random_1、010/random_1、022/frontoorbital、087/frontoorbital、087/parietotemporal

LSQ 的三个 D 独有风险和 C 的 025/random_2 全部保留。D 的 LS 事件 087/random_1 在 LSQ 中不触发，说明净计数不能替代事件集合与新增病例。

事前已固定的 D 重点病例：

| 病例 | LS contact HD95 | LSQ native | LSQ off | 预测 rim 点数：LS / native / off |
| --- | ---: | ---: | ---: | --- |
| 008/random_1 | 18.959702 | 51.538335 | 51.538335 | 81 / 6 / 6 |
| 010/random_1 | 40.622367 | 68.398622 | 68.398622 | 120 / 179 / 179 |
| 087/parietotemporal | 37.945381 | 71.619648 | 71.619648 | 243 / 76 / 76 |

距离单位为 mm。这三例的 native/off contact HD95 和 rim 点数完全相同，disaster 保持为 1；其他几何指标仍有微小变化，所以不是整个模型输出完全没变。

三例中，LSQ 的 RimCover-P95 均低于 LS，却有更高的 contact HD95；C 的 025/random_2 也呈现同类目标分离。这支持提出“覆盖改善不足以保证接触质量”的研究问题，不能把覆盖指标直接当植入体安全。

不能一概归因于预测 rim 点太少：008 与 087 的 LSQ 点数比 LS 少，但 010 的 179 点多于 LS 的 120 点，仍触发风险。没有预测坐标、网格或临床评估，尚不能确定 underfill、穿透、裂缝或具体空间错误。

## 🔬 5. Query 在工作，但不是已验证的有效机制

| 描述量 | Fold C | Fold D |
| --- | ---: | ---: |
| 学得 alpha_q | +0.000111001 | −0.000162930 |
| Warmup | 1 | 1 |
| Native applied residual RMS 均值 | 0.000111158 | 0.000163261 |
| Off applied residual RMS | 0 | 0 |
| 相对潜在 residual RMS 均值 | 约 0.1431% | 约 0.1984% |
| Attention entropy 均值 | 5.543918 | 5.523858 |
| Effective proxy count 均值 | 255.677810 | 250.610488 |

D 相对残差 RMS 范围约 0.1232%–0.4930%，C 为 0.0857%–0.2350%。这是特征空间比例，不是几何误差百分比或解释方差。Native/off 其余 Query 描述值相同，符合只旁路加法的含义。

这排除了 warmup 未开启、残差精确为零两种简单解释。较小注入与较小几何响应相容，但没有证明定量机制。D 的 alpha 为负不自动意味着错误；折间符号不同也不能代替跨 seed 稳定性研究。

Attention 描述值不能证明空间针对性、重要性、collapse 或 capacity 重分配。不能因残差较小就事后放大 alpha、扫 temperature 或修改 gate 后沿用本轮结论。

## 🔎 6. 历史漂移：Fold D 不只是微小舍入差异

C、D 的历史 native 对比均为 210/210 行存在连续数值差异。C 有 68 行事件或计数字段差异，既有证据显示均来自点数，二值事件差异为 0。D 有 70 行点数差异，其中还包含 1 行 disaster 变化；两类计数有重叠，不能相加成 71 行，也不能称 70 个 disaster。

D 唯一二值变化为 LS_native / train__004__random_2：

| 字段 | 历史 | 当前 |
| --- | ---: | ---: |
| Contact HD95，mm | 84.869571 | 41.416903 |
| 预测 rim 点数 | 24 | 26 |
| 参考 rim 点数 | 389 | 389 |
| Disaster | 1 | 0 |
| Zero-contact | 0 | 0 |

Contact HD95 变化约 −43.45 mm，不是 50 mm 附近的微小舍入翻转。它解释了历史 D 的 LS disaster 为 4，当前为 3；当前 LSQ 仍为 5。不能把历史 LS=4 与当前 off 拼接比较，也不能称本次 LS=4。

这表明历史到当前的可比性存在实质限制，但未识别唯一原因。不能归因于某一个 CUDA 扩展、TF32、随机流或接触点数变化；接触子集/最近邻统计的敏感性只是待验证假设。它不自动推翻当前同进程 native/off 配对：当前出口效应与精确历史重放是两个不同问题。

状态继续保持：

- 原历史零容差 request 未通过、已消耗，不追溯改为成功
- HISTORICAL_ENVIRONMENT_NOT_FULLY_MATCHED
- NOT_ADJUDICATED_HISTORICAL_NUMERICAL_EVIDENCE_GAP
- 正式 classification 为 null

没有新增正式 gate、bootstrap 或显著性裁决。

## 🧭 7. 科研主线与最小下一步

### 7.1 R1-B 的科研产出

本阶段完成了固定权重下的 Query residual 出口诊断。两折一致显示小幅、混合几何响应，四个 LSQ 独有风险未解除。这是有用的机制约束和负面证据，不是实验没有产出。

可用于未来论文的谨慎表述：

> 在两个开发折的固定 LSQ checkpoint 上，同进程残差出口旁路仅引起较小且混合的几何指标变化，未改变灾难标志集合。这些结果不支持将观察到的模型间收益与风险主要归因于当前推理残差的直接加法作用；训练期及其他差异的贡献仍未被本干预识别。

不能写成 Query 对训练无用、训练塑形已证实、Mamba 必然修复风险或 QA-1 正式通过。本轮没有检验 Mamba 增量，也未提供 Mamba 有效性的正向证据。

### 7.2 优先建议：结束当前 Query 默认扩展，选择唯一下一问题

R1-B 可以阶段收束；RSD 整体和论文证据链尚未完成。建议不为获得正结论而继续扫 alpha、加大模型或重复同一干预。

优先转向 **Local/SCF 的可证伪增量问题**，先明确候选、最近对照、唯一假设与停止条件。现有 B0/LS 汇总不能直接证明 Local/SCF 已胜出，也不自动恢复旧 QA-2。

如果要识别 SCF supervision，父计划的 L0/LS 匹配结构、仅监督权重不同的设计比关闭推理 head 更能回答训练效应；它是新协议，目前没有实施授权。如果不存在可合法复用的严格匹配 LS，新两候选×C/D 就是四次训练，不能声称只需两次。是否值得投入，须先检查既有证据和信息价值。

R2 四次 seed1 LS/LSQ 训练是可选项，不是 R1-B 后的强制步骤。它可以询问统一新合同下的候选比较，但不能仅靠 seed1 自动补齐历史缺口或证明训练塑形。以近期小论文为目标，不建议仅为挽救当前 Query 主张而默认消耗四次训练。

不立即启动新 Query、Mamba、16384 或外部基线大矩阵。未来保留 Mamba 需要相对合理容量对照的质量增量，或质量非劣下的端到端效率增量；这是父计划条件路径，不是本轮已经证明的结论或已授权实验。

### 7.3 下一步建议的权限边界

建议下一项仅为“R1-B 阶段收束与下一主分支研究决策草案”：依据冻结证据选择是否停止当前 Query，并定义 Local/SCF 最近对照与最小科研问题。不继续开发通用框架，不训练、不创建运行 request、不重跑历史评估。这个建议尚未获执行授权。

当前没有必须再跑一次模型才能写下的 R1-B 结果缺口。若未来需要解释历史漂移，应另有明确科研问题和独立范围，不把该缺口当成无限工程准备的默认入口。

## 🔗 8. 溯源与本次边界

| 本机来源 | SHA256 |
| --- | --- |
| C 正式冻结审计 | ab57f970c6c70eb5a509ce742bd251d07c62238507443f40b2a017aca17fc813 |
| D 正式冻结审计 | 3b364476f1cd47a48215ece45296ed8aa91e32d086666f64694b97ce176d0743 |
| C 既有标量提取 | 71786e0910bfecb5408d7207f2d124db67d19b578ab0e24d4d598660348aed4c |

D 读取的原文件 SHA256、精确字节数、只读命令、标量及工具原始输出保存在[解读证据](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_foldCD_scientific_interpretation_evidence_v1_20261019.json)。这是可追溯摘录，不是服务器原始归档的字节备份。研究路线依据[后续正式计划](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/cranial_scqr_v12_qa_followup_formal_experiment_plan_zh_v1.md)。

本次仅新增本机报告和证据 JSON。服务器写入、NPZ/checkpoint 读取、模型导入、forward、训练、BNCal、测试、bootstrap、正式 gate、request/runtime/launcher 创建均为 0；旧报告和冻结结果未改。文档技能用于组织设计、结果和推断边界，不替代科研授权。长期备份状态未核验，不允许据此删除服务器文件。

