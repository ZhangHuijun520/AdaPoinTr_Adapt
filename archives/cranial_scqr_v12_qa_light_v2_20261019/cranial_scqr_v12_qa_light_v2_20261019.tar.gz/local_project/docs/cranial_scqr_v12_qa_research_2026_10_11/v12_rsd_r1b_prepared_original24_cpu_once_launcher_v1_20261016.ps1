$ErrorActionPreference = 'Stop'
$python = 'C:\Program Files\Python310\python.exe'
$driver = 'E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution\local_tools\r1b_launch_transport_v2_20261016\transport_cpu_once_driver_v2.py'
$request = 'E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution\docs\cranial_scqr_v12_qa_research_2026_10_11\v12_rsd_r1b_prepared_original24_cpu_execution_request_v1_20261016.json'
$authorization = 'E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution\docs\cranial_scqr_v12_qa_research_2026_10_11\v12_rsd_r1b_prepared_original24_cpu_execution_authorization_v1_20261016.json'
$runtime = 'E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution\docs\cranial_scqr_v12_qa_research_2026_10_11\v12_rsd_r1b_prepared_original24_cpu_runtime_v1_20261016.json'
& $python -I -S -B $driver '--run-prepared' $request $authorization $runtime '803dee0cfbe4093380ce2df8a4dd568a0a376f57720df02edbbe42497fab35a1'
exit $LASTEXITCODE
