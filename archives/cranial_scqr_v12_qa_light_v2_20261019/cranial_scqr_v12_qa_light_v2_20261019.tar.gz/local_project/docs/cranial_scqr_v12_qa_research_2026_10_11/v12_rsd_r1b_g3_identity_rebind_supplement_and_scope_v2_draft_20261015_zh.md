# G3 新身份重绑定补充方案与 v2 范围草案

_2026-10-15 · 仅本机起草，待用户确认；不连接服务器，不继续依赖核验_

---

## 📋 1. 提案状态与证据

本次授权仅为起草，不代表同意新的身份基线，更不是再次执行 G3 的授权。新增[身份补充方案 JSON](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_g3_identity_rebind_supplement_draft_v1_20261015.json)及[G3 v2 范围草案 JSON](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_g3_bounded_readonly_origin_scope_v2_draft_20261015.json)，均保留待确认、未执行状态。

[旧 G3 范围](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_g3_bounded_readonly_origin_scope_v1_20261015.json)对应的一次尝试已消耗，因身份不符停止。[停止观测回执](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_g3_authorized_readonly_origin_observation_v1_20261015.json)证明当时用户、uid 和 canonical 项目路径匹配，但 hostname 与 GPU UUID 不匹配；并未读取项目源码、依赖元数据或 ELF 内容。旧文件和原 SHA256 均保留，不回写为 PASS，不复用旧授权。

## 🔍 2. 身份差异与拟采用基线

| 字段 | 原比较基线 | 本次提案使用的已观测值 |
| --- | --- | --- |
| hostname | `shu-common-25721452-notebook-6hm4qc-0` | `shu-common-25721452-notebook-9jgyof-0` |
| GPU UUID | `GPU-34a1b996-2bd7-88e6-9dca-164b718caea6` | `GPU-41b45aa3-f5e3-e609-53cb-9c48bc7716ed` |
| 驱动，仅记录 | `570.190` | `575.51.03` |
| 用户／uid | `jovyan`／1000 | 相同 |
| canonical 项目 | `/home/jovyan/adapointr_work/PoinTr` | 相同 |

观测时刻为 2026-10-15 20:29:15（Asia/Shanghai），不是本轮重新观测。GPU 名称当时为 NVIDIA GeForce RTX 4090 D。Python／Conda 内容未检查，不能填入猜测的 patch 版本、Python binary SHA256、torch／CUDA／cuDNN 版本或扩展来源。

建议只将新 hostname／GPU UUID 用作一次未来 G3 只读来源核验的比较基线。驱动变化如实记录，不宣称新旧数值环境等价；不替换训练、BNCal、evaluation 或 GPU preflight 的资源合同。未来实际执行需要另行冻结其真实 runtime 条件。

## 🎯 3. 选择与建议

| 选项 | 影响 | 建议 |
| --- | --- | --- |
| 继续按旧范围重试 | 仍不匹配且旧尝试已消耗 | 不采用 |
| 去掉身份匹配守卫 | 无法核对执行对象 | 不采用 |
| 保留旧证据，提出新基线与 v2 | 可审核变更，保持原守卫 | 推荐，待确认 |

v2 只改变文档版本、提案状态、身份比较候选值与证据引用，并明确旧尝试不可继续。不会因“同属 4090 D”接受其他 UUID，也不会因只是容器重建就自动批准重绑定。

## 🔐 4. 严格保持不变的范围

v2 原样继承 v1 的 `transport`、`server_read_domains`、`forbidden`、`path_policy`、`permissions`、`budgets`、`phases`、结果解释及输出规则，保留全部先验源码 hash。

| 项目 | 不变限制 |
| --- | --- |
| 内容范围 | 22 个先验身份文件、18 个有限文字候选 |
| 时间／调用 | 总计 120 秒、单命令最多 30 秒、最多 6 次调用 |
| 唯一内容文件 | 最多 200 个 |
| ELF | 最多 16 个候选，仅有限头信息，不做全量 hash 或递归 loader 库存 |
| 重试 | 一次新尝试，自动重试为 false |
| 路径守卫 | 不增允许根、不放宽链接、秘密、payload、checkpoint 守卫 |
| 研究执行 | 不部署、不安装、不改代码、不测试、不运行真实库存／CPU tensor probe／GPU 计算 |

这不是安装包修复或环境迁移方案，不为未知 PointNet2／Chamfer 来源增加 fallback。候选未解析仍应报告 unknown 并停止，而非扩大扫描或从其他目录寻找替代实现。

旧观测的 process wall time 不能升级为完整 120 秒预算通过证明。未来核验仍须按原合同覆盖全部等待与复核；本轮不实现计时工具、不改生产守卫或运行测试。

## 📍 5. 确认、执行与再次身份变化

```mermaid
flowchart TB
    accTitle: Proposed G3 Rebinding Approval Gates
    accDescr: Draft baseline confirmation and separate execution authorization precede a fresh identity check; any new mismatch stops rather than automatically rebinding.
    draft_plan["本机提出新身份与范围"] --> confirm_plan{"用户确认提案？"}
    confirm_plan -->|否| wait_plan(["等待，不连接服务器"])
    confirm_plan -->|是| separate_authority{"另行授权 v2 完整 SHA？"}
    separate_authority -->|否| wait_execution(["仍不执行"])
    separate_authority -->|是| fresh_identity["新尝试先核对真实身份"]
    fresh_identity --> identity_match{"身份仍匹配？"}
    identity_match -->|否| stop_again(["停止，不自动重绑定"])
    identity_match -->|是| bounded_metadata["仅继续原有限只读范围"]
```

仅“确认方案”不会触发服务器操作。后续必须另外明确授权 v2 JSON 的完整 SHA256，才可开始一次新的只读核验；必须重新走身份门，而非续接旧尝试跳过的依赖阶段。两项授权可在用户一句话中分别明确表达，但本轮草案授权不包含其中任何执行许可。

草案中的 false 状态是创建时的事实；后续确认与授权应以外部、绑定完整 SHA256 的记录表达，不改写这些草案以翻转标志。任何 hostname／GPU UUID／用户／路径再次失配，都保留差异并停止；不会自动再生成新基线、重试或进入训练。

## ✅ 6. 本轮交付与未执行项

本轮仅在本机起草补充方案、v2 范围、中文说明及静态审查回执；检查 JSON 可解析、原限制逐项一致、父证据 hash 稳定。静态审查不是 CPU contract tests 或新的服务器审计。

本轮服务器连接与读取均为 0；没有批准后的重绑定回执，没有 runtime、launcher 或 execution request。旧范围、停止回执、v10 代码与 130 项测试证据不变。markdown-mermaid-writing 技能用于变更矩阵与分阶段授权图，未因此执行 Git、部署或实验。

下一步只请用户审核提案；在明确确认及单独执行授权前，继续保持依赖核验锁定。
