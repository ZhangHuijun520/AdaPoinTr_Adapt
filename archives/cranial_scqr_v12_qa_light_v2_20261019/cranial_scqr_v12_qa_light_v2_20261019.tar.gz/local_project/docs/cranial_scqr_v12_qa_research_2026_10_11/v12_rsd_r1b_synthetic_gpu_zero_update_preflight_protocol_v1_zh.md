# Cranial-SCQR v1.2-RSD R1-B：人工输入 GPU zero-update preflight 协议 v1

_2026-10-11｜仅协议与待授权 request；未实施专用执行器，未运行 preflight_

---

## 📋 1. 状态、父证据与设计选择

本次用户仅授权制定人工输入 GPU zero-update preflight 协议及创建待授权 request。当前所有执行权限保持锁定。本文件不授权新增执行代码、CUDA 导入/模型构造、人工 GPU forward、真实诊断、训练或 BNCal。

父协议为已确认 R1-B query-off 草案，其冻结 SHA256 为 `30eeb37fcc6e0172849c5dd4a5a457180d59b9cc0e521a9234b81158bc88b035`，原草案状态字段保留不改，由独立确认回执记录确认。已安装 R1-B P3 为 `PASS_IMPLEMENTATION_ONLY`，SHA256 为 `65f31131cbaedb0b904424f9e381901a6320040bf23376ecd43f09ca5ae3e390`。安装前后各 25 项 CPU 测试通过不等于 CUDA 通过。

本次只读重新核验了服务器 P3 和其九个 implementation hash、LS/A1 与 LSQ/Q0 配置文本、Python 二进制及包安装元数据、GPU 元数据；没有导入 torch/模型，也没有读取真实 NPZ/STL、checkpoint 字节、manifest、allowlist 或真实 CSV。详细来源见 [只读观测记录](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_gpu_preflight_readonly_observation_v1.json)。

| 选择 | 用途 | 局限 |
|---|---|---|
| 仅复用 CPU 测试 | 已完成基础合同 | CUDA 被主动屏蔽 |
| 仅 CUDA 残差出口 | 验证出口恒等/旁路 | 不覆盖完整网络与双模型驻留 |
| 人工出口＋两模型完整 forward | 本协议选择 | 一输入、初始化权重，不外推真实诊断 |

现有 `run_cranial_scqr_v12_rsd_r1b.py` 要求真实 fold request 与 checkpoint，不能当本协议执行器。专用 `tools/run_cranial_scqr_v12_rsd_r1b_synthetic_gpu_preflight.py` 尚不存在。本次不实现它。v1 request 保持 `AWAITING_EXPLICIT_USER_AUTHORIZATION`，同时 `execution_ready=false`、`direct_execution_allowed=false`，是有明确阻断项的请求，不是假称 READY 的可执行申请。

## 🎯 2. 人工对象与固定初始化

### 2.1 唯一点云输入

一个无真实解剖语义的规则点集，按整数 i=0…8191 顺序生成，形状 `[1,8192,3]`，CPU FP32 contiguous 后复制到 `cuda:0`：

```text
x[i] = ((i % 32) - 15.5) / 32
y[i] = (((i // 32) % 16) - 7.5) / 16
z[i] = ((i // 512) - 7.5) / 16
```

各值均为二进制可表示的有理数。不得 jitter、shuffle、归一化、裁剪、换 shape、降点数或增加人工样本。执行时记录 CPU/GPU 输入的 canonical hash 并相等，开始/结束输入不变；本次没有生成实际 tensor，也没有伪造其已验证 hash。它不是颅骨、无 mm 标签、无 GT/implant/接触标签；不调用真实指标、事件规则或 gate。

### 2.2 模型与初始化

只使用本次只读绑定的两个 Fold C 历史训练 YAML 的 `model` 子映射，分别为 LS/A1 与 LSQ/Q0。它们只是结构来源，不获得其历史训练授权。必须 `yaml.safe_load` 并仅提取 `model` 后通过现有模型 builder 构造；不调用会展开 dataset `_base_` 的全配置加载器、不执行 optimizer/scheduler/dataset/qa1_lock/cranial_scqr_execution，不调用 checkpoint loader。

结构固定：num_query=256、num_points=8192、embed_dim=384、encoder depth=6、decoder depth=8、center_num=[512,256]；保留现有 Local/SCF；LS query conditioning=false，LSQ=true。模型配置中的 Mamba adapter 为 false，本人工 preflight 不能宣称验证了 Mamba CUDA 路径。

依次在 CPU 构造 LS、LSQ；每次构造前 Python/NumPy/torch CPU seed=0，保留 SCQR 模块自身 initialization_seed=31001、alpha_local/query_init=0.01。每模型只构造一次，不改权重/alpha/beta/warmup。完成初始化后 `.float().eval().to(cuda:0)`，两模型都保持驻留直到全部比较结束；不存在运行中 reload、替换 buffers 或重初始化。参数/buffer 初始化写入不计为训练更新；从初次构造完成的 baseline 起更新数必须为 0。返回 coarse/dense 必须分别为 `[1,256,3]`/`[1,8192,3]`、FP32 finite。不得打开 full_instrumentation；仅使用现有 RSD 的 per-forward 标量字典。

### 2.3 独立残差出口输入

两组已知人工残差幅度 r=0.0 与 r=0.25；每组 q=ones `[1,2,384]`、residual=full_like(q,r)、conditioned.queries=q+residual、attention=`[[[1,0],[0.5,0.5]]]`、alpha_q=`[0.01]`、warmup=1.0，全部 FP32 CUDA。同一组执行 native plain→native traced→off traced→native restored traced，共四次 `select_rsd_queries`；两组合计八次，不调用完整模型。

原生返回现有 conditioned tensor，off 返回 q 的同一对象；r=0 时相等，r=0.25 时 native−off 每元素严格等于 0.25。全模型 off 的 dense 不要求非零差异；人工已知残差的出口差异不能冒充网络机制结论。

## ⚙️ 3. 数值策略、RNG 与精确调用表

### 3.1 严格数值策略

在 torch/CUDA 相关导入前设置 CUBLAS_WORKSPACE_CONFIG=:4096:8、OMP_NUM_THREADS=1、MKL_NUM_THREADS=1；torch CPU intra/inter-op threads=1。`deterministic_algorithms=true, warn_only=false`、cuDNN deterministic=true、benchmark=false、matmul/cuDNN allow_tf32=false、float32_matmul_precision=highest。无 AMP/BF16/FP16、compile、量化、autotune、降精度/fallback、训练、BNCal、loss/backward 或 timing benchmark。启动/每次 forward 前/结束保存并断言实值。必须保留 eval 状态，使用 torch.no_grad；不强行要求 model.parameters.requires_grad=false 来改变模型。

### 3.2 RNG 比较合同

两模型完成 CUDA 搬运后，将 Python/NumPy/torch CPU/CUDA seed=0，并快照四类 RNG。每次完整 forward 前恢复同一 pre-forward 快照；同时记录各次 after RNG hash。同候选的所有 native after RNG 状态必须相同，LSQ off 与 native after RNG 状态也应一致（计算原 conditioner，只旁路输出）；不以重新 seed 替代快照、不要求不同模型的 after RNG 一样。比较试验的重复快照不是历史 native 跨 case 推进的复现；未来真实 evaluator 的 candidate-isolated progression 保持原合同，不受本协议改写。

### 3.3 唯一顺序与预算

两模型同时驻留后，先八次独立出口调用，再按下表执行八次完整 forward；epoch 全部为 None，warmup 按继承实现为 1.0。任何额外“热身”“检查 forward”“建图试跑”均禁止。

| 序号 | 模型 | rsd_condition | diagnostics |
|---:|---|---|---|
| 1 | LS | 不传，legacy default | 不传 |
| 2 | LS | LS_native | 新空字典 |
| 3 | LSQ | 不传，legacy default | 不传 |
| 4 | LSQ | LSQ_native | None |
| 5 | LSQ | LSQ_native | 新空字典 |
| 6 | LSQ | LSQ_query_off | 新空字典 |
| 7 | LSQ | LSQ_native | 新空字典 |
| 8 | LSQ | LSQ_native | 新空字典 |

成功精确计数：完整模型构造=2、完整 forward 尝试/完成=8/8（LS=2、LSQ=6）、独立出口调用=8、LSQ conditioner full-forward hook 调用=6、有诊断字典的 LSQ query_outlet_calls 合计=4。LS query conditioner 调用=0；LS 标量明确 null/not_applicable。模块计数只用观察性 forward hook，不修改返回值，不做全局 monkey-patch；finally 移除本次 hooks。成功 counter 必须核实真实调用，不靠预填数字。

real payload/checkpoint bytes read/反序列化/保存、optimizer 构造/step、loss/backward、训练/BNCal forward、参数/buffer 更新、真实评估、正式 timing、bootstrap/gate 全部=0。失败时实际计数可以小于成功目标，但任何尝试都占预算，不补跑、不删失败记录、不继续下一个条件。

## 🔍 4. 验收、状态不变与解释限制

### 4.1 张量与标量判据

完整 tensor 比较使用同设备、同 dtype/shape 的 `torch.equal`，不设置近似容差，不 sorting、不匹配重排、不改变输出点顺序。LS #1=#2 coarse/dense；LSQ #3=#4=#5=#7=#8 coarse/dense；LSQ #6 coarse=#5 coarse。最后一项是 Query 出口位于 coarse 选择之后的工程负对照，不验证真实接触安全性。不得要求 LS=LSQ，也不要求 off dense≠native dense。报告每项 exact equality 与 max_abs_difference（审计数值，不用于放宽门槛）。

完整 LSQ #5/#7/#8 的九个 finite 诊断标量必须逐字段精确相同，query_applicable=true/outlet_calls=1。#6 的 potential residual/query/attention/alpha/warmup 与 #5 相同，applied_residual_rms=0；native applied=potential。LS #2 返回 not_applicable，不拿零冒充测量。

独立出口的 query RMS=1、residual RMS=r、relative=r、effective count=1.5、max attention weight mean=0.75、alpha=0.01 的 FP32 预期值按相应表示比较；warmup=1。熵期望自然对数 log(2)/2，单次理论标量允许绝对误差 1e−6、rtol=0；attention 行和沿用现有 atol=1e−6。其余重复执行/trace/restored 的标量仍要求 exact equality。这个熵测试容差只是人工算术测试，绝不是 native CSV 的 14 字段再现容差；不创建或确认真实诊断 tolerance appendix。

### 4.2 状态基线与资源判据

复用现有 length-delimited/little-endian canonical_tensor_hash，参数、buffers 分开 hash；在构造结束、全部出口调用结束、每次 full forward 前后、结束分别核验，保留 state_dict keys/dtypes/shapes。不用 torch.save hash，不 reload 后宣称恢复；BN counters/buffers 不更新，所有模块 training=false，input hash 不变。临时 Python 诊断/观测缓存不计为参数/buffer，但不得挂成持久 buffer/state key。

CUDA 每调用结束 synchronize，以显式暴露异步失败，不做性能计时。重置一次 peak memory stats，在两模型同时驻留及所有比较 tensor 保持到所需比较完成的实际路径下记录峰值 allocated/reserved 和 nvidia-smi；两峰值分别≤20000 MiB。不得通过轮流卸载模型、改变 shape、清空必要证据或减少 forward 绕过 OOM。只证明固定人工配置能运行，不证明未来完整 fold 最坏显存或训练容量。

### 4.3 不能据此声称

PASS 仅表示此次 hash/资源下，一人工输入与初始化权重的有限工程合同通过；不证明全部 CUDA 输入等价、训练/BNCal 历史数值一致、旧父模型真实 CUDA 数值不变、真实 CSV 再现、Query 为灾难唯一因果根源、Mamba 性能或临床安全。没有旧父模型 CUDA 对照；父默认 AST 等价仍仅是 CPU 源码证据。

正式 gate 继续为 NOT_ADJUDICATED_HISTORICAL_NUMERICAL_EVIDENCE_GAP，classification=null，历史缺口与不自动晋级限制不变。

## 🔐 5. 环境、依赖与目前阻断项

观测绑定 hostname=`shu-common-25721452-notebook-2b2doi-0`、jovyan、项目 `/home/jovyan/adapointr_work/PoinTr`、GPU UUID=`GPU-3fea2502-c54e-30e1-ae67-8696c29238d2`、RTX 4090 D 24564 MiB、driver=570.190。Python=3.10.20；torch 安装元数据=2.4.1+cu118、numpy=2.2.6、scipy=1.15.3、PyYAML=6.0.3、timm=1.0.27、mamba-ssm=2.3.1、causal-conv1d=1.6.2.post1。元数据不冒充 torch/CUDA/cuDNN runtime 实测。

执行前 GPU无其他 compute PID、utilization=0、free≥22000 MiB；磁盘 free≥2 GiB；walltime 上限600秒。资源变化先版本化 rebind，不临时借用旧授权。所有 Windows 路径只作本机文档，不用于服务器命令。

缺少的必要条件：专用 preflight 执行器/守卫/CPU 回归测试、其 post-implementation P3、最终工具和依赖源/二进制闭包清单（含必要 CUDA 扩展）、冻结的 CUDA/cuDNN runtime 版本及 artificial input identity 合同实现。不得凭 CPU P3 新增 GPU 脚本，或在执行授权后临时即兴写未绑定工具。需要用户单独 implementation-only 授权；完成后新建 v2 request，绑定最终 hash，新 run ID/路径，重新单独授权。v1 不原地补 hash 或升级为 READY；即便用户现在授权 v1 hash，也不能执行。

## 💾 6. 未来执行路径、产物和失败冻结

v1 request 预留 `r1b_synthetic_gpu_pf_v1_20261011` run ID 和 `r1b-synthetic-gpu-pf-v1-20261011` tmux 名，所有路径在 server root 内，尚不存在且本次不创建。新 v2 将使用全新路径，v1 预留路径不可执行。

未来通过绑定与独立执行授权后按单向链：授权回执→其 SHA256→runtime JSON→单次 launcher。回执不得反向绑定 runtime hash。先创建并验证 runtime/log 父目录再写文件或重定向；PowerShell 显式 exit $LASTEXITCODE；输出目录 exclusive，不覆盖。tmux 启动一次，记录PID/退出码/日志，任何启动失败都消耗本次尝试，不自动重试。

未来只保存 scalar/equality/counter、参数/buffer/RNG/input hash、数值设置、环境/依赖清单、峰值显存、runtime/授权/日志/退出码和 files.sha256；不保存 prediction coordinates、完整 features/attention、NPZ、checkpoint。产物≤16 MiB、日志≤32 MiB，上限错误则停止而非截断。PASS receipt 的目标状态 `PASS_SYNTHETIC_R1B_ZERO_UPDATE`；它还必须明确 synthetic_only=true、真实访问/更新=0、success counters exact、implementation_sha256 与新 request 的原 R1-B implementation map一致，另列 preflight tool bindings，不混为同一map。

任一 hash/身份/版本/数值断言/finite/equality/state/count/权限错误、OOM、严格确定性 kernel 不支持、预算超限或输出已存在：立即停止、非零退出、保留失败及部分证据，不改断言、不 fallback、不重试/resume，不进入训练、BNCal、development、下一 fold、统计或 gate。超时只终止经 PID/启动指纹确认属于本次的进程，不宽泛 pkill；客户端超时先只读检查，不能当作许可再次启动。工具执行完成不代替另行授权的正式只读 post-preflight freeze audit。

## 📍 7. 版本流与当前停止点

```mermaid
flowchart TB
    accTitle: Synthetic Preflight Authorization Boundaries
    accDescr: The current protocol and blocked request require a separately authorized implementation and a new hash-bound execution request before any GPU work.
    current_plan["📋 协议与阻断 v1 request"] --> implementation_gate["🔒 单独 implementation-only 授权"]
    implementation_gate --> cpu_p3["🔧 专用工具 CPU 测试与 P3"]
    cpu_p3 --> new_request["📝 新 v2 冻结 request"]
    new_request --> execution_gate["🔐 单独完整 SHA256 执行授权"]
    execution_gate --> synthetic_run["🧪 唯一人工 GPU preflight"]
    synthetic_run --> readonly_audit["🔒 单独只读 freeze audit"]
```

本次只完成文档及只读来源记录，未新增代码、运行 CPU tests/GPU preflight、创建授权回执/runtime/launcher/tmux；服务器没有写入，待授权 v1 request 仅保存本机规范管理目录，不是假称已上传服务器。需要本机文件运输时由用户上传，核验准确名称/bytes/hash；不能假定 E: 与服务器同步。没有归档下载认证、删除、安装依赖、Git commit/tag/push 权限。

下一步建议仅单独授权按本协议实施人工 preflight 专用工具与人工 CPU tests/P3；不运行 GPU、不接触真实 payload/checkpoint、不调整旧 R1-B 实现，完成后再创建绑定最终实现的 v2 request。

## 🔗 8. 来源与文档校验

父 R1-B 协议、当前 P3 的本机派生记录、服务器只读观测与已存在代码是本文件依据；未引入外部事实、文献或性能主张。采用 markdown-mermaid-writing 决策记录结构，将“计划/待授权/缺少实现/已执行”分开；Mermaid 仅作授权依赖展示，没有外部渲染或第三方上传。文件绑定采用 protocol→observation、request→protocol/observation/P3，manifest 不包含自身，避免循环。

[R1-B 已确认设计源](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_query_off_protocol_draft_v1_zh.md)；[本机安装核验](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_installation_verification_local_v1.json)；[远程操作规范](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/references/server_operations/remote_codex_experiment_operations_guide.md)。JSON request 是固定数值/路径/权限的机器可读配套，不是 runtime，也不是实际执行授权。
