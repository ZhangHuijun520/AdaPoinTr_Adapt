# R1-B 已准备副本的单次启动接口收尾方案 v1 草案

_2026-10-16，Asia/Shanghai；状态：DRAFT_AWAITING_USER_REVIEW。仅设计，不实施、不重新复制、不运行测试。_

---

## 📋 决策摘要与现有证据

本方案只关闭 `LAUNCH-01`：已准备的 Linux 副本不能再走“先准备再执行”的 Windows 入口，直接调用 Linux 内部工作入口又缺少外层预算、授权消费、证据导出和失败回执。它是阶段拆分后的接口交接缺口，不是已经发生的测试失败，更不是科研算法失败。[只读启动审查报告](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_launch_transport_v2_prepared_copy_readiness_launch_review_v1_20261016.json) SHA256：`0a028703062928776943c0bd3e200538d4b1a5a9aeb69d6d29c9c065900e8182`。

拟采用的决策是：**仅在现有 Windows driver 中增加使用已准备副本的专用入口**，复用既有监督、预算和回执逻辑；Linux 四文件和准备元数据不改、不重新复制。新入口必须有自己的人工契约验证，不能把旧的 24 项 Linux 测试当成新 Windows 入口已经被验证。

确认本草案不等于授权实施，也不等于授权测试或创建 execution request。本文没有启动命令、可执行 launcher 或实际授权回执。

### 不重新判定的历史事实

[准备核验回执](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_launch_transport_v2_linux_copy_prepared_receipt_v1_20261016.json) SHA256：`482d358f0a2877c4e2e8eae1119cb857b7b14ba62b6c88d9b1ab3fc64fa4a2b8`。已准备路径为 `/home/zhj/.local/share/r1b_transport_v2_once_20261016`；准备元数据 SHA256 为 `0be7f51d55c15a0a69c171eac0ffbace0826adf1d7003e07874627b14948a663`。

上次只读核验确认四文件一致、目录权限 `0700`、文件权限 `0600`、UID 1000，`fixtures` 为空、`evidence` 不存在。本文只引用这些历史观察，不调用 WSL 重新确认当前状态。未来实际分派前仍须精确核验，历史审查不能代替启动前检查。

## 🔍 选项与取舍

| 选项 | 是否保留副本 | 主要代价 | 本草案决定 |
| --- | --- | --- | --- |
| 再调用 `--prepare-run` | 不能安全使用 | 已存在目录触发拒绝 | 不采用 |
| 直接运行 `--linux-batch` | 保留 | 缺完整外层合同 | 不采用 |
| 更新四文件并重新准备 | 需新副本与新绑定 | 增加本轮工作范围 | 暂不采用 |
| 现有 driver 增加已准备入口 | 保留 | 必须区分两端版本 | 拟采用 |

最后一个选项不是“Windows 与 Linux 源码继续完全相同”的方案。它明确引入角色化版本绑定，只有用户确认本草案并另行授权实施后才可生效；不允许静默豁免哈希差异。

## 📦 冻结对象与唯一实施文件

### Linux 输入保持原样

以下四份文件位于 `/home/zhj/.local/share/r1b_transport_v2_once_20261016/source/`，未来请求逐份绑定大小和完整 SHA256：

| 文件 | bytes | SHA256 |
| --- | ---: | --- |
| `transport_adapter_v2.py` | 32977 | `895112427394280c9dce312d69ac571a89fe97cd76da26f73ecfd48760789bc6` |
| `transport_entry_v2.ps1` | 1002 | `e8405762162cf1d713aee9ec330952282c69617188ebb66295a5a237ac8ab483` |
| `transport_contract_tests_v2.py` | 23601 | `1c4ae27a01d2211d9c59d0025e1be709bd6333c5fa6083561ab5149ef4817580` |
| `transport_cpu_once_driver_v2.py` | 17128 | `f87bc2fb6b5cb451a409fb0376fae111eb564274186feb8619d75bfafc773d98` |

Linux 的 `preparation.json` 保留 `PREPARED_NOT_EXECUTED` 和 `tests_authorized=false`，作为历史准备记录，不将其改写为执行授权。未来是否已执行，以单次消费记录和执行证据判断，不拿这个历史状态覆盖真实运行状态。

### 仅一个 Windows 文件拟允许修改

唯一实施文件为 [transport_cpu_once_driver_v2.py](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/local_tools/r1b_launch_transport_v2_20261016/transport_cpu_once_driver_v2.py)。当前基线为上表中的 `f87bc2fb…773d98`；实施后的完整哈希必须重新冻结，现在未知，不预填。

该文件拟新增 `--run-prepared` 专用分派及其有限人工契约检查，必要时将现有预算、子进程调用、导出、最终回执代码抽取为同文件共享函数。旧入口保持原语义，不自动改道、不删除排他准备守卫。新入口不得调用准备函数。

其余三份 Windows 文件、全部 Linux 文件及准备元数据保持不变。仍只有原四个实现文件，不新增第五实现文件、不新增框架、不把实现逻辑藏进 execution request 或单次 launcher。后续 launcher 只能是审核过的固定 argv 调用，不承载第二套调度逻辑。

未来 execution request 必须分别列出：

- `windows_orchestrator_sha256`：实施后 Windows driver 的新哈希
- `linux_prepared_sources`：上表四份已准备文件的原哈希
- 准备回执、元数据、启动就绪审查及新增入口验证报告的哈希
- 仍供 case 12 使用的未修改 Windows PowerShell 入口哈希

Windows 新 driver 与 Linux 旧 driver 的差异只能由上述精确角色声明接受，不能接受任意“Windows 端不同也没关系”。Linux case 18 导入的是原 Linux driver，其通过只能支持原 Linux 工具合同，不能支持新增 Windows 入口。

## 🔐 已准备入口的单次授权与调用合同

### 输入与权威边界

拟新增的入口仅接受冻结的 request 文件、外部给定的完整 request SHA256、独立执行授权回执及单向绑定的 runtime 描述；不接受自由 Linux 根目录、自由命令、任意脚本正文或替代测试列表。缺少字段、哈希不符、未知 schema 或未授权时，在任何 WSL 调用前拒绝。

request 本身仍可保留 `AWAITING_EXPLICIT_USER_AUTHORIZATION`，独立执行授权回执记录其后的人类单独授权；不能因为 JSON 含 `authorized=true` 就声称获得授权。信任边界仍是本机受控工作流和真实用户授权，不声称普通 JSON 回执具有密码学签名证明。

无环顺序为：最终实现冻结 → 待授权 request → 用户明确授权该 request 完整 SHA256 → 授权回执 → 计算回执 SHA256 → runtime 单向绑定回执 → 固定 argv launcher。授权回执不反向绑定 runtime 哈希。本文只描述顺序，不生成其中任何执行对象。

### 一次调用的固定顺序

1. 外层单调时钟开始，验证本机冻结实现、request 完整哈希、独立授权回执、runtime 绑定及精确路径；任何失败不调用 WSL。
2. 排他创建全新 Windows 证据目录及单次消费记录，在第一个 WSL 调用前持久化。目录或记录已存在即拒绝，不覆盖、不借用；消耗后即使只读核验失败，也不得复用该 request。
3. 以一次有界 WSL 只读调用核验已准备根目录及祖先无链接、拥有者/权限、四文件及元数据完整哈希、24 项名称、空 `fixtures`、`evidence` 不存在。只查看声明路径，不递归扫描环境或旧目录。
4. 通过后，记录唯一批次分派意图，以固定 argv 调用原 Linux driver 的内部 `--linux-batch`，传入由同一外层 deadline 推导的剩余预算。这是受控外层调用，不是人工绕过外层直接执行工作入口。
5. 批次正常返回时，按固定五文件集合导出证据。若有非零退出但完整失败证据已经形成，也只导出已有证据；不得重新执行、补跑 case 或生成替代结果。
6. 外层始终尝试冻结真实已知退出码、首个错误、当前阶段、消费/分派状态、收集状态、部分输出及最终耗时。缺少结束证明保持 `UNKNOWN`。冻结失败只尝试结构化输出回退，不改用其他目录或执行通道。

```mermaid
flowchart TB
    accTitle: Prepared Copy Single Launch
    accDescr: A separately authorized Windows entry consumes one attempt, verifies the immutable Linux copy, dispatches one batch and preserves the outer evidence chain without preparing the copy again.
    explicit_authority["校验独立执行授权"] --> consume_once["排他消费一次请求"]
    consume_once --> verify_copy{"已准备副本匹配？"}
    verify_copy -->|是| dispatch_batch["分派唯一 Linux 批次"]
    verify_copy -->|否| freeze_outcome["冻结失败或结束证据"]
    dispatch_batch --> collect_evidence["有界导出已有证据"]
    collect_evidence --> freeze_outcome
    freeze_outcome --> stop_once(["停止并等待独立审计"])
```

未获得执行授权时，不创建 Windows 运行目录、消费文件、runtime 或 launcher。无效输入最多产生结构化标准输出错误；不为其偷偷创建运行材料。

## ⏱️ 总预算、路径与失败封闭

### 不增加现有测试预算

| 项目 | 拟保持上限或规则 |
| --- | --- |
| 一次正式离线批次的 Windows 总墙钟 | 180 s，含当前启动核验、批次、导出及冻结 |
| 已准备副本的 WSL 只读核验 | ≤15 s，且受总余量限制 |
| 既定 24 项 Linux case | 普通每项≤5 s；case 12≤20 s |
| 既定 case 理论总和 | 135 s，不增加名称或隐藏批次 |
| 导出预留 | 10 s |
| 最终冻结预留 | 5 s |
| 直接 dispatcher 收尾预留 | 3 s |

每一步都使用同一个外层 deadline 的剩余时间，批次分派前预留 `10+5+3=18 s`，Linux 内部仍保留其冻结余量。不得复用旧副本准备阶段的历史耗时作为新启动的总时钟，也不得把180秒重新按阶段各算一遍。

预算设计可容纳135秒 case上限、15秒前置核验和18秒预留，但不保证机器负载下必定成功；局部余量不足即在下一次分派前停止。同步文件系统调用、fsync及进程创建不是硬实时可中断操作，报告如实记录实际耗时和超限，不能宣称绝对180秒内完成所有内核动作。

### 精确读写范围

拟使用全新 Windows 运行证据目录：

`E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_launch_transport_v2_prepared_once_v1_20261016`

该名称只是草案候选，本文未创建。创建待授权 request 时须再次只读确认不存在并冻结；存在即停，不能自动增加编号另选目标。

Linux 输入只读范围为已准备根、四文件、准备元数据和其精确祖先检查。未来获授权运行后，Linux 写入仅限同一根目录下原测试定义的 `fixtures` 内容及 `evidence`；不得修改 `source` 或 `preparation.json`，不得清理旧残留。这里指本机 WSL，不是自强5000服务器。

固定导出集合保持 `attempt.json`、`events.jsonl`、`partial_output.bin`、`result.json`、`files.sha256`。保留已有输出/部分输出/报告上限，按类型与大小校验后有界读取；缺少文件即记录证据不完整，不合成一份“成功结果”。Windows 自身消费记录与 Linux 导出的 `attempt.json` 必须区分文件名，不能互相覆盖。所有运行证据文件名在未来 request 中完整冻结。

### 失败时不进入下一项测试

核验失败不分派批次；首个实际 case 失败后沿用原 Linux fail-fast。正常返回的失败批次可以导出证据，但不能将导出成功当作测试通过。

外层超时只允许对本次直接 Windows dispatcher 做既定的有界终止/等待；不能按进程名杀进程，不能发起第二条 Linux 清理命令。WSL dispatcher 已退出不等于 Linux 或 Windows 互操作后代已结束；Linux 工作完成、进程组信号提交、leader 回收、Windows 后代状态分别记录，无法证明的项保持 `UNKNOWN`。超时后不再为补收证据发起新 WSL 调用。

## 🔧 拟实施范围与十项人工入口验证

若后续明确授权 implementation-only，最多修改上述现有 driver 一文件，并在同文件中提供独立的人工入口合同检查模式。人工检查仅用内存 fake clock、fake I/O、fake dispatcher 与事件记录，不创建 Linux 副本、不调用 WSL/PowerShell/hpc5000、不读取真实依赖、不执行真实24项测试。不得通过动态执行任意传入源码来替代接口测试。

十项检查的拟冻结名称和断言范围如下；同一项中的负例是有限枚举，不是自动修复或执行重试：

| 编号／拟定名称 | 必须观察到的合同 |
| --- | --- |
| PC01 `authority_missing_or_hash_mismatch` | 缺授权、错 request SHA 或错回执绑定时，WSL/消费记录调用数为0 |
| PC02 `role_specific_source_binding` | 接受唯一声明的新 Windows/旧 Linux 角色绑定；任意端漂移拒绝 |
| PC03 `prepared_state_is_not_authority` | 历史 `tests_authorized=false` 不作执行授权；独立授权齐全时无需改写准备元数据 |
| PC04 `consume_before_verify` | 消费持久化先于第一个 WSL只读核验；写入失败不调用 WSL |
| PC05 `existing_attempt_refused` | 已有消费目录或记录时拒绝，无覆盖、换路径或第二次分派 |
| PC06 `prepared_verification_failure` | 四文件/元数据漂移、非空fixtures、已有evidence三类有限失败均不分派批次 |
| PC07 `remaining_budget_and_reserve` | fake clock验证180秒总预算、18秒预留及余量不足时不分派 |
| PC08 `single_dispatch_no_preparation` | 成功人工链恰有一批次分派、零准备/复制调用，并保持固定 argv |
| PC09 `timeout_partial_exit_unknown` | 人工超时保留已知退出码/部分输出；Linux完成为UNKNOWN；无重试、无超时后WSL补收 |
| PC10 `export_and_final_receipt` | 成功、失败批次、缺失导出文件、冻结写盘异常四种有限场景保持首错与证据状态分离 |

若获测试授权，上述十项仅执行一个版本化人工检查批次：总墙钟≤30 s，每项≤2 s，其余用于记录；首个非预期失败即停止，不自动改代码重跑。它们是新增 Windows 入口的人工验证，不计入原24项，也不代替原24项、正式post-test审计或完整P3。

默认入口不能触发这些检查或实际批次。检查模式不接受真实request作为执行材料，也不能把检查中构造的人工授权回执用于真实入口。

## 🎯 完成标准、止损与后续授权

### 一次收尾的交付门

1. 静态门：仅driver一文件发生预期改动；原其余三文件和Linux四文件不变；新增入口没有准备/复制调用，旧入口语义不变；默认入口不执行，参数解析和角色哈希绑定明确。
2. 人工门：仅在获明确测试授权后，一次上述十项内存人工合同检查通过，记录最终Windows实现哈希、计数、耗时及未执行项；失败即停。
3. 请求门：完成上述静态与人工证据汇总后，另行授权才能创建绑定两端精确哈希的单次24项execution request，状态保持 `AWAITING_EXPLICIT_USER_AUTHORIZATION`；不能在实现过程中顺手创建。
4. 执行门：用户再次明确授权该request完整SHA256后，才能按单向顺序生成执行回执、runtime和固定launcher，启动一次批次。
5. 结果门：批次结束后，正式只读post-test freeze audit与完整P3仍需各自授权，不自动部署、真实库存审计、G3或GPU。

本方案不要求为这一个接口另建环境库存工具、另做身份重绑定、重写监督器或展开整仓库审计。若确实发现必须修改Linux工作副本、第二个实现文件或增加第五实现文件，视为本方案范围冲突：停止并说明，不能现场扩大、重复制或绕道执行。

拟定工作量止损为：一次限定实现、一次静态审查、一个十项人工批次。实际发现合同不闭合时保留失败证据；不允许靠增加审计数量、隐藏测试分支或更改24项列表声称完成。

### 待用户审核的关键决定

- 是否接受只修改Windows现有driver、保留Linux已准备四文件不变的角色化版本绑定
- 是否接受同文件十项内存人工检查作为新增入口验证，仍将原24项Linux测试留待独立执行授权
- 是否接受失败即停、无自动重复制、无自动清理、无自动创建或执行request的门控顺序

建议下一条授权仅覆盖：按本草案限定修改现有Windows driver、完成静态审查及一次十项人工入口合同检查；不得调用WSL、重新复制或执行原24项。该文字只是待审核授权范围建议，本次没有获得或使用这项新授权。

## 🔗 本次实际动作与交付边界

本次只新增本文及SHA256清单，使用文档写作技能的决策记录结构、版本对照表和小型门控流程图明确交接。仅在Windows本机读取既有审查报告、准备回执、现有driver和文档规范，并核验文档及来源哈希。

源码修改、Linux文件写入、WSL调用、服务器调用、复制、测试、request创建、授权回执/runtime/launcher材料化、部署、库存审计、G3、GPU及清理均为0。本文中的哈希和目录状态来自已冻结材料，不构成新一轮副本就绪通过证明，也不解除 `LAUNCH-01`。
