# Cranial-SCQR v1.2-QA：R1-B Fold C 冻结科研结果解读与 Fold D 决策建议

日期：2026-10-19。版本：v1。性质：冻结结果的描述性解读，不是新的统计执行、正式 gate 或临床安全认证。

## 🎯 结论与建议

**建议继续既定的一次 Fold D 同进程配对诊断，但不调整参数、不重训、不重复 Fold C。**

Fold C 已完成 105 病例、315 次 forward，正式只读冻结审计通过。当前结果表明：在这个已训练 LSQ checkpoint、当前数值环境与固定 Fold C 样本下，关闭 Query 残差加法产生的几何指标变化幅度较小、方向混合，且没有消除唯一的 LSQ disaster 病例。它不支持“当前 Query 残差加法解释了 LSQ 相对 LS 的全部差异”，也不支持“Query 完全无用”或“Query-off 已修复风险”。

Fold D 的价值是完成原定跨折诊断，尤其核查其历史上的三个 LSQ 独有风险病例，而非寻找一个更好看的折。当前工具有 Fold C 专用守卫，**不能直接作为 Fold D 入口使用**；下一步应先单独授权最小 Fold D 适配范围。本报告未实施适配、创建 request 或启动 Fold D。

## 📋 证据与执行有效性

依据：

- [Fold C 冻结 execution request](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_same_process_foldC_seed0_execution_request_v1_20261019.json)，SHA256：`4e36c6bfaecce3c9ae15c412f6079d8e9d9f0635f1de8df8c13c2493e121b0ca`。
- [正式 post-intervention freeze audit](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_same_process_foldC_formal_post_intervention_freeze_audit_v1_20261019.json)，SHA256：`ab57f970c6c70eb5a509ce742bd251d07c62238507443f40b2a017aca17fc813`；状态为 `PASS_FORMAL_READONLY_FREEZE_AUDIT_CURRENT_PAIRED_DIAGNOSTIC_ONLY`。
- [本次只读标量提取证据](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_foldC_scientific_interpretation_evidence_v1_20261019.json)：包含冻结描述汇总摘录、条件均值、病例配对范围、Query 标量及预先固定病例。它是可追溯提取记录，不是服务器原始 CSV 的字节副本。

本次成功运行位于服务器：

`/home/jovyan/adapointr_work/PoinTr/logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldC_seed0_v1_20261019`。

执行记录：退出码 0；21 个 source，每个 5 类缺损，共 105 病例；LS native、LSQ native、同一 LSQ 的 query-off 各一次，共 315 次 forward。checkpoint 加载 2 次、哈希检查 4 次；优化器步骤、权重更新及 BNCal 均为 0。两模型参数与 buffers 保持不变，105 对 native/off 的 RNG 前后证据相等。

推理采用冻结的确定性／TF32 关闭设置，FP32、eval/no_grad、线程数 1；warmup 为 1。记录的 peak reserved 显存为 859,832,320 bytes（820 MiB），不是独立记录的 peak allocated。完整冻结覆盖 15 个控制与结果文件；结果目录 9 文件，共 561,053 bytes。

**本实验的干预对象是固定已训练 LSQ 模型中的 Query 残差加法。** Off 保留该分支的计算与诊断，但将实际加入的残差置零。它不等同于重新训练一个没有 Query 的模型，也不等同于 LS checkpoint。

## 📊 总体几何结果：即时残差效应幅度较小，方向并不一致

下表全部距离单位为 mm；均值先按 source 内 5 类缺损平均，再对 21 个 source 等权平均。由于每个 source 病例数相同，其数值也等于病例均值，但 105 个病例不能据此视为 105 个独立 source。

差值固定为 **LSQ off − LSQ native**；负值表示 off 的该距离更低。显示值经过四舍五入，完整精度保存在提取证据。

| 指标 | LS native | LSQ native | LSQ off | off−native |
| --- | ---: | ---: | ---: | ---: |
| Implant CD-L1 | 2.558343513 | 2.226912031 | 2.226926790 | +0.000014758 |
| Implant HD95 | 6.653524079 | 5.650103684 | 5.650123302 | +0.000019617 |
| Final CD-L1 | 2.225522209 | 2.201136406 | 2.201133884 | −0.000002522 |
| Final HD95 | 4.738093664 | 4.633511302 | 4.633502945 | −0.000008357 |
| RimCover-P95 | 7.047021217 | 6.486223497 | 6.486179704 | −0.000043794 |
| Rim contact CD-L1 | 4.048929591 | 3.300956147 | 3.301468092 | +0.000511945 |
| Rim contact HD95 | 16.746165867 | 14.082942200 | 14.085394141 | +0.002451941 |

可以作出的描述性判断：

1. 关闭残差后，RimCover-P95 均值下降约 0.000044 mm，但 Implant CD-L1、Implant HD95 及 contact 距离均值反而上升。不能只选 RimCover 的负号称为一致改善。
2. LSQ off 保留了当前 LSQ 相对 LS 的大部分均值差距。LS 与 LSQ 是不同训练产物，故该差距不能被归因于“当前一次残差加法”，也不能反向证明它全部来自某个训练阶段或其他单一模块。
3. 这里只报告观察幅度；没有预设等效性界限、置信区间或临床可接受阈值，因此不作“统计等效”“临床可忽略”“显著有效／无效”的判断。

病例级结果并非所有变化都等于均值：

| 配对指标 | 最小差值 | 中位差值 | 最大差值 |
| --- | ---: | ---: | ---: |
| Implant CD-L1 | −0.000154929 | +0.000006653 | +0.000688337 |
| Implant HD95 | −0.002292721 | −0.000003282 | +0.003468640 |
| RimCover-P95 | −0.005132676 | +0.000107264 | +0.002352972 |
| Rim contact CD-L1 | −0.015856123 | 0 | +0.025671445 |
| Rim contact HD95 | −0.024905826 | 0 | +0.138765249 |

RimCover 的均值为负而中位数为正，说明方向混合；contact HD95 的最大正差也远高于其平均正差。不能以均值接近零替代尾部检查。

按缺损类型，RimCover-P95 的 off−native 均值依次为：bilateral −0.000134467、frontoorbital −0.000169426、parietotemporal −0.000001574、random_1 −0.000241142、random_2 +0.000327641 mm。这是固定五类的完整描述，不据此追加子组筛选或参数搜索。

## 🛡️ 风险事件：没有被 query-off 即时解除

沿用冻结的 disaster／zero-contact 定义，不更改阈值：

| 条件 | disaster 数／105 | zero-contact 数／105 | disaster 病例 |
| --- | ---: | ---: | --- |
| LS native | 3 | 0 | 025/bilateral；051/frontoorbital；072/random_2 |
| LSQ native | 1 | 0 | 025/random_2 |
| LSQ off | 1 | 0 | 025/random_2 |

LSQ native/off 的配对转换为：104 例均非 disaster、1 例均为 disaster、native-only 0、off-only 0。**Off 在本折没有新增或解除 disaster，但这不是总体安全性证明。** LS 的 3 例与 LSQ 的 1 例也不是简单的“同一风险集合减少两例”：LSQ 仍存在 LS 未触发的 025/random_2。

预先固定的重点病例 `train__025__random_2`：

| 指标 | LS native | LSQ native | LSQ off |
| --- | ---: | ---: | ---: |
| RimCover-P95（mm） | 14.619330 | 12.882498 | 12.883392 |
| Rim contact HD95（mm） | 46.997949 | 53.447213 | 53.447213 |
| 预测 rim 点数 | 120 | 38 | 38 |
| 参考 rim 点数 | 202 | 202 | 202 |
| disaster | 0 | 1 | 1 |

该病例说明覆盖距离改善与接触风险改善并不必然同步；关闭当前残差后，风险标志、rim 点数及 contact HD95 没有变化。它支持“这一即时加法旁路没有救回该病例”，但不能仅凭标量判断几何断裂位置、组织穿透或唯一机制；本次未读取／生成预测坐标。

另两个预先固定展示病例 051/random_2、081/random_2 在三个条件下均未触发 disaster；其 LSQ native/off contact HD95 分别同为 21.523464、9.101818 mm。完整九行展示记录已保存，未重新选择有利病例。

## 🔬 Query 诊断：非零、已完成 warmup，但注入幅度较小

所有 105 例均观察到：

- `alpha_q = 0.00011100097617600113`，`query_warmup = 1`。
- Native 的实际残差 RMS 均值为 0.00011115755762494656；off 的实际残差 RMS 精确为 0。
- 两条件的潜在残差、Query 与 attention 描述值相同，符合“只旁路加法”的干预含义。
- 相对潜在残差 RMS 的均值为 0.00143071065，即约 0.1431%；范围约 0.0857%–0.2350%。这是**特征空间 RMS 比例**，不是几何误差比例、安全阈值或解释方差。

因此不能将本次低响应简单解释为“warmup 没开”或“分支根本没产生残差”。较小的特征注入幅度与较小的几何响应相容，但尚未证明二者之间的定量因果关系，也没有授权将 alpha 放大进行敏感性扫描。

Attention entropy 均值约 5.543918、effective proxy count 均值约 255.677810、maximum-weight mean 均值约 0.00442587。这里只作为分支状态记录；没有据此证明注意力具有空间针对性，也不将熵指标直接当作科研有效性证据。

## 🔎 历史一致性与推论边界

本次同进程配对回答的是“当前固定条件下，关闭残差加法怎样改变输出”，并未使旧的历史精确重放要求自动通过。

历史比较中 210/210 个 native 行存在连续数值差异；68 个事件或计数字段差异均来自点数，不是 68 个 disaster，二值 disaster／zero-contact 差异为 0。原先因零容差历史重放失败的 request 仍已消耗，不得因本次成功改写为通过。

当前配对协议是历史失败后经单独确认的探索性补充，不应写成原预注册历史重放成功。历史运行与当前条件并非完全可追溯一致，仍不能断言唯一漂移来源。

正式状态继续为：

`NOT_ADJUDICATED_HISTORICAL_NUMERICAL_EVIDENCE_GAP`

正式 classification 仍为 `null`。本次未新增 bootstrap、置信区间、显著性检验或正式 gate，不能据此宣布 QA-1 正式通过。

## 🧭 是否继续 Fold D：建议继续，但只回答原来的问题

历史[安全性与数值证据复盘报告](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_10/v12_qa1_safety_historical_evidence_review_report_zh_v1.md)记录：Fold D 的 LS disaster 为 4、LSQ 为 5，LSQ 独有病例为 `008/random_1`、`010/random_1`、`087/parietotemporal`。这些是历史结果，不是尚未执行的当前 Fold D 结果。

继续理由：

1. Fold C 的即时响应幅度较小，不足以推断另一独立折也如此；Fold D 有不同的历史风险病例。
2. C＋D 是既定范围。仅因 C 不支持预期机制而停止，跨折诊断将不完整；也不能反过来只保留 D 的有利结果。
3. 当前实验已经产生可解释科研证据，下一步不应回到通用库存、传输或审计框架扩展。只处理 Fold D 不能启动的必要入口约束。

后续判断应保持对称：

- 若 D 同样表现为小幅、混合响应且风险保留，则“当前推理残差加法直接主导收益／风险”的解释获得的支持有限。应先完成 C/D 联合复盘，再讨论是否终止这一机制路线；不自动重训。
- 若 D 出现不同幅度或风险转换，则报告跨折异质性和完整病例集合，不删 C、不追加筛选、不事后修改阈值。
- 两种情况都不能补齐历史数值证据缺口，也不自动形成正式 gate。

**最小下一步范围（建议，尚未授权实施）：**起草 Fold D 专用最小适配与冻结执行范围；随后按单独授权完成必要适配、针对性人工 CPU 合同验证／P3，并创建待授权 request。固定 105 病例／315 次 forward，保留同进程配对与原指标／阈值；不更改科研计算、provider、wheel、容差或数据范围，不重复已通过的人工 GPU preflight。

当前 v3 的 request 验证、命名及历史表读取含 Fold C 约束，不能仅替换 fold 标签绕过。只有这部分必要兼容性收尾属于下一步实施候选；本次未改任何生产代码。

## 📦 溯源与本次边界

服务器原始结果关键 SHA256：

| 文件 | SHA256 |
| --- | --- |
| fold_descriptive_summary.json | `ee9cd70c58db26c7fe3c299dd0c5e426999ab1c1e90725ad39ce4946960520e5` |
| per_condition_case_metrics.csv | `c5f885a4b32e07990dfa352813844230ea80e392ba9887ae69fcfd40d4bdc7d6` |
| paired_intervention_case_deltas.csv | `f77a5eb99d0843b0a6bccb0d92d73ecd9121bfc4a557afed114f34cdc23787b9` |
| historical_native_comparison.csv | `b32bbeee3050382ebaf8fe97174fa560fc57c9be70d35f4b05797a1564931e42` |
| execution_receipt.json | `6984ec534f3b3e48f616d11d7d0ea4c46c0375799f2f22413373818a838251ca` |
| files.sha256 | `41e077e4bf1bca7925da65752a53590fc080c8ec485206bc891dd322482a5511` |

运行核算：本次成功 Fold C 315 次；此前失败尝试已执行 3 次，故该真实干预阶段累计实际 318 次，不应写成“当前已完成 C/D 共 630 次”。若后续 D 恰好完成 315 次，该阶段累计实际应为 633 次；人工 GPU preflight 另计。

本次仅对已冻结标量文件做有界只读提取及本机报告保存；没有加载 checkpoint／真实 NPZ payload，没有运行 forward、训练、BNCal 或新的统计执行，没有创建 Fold D 执行内容。已保存本机报告不代表服务器全部原始归档已在长期备份目录下载并核验，亦不授权删除服务器文件。

