# R1-B implementation-only：新容器身份重绑定与启动守卫补充方案草案 v1

_2026-10-12；状态 `DRAFT_AWAITING_USER_CONFIRMATION`；仅本机证据与方案，不构成实施或执行授权。_

---

## 📋 结论与证据范围

新容器上传包、父代码及协议证据核验通过，但**部署仍不可执行**。当前阻断来自旧主机绑定及启动/回收保障不足，不是文件运输损坏。本草案采用决策记录结构，区分已观测事实、静态代码发现和待验证设计。

机器可读证据：[resource-rebind 只读证据 v1](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_v2_resource_rebind_readonly_evidence_v1_20261012.json)。服务器观测时间为 `2026-10-12T08:05:33.602188+00:00`；这些资源状态不是未来执行时仍有效的保证。

| 检查项 | 观测结果 |
| --- | --- |
| 上传五件套 | 大小及全部 SHA256 匹配 |
| 归档成员 | 恰好三个普通文件，成员哈希匹配；未解压 |
| 原 R1-B 九文件、parent P3 | 哈希匹配 |
| 三个 canonical preflight 工具 | 哈希匹配 |
| 两份模型 YAML、协议、parent request | 哈希匹配 |
| 旧失败回执 | 哈希匹配，未覆盖 |
| 新 stage/output/P3/control | 均不存在，未见符号链接 |
| 固定 v2 tmux 会话 | 不存在；未创建 tmux 服务 |
| 服务器 Git | 项目中未见 `.git`；不依赖 Git 做恢复 |
| 本轮执行 | 测试0、库存审计0、真实数据读取0、GPU计算0 |

首次长只读查询未形成完整返回；已取消本机对应查询客户端，后续短、有界查询返回了上述证据。其未返回的根因未证实，不能称为实验失败或计入通过证据，也不能推导任何启动授权。

## 🔐 资源重绑定候选

| 字段 | 旧绑定 | 新观测 |
| --- | --- | --- |
| hostname | `shu-common-25721452-notebook-2b2doi-0` | `shu-common-25721452-notebook-2vuh4c-0` |
| GPU UUID | `GPU-3fea2502-c54e-30e1-ae67-8696c29238d2` | `GPU-aeeaea56-513b-fc9b-7a70-bb6d37a0a04c` |
| GPU 型号 | RTX 4090 D | RTX 4090 D |
| 驱动 | 570.190 | 570.190 |
| uid/project | jovyan 1000 / PoinTr | 相同 |
| Python | 3.10.20 | 相同，二进制SHA256相同 |

新容器 Python：`/opt/conda/envs/adapointr-mamba/bin/python3.10`，SHA256 `01b4275dc374dcae51d245bda004daad6d7882d3f5de7f9852567bb7ab83180d`。包元数据仍为 torch `2.4.1+cu118`、NumPy `2.2.6`、SciPy `1.15.3`、PyYAML `6.0.3`、timm `1.0.27`、mamba-ssm `2.3.1`、causal-conv1d `1.6.2.post1`；本轮未导入这些计算库来运行模型。

元数据观测：显存总量 `24564 MiB`、已用 `1 MiB`、利用率 `0%`；磁盘可用 `9,861,857,280 bytes`。本轮没有计算完整依赖库存，因此不能据此宣称所有库二进制和动态加载链均与旧容器等价。型号相同也不等于GPU身份相同。

未来只允许在明确确认后把这些值写入新的 CPU 部署资源绑定。旧协议/request/P3不回写，原 GPU 身份不能伪装成新 UUID。CPU部署重绑定只授权CPU路径；任何未来GPU preflight须另做资源绑定和完整request授权，原600秒门控不改变。

## 🔍 启动契约发现

依据当前未改动的本机 v2 源码静态审查：

1. `parent_check()`硬绑定旧hostname，现有包在新容器必定不满足身份守卫。
2. `1300 s`仅在部分控制流位置进行单调时钟检查；检查之间可能阻塞，因此不是覆盖从入口到最终发布的独立总期限守卫。
3. `bounded_child()`以 `start_new_session=True`创建独立子会话，并在自身超时时尝试组终止；但没有覆盖父控制器被终止后的统一回收。Python文档说明该参数会在POSIX子进程执行前调用 `setsid()`。[^1]
4. 仅靠控制器信号处理无法覆盖控制器被 `SIGKILL`的情况；该信号不能被捕获、阻塞或忽略。[^2]
5. 现有24项人工测试中的进程回收使用FakeProcess与注入信号；已通过不等于证明真实Linux父/子/孙进程退出行为。
6. `control.iterdir()`要求启动时控制目录仅含授权文件；把launcher/master log/PID/退出码放入该目录，会与守卫冲突。
7. 产物发布后仍需哈希并写completion；此部分也必须计入总期限。当前关闭进度流后的错误分支可能再向已关闭流写FAIL，从而掩盖最初异常，需纳入未来纯人工发布失败回归。

以上是启动就绪的阻断，不是本轮执行了失败测试的结果。不得放宽守卫、跳过哈希或直接尝试启动来验证。

## 🎯 方案选择

| 选择 | 评价 | 本草案意见 |
| --- | --- | --- |
| 只替换hostname | 不能解决超时与回收 | 不采用 |
| 外层仅加shell timeout | 独立子会话仍可能残留 | 不单独采用 |
| 独立监督器＋统一受管进程组 | 易于明确所有权和故障边界 | 推荐，尚未实现验证 |
| 特权cgroup/systemd方案 | 当前权限与可用性未核验 | 不作为默认前提 |

推荐形成新 v3 implementation-only 包，保留 v2原包及失败证据。这里的“v3”指实现/运输版本，不是GPU实验request的版本，也不意味着修改实验比较规则。

### 独立监督器的拟定职责

- 在tmux中运行独立supervisor，先核验已授权CPU request、资源及代码哈希，再开始1300秒全流程单调时钟期限。入口校验、bootstrap、安装、CPU测试、900秒库存审计、最终P3发布全部纳入；一次性回收另设不超过15秒，不提供额外计算时间。
- supervisor在自身进程组之外创建唯一controller作业组。测试、审计、加载器等受管后代继承该作业组，不得各自再创建未受管会话。实现时必须同时调整现有组终止逻辑，不能只删除 `start_new_session` 后继续向child PID当作PGID发送信号。
- 对阶段超时、controller异常退出、总期限到达、TERM/INT建立统一失败路径。controller返回0也需确认没有存活后代和全部冻结结果门控通过，才能判PASS。
- 记录controller PID/PGID、启动标识、受管后代及回收证据。信号只发给本轮核验过所有权的作业组；回收前确认身份，避免PID/PGID复用和误杀外部任务。禁止 `pkill python` 或扫描全系统后随意杀进程。
- 失败时由独立supervisor执行TERM→有限等待→必要时KILL→组内存活核验和直接子进程wait。组内残留或回收无法确认时输出 `PROCESS_REAP_UNCONFIRMED`，不得发布PASS/P3或自动再试。
- 不声称能处理supervisor自身遭SIGKILL、容器强制销毁等所有灾难情形。若监督器丢失，下次连接必须只读检查登记的PID/组/结果；既不能认定完成，也不能自动重跑或未经授权清理残留。

这些是验收要求，尚不是已实现的Linux进程隔离保证；第三方库是否会创建逃逸会话也未在本轮验证。后续发现不能维持受管进程组闭包时停止，另报方案，而非把未知进程归为安全。

## ⏰ 保留预算、扫描覆盖与发布门控

库存仍保留原 `models/utils/extensions` 与整个Conda `lib`的批准代码集合，不缩成少数包。上限继续为20万枚举条目、5万去重文件、8GiB内容、32个loader目标、元数据16MiB、单文件120秒；超限失败，不截断、抽样或缓存跳过。

| 约束 | 保留值 |
| --- | ---: |
| 每轮人工CPU/回归测试 | 60秒 |
| 身份与CPU probe合计 | 60秒 |
| 枚举 | 120秒 |
| loader解析 | 120秒 |
| 内容哈希 | 480秒 |
| 最终验证与发布合计 | 60秒 |
| 单次库存审计总期限 | 900秒 |
| CPU完整编排总期限 | 1300秒 |
| 失败回收期限 | 15秒 |
| 未来GPU preflight总期限 | 600秒，不变 |

所有阶段期限同时受总期限约束，不能自动借用其他阶段预算。900秒仍是规划上限，不是该容器一定通过的保证。900秒CPU审计完成也不能证明600秒GPU前置核验和固定forward可完成。

进度与完整结果分离：大文件开始/结束、5秒或64MiB心跳、阶段切换、已处理条目与字节数均记录并flush；独立supervisor不依赖worker心跳来证明存活。发布失败须保留原始异常，不能因为进度流已关闭而遮蔽它。PASS以进程退出、文件清单、completion、计数及只读freeze复核同时满足为准。

## 📦 新版本文件与目录提案

后续若获implementation-only授权，建议在全新本机overlay新增四个文件：

1. `audit_synthetic_pf_dependencies_v3.py`：新资源绑定、v3路径、发布错误门控；不改实验数值规则
2. `install_synthetic_pf_implementation_v3.py`：受管子进程、外部监督器协作、兼容原P3 reader
3. `supervise_synthetic_pf_implementation_v3.py`：独立全流程期限、组回收和退出凭据
4. `test_synthetic_pf_dependency_audit_v3.py`：保留既有人工契约并增加监督器与资源重绑定回归

旧九个R1-B文件、三个canonical preflight工具、v1.1路径及原v1/v2运输文件均不覆盖。新archive精确成员规则须从三文件显式更新为四文件，最终test count及完整哈希须在实现测试通过后冻结，不沿用24项已通过来声称新监督器已验证。

建议新run命名空间：`r1b_synthetic_pf_impl_v3_20261012`。服务器根仍为 `/home/jovyan/adapointr_work/PoinTr`：

| 新路径（相对根） | 用途 |
| --- | --- |
| `server_overlays/r1b_synthetic_pf_impl_v3_20261012` | 新增工具 |
| `docs/cranial_scqr_v12_qa_research_2026_10_11/r1b_synthetic_pf_implementation_v3_20261012` | CPU产物 |
| `docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_post_implementation_p3_v3.json` | 新P3 |
| `logs/cranial_scqr_v12_rsd_r1b/synthetic_impl_cpu_audit_v3_20261012/auth` | 仅授权文件 |
| 同级 `launch` | 已授权后才材料化launcher/bootstrap |
| 同级 `control` | supervisor日志、PID/PGID/exit及回收凭据 |

固定CPU会话候选：`r1b-synthetic-impl-cpu-audit-v3-20261012`。这些v3路径/会话**本轮未创建，也未核验不存在**；不能把已核验v2路径不存在当作v3路径不存在。

bootstrap必须先验archive整体哈希、大小、安全成员与各实现哈希，才在内存中执行已验证installer；installer stage仍须不存在，不能先解压stage再调用其“stage不存在”守卫。所有日志父目录先创建并核验再重定向；Windows调用显式 `exit $LASTEXITCODE`。启动返回0不代替最终成功证据。

## 🧪 后续CPU验收提案

本轮不执行任何测试。后续实施必须获得明确范围授权，并先在本机隔离WSL Python运行小型人工fixture，保持GPU/真实payload/checkpoint不可访问。除现有集合/数值/权限契约外，新增：

- 新hostname与绑定一致可通过，旧hostname或错误GPU元数据/资源字段失败；不能按型号模糊匹配UUID
- 阻塞入口校验、无心跳worker、阶段超时、controller主动异常退出的监督器期限与退出证据
- 真实但无害的短生命周期CPU子/孙进程：controller TERM以及KILL后，supervisor仍能回收其作业组；不得仅FakeProcess断言
- worker非0、controller0但残留后代、回收未确认均不能发布P3；回收不得触及组外人工对照进程
- 不存在的或复用身份的PID/PGID不得被当作本次所有权；bootstrap失败不能触发后续审计
- publication/completion写失败时保留第一异常，FAIL记录不得因关闭日志流而遮蔽错误
- 授权、launch和control目录分离；旧v2包未执行且不得作为新容器可执行包

真实CPU进程试验只允许小型标准库helper，不加载模型/库库存、不开GPU、不长时间运行；最大进程数、具体次数、各场景秒数和输出目录应在下一步授权范围中明确冻结。当前未授权这些试验，不能擅自开始。

## 🚫 权限边界与下一步

```mermaid
flowchart TB
    accTitle: Resource Rebind And Guard Approval
    accDescr: Read-only evidence supports a draft, but implementation, transport and CPU deployment require separate authorization and successful gates; GPU remains locked.
    evidence_review["新容器只读证据"] --> draft_review["确认重绑定与守卫草案"]
    draft_review --> implementation_authority["单独授权本机 implementation-only"]
    implementation_authority --> cpu_validation["人工CPU与监督器契约验证"]
    cpu_validation --> package_freeze["单独冻结新包与待授权范围"]
    package_freeze --> server_readiness["上传后只读部署就绪审查"]
    server_readiness --> cpu_authority["完整SHA单独授权CPU部署"]
    cpu_authority --> p3_review["完成后单独只读P3审计"]
    p3_review --> gpu_locked(["GPU与真实诊断仍锁定"])
```

本轮仅创建本机resource-rebind证据和本草案。不得改写旧部署范围为execution_ready；不得创建CPU execution request、服务器授权、runtime、launcher或tmux；不得运行库存审计、训练、BNCal、development evaluation或GPU preflight。

建议下一步：先确认本草案。若同时需要实施，请单独明确授权上述四个新增v3文件及限定人工CPU/无害Linux进程契约测试；不包含服务器部署、库存审计或GPU。任何失败都停止，保留版本化证据，不自动修补或重跑。

## 🔗 来源与保留证据

- [原implementation-only v2方案](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_implementation_v2_revision_proposal_v1_zh.md)，SHA256 `efdcfa60510e6e812f652711384dba7debeeb4bca737b218914a2b16bf851f51`
- [旧待授权CPU部署范围](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_v2_pending_cpu_deployment_scope_v1_20261012.json)，SHA256 `f870ed74410b5d631544e2a29466d48597a84a420561dc61c719fe07d2c647f8`
- v2归档SHA256 `4313671a14e27e846a2dae2314221a17ca081666ff2decdfd5f322828794cf48`；只读验证，不修改、不删除

[^1]: Python Software Foundation. Python 3.10 `subprocess` documentation：`start_new_session`的POSIX行为。https://docs.python.org/3.10/library/subprocess.html
[^2]: Python Software Foundation. Python 3.10 `signal` documentation：`SIGKILL`不可捕获等限制。https://docs.python.org/3.10/library/signal.html
