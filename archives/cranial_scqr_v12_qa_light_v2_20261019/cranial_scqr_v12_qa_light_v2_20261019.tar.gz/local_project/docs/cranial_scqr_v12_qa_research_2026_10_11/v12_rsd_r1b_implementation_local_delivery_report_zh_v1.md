# R1-B implementation-only：本机交付与服务器待部署报告 v1

_2026-10-11｜已确认协议，实施权限仅 L1｜待用户上传运输五件套_

---

## 📋 1. 当前状态

本机实施代码与 v2 运输包已准备，19 项纯文本/人工访问契约测试通过。服务器仅做了只读前置审计，尚未部署适配；6 项人工 CPU 张量/几何测试未运行，post-implementation P3 未生成，不能称为通过。

用户确认并授权实施的父草案 SHA256 为 30eeb37fcc6e0172849c5dd4a5a457180d59b9cc0e521a9234b81158bc88b035。确认和 L1 授权记录已准备，execution_authorized=false。原草案与 R0/R1-A 报告未修改；本机 work/PoinTr_mamba_v12_dev 原模型文件仍为父 SHA256，不自动把运输目录视为规范仓库同步。

当前暂停原因是沿用用户明确的“需要本机文件时由用户完成上传/下载”边界，不自动 hpc5000 put。请上传第 5 节五个 v2 文件并告知“已上传完成”。上传后可在既有 L1 范围内继续校验、隔离 CPU tests、安装与 P3；不启动 GPU preflight 或真实诊断。

## 🔍 2. 服务器前置证据

| 项目 | 核验结果 |
|---|---|
| hostname | shu-common-25721452-notebook-2b2doi-0 |
| 用户/项目 | jovyan；/home/jovyan/adapointr_work/PoinTr |
| 服务器 Git | 无 .git，不伪造 Git 提交状态 |
| 默认审计 Python | /opt/conda/bin/python，仅标准库读代码/元数据 |
| 现有 CPU 测试 Python | /opt/conda/envs/adapointr-mamba/bin/python，3.10.20 |
| 包版本元数据 | torch 2.4.1+cu118；NumPy 2.2.6；SciPy 1.15.3 |
| GPU | 本次未调用 GPU、未证明空闲或 CUDA 兼容 |
| 父模型 SHA256 | 62a743c4c2143b77b0f1656c59d0482563976440d841f04bae995017dbf7588f |
| 最终只读核对 | 新代码目标与 staging 不存在，P3 不存在；服务器模型仍为父 hash |

实际函数为 PCTransformer._condition_scqr_queries，不是草案中作为本机历史描述使用的 _apply 名称。训练和 inference 分支各有一个调用点；RSD 条件明确禁止 training。推理分支的 outlet 位于 coarse/FPS/ranking 之后：off 改变 decoder query 特征，不重新产生 coarse anchors。因此增加 native/off coarse 精确一致的工程负对照，尚需人工 GPU preflight 直接验证，不能据静态审阅声称已证明全部 CUDA 输出性质。

## ⚙️ 3. 拟部署文件与守卫

本机源码目录：E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/v12_rsd_r1b_impl_v1_20261011。

| 文件 | 变化与职责 |
|---|---|
| models/AdaPoinTr.py | 唯一 existing-code 修改：显式 keyword-only RSD 条件/诊断分派；默认保留旧路径 |
| models/cranial_scqr/rsd_query_bypass.py | 推理专用条件/variant 校验、仅加法出口旁路、低体积 query/attention 标量 |
| tools/cranial_scqr_v12_rsd_r1b_contract.py | 纯文本授权/资源/环境/预算/容差/flags 及 one-case 访问状态机 |
| tools/run_cranial_scqr_v12_rsd_r1b.py | 惰性导入、完整新授权链后才允许未来单 fold 三条件执行 |
| tools/test_cranial_scqr_v12_rsd_r1b_contract.py | 19 纯文本＋6 人工 CPU tests，不构造完整模型 |
| parents/AdaPoinTr.parent.py | 原字节父副本，SHA256 完整保留，可作后续明确授权回滚依据 |
| install_r1b.py | 仅 L1 安装器：安全归档校验、隔离 CPU tests、drift 拒绝、安装后 tests/P3 |

Query 原模块、原 v1.1/QA-1 evaluator、原指标和已有 QA-1 contract test 不修改。新增 RSD 路径不改 alpha/beta/warmup/Local/SCF/state_dict；同 LSQ 实例显式旁路，无持久化全局开关或 inference monkey-patch。

未来实际入口要求单独 request/authorization/runtime、协议确认、P3、人工 GPU preflight 与事前冻结容差；L1 receipt 不能启动它。schema 为 cranial-scqr-v1.2-RSD-R1B-fold-request-v1，runtime 是严格 JSON 单向绑定，不产生本次 runtime 文件。

模型运输稿 SHA256：06fafe4fb9a7a2d9d3d8c4c50ca44ddcec6c1935eb6630737d70fceaf4aced1d。默认行为 AST 对照通过不等于 byte hash 不变，也不等于已验证 CUDA 等价。将来安装后，绑定旧模型 byte hash 的旧 execution requests 不可复用；已有结果不被覆写，历史父代码仍有副本。

单 fold 仍为 105 case／315 forwards／105 NPZ opens／2 checkpoint deserializations；另明确四次 checkpoint SHA 校验（前置各一次、加载前各一次），不混记反序列化。状态机记录 attempts 与 successful forwards，GT members 只能在三次成功 forward 后读。禁止保护分区、自动 retry/resume、BNCal、训练、bootstrap/gate；空接触按独立诊断完整性失败停止，旧 disaster flags 不变。

## 📊 4. 已验证与未验证

| 检查 | 当前结果 |
|---|---|
| 本机 C:/Program Files/Python310/python.exe -B 的 19 项 contracts | 全部通过 |
| 整个模型模块默认 AST 与父文件对照 | 去除仅 opt-in RSD 分派后完整相同 |
| 编码/语法/JSON、导入惰性、GT 后置/预算/禁止权限 | 通过 |
| 原灾难 50.0 严格边界、空接触/非有限停止 | 通过人工字段 tests |
| 人工 CPU Tensor/geometry 6 项 | 未运行，本机没有 PyTorch，不安装依赖 |
| 服务器 staged/canonical CPU 25 项 | 未运行 |
| post-implementation P3 | NOT_CREATED_NOT_PASSED |
| GPU preflight、真实 native/Query-off、checkpoint 加载 | 未执行、未授权 |

测试标准输出见 [本机 19 项测试日志](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_local_text_contract_tests_v1.log)；机器可读来源、源码 hash 和状态见 [交付 ledger](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_implementation_local_delivery_v1.json)。

315 次 fake ledger 完成次数是纯人工计数测试，没有 315 次模型 forward。测试中的人工容差 0.001 只用于 fake 字段比较，不是实际 replay tolerance；没有创建容差附件或 dev 执行 request。历史训练数值证据缺口、正式 gate 未裁定与 classification=null 均保留。

## 📦 5. 需要用户上传的五件套

本机准确目录：E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_uploads/r1b_impl_v2_20261011。

建议上传位置：/home/jovyan/（仅由用户放置这五个运输文件；代码安装仍仅在项目根内）。保持原文件名，不使用旧 v1 包，不先手动解压或运行安装器。本机/服务器不是同一文件系统；未推断同步，也未使用猜测 Linux 路径。

| 精确文件名 | bytes | SHA256 |
|---|---:|---|
| [r1b_impl_v2_20261011.contents.sha256](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_uploads/r1b_impl_v2_20261011/r1b_impl_v2_20261011.contents.sha256) | 1178 | ac4f7ecf23f79b98b329942598eef1560de575ad06848275d45b32a6c572803f |
| [r1b_impl_v2_20261011.contents.sha256.sha256](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_uploads/r1b_impl_v2_20261011/r1b_impl_v2_20261011.contents.sha256.sha256) | 103 | 26aacfcc243d6bc8f6423e847d190a873c1a736281605c80facfe26dbc68bfb6 |
| [r1b_impl_v2_20261011.tar.gz](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_uploads/r1b_impl_v2_20261011/r1b_impl_v2_20261011.tar.gz) | 71945 | 3d39ad78886810bfca72b077aeb56e20bbf74137894d2784b6ceeee9588236c8 |
| [r1b_impl_v2_20261011.tar.gz.bytes](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_uploads/r1b_impl_v2_20261011/r1b_impl_v2_20261011.tar.gz.bytes) | 6 | cd7699d86ddd2eed9d077e9aa92d296d6ffc939722fc994ca049dba8dc692e4e |
| [r1b_impl_v2_20261011.tar.gz.sha256](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_uploads/r1b_impl_v2_20261011/r1b_impl_v2_20261011.tar.gz.sha256) | 94 | fde21387eda885cb8a5db23dde3df8af8387593a93a5e73c84c65087ad5d9fa3 |

主归档 71945 bytes，11 个 regular members；五件套、每成员 SHA256、成员集合及不含绝对路径/../link/device 已在本机验证。归档包含代码、父备份和四项协议/授权文档，不包含真实数据、checkpoint、runtime、GPU launcher 或实验结果。

运输 v1 未部署、未执行，保留原五文件，状态 UNEXECUTED_SUPERSEDED_DO_NOT_INSTALL；旧主归档 SHA256=fbcc230aad82db8af536a3c1bcc6244c3e03e6997eef2f54ae6c0338325cbade。静态审阅发现旧 installer 的异常分支可能向已存在 stage 写失败记录；v2 改为仅向本进程创建的 stage 写记录，并加强文档目录解析边界。没有覆盖或删除旧包，未发生服务器安装失败或实验重试。

## 📍 6. 上传后的仅 L1 路线

```mermaid
flowchart TB
    accTitle: Implementation Only Delivery Gates
    accDescr: 上传后的校验、隔离CPU测试、安装与后置P3属于现有L1权限；任一步失败停止，P3完成也不授权GPU或真实诊断。
    upload_verify["用户上传并核验五件套"] --> staged_cpu["隔离 CPU 25 项测试"]
    staged_cpu --> staged_pass{"全部通过？"}
    staged_pass -->|是| install_post["安装并后置 CPU 25 项"]
    staged_pass -->|否| freeze_stop(["冻结失败 不重试"])
    install_post --> p3_pass{"hash 与 P3 通过？"}
    p3_pass -->|否| freeze_stop
    p3_pass -->|是| wait_gpu(["等待单独 GPU 阶段授权"])
```

先只读重核 hostname/用户/根目录、运输五文件、归档安全性、父/immutable hashes、staging 和新目标不存在。验证后，采用项目内全新 staging=/home/jovyan/adapointr_work/PoinTr/server_overlays/r1b_impl_v1_20261011。

隔离 tests 使用现有 Conda Python，CUDA_VISIBLE_DEVICES 空、Torch CUDA 初始化陷阱、OMP/MKL=1、-B；只有人工 CPU 小张量/几何，不构造完整模型，不访问真实点云/checkpoint。全部通过后才修改唯一 existing model 文件和安装四个新代码文件；再运行 canonical CPU tests、核验旧文件未变及默认 AST，才生成新 P3。

拟 P3 路径：/home/jovyan/adapointr_work/PoinTr/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_post_implementation_p3_v1.json，当前不存在。失败立即停止，保留已有 stage/日志与实际修改清单；不自动回滚、hotfix/retry 或切入 GPU。若失败发生在 canonical 安装之后，需正式报告可能部分部署，不能因失败就称服务器“未修改”。

后续真实执行仍锁定：必须另外建立并授权人工 GPU preflight，再冻结有依据的 replay tolerance、当前资源和完整环境/扩展 binary/source hash、wall-time/显存预算，之后才可另授权创建真实 fold request。当前授权不会自动生成这些内容。

## 🔒 7. 边界与交付结论

本次服务器文件写入=0，真实 NPZ/STL/checkpoint 访问=0，模型构造/forward/update=0，GPU/BNCal/训练=0，execution request/runtime/launcher/tmux=0；没有依赖安装、Git commit/tag/push、清理或删除。数据/保护分区、历史报告和原计划保持不变。

本机 E:/ResearchBackups/AdaPoinTr 没有因软件运输包获得长期实验归档或恢复验证认证，不能推导服务器删除权限。本机管理根不是本次可用 Git worktree，未进行 Git 操作；源码只在新 overlay 中改动，不假定规范仓库已自动同步。

状态为 LOCAL_IMPLEMENTATION_PACKAGE_READY_AWAITING_USER_UPLOAD，而不是实施/P3全完成。报告采用 markdown-mermaid-writing 状态模板，将证据、阻塞和下一步分开，未扩大权限；图只是 L1 门槛说明。原草案、R0/R1-A 报告与 v1 运输档案保持原 SHA256，后续报告/P3采用新文件，不覆写本报告。
