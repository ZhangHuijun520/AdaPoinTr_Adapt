# Cranial-SCQR R1-B：历史重放准入与同进程配对诊断补充协议草案 v1

_2026-10-19｜基于已暴露失败证据的前瞻性修订提案｜待审核，不实施、不执行_

| 字段 | 值 |
|---|---|
| 文档状态 | DRAFT_AWAITING_USER_CONFIRMATION |
| 本次授权 | 仅起草补充协议 |
| implementation_authorized / execution_authorized | false / false |
| 新 execution request / runtime / launcher | 均未创建 |
| 正式 gate | NOT_ADJUDICATED_HISTORICAL_NUMERICAL_EVIDENCE_GAP |
| 正式分类 | null |

---

## 📋 1. 决策摘要与既有失败的不可变性

建议将两个问题分别判定：

1. **历史一致性问题**：当前 native 是否精确再现历史 CSV？历史条件哪些已匹配、哪些已变更或无法追溯？
2. **同进程干预问题**：在当前冻结环境、相同 LSQ 实例、相同权重/输入及配对 RNG 下，只旁路 Query residual 加法，会怎样改变输出与既有指标？

推荐采用“历史一致性独立报告，同进程干预按自身完整性准入”的新诊断分支。这是对原协议停止条件的实质修订，不是原零容差规则已经通过，也不是扩大容差。未确认本草案前，原合同继续有效，现有入口仍须按原门槛停止。

旧 request `69c10ecbae5189c6934c5502d1ea5f5f498ee8977183f4c86fc802c8538974b0` 已消耗。其退出码 1、1 个病例/3 次 forward、首个 LS_native 指标精确重放失败和全部冻结产物均永久保留，不复用、不覆盖、不拼接新结果。该差值已被研究者观察，因此本补充是结果知情后的修订，不能称为在所有 development 输出前预注册；新分支仅限探索性机制诊断。

来源：[正式失败冻结审计](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_foldC_seed0_formal_post_intervention_freeze_audit_v1_20261019.json)、[历史与当前条件调查](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_foldC_historical_current_numerical_conditions_readonly_investigation_v1_20261019.json)。

## 🎯 2. 研究问题、方案选择与效力边界

### 2.1 三种可选决策

| 方案 | 历史数值停止门 | 科研去向 |
|---|---|---|
| A：坚持历史精确复现 | 原零容差不变 | 当前停止；历史环境若不可重建，可结束此分支 |
| B：新同进程诊断，推荐 | 历史差异独立报告 | 仅在新协议获批后建立当前配对证据 |
| C：校准非零容差 | 尚无可用附件 | 不在本草案采用或授权 |

不根据已看到的 `1.359269574674471e-7 mm` 设置 epsilon，不采用四舍五入、有效位截断或“差值够小就放行”。人工输入校准即使另行开展，也不能直接认证所有真实病例的历史误差范围。

### 2.2 估计对象保持不变，比较基准明确分开

核心逐病例效应仍为：

`delta_pair = metric(LSQ_query_off_current) - metric(LSQ_native_current)`

两者必须来自同一次新运行。LS_native_current 只作为不同训练权重的当前环境参考，不等于 LSQ_query_off。历史 LS/LSQ CSV 不作为新干预差值的减数，不替代当前 native，也不与新 off 拼成混合配对。

诊断只能描述固定 checkpoint、固定病例、当前环境中的即时旁路效应。不能解释训练期 Query 的反事实、跨 seed 稳定性或临床安全；不能消除原训练/BNCal 数值证据缺口。RimCover 改善不自动代表植入体总体质量或安全性改善。

## 🔍 3. 历史一致性轨：核验层级和判断标准

### 3.1 身份、绑定和历史运行证据是硬前提

下列任一失败，停止新分支，不以“历史差异只记录”豁免：

- 历史 CSV/协议/模型配置/checkpoint 的预期 SHA256 或字节数不符，文件缺失、重复、链接越界或读中变化。
- 新运行的 case 身份、fold、seed 标签、source、defect、allowlist 顺序与冻结设计不符。
- 历史 reference 本身缺病例、重复键、非法 flag、无效必需字段，或不能唯一映射当前病例。
- 当前模型/扩展/指标实现或资源身份不符合新 request 冻结值。
- 历史 checkpoint 绑定与当前同候选实际加载权重不是同一来源。

这里的“身份精确”是病例身份和输入/权重来源，不是要求旧/新数值结果相同。调查时不读取 payload 的结论不能替代未来执行阶段的实际文件核验。

### 3.2 跨历史数值仅作独立、完整披露

原历史零容差附件保持不可变，不签发其 PASS。新分支逐 native 条件、逐病例、逐原连续字段保留历史值、当前值、原始有符号差和绝对差；不压缩精度，不删点，不形成新“可接受误差”阈值。

| 判定对象 | 建议状态 | 含义 |
|---|---|---|
| 历史六项 flags 证据一致 | RECORDED_POLICY_MATCH | 仅证明所记录设置一致 |
| 完整执行环境缺证或已变 | HISTORICAL_ENVIRONMENT_NOT_FULLY_MATCHED | 不能追溯认证完全相同 |
| 全部必需 native 数值及 flags 精确相同 | EXACT_NATIVE_METRIC_REPLAY | 仅覆盖实际比较范围，不证明预测坐标逐位相同 |
| 任一连续字段数值不同 | HISTORICAL_NUMERIC_DIFFERENCE | 不作大小分级，不补发旧版通过 |
| 任一历史/当前事件或点数不同 | HISTORICAL_EVENT_OR_COUNT_DIFFERENCE | 单列具体字段与病例，不被连续误差掩盖 |

环境状态与数值状态分别保存，允许“设置记录一致但数值不同”，不得强行归为单个 PASS。未完成整折时只能报告部分范围，不能宣称全折精确复现。

方案 B 的明确变化是：纯历史数值、派生点数或事件差异不再单独中止当前配对采集；它们全部列入独立差异表，且禁止声称历史可迁移/复现。历史事件不同不代表可忽略：必须披露，并阻断任何沿用旧病例安全分类、旧展示标签为“新事件”或旧效果结论的主张；新运行的事件须按新 native/off 自身重新描述。不得按历史一致性筛选病例或决定是否汇报结果。

### 3.3 当前已知历史限制

两次 evaluation 的 deterministic/TF32 六项记录相同；历史开启完整 instrumentation，本次关闭；模型源码新增 R1-B 分派；旧/新 GPU UUID 不同。历史独立单模型进程与当前双模型、候选隔离 RNG 不同；历史实际 PointNet2 二进制、完整线程/精度快照未充分冻结。上述均不作为已确认的唯一误差根因。

不要求为方案 B 重建已不可追溯的全部旧依赖；不修复或重装环境来“追零误差”。若用户选择方案 A，则应先判断能否重建；无法重建时保留未通过并停止，而不是无限开发审计工具。

## ⚙️ 4. 当前同进程配对轨：技术准入和失败标准

### 4.1 不变的执行合同

固定当前已验证的轻量 instrumentation 路径；不为了匹配旧 CSV 改用完整诊断。沿用严格数值策略：eval/no_grad、FP32、batch1、epoch=None、无 AMP/TF32/compile/量化，deterministic_algorithms=true、warn_only=false、cuDNN deterministic=true、benchmark=false、matmul precision=highest、CUBLAS=:4096:8、CPU/interop 各1线程。

继续冻结解释器/依赖/compiled PointNet2 provider 的实际来源与哈希，禁止 fallback、下载、升级、重新编译或重装。新运行若换容器/GPU，先做限定 resource-rebind，不静默改身份期望。

不改变现有模型初始化和 RNG 起点，不以新增每 case reseed 或寻找“更匹配”的 seed 解决历史差异。seed0 仍为训练运行身份标签；当前推理实际 RNG 状态必须记录，不能声称已恢复历史初始状态。

### 4.2 配对 RNG 和状态

- LS、LSQ 各构建/严格加载一次；LSQ native/off 共用同实例、权重和 buffer，不重载、不补 BNCal。
- 每 case 先确定 LSQ 的 pre-forward Python/NumPy/torch CPU/CUDA RNG。native 与 off 各从该相同快照进入；之后仅按 native 的 post-state 推进下一病例，off 不污染 native 流。
- 比较并记录 native/off 的 pre-RNG 指纹相同；在已冻结“旁路不改变随机调用消费”的合同下，post-RNG 指纹也必须相同，否则停止。不得通过重设或补抽随机数来伪造相等。
- 参数/buffer 使用同一 canonical 格式在加载后、结束及可观测失败时核验；buffer 每 case 守卫不变。禁止恢复旧状态后声称从未改变。
- 推理中不新增控制组 forward 来验证上述条件；从既有两次调用取证。任何新计算需单独计数、授权。

### 4.3 单一出口旁路与判断标准

| 检查 | 必须满足 | 不满足时 |
|---|---|---|
| LSQ Query 出口 | native/off 各恰好1次 | 停止并冻结 |
| 上游 coarse | native/off 精确相等 | 停止，不能归因单出口 |
| applied residual | off 精确为0；native 沿用出口值 | 停止 |
| potential residual | 正常计算、标量有限 | 停止 |
| 输入/权重/GT边界 | 相同 partial；GT不入forward | 停止 |
| 参数、buffer、RNG、数值设置 | 满足冻结合同 | 停止 |
| 计数/输出/资源 | 未超预算、无未授权读写 | 停止 |

不强制 final implant 有非零差，也不强制其等于 native；零 delta 只按原数值报告，不新增“Query 无作用”分类。attention/residual RMS 不单独构成机制因果证明。

人工 GPU v7 已通过的两模型、8次出口调用及8次完整 forward 证据保留；不得把它说成历史轻量/完整 instrumentation 跨路径等价证明。本草案不要求重复 GPU preflight；若适配实际改变模型计算、provider、数值或旁路语义，则停止并先修订范围，不能沿用“不重复”的理由跳过必要验证。

## 📊 5. 新诊断设计、预算与分析标准

### 5.1 固定病例和完整新运行

后续若获执行授权，Fold C 仍为原 allowlist 全部105病例、21 source×5 defect，条件顺序仍为 LS_native、LSQ_native、LSQ_query_off，每病例3次，总315次 forward。不得删首个失败病例、只选14个展示病例、增加筛选、扫描参数或从第2例 resume。

这是新协议分支下的全新完整运行，不是原 request 的继续执行。其预计315次加已发生3次，研究累计为318次；若未来 Fold D 再单独批准315次，跨折累计将为633次而非630次。原失败1次NPZ打开和2次checkpoint加载也另列，不能从总账抹除。当前草案不授予任何新增次数。

| 目标计数 | 新 Fold C 单次 |
|---|---:|
| 病例 / forward / NPZ打开 | 105 / 315 / 105 |
| partial、implant、gt读取 | 各105 |
| checkpoint加载 / checkpoint哈希 | 2 / 4 |
| 训练、BNCal、optimizer、参数/buffer更新 | 全部0 |

checkpoint 4次哈希保持“准入2＋加载前2”，不得把权重加入新历史比较清单导致隐藏多读。历史 CSV/回执仅文本，不算模型 forward，也不能顺便加载旧模型。

沿用单NPZ handle；先 partial，三 forward 均成功后才读取 implant/gt。不存在额外 warmup、native重测、instrumentation A/B 或 sham-forward 的隐含预算。原105/315只是新运行成功目标；任一失败只保留实际计数，不补齐。

### 5.2 指标、聚合与结论

核心指标、14连续字段、两方向接触诊断、world/mm FP64恢复和既有 flags 不变。disaster 继续按原五core非有限或有限 contact HD95>50.0定义；zero-contact独立。非有限预测/必需指标、空接触、GT半径无效仍立即停止，不改flag、不填零、不丢病例。

新运行产生315条condition-case指标、105条 off−native 配对；每 source 五defect等权、Fold C 21source等权；按defect及原事件迁移四格描述，不把病例当独立训练样本。

历史差异表单独输出LS/LSQ共210条native-case记录，连续字段含原值/当前值/有符号差/绝对差，事件/点数分别列；它不是新增模型条件，不产生额外forward。与315条当前条件表分开，不把旧/新数据池化。

无新效果阈值、等效检验、p值、CI、bootstrap、正式gate或跨fold自动比较。既定14例清单只保留“历史选定展示”身份，不依据本次新结果换人；也不把它们当总体主证据或新运行中必然仍有事件的病例。

配对技术审计通过只允许称“完整的当前环境描述性干预数据”，不能称科学假设通过、安全通过或晋级QA-2。正式解释须在单独授权的 post-intervention freeze audit 后。

## 🔐 6. 二轨判定与失败路由

以下为设计逻辑，不是执行指令。

```mermaid
flowchart TB
    accTitle: Historical And Paired Diagnostic Decisions
    accDescr: 先核对不可豁免的身份与执行守卫，再分别记录历史一致性和当前配对有效性；历史差异不被追认通过，配对失败仍停止。
    bind_inputs["核验身份与冻结绑定"] --> binding_gate{"硬前提满足"}
    binding_gate -->|否| freeze_failure["停止并保留失败"]
    binding_gate -->|是| paired_run["执行新协议配对采集"]
    paired_run --> history_record["单列历史数值与事件差异"]
    paired_run --> paired_gate{"配对守卫满足"}
    paired_gate -->|否| freeze_failure
    paired_gate -->|是| audit_wait["等待独立正式冻结审计"]
    history_record --> disclose_limits["披露历史不一致及证据局限"]
    audit_wait --> descriptive_only["仅作描述性机制解释"]
    disclose_limits --> descriptive_only
```

配对守卫是采集过程中的实时停止条件，不等于先跑完整折再审核。若写历史差异表、日志或失败回执自身失败，同样停止，不默认继续。

任一链路hash、权限、身份、路径、状态、采样/出口覆盖、RNG、严格数值、预测/指标有限性、计数或资源失败均为执行失败。历史连续值或派生flags不同，只有在用户明确确认方案B且新入口完成适配后，才按独立历史状态记录；现有v2入口不具备该行为，不得直接启动。

## 📦 7. 最小实施范围、产物和完成标准

### 7.1 后续实施提案，本次未授权

若用户选择B，建议只对R1-B专用contract、runner和对应人工测试作一次集中适配，不改AdaPoinTr、v1.1、原QA evaluator、metric、provider或旧容差附件。不新增通用库存、传输、隔离框架，不重建历史环境。

集中范围仅包括：识别新补充协议绑定；硬前提/历史数值判定分域；输出历史差异表；记录已有配对调用的RNG指纹；确保历史精确重放未通过不能被写成PASS；保持失败即停和预算。最终文件数、路径、人工测试次数和输入需在后续implementation-only授权范围明确，不在本文生成可执行scope。

人工CPU验证覆盖身份/hash拒绝、历史数值及事件差异只记录且不丢case、配对RNG/状态/出口失败仍停止、历史与当前差值不混用、旧v2路径保持原行为、计数无增量、失败记账不可复用。CPU不得冒充CUDA验证，不安排新的通用全套测试链。

### 7.2 新版本证据结构

未来产物至少分开记录：

- 历史轨：reference绑定、环境已知差异/缺证、全量native差异表、比较范围与状态
- 当前轨：三条件指标、off−native配对、source/defect描述、配对RNG/状态/出口/数值flags证据、计数
- 执行轨：独立授权/runtime/launcher哈希、日志/PID/退出码、SHA256清单与正式冻结审计
- 修订轨：本补充协议确认哈希、旧失败来源、实际累计数据暴露和forward账本

新命名不得沿用旧式PASS_NATIVE_METRIC_REPLAY_ONLY冒充两轨成功；状态拆分为历史比较状态、配对完整性状态及执行完成状态。若历史不一致，标题与摘要都披露，不能藏入附录。

继续沿用每fold7200秒、allocated/reserved各20000MiB、启动空闲显存至少22000MiB、磁盘至少2GiB、标量16MiB、日志32MiB，超限停止；资源监测不是专属cgroup硬隔离。历史差异输出应计入标量总预算；不能删字段以满足预算。

完成标准是：一次限定适配、对应人工CPU合同与P3、最终哈希冻结、新request保持待授权；不要求重做已通过的传输框架/通用库存/人工GPU v7。若发现需要改科研计算、加载次数或预算之外的验证，应一次性列出缺口等待决定，不滚动修补试跑。

## ⚠️ 8. 风险、不可作出的声明与止损

1. 修订发生在首例development差异已知之后，必须披露，不能把新结果包装为原精确重放准入成功。
2. 当前native与历史差异的根因仍未唯一定位；新同进程设计隔离比较目标，但不追溯认证历史。
3. 未保存历史预测坐标，当前标量历史差异不能定位到某个网络层；不因此新增预测保存或额外真实forward。
4. 独立的同进程旁路效应仍受当前checkpoint、推理环境和干预分布偏移限制；不外推临床或训练因果。
5. 任何新的历史事件迁移都须披露；不得用“只看本次配对”掩盖原QA-1安全风险。
6. 若研究目标必须依赖历史逐位复现，且环境证据无法补齐，则选择A停止，不能把方案B当作同一问题已解决。
7. 若仅能通过改阈值、换病例、重训、重新BNCal或额外参数扫描推进，停止本补充范围，另行决定是否结束路线。

## ✍️ 9. 审核项、权限顺序与当前停止点

待用户明确确认的核心决策：

- [ ] 选择方案B，并承认这是结果知情后的新诊断分支，不是旧失败修复/通过
- [ ] 旧0容差附件和失败结论不变；新分支不新增或放宽epsilon
- [ ] 历史身份/输入绑定是硬前提；纯历史数值、派生点数及flags差异独立记录，不再作为新配对采集停止门
- [ ] 当前配对以同实例/输入/权重/RNG和单出口语义为硬准入，任何失败立即停止
- [ ] 全105病例/315forward不删点；旧3次保留在累计318次账本
- [ ] 不以新结果补证历史训练/BNCal、不改变安全事件定义、不执行正式gate或晋级
- [ ] 同意最小R1-B适配，不增加通用框架，不重复已通过GPU preflight；实质计算变更须另议
- [ ] 确认协议仅确认设计，不授权实现、测试、部署、数据访问或执行

未来顺序为：协议确认 → 单独implementation-only授权 → 限定人工验证/P3与最终哈希 → 单独授权创建新request（待授权）→ 完整哈希单独执行授权 → 唯一一次新运行 → 单独正式只读冻结审计。Fold D仍需独立阶段授权。

本次停止在DRAFT_AWAITING_USER_CONFIRMATION。没有服务器操作、代码改动、容差改动、测试、GPU、NPZ/checkpoint读取或execution request。没有授权回执/runtime/launcher/tmux材料化，没有Git或长期备份声明。

## 🔗 10. 父证据及修订优先级

| 来源 | SHA256 |
|---|---|
| 原R1-B协议 | 30eeb37fcc6e0172849c5dd4a5a457180d59b9cc0e521a9234b81158bc88b035 |
| 已确认零容差附件 | 50bdafc97fe53405d9bd8f8557b08132ccf2c8d5fbb2f95e8a7ad733b0da0fe6 |
| 已消耗Fold C request | 69c10ecbae5189c6934c5502d1ea5f5f498ee8977183f4c86fc802c8538974b0 |
| 失败正式冻结审计 | 83b25b93acda7f7a62a06586f9def9a16f3cd3c75081d9eb8a4c4b127321ff34 |
| 数值条件只读调查 | bb592f1efa2dde9fae668c36b19f7e884a461bd1f0375dbd15b205ad67997053 |

[原协议](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_query_off_protocol_draft_v1_zh.md)、[已确认零容差附件](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_native_replay_tolerance_confirmed_v1_20261019.json)、[数值调查](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_foldC_historical_current_numerical_conditions_readonly_investigation_v1_20261019.json)提供本地精确来源；原协议文件名含draft但其内容哈希是既有已确认协议，不由本草案重新确认。

本草案若确认，仅对未来明确引用其哈希的新R1-B诊断分支，替换原协议第6.1节和第8节中“历史数值/事件精确重放作为当前诊断停止门”的部分，并澄清第4.3节RNG的当前环境含义；原权重、病例、指标、数据边界、旁路、预算和失败治理继续继承。对旧request、旧容差附件和已发生运行没有追溯效力。冲突以“未获确认不生效，未获执行授权不运行”为准。

本文按科学文档写作技能的决策记录结构编写，并用两轨判定图区分证据用途；技能只影响本机文档组织，不扩大操作权限。本次无新增外部文献或经验误差主张。后续修订新建v2，不覆盖v1。

