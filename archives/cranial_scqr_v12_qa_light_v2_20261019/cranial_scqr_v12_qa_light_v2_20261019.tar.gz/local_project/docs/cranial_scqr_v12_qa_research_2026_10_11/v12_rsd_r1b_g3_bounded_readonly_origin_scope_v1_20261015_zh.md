# G3 有界只读依赖来源核验范围与预算 v1

_Cranial-SCQR v1.2-RSD／R1-B · 2026-10-15 · 本机范围冻结，不执行服务器核验_

---

## 📋 1. 状态与唯一授权边界

本文配套的[机器可读范围文件](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_g3_bounded_readonly_origin_scope_v1_20261015.json)为权限、路径和预算的权威定义，状态为 `FROZEN_SCOPE_AWAITING_EXPLICIT_SERVER_READONLY_AUTHORIZATION`。

当前仅获准本机冻结范围。本文不是 execution request，不是授权回执、runtime config 或 launcher；不存在服务器执行授权。后续须对 JSON 的完整 SHA256 单独授权一次服务器只读核验，才能开始。

本机 v10 接口 P3 已通过，前三项接口缺口已在人工验收范围内关闭；但真实依赖身份 G3 未核验，[本机 P3](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_finite_v10_local_post_implementation_p3_gap_review_v1_20261014.json)中的 `deployment_ready` 和 `gpu_request_ready` 仍为 false。此次不继续扩展审计工具、不重跑人工测试。

## 🎯 2. 本次目标与不承诺的事项

未来单次核验只回答：固定入口相关的 PointNet2、Chamfer、核心 Python 包及启动 hook 的实际候选来源能否在限定路径中定位；其包装源码、安装记录和选定 ELF 元数据是否一致；哪些来源／ABI／加载条件仍未知。

允许有限源码与元数据内容指纹，不进行整个分发包代码扫描，不对研究扩展或 torch／numpy `.so` 做全量 SHA256，不递归解析系统 loader 闭包。仅 Python 可执行文件身份允许整文件 SHA256，受独立大小及全局读取预算限制。

```mermaid
flowchart TB
    accTitle: Bounded Origin Audit Authorization Flow
    accDescr: A locally frozen scope requires separate authorization before one server readonly pass; unresolved evidence stops work and no later inventory or GPU stage is automatic.
    freeze_scope["本机冻结范围预算"] --> user_authority{"单独核验授权？"}
    user_authority -->|无| wait_authority(["等待，不连接服务器"])
    user_authority -->|有| readonly_pass["一次限定来源核验"]
    readonly_pass --> audit_outcome{"来源与边界可核对？"}
    audit_outcome -->|否| stopped(["保留未知，停止"])
    audit_outcome -->|是| candidate_review["候选清单，本机冻结"]
    candidate_review --> later_authority(["后续库存另行授权"])
```

即使来源候选定位完成，也不能证明真实 import 成功、CPython310 扩展兼容、CPU 输入 hash 已实测、CUDA 等价、完整执行 P3 或 GPU request 就绪。

## 🔐 3. 身份、连接与文件系统边界

| 项目 | 冻结要求 |
| --- | --- |
| 连接方式 | WSL＋`hpc5000` WebShell，不改 SSH、端口或客户端配置 |
| 服务器项目 | `/home/jovyan/adapointr_work/PoinTr`，canonical cwd 必须一致 |
| 用户 | `jovyan`、uid 1000 |
| 环境 | `/opt/conda/envs/adapointr-mamba`，Python 主次版本 3.10 |
| 当前资源 | 本轮尚未观测，不照抄历史值作为新审计结果 |
| 身份门 | 新观测 hostname／GPU UUID 须匹配 JSON 中最后观测基线，才继续依赖内容读取 |
| 基线不符 | 仅返回非秘密身份差异，停止；不自动 resource-rebind |

历史基线来源为[2026-10-13 定向只读记录](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_minimal_chain_targeted_readonly_review_v1_20261013.json)，不是本轮鲜活证据。Python patch 版本和驱动信息记录，不据此宣布数值条件等价；未来实际执行仍须重新冻结精确 runtime 条件。

GPU 只允许一次身份元数据查询 name／UUID／driver；不初始化 CUDA、不导入 torch、不构造张量或模型、不运行 GPU 算子。所有服务器命令使用 Linux 的明确路径，不引用 `E:\` 或 `C:\`。本机规范仓库与备份目录不会被当作已同步服务器文件系统；不读取或认证长期备份目录。

## 📚 4. 精确种子与有限来源定位

### 4.1 项目种子

JSON 冻结了 22 个先验身份文件：parent9、canonical3、六个附加源码、两份仅 model 子映射配置，以及两个已观察包装源码。先比较 SHA256／已知 bytes；漂移停止，不覆盖、更新父哈希或读取真实结果。

另有 18 个历史文字级候选，包含模型注册导入、Transformer、misc、registry、PointNet2 与其他扩展包装入口。它们尚非当前服务器认证文件；只能在项目允许代码域内按明确名称及源码引用定位。新增传递路径须在打开前记录父源码、行号、literal import／loader 依据；最多四跳，未知动态表达式不能 eval／exec／import。

项目允许域仅为指定 `models`、`utils`、`extensions`、`tools` 代码路径和两份精确 YAML。不能遍历项目 data／datasets／checkpoints／logs／results／outputs；YAML 中出现的训练、dataset base、checkpoint 或历史授权字段不得展开或继承。v10 的 11 个文件目前是本机冻结实现，不假定已经上传或部署。

### 4.2 环境安装元数据

唯一包索引根为 `/opt/conda/envs/adapointr-mamba/lib/python3.10/site-packages`。最多一次顶层名称枚举，先筛选名称再读内容，不递归 ENV/lib，不跟随 RECORD 打开整个分发包。

JSON 的有限名单涵盖 torch、numpy、timm、einops、PyYAML、easydict、matplotlib，以及 PointNet2／Chamfer／注册入口扩展的安装候选；总计最多 16 个已选 distribution。未进入入口的 mamba-ssm／causal-conv1d 仅记录，不因为未安装或无关版本差异升级为必需依赖。

只读 allowlisted 的 `METADATA`、`WHEEL`、`top_level.txt`、`RECORD`、`direct_url.json`；wrapper 仅限有关 `.py/.pyi` 精确文件。direct URL 不原样输出，移除凭据、查询串和 fragment。metadata 文件不授予其引用目标的访问权限。包内 `timm/data` 等代码目录按依赖域处理，不误用项目 data 禁令；其中 payload、权重、样例数据仍禁读。

### 4.3 启动 hook、扩展与 ABI

最多八个顶层 `.pth` 作为启动 hook 文本检查，每个最多 64 KiB；只选 approved roots 中的 `sitecustomize.py`／`usercustomize.py`。这不是 checkpoint `.pth` 许可，也不允许执行 hook；未知或越界引用阻断就绪。

选定 ELF 最多 16 个，从已审核 wrapper literal、RECORD 路径或精确 provider 目录名称取得；每个只读最多 256 KiB 的 ELF 头／program header／dynamic strings／build-id 区段。记录 ELF class、machine、ABI tag、DT_NEEDED、RPATH／RUNPATH，不 dlopen、不 ldd、不 JIT、不执行安装脚本，不递归进入系统库。系统库路径和完整二进制 hash 留给下一阶段有限库存。

历史 CPython39 build 文件只能记录为历史构建残留，不能用来证明 CPython310 可加载；无 tag 或无法静态认证的 ABI 保留 unknown。若必要 PointNet2 来源无法在允许范围中定位，则记录 `REQUIRED_ORIGIN_UNRESOLVED` 并停止，不启用现有或新建的纯 torch fallback。受限搜索未发现不等于全局不存在。

## ⏰ 5. 冻结预算与计数规则

| 预算项 | 上限 |
| --- | ---: |
| 总墙钟时间，含网络等待 | 120 秒 |
| 服务器调用数／自动重试 | 6／0 |
| 单命令／单次传输等待 | 30 秒／15 秒 |
| 项目源码／依赖 wrapper | 80／48 个文件 |
| 元数据内容／全部唯一内容文件 | 64／200 个文件 |
| 唯一文本内容 | 16 MiB |
| 实际读取总量，含复核 | 192 MiB |
| 普通源码／单个元数据文件 | 1 MiB／4 MiB |
| Python 身份 hash 文件 | 64 MiB |
| ELF 根／每根读取／累计读取 | 16／256 KiB／4 MiB |
| site-packages 顶层 entries | 4096 |
| 累计枚举 metadata entries | 16000 |
| RECORD 每 distribution／累计行数 | 30000／60000 |
| stdout＋stderr 累计 | 512 KiB |
| 最终本机报告 | 1 MiB |

阶段预算为：身份 15 秒，继承种子与 literal import 30 秒，有限安装元数据与 hook 25 秒，所选 ELF 元数据 25 秒，返回及本机证据冻结 10 秒；另留累计传输 15 秒。阶段与全局限制同时成立，不能将六次调用都用满 30 秒。再次读取、hash 复核、目录元数据读取与传输均计入总预算。

这些是权限上限，不是保证足以完成核验的性能估算。工具不能严格执行预算时不得启动该阶段；不得靠输出截断、丢弃必要目标、减少哈希覆盖或自动增加预算来取得 PASS。未到阶段终点而超时，须保留已观察事实及首个失败，不补跑或从断点继续。

## 🚫 6. 禁止项与失败日志

始终禁止秘密目录、`auth.json`、真实 NPZ／STL、checkpoint／序列化权重、prediction／CSV、归档 payload，以及 `/home/jovyan/aic22-4090`。不枚举 home，不全文输出环境变量，不读取本机长期备份。只允许受限、脱敏的 PYTHONPATH／LD_LIBRARY_PATH／LD_PRELOAD 路径信息；未审查外部根或 preload 出现即停，不跟随它们。

读取前检查原始路径、每层 lstat、canonical 根、角色、类型及剩余预算。普通文件／目录链接拒绝；唯一预先定义例外为 ENV/bin 的解释器别名链，最多四跳且 target 仍在 ENV/bin。新增链接不能边执行边补白名单。

失败日志记录 phase、rule_id、安全精确路径、root、relative path、最后成功文件、计数、实际 bytes 与 elapsed。秘密只记脱敏类别，不输出原路径或内容。源码／元数据内容变化阻断，atime 不作为内容身份；metadata-only 枚举不得误记为内容 hash 已完成。

只读是“不主动改变服务器状态”的操作边界，不是假称工具没有标准库／原生加载器 IO，或 atime 永不变化。不得据 Python 守卫宣称操作系统级沙箱证明。

## ✅ 7. 完成标准与唯一停点

未来报告应分别列出：明确来源候选、required 未解析项、optional 未确认项、record-only 项、ABI 风险及未完成 loader 目标；每个选项有路径／域／理由，授权读取者有 bytes／hash 或 ELF 元数据，metadata-only 项不能伪造完整 hash。

若本范围内无未知阻断，最高终态仅为 `ORIGIN_CANDIDATES_RESOLVED_AWAITING_FINITE_SCOPE_REVIEW`。若仍有必要来源未知，则 `STOPPED_UNRESOLVED_NO_RETRY`；身份不符则 `STOPPED_RESOURCE_REBIND_REQUIRED`；超预算、边界或完整性失败则 `FAILED_STOPPED_NO_RETRY`。

服务器只返回有界 stdout，不写日志、结果目录、scope、runtime 或 launcher。单独授权实际核验后，可在本机项目 docs 新建版本化脱敏观测、报告和 SHA256 清单；输出不得覆盖旧文件，也不得用于认证长期备份或授权清理。

下一步仅等待用户对 JSON 完整 SHA256 的一次只读服务器核验授权。没有自动部署、完整库存、CPU probe、GPU preflight、训练、BNCal、development evaluation、统计或 gate。

## 🔗 8. 冻结依据与本轮实际操作

- [v10 正式本机冻结审计](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_finite_v10_post_test_readonly_freeze_audit_v1_20261014.json)
- [v10 本机接口 P3](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_finite_v10_local_post_implementation_p3_gap_review_v1_20261014.json)
- [已确认最小执行链方案](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_minimal_execution_chain_convergence_review_draft_v1_20261013_zh.md)
- [历史定向服务器观测](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_minimal_chain_targeted_readonly_review_v1_20261013.json)
- [远程操作规范](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/references/server_operations/remote_codex_experiment_operations_guide.md)

本轮仅本机读证据与规范，新增范围 JSON、中文说明及独立冻结回执；服务器连接／读取、实现修改、测试、真实库存、GPU 和 execution request 创建均为 0。markdown-mermaid-writing 技能用于范围表、预算表和授权边界图；未因此提交 Git、生成执行内容或扩大权限。各文件 SHA256 由独立回执单向绑定，避免自引用循环。
