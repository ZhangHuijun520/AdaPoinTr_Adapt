# R1-B PointNet2：B 阶段精确修复范围 v1

_2026-10-18｜方案待确认；未实施、未编译、未安装，不是 execution request_

---

## 📋 1. 结论与授权边界

本方案已确定上游源码身份、候选构建工具链、隔离命名空间及拟执行预算；但 CUDA 头文件路径、目标架构、两个拟适配文件的最终字节与构建入口尚未冻结，因此 `execution_ready=false`，不创建可执行安装 request。

已确认后端仍为 `POINTNET2_OPS_COMPILED_FP32_V1`。只有 PointNet2 在范围内；不改模型采样、v1.1 路径、Chamfer、Mamba、PyTorch、Python、NumPy、驱动或 CUDA runtime。

本次做了三次固定范围服务器只读采集；未执行编译器、包导入、setup、安装、测试、库存解析器或 GPU。公开上游归档仅在 Windows Python 内存读取、哈希和检查，没有保存源码副本、解包到磁盘或传到服务器。

## 🔗 2. 精确上游输入

| 项目 | 绑定 |
| --- | --- |
| 仓库 | `erikwijmans/Pointnet2_PyTorch` |
| Git commit | `b5ceb6d9ca0467ea34beb81023f96ee82228f626` |
| Git tree | `6d4f9bb2a208978859101817695feeb9b170286a` |
| commit 时间 | `2021-07-30T19:56:58Z` |
| 修复对象 | `pointnet2_ops_lib`，上游版本字段为 `3.0.0` |
| 完整归档字节数 | `20,722` |
| 归档 SHA256 | `a1e568a4f116eacfa41658077ba9c93efbce547856343857e09d1155211291e8` |
| 21 个包文件＋UNLICENSE 清单 | 22 项，3,371 字节 |
| 清单 SHA256 | `9456de4429724acf8370fda3a07d393339fb2c6539e2201b2109a845a97bd27b` |

来源为项目 README 已引用的仓库，不从未经核验的第三方 wheel 或 fork 替换。上述 commit 是本次锁定的候选源码身份，不是其在当前软件栈上已经通过兼容性认证的结论。

固定归档地址：
[上游固定 commit 归档](https://codeload.github.com/erikwijmans/Pointnet2_PyTorch/tar.gz/b5ceb6d9ca0467ea34beb81023f96ee82228f626)。

[本机源码清单](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_pointnet_upstream_source_manifest_v1_20261018.json)包含逐文件 bytes／SHA256；其规范序列化为按 path 排序的数组，键排序、紧凑 JSON，加一个 LF。已与内存归档独立形成的清单哈希核对一致。保留 UNLICENSE；不复制论文示例训练、数据与无关工程。

如果以后授权运输，建议精确文件名为 `pn2_b5ceb6d_upstream_v1.tar.gz`，本机建议位置为本项目 `server_uploads/pointnet2_cp310_repair_v1_20261018/`，服务器上传建议位置为 `/home/jovyan/pn2_b5ceb6d_upstream_v1.tar.gz`。这些位置本次均未创建或上传；未来必须重新核验实际下载／上传字节，不因 URL 相同接受哈希漂移。

## 🔍 3. 必须适配的两处合同

上游 setup 会覆盖架构环境变量，包装器在 native 导入失败时会调用 JIT 编译；原样执行不符合已确认的禁止 JIT 合同。[^1][^2]

仅拟适配以下两个上游文件；本次没有生成补丁或修改源码。

| 文件 | 原始 SHA256 | 拟适配边界 |
| --- | --- | --- |
| `pointnet2_ops_lib/setup.py` | `4cca631077dedf998f80a6b3af1c377518325b5cec5ecb12d993030c2ac23f59` | 不再覆盖冻结架构；构建入口固定、禁止下载依赖；拟采用非 Ninja 的串行构建 |
| `pointnet2_ops_lib/pointnet2_ops/pointnet2_utils.py` | `8558f8c958551ad7eb46990d08b563a095a8cd4038b4527f1c63609ee6c9bc6d` | native 导入失败立即报错，移除 JIT 分派；保留成功导入后的算子实现与导出 |

导入失败应保留原异常作为 cause，并抛出明确的不可用错误，不能再次抛出会被项目适配器吞掉、从而选择 toy fallback 的普通 ImportError。具体异常合同、人工检查和两文件最终 hash 必须在另行 implementation-only 阶段冻结。

构建方案优先在 setup 的 BuildExtension 配置中使用串行路径，避免仅凭已安装 ninja 元数据就假定 PATH 上存在可执行程序。PyTorch v2.4.1 的相应构建实现是审查依据，而不是本次已经运行的构建行为。[^3]

范围不包括修改 `_ext-src` 的 C++／CUDA kernel、FPS 初始点、tie-breaking、gather 或 backward 实现。若固定 torch 组合确实需要 C++／CUDA 兼容性改动，应停止并另交精确补丁范围，不能自动升级依赖或边失败边修复。

正式 preflight 的专用后端守卫仍是独立后续实施项，不混入此扩展修复；不把“构建成功”冒充其已完成。

## ⚙️ 4. 当前工具链证据与未解项

当前只读身份为 `shu-common-25721452-notebook-hwq6lx-0`、UID 1000，服务器项目为 `/home/jovyan/adapointr_work/PoinTr`。

| 项目 | 观测与约束 |
| --- | --- |
| Python | 3.10.20，SOABI=`cpython-310-x86_64-linux-gnu`；沿用已核验二进制 hash |
| torch | version.py 静态字段为 `2.4.1+cu118`，CUDA 字段 `11.8`；禁止升级／降级 |
| C++ ABI | TorchConfig.cmake 文本为 `_GLIBCXX_USE_CXX11_ABI=0`，不冒充动态导入实测 |
| C 编译器 | `/usr/bin/x86_64-linux-gnu-gcc-9`，1,158,288 字节，SHA256 `7633416c7f569942758cbffc9660b1f4b45f0abff0f076ea31b7d964b34cc694` |
| C++ 编译器 | `/usr/bin/x86_64-linux-gnu-g++-9`，1,158,288 字节，SHA256 `e0ffcd2e066c74a2707a8cd4b6fcee70965c8a111368ed7c2dc96ac0df0576ba` |
| nvcc | `/usr/local/cuda-11.8/bin/nvcc`，15,006,120 字节，SHA256 `e85eeb9af396e7aba7d92fd35539a94721ede321f5d2de27a6d1857507dfd1dc` |
| ninja | 安装元数据为 1.13.0，但当前 PATH 未找到命令；不自动重装，拟使用串行构建 |
| setuptools | 已读元数据为 83.0.0；版本存在不等于 setup 兼容已通过 |
| 可用磁盘 | 观测时 9,860,808,704 字节；执行前重新检查，不能把本次观测当长期保证 |
| CUDA 版本文件 | `/usr/local/cuda-11.8/version.json` 未见，不能仅凭目录名宣称 toolkit 全部就绪 |
| CUDA include | no-follow 打开在 `include` 组件被拒绝；未读到目标头文件／版本宏 |
| 目标 GPU 架构 | 本次未查询 GPU；不得从旧容器或 CUDA runtime 字段代填 |

最后一组只读调用退出码 1，错误是 `NotADirectoryError: ... 'include'`。这是路径守卫拒绝继续，不是源码编译失败。常见目录链接是可能解释，但本次未取到该组件的 lstat/readlink 证据，不将可能解释写成已确认事实。

因此仍需限定核对 include 的属性、精确链接目标及目标是否属于已授权 toolkit 根，同时补齐头文件、编译器版本文本和当前资源架构。不得为了继续而关闭 no-follow；任何确有必要的别名应先记录、审核，再以规范目标绑定，而非递归放开目录。

## 📦 5. 隔离目录与写入边界

拟固定唯一新命名空间：

`/home/jovyan/adapointr_work/PoinTr/third_party/r1b_pointnet2_cp310_b5ceb6d_v1_20261018`

本次只读观测为目标或其父目录不存在；未创建。执行前全部目标再次做不存在性与安全路径检查，已存在即停止。

| 相对路径 | 唯一用途 |
| --- | --- |
| `upstream/` | 经哈希核验的原始源码，保留不改 |
| `src/` | 仅两文件适配后的候选源码 |
| `build/`、`tmp/` | 本次构建与临时文件 |
| `wheelhouse/` | 仅本次 PointNet2 wheel |
| `provider/` | 旁路包提供者，不写全局 Conda site-packages |
| `control/` | 独立 request、回执、launcher、日志、PID／退出码与变更清单 |
| `cache/` | 仅显式必要缓存，不复用旧 JIT 产物 |

未来 provider 的可见性只能在获授权的单进程启动合同内固定，不修改全局 PYTHONPATH、sitecustomize 或 .pth；其源码／二进制／加载器来源必须纳入有限 scope。该路径调整本次也未实施。

原始源码保存与候选源码分离；不覆盖原 Conda 包、既有 third_party、模型文件或旧失败产物。不安装其他依赖，不从公网在服务器拉取“最新版本”。如果旁路方案需要额外改变现有执行合同，应先报告，不自动改模型或旧工具。

## ⏰ 6. 拟执行预算与失败即停

以下为有界修复方案的预算提案，不是已实现的运行时限额，也不是成功耗时预测。

| 资源／动作 | 上限或门槛 |
| --- | --- |
| 构建次数 | 一次，不自动重试 |
| 构建工作段 walltime | 1,800 秒 |
| 所有者进程清理预算 | 15 秒，只处理本次已登记进程 |
| 编译并发 | 1；最多两个授权 CPU 核的 affinity |
| 进程组内存 | 8 GiB；拟由任务专属限额／监控守卫约束 |
| 启动前可用内存 | 至少 12 GiB，当前未核验 |
| 新目录磁盘增长 | 至多 4 GiB |
| 启动前可用磁盘 | 至少 6 GiB，失败后仍保留原始证据 |
| master log | 至多 32 MiB，不截断后声称成功 |
| 服务器联网下载 | 0 |
| 扩展导入／算子测试 | 0；独立阶段授权 |
| GPU／模型 forward | 0 |

编译进程需要独立登记、非零退出与超时回执；必须先确认现有执行设施能落实 walltime、进程身份、资源上限和 no-overwrite。若内存上限等只能监测而无法可靠约束，应明确降低保证，不能在 request 中假称已实现硬隔离。

记录首个错误、准确文件／阶段、编译命令、工具链 hash、退出码、部分输出和已创建清单。不自动修补、修改 kernel、放宽预算、清理、切换源码或重新编译；不自动进入 CPU 导入检查或 GPU preflight。

## 🔐 7. 创建安装 request 之前的完成标准

必须全部满足才创建待授权安装 request：

1. 本方案及明确适配范围经用户确认；随后独立 implementation-only 授权产出两文件候选、静态审查／人工合同证据及最终 hash。
2. CUDA include 属性／规范目标、头文件与工具链版本、实际目标架构无歧义；未扩大为安装另一套 CUDA。
3. 冻结无 JIT 的候选源码、单次构建入口／supervisor 实现及输入 hash；方案不能替代实现与合同检查。
4. 原始归档已明确准备位置并完成运输核验；包与目录冲突策略、实际输出路径及资源强制机制已落实。
5. 冻结与 torch 2.4.1+cu118 对齐的构建参数，ABI=0；不以“版本号满足 torch>=1.4”证明当前兼容。
6. 不增加 GPU 试跑；构建、安装后只读审计、CPU import-only、正式 GPU preflight 分阶段独立授权。
7. 新 request 标记 `AWAITING_EXPLICIT_USER_AUTHORIZATION`，不提前创建授权回执、runtime 或 launcher；确认方案不等于允许编译。

本次上述标准尚未全部满足，所以没有创建 request。

## 🔗 8. 证据与当前唯一下一步

本文件按决策记录组织“已确定／未确定／拟执行”，避免把待确认方案写成执行事实。所有旧协议、已安装11工具和历史六运行结果不变。

当前建议下一步仅补齐 CUDA include 路径与剩余工具链／目标架构的限定只读证据；若涉及 GPU，只能另获元数据查询授权，不能执行 CUDA 计算。确认适配范围后再单独实施，不在本方案内滚动修补代码。

- [A 阶段只读结论](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_pointnet_cp310_phase_A_readonly_outcome_v1_20261018.json)，SHA256 `16dfc14e3b960b0d80077a6addff944f224c2dff662e43c7584d7dd7baa360a7`
- [已确认后端回执](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_pointnet_backend_policy_confirmation_receipt_v1_20261018.json)，SHA256 `789f2bd092e2d86f0df9a27e3289336a32c0a08e935e91ca8be96a1524eae462`

[^1]: 固定 commit 的 [setup.py](https://github.com/erikwijmans/Pointnet2_PyTorch/blob/b5ceb6d9ca0467ea34beb81023f96ee82228f626/pointnet2_ops_lib/setup.py)，另在内存归档中逐字节核验。
[^2]: 固定 commit 的 [pointnet2_utils.py](https://raw.githubusercontent.com/erikwijmans/Pointnet2_PyTorch/b5ceb6d9ca0467ea34beb81023f96ee82228f626/pointnet2_ops_lib/pointnet2_ops/pointnet2_utils.py)，以本次归档源码 hash 为内容身份。
[^3]: PyTorch v2.4.1 [cpp_extension.py](https://github.com/pytorch/pytorch/blob/v2.4.1/torch/utils/cpp_extension.py)，仅为构建方案参考，服务器真实文件仍需后续绑定。

