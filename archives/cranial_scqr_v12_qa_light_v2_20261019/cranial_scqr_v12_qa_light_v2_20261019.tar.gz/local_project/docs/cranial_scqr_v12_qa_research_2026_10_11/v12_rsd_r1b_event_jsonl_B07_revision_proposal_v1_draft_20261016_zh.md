# R1-B 事件 JSONL 合同与 B07 断言／诊断限定修订方案 v1 草案

_2026-10-16，Asia/Shanghai；DRAFT_AWAITING_USER_REVIEW。仅起草，不实施、不导入候选、不运行检查。_

---

## 📋 结论与依据

建议仅修订当前候选driver内的事件编码／读取接口、B07断言及有限失败诊断，并将对应回归并入同一套十项内存检查。不要只改变人工fixture来绕过Linux writer的真实合同冲突，也不要全局改变文档JSON编码。

既有[正式失败冻结审计](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_rebinding_failed_freeze_audit_v1_20261016.json)的SHA256为
`a4efa76d86ed51139a9299847db0053410e6109d7f011fb3671aa40d40fe83c4`。
冻结对象是失败批次，不是通过结果：B01–B06通过，B07为CONSUME_ORDER，B08–B10未执行，检查子进程退出码1。

[限定原因报告](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_rebinding_B07_readonly_cause_v1_20261016.json)的SHA256为
`c08ff668d40c41dc53ab530457186bd987335bea762535e09412451332d34343`。
已确认的源码事实是：json_raw使用indent=2；Linux writer与Memory.export均用其写事件；reader则按splitlines逐行json.loads。B07还把结果成功和调用顺序合在一个断言中。原始记录没有保留内部回执，故底层JSONDecodeError／EXPORT_VALIDATE只能标为源码推导，不能追填成旧批次实测日志。

时钟转发缺失假设已由源码排除，不属于本次修复范围。原批次已消耗，不得复用、补跑剩余三项或把新结果覆盖旧证据。

## 🎯 选择与修改边界

| 选择 | 影响 | 决定 |
| --- | --- | --- |
| 全局修改json_raw | 改变metadata、request等确定性字节合同 | 不采用 |
| reader兼容任意多行JSON | 弱化JSONL约定，事件分界仍不明确 | 不采用 |
| 只改人工fixture | Linux writer仍与reader不兼容 | 不采用 |
| 独立事件codec＋双方使用＋分离断言 | 直接覆盖已定位冲突 | 拟采用 |

未来若单独授权，最多修改一个现有实现文件：
[候选driver](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/local_tools/r1b_transport_return_contract_v1_20261016/transport_cpu_once_driver_v2.py)。
基线为52285字节，SHA256：
`b770ba6c50c1fc69b03e90611dadcd5ea2d45868150f6b861f633b3cf7e7d116`。

同目录adapter、tests和PowerShell保持原字节与哈希；旧r1b_launch_transport_v2_20261016目录完全不改。不新增第五实现文件，不创建新Linux目录，不改候选根路径、发行版、Python路径或原24项。

允许driver内集中修改的范围只有：事件专用编码／解析函数、Linux事件writer、Memory.export的事件构造、decode_prepared_export的事件读取调用、B07分离断言、检查失败诊断保存点，以及B07／B10的限定回归。其他B项语义、run_prepared的执行／授权／预算逻辑、首错与次错策略不变。

实施前应将旧driver原始字节以带bytes／SHA256的非可执行JSON载体冻结到DOCS版本化证据文件，保留失败版本的可恢复内容。该载体不是Linux副本、不是第五程序，不得用于运行。仅记录旧哈希而不留旧内容不等于可恢复归档。本次尚未生成该载体。

## 📚 事件 JSONL 的共同字节合同

### 文档与事件编码分离

json_raw函数的源码与行为必须逐字保持不变；metadata、source-binding、plan、request、授权回执、runtime及普通结果文档继续使用原确定性文档JSON格式。新事件编码建议具名event_raw，事件解析建议具名parse_event_log，均留在现有driver。

| 对象 | 格式 | 使用者 |
| --- | --- | --- |
| 普通JSON文档 | 原json_raw，indent=2 | 现有文档读写者 |
| 单条事件 | 无缩进的单行JSON＋一个LF | Linux writer、人工fixture |
| 整段事件流 | 顺序拼接零条或多条完整事件 | export reader |

单条事件合同拟定为：dict对象，包含字符串phase；UTF-8无BOM，sort_keys=true、ensure_ascii=true、allow_nan=false、separators为逗号与冒号紧凑形式，不使用indent；末尾恰一个LF。字符串内部的换行必须JSON转义，不形成第二条物理行。只约束已有事件字段的编码形状与已有capture校验，不扩建完整事件业务schema。

Linux event writer与Memory.export必须调用同一个event_raw，禁止各自拼接两套近似格式。写入前按实际编码字节计数，继续保留整份events.jsonl≤1048576字节限制。目录权限、排他创建、fsync、事件顺序及旧五文件集合不变。

### reader的限定行为

parse_event_log应只接受bytes，在解码前检查原1MiB上限，严格UTF-8解码。空字节日志可解析为空事件列表，以容纳首条事件前失败；这不意味着批次成功，成功仍由既有结果／计数／manifest合同决定。

非空日志要求每条为完整单行JSON对象、phase为字符串、末尾LF完整；不接受BOM、CRLF、空白行、无末尾LF、截断JSON、标量／数组、非有限数值或重复键。可通过重新event_raw后逐字节比较实现确定性格式拒绝，不能默默修复、跳过、补尾或拼接旧多行事件。

reader继续调用现有validate_capture验证事件中已有stdout／stderr载体。事件解析失败转换成可定位的安全错误：稳定规则、固定逻辑文件名events.jsonl、1起算行号；不得附带原始行、完整异常消息或自由路径。具体规则建议区分EVENT_JSONL_ENCODING、EVENT_JSONL_FORMAT、EVENT_JSONL_SYNTAX与EVENT_JSONL_CAP，最终实现须让writer／reader／回归使用同一映射。

不改变manifest哈希校验顺序，不接受缺失events.jsonl，不把旧格式错误改成UNKNOWN成功。既有失败证据保持原字节，不迁移转换或重新计算其manifest。

## 🔍 B07 分离断言与诊断合同

### 断言分离

B07首个“合法人工路径”子场景先保留实际结果和安全诊断，再分开验证：

1. 结果退出码严格为0，不满足时规则为B07_RESULT_NOT_SUCCESS。
2. 已消耗／已分派／已收集等既有结果标志与成功语义一致，不满足时使用独立结果规则。
3. 事件顺序严格为CONSUME、VERIFY_PREPARED、BATCH、EXPORT，不满足时才使用CONSUME_ORDER。

不得改为只检查顺序而忽略结果失败，也不得放宽为包含某几个事件。后两个已有目录拒绝和旧request拒绝子场景保留；若前一子场景失败，仍立即停止，不继续执行它们。

### 失败前保存上下文

在检查入口局部维护“当前case安全上下文”，每项开始清空，每次内存run返回后、任何后续断言前立即记录。上下文不能依赖测试已经通过才能输出，也不能覆盖wrapper断言与内部首错之间的区别。

| 字段 | 允许内容 |
| --- | --- |
| case／subscenario | 固定编号和固定子场景名 |
| wrapper_error | 类型和稳定断言规则 |
| inner_first_error | 经过允许列表过滤的类型／规则／阶段 |
| inner_secondary_errors | 最多8条安全规则与阶段 |
| inner_result | exit_code、batch_exit_code及已消耗／分派／收集／冻结布尔状态 |
| events | 最多16个固定阶段名，保留顺序 |
| logical_location | events.jsonl及可用行号 |

每case诊断JSON编码后≤4096字节；超界时按固定优先级保留内部首错、wrapper规则及关键布尔状态，明确标记省略数量。不输出request内容、源码、绝对自由路径、日志原文、完整回执、凭据、argv、异常消息或traceback。不能调用str(exception)作为无界诊断；未知类型／规则使用固定UNKNOWN标识。

检查总结果建议使用独立版本标识r1b-return-contract-interface-checks-v2，明确新增诊断结构；不改变生产授权文档、r1b-controller-result-v3或Linux五文件合同。检查产生的原始stdout／stderr继续由外层以无损字节载体保存bytes与hash。

B07失败诊断应能区分“内部export校验失败”与“实际顺序不符”。不能重写run_prepared原来的first_error、secondary_errors以使断言通过；诊断只是安全摘录。

## 🧪 限定回归矩阵与执行预算

本次不运行任何检查。后续建议完成新静态S0/S1后，仅执行一次新的版本化B01–B10批次；保留十个顶层编号、顺序及既有检查目的，不新增第十一项、不单独补跑B07，不运行旧PC／RC、原24项或Linux入口。

| 顶层项 | 拟定回归补充 |
| --- | --- |
| B01–B06 | 保留，核对绑定／授权合同未漂移 |
| B07 | 合法链独立断言成功与顺序；保留两个拒绝子场景；安全上下文先于断言 |
| B08 | 保留固定argv／legacy拒绝；随新事件codec使用完整合法链 |
| B09 | 保留批次失败＋export失败的首错／次错；核对诊断不篡改原结果 |
| B10 | 生产共用codec→人工事件流→真实export reader往返及拒绝分支 |

B10限定子场景：空事件流、两个有序事件及包含中文／内嵌换行的字符串往返；旧indent=2多行格式拒绝；BOM／CRLF／空白行／缺LF／截断JSON拒绝；非对象／重复键／非有限值拒绝；原manifest重复、大小上限与capture哈希负例保留。负例必须在重算人工manifest后到达预定事件规则，不能被更早的无关哈希错误挡住还声称覆盖事件解析。

B07或B10内增加有限诊断自检：用人工无效事件流得到非零内层结果，验证稳定规则／阶段／逻辑行号可保存；该负例预期拒绝本身不得令整批失败。另以明确的纯人工结果与事件列表验证“结果失败但顺序正确”不会误报CONSUME_ORDER；不为验证诊断启动额外测试批次。

单批总墙钟≤30秒，每项≤2秒，首个非预期失败即停；不自动修复重跑，不增时。仍使用Windows Python隔离子进程，审计钩子拒绝检查内部文件写入、目录变更、子进程、网络；所有业务IO均在内存，旧PC／RC和原24执行计数为0。普通外层证据写入与纯内存检查的边界分别记录。

## 🔐 静态门、版本留存与验收标准

S0必须核验driver基线及旧字节载体、仅一个实现文件发生变化、其他三文件未变、json_raw函数AST及原字节不变、受信bootstrap／PROGRAM不变、原24与旧八项函数不变、新入口仍默认不执行。核对所有事件写端共用codec，不能只匹配函数名存在。

S1集中核对event_raw与parse_event_log字节合同、非空／空流和限额、错误定位、B07分离断言、上下文先于断言与失败即停、诊断允许列表和上限、完整export reader调用路径。源码审查应区分已证明的接口一致与尚未执行的分支，不再把AST能解析等同于合同已通过。

新实施证据文件统一使用新的版本化前缀，例如
v12_rsd_r1b_event_jsonl_B07_hotfix_v1_20261016；
不得覆盖v12_rsd_r1b_rebinding_memory_attempt_v1_20261016.json或任何旧结果。本次不创建新attempt、request或runtime。以后新检查前需记录独立的一次性测试attempt及最终driver哈希；旧attempt不得再次使用。

未来driver变更后，其最终哈希由尚未创建的source-binding等后续文档绑定。CLOSEOUT_SHA仍保留已确认的四文件收尾方案；本修订方案作为独立实施证据引用，不为了“填未来hash”修改元数据或新增逆向依赖。本机候选根不变不代表旧Linux准备或执行授权可复用；没有授权则不查询／创建Linux目标。

验收分层：新静态门通过＋新十项检查通过，只能说明候选修订通过有限本机人工验证。之后仍须另行授权正式post-test freeze audit及P3缺口复核；本次不能进入副本准备、原24request或部署。若需改第二实现文件、改根路径、放宽授权／payload守卫或扩大审计范围，停止报告，不滚动扩展。

## 📍 审核门与本次实际交付

本草案待用户确认。确认方案与授权实施分开；建议将来的实施授权限定为：只修改现有候选driver，冻结旧driver非可执行字节载体，集中修订事件codec、B07断言／诊断与对应B07／B10回归；S0/S1通过后执行唯一一次新版本十项纯内存检查，失败即停，不自动修复重跑；不改adapter／tests／PowerShell，不调用WSL、不准备Linux副本、不运行原24项。

本次仅新增本文及SHA256清单；使用文档技能的决策记录结构与合同／回归表区分事实、推导、拟定改动和后续门。读取既有原因材料和相关源码，源码编辑、模块导入、检查／测试、WSL、复制、清理、服务器操作、GPU与执行材料创建均为0。
