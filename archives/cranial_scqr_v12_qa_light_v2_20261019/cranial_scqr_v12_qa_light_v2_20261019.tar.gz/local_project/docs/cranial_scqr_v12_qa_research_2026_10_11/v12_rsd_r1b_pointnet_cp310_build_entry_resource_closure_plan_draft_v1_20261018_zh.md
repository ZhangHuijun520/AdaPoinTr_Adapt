# R1-B PointNet2 单次构建入口与资源约束收尾方案 v1

_2026-10-18｜决策草案，待确认；仅制定方案，不是 execution request_

---

## 📋 1. 结论、范围与不变量

本轮只把 B1–B4 四项执行缺口合并收尾，不重新设计已经通过的两文件候选或17项本机合同。当前状态为：本机候选冻结与限定 P3 通过，完整构建就绪 P3 未通过。证据见[正式冻结与 P3 复核](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_pointnet_cp310_post_test_freeze_P3_gap_review_v1_20261018.json)，SHA256 为 `8d505e23d08942b5ad2156299eef1c14cc7f9834b8cd6a734f285511a5b9d4a4`。

推荐决策是：先一次性核清实际可用的资源约束机制，再限定实现专用单次构建入口，最终只生成一个 PointNet2 wheel 并停止。不得把构建成功解释为安装、CPU import-only 或人工 GPU preflight 的授权。

本方案不调整已有数值阈值，不自动接受“轮询监测等同硬限额”。不能实现既定预算时，停止并提出具体选择，而不是继续扩展工具链。

保持以下不变量：

- 两份候选源码及17项测试文件不变；不改 native kernel、模型、v1.1、Chamfer、Mamba、Python、PyTorch 或 CUDA
- 不使用 toy fallback、JIT、第三方预编译 wheel，不访问真实 payload／checkpoint／development 数据
- 不复用现有 CPU 库存审计 supervisor，不重跑原17项或更早24／85／130项测试链
- 不覆盖旧目录，不自动重试、resume、清理或提权
- 本次仅新增方案文档与绑定记录；不编写入口，不准备源码副本，不生成运输包，不连接服务器

## 🔗 2. 沿用的输入与身份

| 输入 | 已冻结身份 |
| --- | --- |
| 上游 commit | `b5ceb6d9ca0467ea34beb81023f96ee82228f626` |
| 原归档 | 20,722 bytes；SHA256 `a1e568a4f116eacfa41658077ba9c93efbce547856343857e09d1155211291e8` |
| 22项源码与许可证清单 | SHA256 `9456de4429724acf8370fda3a07d393339fb2c6539e2201b2109a845a97bd27b` |
| 候选 setup.py | 2,241 bytes；SHA256 `355449d8e807e303bf60942a920d4daa9c14098281898128ff7fceb93e745b34` |
| 候选 pointnet2_utils.py | 9,943 bytes；SHA256 `ec597d77b1215fbc87bdb452b8ce04b85eb0b816d5e39e7696fc792a2f61ea5b` |
| 既有17项测试 | SHA256 `c480cd56fb3c898edbf1cb8f84cf6257b3c3cffaad2ef6daaa967e7d3c3e177b` |

服务器身份仅沿用此前快照，不冒充本次重新核验：hostname 为 `shu-common-25721452-notebook-hwq6lx-0`，UID 1000；GPU UUID 为 `GPU-34a1b996-2bd7-88e6-9dca-164b718caea6`，计算能力8.9。

拟继续使用 Python3.10.20、torch2.4.1+cu118、GCC/G++9.4.0、nvcc11.8.89，编译架构仅 `8.9`，ABI证据为0。实际解释器、工具、链接器及执行身份必须在创建构建 request 前绑定；旧快照不是长期保证。

服务器拟用唯一新根目录仍为：

`/home/jovyan/adapointr_work/PoinTr/third_party/r1b_pointnet2_cp310_b5ceb6d_v1_20261018`

以下用 R 表示该精确路径，仅为文档简写，不是待执行 shell 变量。Windows 本机路径仅用于管理与运输，绝不能出现在服务器 argv 中。

## 🎯 3. 先解决资源保证，禁止失败后自动换路线

### 3.1 默认路线：保留聚合硬限制

默认仍要求专属构建任务的聚合内存上限8 GiB，不以单进程限制或 RSS 求和轮询替代。拟优先核查当前已有 cgroup-v1 memory 任务约束／合法委派；不为本任务新增通用 v1/v2／调度器适配框架。

memory cgroup 的计量对象不等同于逐进程 RSS；memory 和 memory+swap 也不是同一个限制。必须按实际内核接口记录计量与 swap 语义，不能声称约束所有未纳入计量的系统内存。[^1] Python 的单进程资源限制也不能直接证明整个编译任务的聚合上限。[^2]

为消除本草案中的口径歧义，默认推荐将8 GiB同时作为计量内存及memory+swap总量上限；若memsw接口不可用，须有任务不使用swap的可验证依据，否则视为保证不足。此为待确认的预算口径，不擅自修改既有执行协议，也不通过关闭系统swap来满足它。

推荐操作边界：

1. 构建 controller 及全部编译／打包子进程应在专属任务约束内，supervisor 位于约束外以保留失败回执能力；其自身开销另记，不冒充也计入8 GiB。
2. 释放任何构建工作前，必须得到专属任务归属、8 GiB 限制及继承关系的证据；已有平台任务只有满足专属性与阈值才能使用。
3. 若必须创建专属 cgroup 或写任务归属文件，须列出精确 cgroup 路径及操作，在后续执行范围中获得单独明确授权；它不是默认的项目目录写权限。
4. 不移动外部任务，不改父 cgroup、容器总限额、驱动、系统 swap 或调度器设置，不 sudo、不自动申请管理员权限。
5. 内存触限／OOM事件必须使本次失败，即使外层进程意外返回0也不能判成功。

若没有可用机制，状态为 `RESOURCE_GUARANTEE_UNAVAILABLE`。此时只报告：缺哪个接口／哪级权限／哪份平台凭据，以及是否需要用户选择另一个资源条件。监测停止模式可作为另行讨论的替代保证，但本草案不自动启用它，不更改8 GiB阈值或把保证降级写成已确认。

### 3.2 12 GiB 启动余量的定义

不得直接使用宿主机 `MemAvailable` 证明容器能分配12 GiB。拟采用保守门槛：宿主可用量与当前任务相关各级有限祖先的“限制减计量用量”中的最小值，均须可解释且不少于12 GiB。

该检查针对创建8 GiB专属子任务之前的承载环境／祖先余量，不能把新子任务自身8 GiB限额再代入并与12 GiB比较。swap不能冒充物理内存余量；不能把可回收缓存全部视为已预留资源。读取未知、层级不可见或计量语义无法解释时停止，不估填数值。

### 3.3 唯一一次必要补证的拟范围

以下只是未来服务器只读核验的范围草案，当前没有授权执行。

- 一次固定批次，总 walltime不超过60秒；远端各段不超过15秒，不自动重试
- 最多32个精确普通文件，内容总量不超过8 MiB；单文件不超过2 MiB；目录只列一级，最多64项
- 只读核验身份、解释器／已选工具和有限的配置元数据；不导入 torch，不调用 setup，不运行编译器输入、实验或库存解析器
- cgroup来源仅为 `/proc/self/cgroup` 与 `/proc/self/mountinfo`；先冻结由它们导出的当前 memory 路径和最多4级相关祖先，后续精确读取限制／用量／层级／swap与任务归属文件属性
- 不打印 cgroup 中其他任务列表，只保留必要的当前归属与“是否专属”的证据；不能确认专属即未知
- 精确补核 Conda `compiler_compat` 下实际链接器别名、规范目标及哈希，以及已选构建路线上必要的 setuptools／wheel 命令实现来源；不递归扫描 Conda／CUDA
- 若任何预算不足，不拆成无限续页、不增加扫描深度；列出未核清的精确项目，结束本批次

实际调用前必须冻结32项以内的具体路径／规范化映射及单段预算。动态来源只能用于形成第二段精确列表，不得未经检查直接跟随链接或扩大到任意祖先。路径过深、文件过大、跨根目标或别名循环均停止。不得读取秘密配置内容或完整环境变量。

## ⚙️ 4. 单次构建入口的唯一推荐路线

### 4.1 构建 wheel，不安装 provider

推荐使用现有、已绑定环境中的 setuptools wheel 命令，单次受监督的 Python 进程生成 wheel，不调用 pip／conda／包解析器／PEP517隔离环境，不升级或拉取依赖。

拟定 argv 合同是：固定 Python → 隔离源码中的 setup.py → 固定 build-base 的 build → bdist_wheel，并把 wheel临时树及输出目录固定到 R 内。最终 argv 必须在实施后冻结为数组，不通过 shell 字符串拼接；本草案不提供可直接粘贴运行的 launcher。

将 setup.py 直接作为受控命令入口是一项针对已锁定旧工程的窄范围选择，不是通用安装推荐。setuptools 的 wheel命令内部会使用临时安装树进行打包，因此“未安装 provider”指不写 Conda site-packages 或正式 provider，不声称打包过程没有内部 install 子命令。[^3]

完成前必须静态核清：

- 同一进程中 build 的已执行状态与 bdist_wheel 的再初始化行为；整个任务只触发一次实际 extension build，不靠失败后第二次命令补齐
- bdist树的全部路径留在 R 内，并启用保留临时树的选项；不事后清理失败产物
- 正常打包在本次新临时树内的 metadata 转换／替换行为列入明确写入白名单，不把它授权为删除旧文件
- wheel包含所需 Python包装器与一个正确命名的原生扩展，metadata版本为3.0.0、平台／ABI标签匹配；检查只读 ZIP／metadata，不导入扩展
- 原 UNLICENSE 随交付材料保留，不因 wheel生成而丢失或伪造许可证

成功状态只能是 `WHEEL_BUILT_PENDING_READONLY_FREEZE`。R/provider/本阶段不创建、不写入；之后的旁路安装、导入与 preflight仍须分别授权。

### 4.2 进程、身份和完成合同

新入口不修改、不直接调用现有库存 CPU supervisor。它的旧流程和1,300秒上限不适用于本构建。

拟用一个专用 Python工具合并controller与supervisor角色，避免多层入口适配；子角色通过固定参数、同文件哈希绑定。工作进程必须先进入独立 session，完成 PID／starttime／PGID／SID 登记、资源归属和 affinity 设置后，才获得一次 release。supervisor全程保留首错；后续日志／收尾错误记为次级错误。

以下全部满足才允许成功：

1. 授权request、回执、runtime、入口和输入哈希一致，唯一运行标记已不可覆盖地消费
2. 原生构建只启动一次，退出码0，未触发超时、预算、OOM或身份守卫
3. 本次已登记任务没有残留子进程；不把tmux消失或主PID退出当完成
4. 恰好一个wheel，通过ZIP成员、bytes、哈希和metadata检查；没有未知额外二进制
5. 完成回执与精确产物清单均已写入新路径；任何观察不确定都不得标PASS

tmux只承担承载作用，不是超时／资源／完成证明。WebShell或PowerShell返回0也不能替代服务器完成回执。PowerShell入口仍显式传回 `$LASTEXITCODE`；WSL使用已验证的 `--exec` 参数边界，不添加新的传输框架。

### 4.3 环境与离线含义

未来白名单至少包含固定 PATH、Python/CUDA/编译器路径，`TORCH_CUDA_ARCH_LIST=8.9`、`MAX_JOBS=1`、`CUDA_VISIBLE_DEVICES=""`、禁止bytecode、R内HOME／TMP／cache及禁止core dump。外部编译flags、`NVCC_PREPEND_FLAGS`、`NVCC_APPEND_FLAGS`、`LD_PRELOAD` 等注入不继承；必要共享库路径逐项绑定，不凭空删除后试错。

构建工具可导入已绑定的预装torch与setuptools；不得导入本次新生成的PointNet2扩展，不作CUDA计算。预设架构意在避免构建工具依赖GPU自动探测，不把环境变量本身当GPU隔离证明。PyTorch构建行为仍以已绑定的2.4.1实现为准。[^4]

“服务器下载0”拟由无解析器、无JIT、固定本地输入、无升级／联网分派的审查合同保证；不将其冒充内核级禁网。若要求任意代码都无法联网，必须另有平台隔离能力，不能由本方案默认实现。

`--no-user-cfg`、隔离HOME及精确项目输入用于控制用户配置影响；仍须核清环境级配置、命令插件／entry points对所选build路径的实际影响。只核必要入口，不重新展开通用依赖库存。

## 📊 5. 资源预算与保证等级

以下数值沿用原方案；新增的是可核验的含义，未声称已经落实。

| 项目 | 数值 | 拟保证／失败行为 |
| --- | --- | --- |
| 构建尝试 | 1次 | 唯一claim，失败消费，不重试 |
| 工作段期限 | 1,800秒 | 单一单调时钟，整段共享 |
| 收尾期限 | 15秒 | 独立共享，超时记未回收确认 |
| 编译并发 | 1 | 候选守卫＋固定命令 |
| CPU affinity | 最多2核 | release前设置，子进程继承 |
| 专属任务聚合内存 | 8 GiB | 任务级硬限制，机制未核清即停 |
| 启动有效可用内存 | 至少12 GiB | 当前承载环境的保守余量 |
| R内增长 | 4 GiB | 有界监测阈值，不伪称硬配额 |
| 启动剩余磁盘 | 至少6 GiB | 新鲜statvfs，不当作预留 |
| master log | 32 MiB | 有界管道捕获，超量触发失败 |
| 服务器下载／GPU计算 | 0 | 固定离线路线，不派发实验 |

工作段从入口开始验证授权与启动前条件计时，包括验证、staging、资源归属、build、wheel检查和完成回执；不是给每个子命令分别1,800秒。输入运输在该段之外，不能在计时段内等待用户上传。15秒为失败回收与失败回执共享预算，不延长构建工作段。

4 GiB拟定义为R内普通文件逻辑大小的增长，保守按路径计数；禁链接／稀疏文件规避，不把压缩占用当完整代价。拟每250 ms完成一次有界核验，单次不超过250 ms，最多4,096项；无法按时完成、超数量／路径异常即停止。这个机制可能在采样间超额，无法给出无依据的最大超调量；它是监测停止合同，不是文件系统硬配额。若用户要求4 GiB绝不被瞬时超过，需要另有任务级配额，不自动宣称满足。

master log由supervisor读管道，最多写32 MiB；超出时保留首个超量错误和已捕获内容并终止本次，不无声截断后判成功。管道背压与失败后的15秒清理均计入合同。stdout/stderr不直接无限重定向到文件；失败摘要单独最多64 KiB，并计入R的磁盘统计。

1,800秒是已定义的工作deadline，不是对supervisor遭SIGKILL、容器销毁或内核不响应的绝对保证。此类情况保持 `COMPLETION_UNCONFIRMED` 或 `PROCESS_REAP_UNCONFIRMED`，不自动重启。

## 📦 6. 输入准备、运输与写入映射

未来按以下顺序实施，当前都未执行：

1. 在本机核验原始归档及22项清单，准备“原始源树＋两文件候选delta＋UNLICENSE＋入口工具”的运输材料
2. 原始源树不变；候选只替换两个已批准文件，明确两套hash，不把补丁后的源树仍标成上游原字节
3. 冻结归档bytes／SHA256、逐文件清单、精确服务器映射、工具链与预算证据；由用户完成上传
4. 单独授权上传后只读核验；所有目标重新核验不存在，链接／越界／循环均拒绝
5. 全部执行前提完成后，才创建待授权build-only request；状态保持 `AWAITING_EXPLICIT_USER_AUTHORIZATION`
6. 用户单独授权该完整SHA256后，才按单向绑定顺序材料化回执、runtime、一次launcher，执行staging和唯一一次build

R内写入仅限原始 `upstream/`、候选 `src/`、`build/`、`tmp/`、`wheelhouse/`、`control/`、`cache/`。其中 `src/` 是可产生egg-info等metadata的工作副本，不要求构建后字节全不变；原始 `upstream/` 及构建前源文件绑定不变。R/provider/留给后续授权，不在本次build-only写入白名单。

cgroup等项目外路径若确需操作，必须单列精确映射和授权，不能藏在上述目录权限中。归档安装不覆盖用户文件，不删除服务器旧产物；没有用户的本机下载核验确认，不作任何“已备份所以可删除”的判断。

## 🔍 7. 限定实施与验收，不扩展旧测试链

### 7.1 未来实施范围上限

若资源能力核清且另获implementation-only授权，最多新增以下三个候选文件，暂拟放在本机 `server_overlays/r1b_pointnet2_build_entry_v1_20261018/`：

| 拟新增文件 | 单一职责 |
| --- | --- |
| run_pointnet2_build_once_v1.py | 专用controller／supervisor、限额与回执 |
| test_pointnet2_build_entry_contract_v1.py | 新入口的限定人工合同 |
| pointnet2_build_scope_template_v1.json | 未授权模板，不是runtime |

源码／scope模板不是执行回执。运输清单及审计文档是证据产物，另行列出，不以工具数量上限掩盖新增代码。既有两个候选、17项测试和CPU库存工具都不修改。

### 7.2 仅验新入口的12类人工合同

拟一次运行12类内存人工检查：输入哈希漂移、目标已存在、单构建argv、环境／配置注入、登记与release顺序、共享deadline与非零退出、首错与清理身份、硬限额能力缺失、有效内存余量、affinity错误、磁盘监测异常、日志超量与失败回执。

这些是新增入口的必要验证，不是扩展原17项测试。使用假时钟、假进程和人工文件描述，不运行真实编译器、不准备WSL副本，不访问真实数据。失败即停，不自动修复重跑。

纯内存通过不证明Linux进程回收／cgroup强制有效。后续平台资源凭据和执行前在gated子角色上的设置／读回检查仍不可省；若需要新增独立Linux无害进程测试，必须明确报告其必要性并另获授权，不能由12项人工通过推导出许可。

### 7.3 完成标准与停止预算

收尾只允许：一次限定补证、一组入口实施、一次12类人工验证、一次正式冻结与P3复核；不包含自动失败修复循环。任何新缺口集中到一次清单，不每发现一点就新增版本工具。

创建build-only request必须同时满足：

- B1：入口和scope最终哈希、唯一claim、argv、角色协议及完成判断齐全
- B2：精确本地构建路线、编译／链接工具来源、配置与离线边界齐全
- B3：8 GiB硬限制和12 GiB余量有可操作证据；其余预算实现与保证等级明确
- B4：源树、许可证、delta和运输映射已核验，候选与原始身份可区分
- 新入口的12类人工检查及独立冻结／P3通过，但不冒充真实构建兼容性
- request不包含provider安装、扩展import、CUDA smoke test或GPU preflight

若条件不齐，全局状态仍为 `NOT_READY_NO_EXECUTION_REQUEST`，不生成“先建一个可执行request再补证”的空壳。

## 🔐 8. 授权顺序、决策与唯一下一步

```mermaid
flowchart TB
    accTitle: PointNet2 Build Closure Gates
    accDescr: 先确认方案并单独核清资源能力，能力不足即停止；能力明确后才实施入口并验证，最终创建待授权构建请求，不自动执行。
    draft_confirm["确认本收尾方案"] --> resource_evidence["单独授权有界补证"]
    resource_evidence --> capability_ok{"资源与工具条件明确"}
    capability_ok -->|否| stop_state(["停止并报告精确阻断"])
    capability_ok -->|是| entry_implementation["单独授权入口实施"]
    entry_implementation --> review_once["限定验证与冻结 P3"]
    review_once --> transfer_review["另行运输与上传核验"]
    transfer_review --> pending_request(["创建待授权 build request"])
```

确认本草案仅表示接受默认硬限制路线、预算含义和分阶段顺序，不等于授权服务器补证或本机写入口。若同时授权下一阶段，应明确说“仅授权一次有界资源与实际构建工具链只读补证”。

关键待确认决策：

1. 接受默认8 GiB专属任务硬限制路线，无法落实时停止；不自动接受监测替代
2. 接受4 GiB为有界监测停止阈值而非硬配额，32 MiB为捕获文件上限
3. 接受单次build-only生成wheel后停止，不捆绑provider安装或import
4. 接受最多三个入口候选文件和一次12类人工合同，既有17项链保持封存

本方案采用决策记录结构与一张授权门控图，明确区别“已核验”“拟选择”“未实现”，不生成图片、不运行渲染，不改变实验方案或数值阈值。

## 🔗 9. 证据与参考依据

- [本机两文件实施回执](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_pointnet_cp310_two_file_implementation_outcome_v1_20261018.json)，SHA256 `81f27c6e697254f3e8ec68f0caeb24e81893197321c77418a57d8215c8fd69ba`
- [路径与工具链只读补证](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_pointnet_cp310_phase_B_path_toolchain_readonly_supplement_v1_20261018.json)，SHA256 `1b782f62b5ee3662ef4c1c78fd5060260a30ea3003ee59f9aa02aca953cda4e5`
- [正式冻结与P3复核](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_pointnet_cp310_post_test_freeze_P3_gap_review_v1_20261018.json)，SHA256 `8d505e23d08942b5ad2156299eef1c14cc7f9834b8cd6a734f285511a5b9d4a4`

以下公开资料只解释机制／审查所选命令，不替代服务器实际文件哈希或运行认证。当前setuptools文档将部分直接命令列为历史接口；本方案的例外必须锁定具体83.0.0来源，不把“文档有命令”当作当前环境兼容证据。[^5]

[^1]: Linux Kernel. Memory Resource Controller（cgroup-v1，文档自身注明历史局限）。https://www.kernel.org/doc/Documentation/cgroup-v1/memory.txt
[^2]: Python. resource — Resource usage information，Python3.10。https://docs.python.org/3.10/library/resource.html
[^3]: setuptools v83.0.0. bdist_wheel 命令源码，临时打包树与内部命令行为。https://raw.githubusercontent.com/pypa/setuptools/v83.0.0/setuptools/command/bdist_wheel.py
[^4]: PyTorch v2.4.1. cpp_extension.py。https://github.com/pytorch/pytorch/blob/v2.4.1/torch/utils/cpp_extension.py
[^5]: setuptools. Running setuptools commands。https://setuptools.pypa.io/en/latest/deprecated/commands.html
