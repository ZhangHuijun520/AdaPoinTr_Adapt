#!/usr/bin/env python3
"""24 tiny artificial stdlib CPU contracts; never scans production or imports torch."""
import ast
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tarfile
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent


def module(name):
    spec=importlib.util.spec_from_file_location(name,HERE/(name+'.py'))
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m


e=module('audit_synthetic_pf_dependencies_v2')
c=module('install_synthetic_pf_implementation_v2')


class Clock:
    value=0
    def __call__(self): return self.value


class FakeProcess:
    pid=123
    def __init__(self,reap=True): self.code=None; self.reap=reap; self.calls=0
    def poll(self): return self.code
    def wait(self,timeout):
        self.calls+=1
        if self.calls==1 or not self.reap: raise subprocess.TimeoutExpired('fake child',timeout)
        self.code=-9; return self.code


class Contracts(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.base=Path(self.temp.name)
        self.root=self.base/'fixture'; self.root.mkdir()
        self.clock=Clock(); self.p=e.Progress(self.base/'progress.jsonl',self.clock)
        self.p.emit('START'); self.p.begin('ENUMERATE')

    def tearDown(self):
        if not self.p.stream.closed: self.p.close()
        self.temp.cleanup()

    def put(self,name,data=b'x'):
        p=self.root/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(data); return p

    def scan(self): return e.enumerate_files([self.root],[self.root],self.p)

    def test_01_inert_import_and_sources_compile(self):
        for name in c.NAMES:
            source=(HERE/name).read_text(); compile(source,name,'exec')
            tree=ast.parse(source)
            self.assertFalse(any(isinstance(n,ast.Import) and any(x.name=='torch' for x in n.names)
                                 for n in tree.body))
        self.assertNotIn('torch',__import__('sys').modules)

    def test_02_old_selection_coverage_same_fixture(self):
        for n in ['a.py','a.pyc','a.cpp','a.cu','a.h','a.hpp','lib.so','lib.so.1',
                  'pkg.dist-info/METADATA','pkg.dist-info/RECORD','ignored.txt','fake.npz']:
            self.put(n)
        expected={p.resolve() for p in self.root.rglob('*') if p.is_file() and
            (p.suffix in ('.py','.pyc','.cpp','.cu','.h','.hpp') or
             __import__('re').search(r'\.so(?:\.[0-9]+)*$',p.name) or
             '.dist-info' in str(p.parent) and p.name in e.META)}
        found,_,_=self.scan(); self.assertEqual(set(found),expected)

    def test_03_required_classes_selected(self):
        for n in ['x.py','x.pyc','x.cpp','x.cu','x.h','x.hpp','lib.so.9','pkg.dist-info/WHEEL']:
            self.assertTrue(e.selected(Path(n)))

    def test_04_alias_dedup_keeps_binding(self):
        a=self.put('a.py'); b=self.put('b.py')
        original=Path.resolve
        def resolve(p,*args,**kwargs):
            if str(p)==str(b): return original(a,*args,**kwargs)
            return original(p,*args,**kwargs)
        with patch.object(Path,'resolve',resolve):
            files,aliases,_=self.scan()
        self.assertEqual(len(files),1); self.assertEqual(aliases[str(b)],str(a.resolve()))

    def test_05_forbidden_payload_pre_read(self):
        p=self.put('fake.npz')
        with self.assertRaises(e.ContractError): e.safe_path(p,[self.root])

    def test_06_secret_path_rejected(self):
        p=self.put('secrets/a.py')
        with self.assertRaises(e.ContractError): e.safe_path(p,[self.root])

    def test_07_escape_rejected(self):
        p=self.base/'outside.py'; p.write_bytes(b'x')
        with self.assertRaises(e.ContractError): e.safe_path(p,[self.root])

    def test_08_directory_link_fail_closed(self):
        self.put('a.py')
        # Simulate a directory-link entry without requiring Windows symlink privileges.
        class Link:
            path=str(self.root/'link'); name='link'
            def is_dir(self,follow_symlinks=False): return False
            def is_symlink(self): return True
        with patch.object(e.os,'scandir') as scan, patch.object(Path,'is_dir',return_value=True):
            scan.return_value.__enter__.return_value=iter([Link()])
            with self.assertRaises(e.ContractError): self.scan()

    def test_09_permission_error_not_swallowed(self):
        with patch.object(e.os,'scandir',side_effect=PermissionError('fixture')):
            with self.assertRaises(PermissionError): self.scan()

    def test_10_mutation_rejected_before_content(self):
        p=self.put('a.py'); fp=e.fingerprint(p); p.write_bytes(b'changed')
        self.p.begin('HASH_CONTENT')
        with self.assertRaises(e.ContractError): e.hash_file(p,fp,self.p)

    def test_11_loader_missing_rejected(self):
        with self.assertRaises(e.ContractError): e.parse_loader('lib.so => not found',self.root,[self.root])

    def test_12_entry_cap_no_truncation(self):
        self.put('a.py'); self.p.limits['entries']=1
        with self.assertRaises(e.ContractError): self.scan()

    def test_13_file_cap_no_truncation(self):
        self.put('a.py'); self.put('b.py'); self.p.limits['files']=1
        with self.assertRaises(e.ContractError): self.scan()

    def test_14_byte_cap_before_open(self):
        self.put('a.py',b'123'); self.p.limits['bytes']=2
        with self.assertRaises(e.ContractError): self.scan()
        self.assertEqual(self.p.counts['completed_bytes'],0)

    def test_15_metadata_cap(self):
        self.put('pkg.dist-info/METADATA',b'123'); self.p.limits['metadata_bytes']=2
        with self.assertRaises(e.ContractError): self.scan()

    def test_16_total_and_phase_exact_boundary(self):
        self.clock.value=120
        with self.assertRaises(e.ContractError): self.p.check()
        self.clock.value=0; self.p.limits['total_seconds']=1; self.clock.value=1
        with self.assertRaises(e.ContractError): self.p.check()

    def test_17_single_file_deadline(self):
        p=self.put('a.py'); self.p.begin('HASH_CONTENT'); self.p.limits['file_seconds']=1
        def opener(path): self.clock.value=1; return path.open('rb')
        with self.assertRaises(e.ContractError): e.hash_file(p,e.fingerprint(p),self.p,opener)

    def test_18_progress_flush_and_correct_hash(self):
        p=self.put('a.py',b'artificial'); files,_,_=self.scan(); self.p.begin('HASH_CONTENT')
        row=e.hash_file(p,files[p.resolve()],self.p)
        self.assertEqual(row['sha256'],hashlib.sha256(b'artificial').hexdigest())
        rows=[json.loads(x) for x in (self.base/'progress.jsonl').read_text().splitlines()]
        self.assertEqual(rows[-1]['event'],'FILE_END'); self.assertEqual(rows[-1]['counts']['completed_bytes'],10)

    def test_19_incomplete_no_completion_and_one_way_authority(self):
        self.assertFalse((self.base/'completion_v2.json').exists())
        with self.assertRaises(e.ContractError): e.validate_authority({'status':'DRAFT_AWAITING_USER_CONFIRMATION'})
        q={'status':'AUTHORIZED_ONCE_CPU_IMPLEMENTATION_V2','proposal_sha256':e.PROPOSAL_SHA,
           'permissions':{'deploy':True,'canonical_cpu_regression':True,'new_cpu_tests':True,
           'cpu_inventory_once':True,'p3':True,'gpu':False,'real_payload':False,'checkpoint':False,
           'training':False,'request_creation':False},'limits':e.LIMITS,'phase_limits':e.PHASES,
           'tmux_session':e.SESSION,'archive_sha256':'a'*64}
        self.assertEqual(e.validate_authority(q),q)
        q['permissions']['gpu']=True
        with self.assertRaises(e.ContractError): e.validate_authority(q)

    def test_20_parent_watchdog_phase_boundary(self):
        row={'phase':'HASH_CONTENT','monotonic_seconds':10}
        self.assertFalse(c.stage_expired(row,489)); self.assertTrue(c.stage_expired(row,490))
        self.assertTrue(c.stage_expired({'phase':'PUBLISH','monotonic_seconds':70},80,20))

    def test_21_owned_process_group_reap(self):
        events=[]; report=c.terminate_owned(FakeProcess(),clock=self.clock,killer=events.append)
        self.assertTrue(report['reaped']); self.assertEqual(len(events),2)

    def test_22_unconfirmed_reap_never_pass(self):
        report=c.terminate_owned(FakeProcess(False),clock=self.clock,killer=lambda _:None)
        self.assertFalse(report['reaped']); self.assertEqual(report['status'],'PROCESS_REAP_UNCONFIRMED')

    def test_23_p3_reader_fields_and_zero_permissions(self):
        p=c.compatible_p3({},[],{}, {},{}, {},[])
        self.assertEqual(p['status'],'PASS_SYNTHETIC_PREFLIGHT_IMPLEMENTATION_ONLY')
        self.assertFalse(p['gpu_used']); self.assertFalse(p['execution_request_created'])
        self.assertEqual(p['real_model_constructions'],0)
        self.assertIn('NOT_ASSESSED',p['gpu_600_second_readiness'])
        src=(HERE/c.NAMES[0]).read_text()
        tree=ast.parse(src); calls={ast.unparse(n.func) for n in ast.walk(tree) if isinstance(n,ast.Call)}
        self.assertNotIn('torch.load',calls); self.assertNotIn('torch.cuda.init',calls)
        self.assertNotIn('build_model',calls)

    def test_24_archive_and_json_fail_closed(self):
        p=self.base/'duplicate.json'; p.write_text('{"a":1,"a":2}')
        with self.assertRaises(e.ContractError): e.strict_json(p)
        p.write_text('{"a":NaN}')
        with self.assertRaises(e.ContractError): e.strict_json(p)
        archive=self.base/'fixture.tar.gz'; expected={n:'a'*64 for n in c.NAMES}
        with tarfile.open(archive,'w:gz') as tar:
            member=tarfile.TarInfo('../escape.py'); member.size=1; tar.addfile(member,io.BytesIO(b'x'))
        with self.assertRaises(RuntimeError): c.validated_members(archive,expected)


if __name__=='__main__': unittest.main(verbosity=2)
