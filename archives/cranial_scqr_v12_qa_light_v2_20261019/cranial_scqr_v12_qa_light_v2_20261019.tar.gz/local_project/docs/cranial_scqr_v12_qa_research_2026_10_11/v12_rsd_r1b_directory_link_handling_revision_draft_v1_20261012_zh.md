# Cranial-SCQR v1.2-QA R1-B：目录链接处理修订方案与人工回归范围 v1

_待确认技术决策草案 · 2026-10-12 · 仅文档，不是 implementation 或 execution 授权_

---

## 📋 状态与授权边界

| 项目 | 状态 |
| --- | --- |
| 草案版本 | `directory-link-handling-v1` |
| 状态 | `AWAITING_EXPLICIT_USER_CONFIRMATION` |
| 本次允许 | 新增本机方案文档、阅读已有代码与证据 |
| 本次禁止 | 代码修改、测试、部署、库存审计、GPU、真实数据与 checkpoint 访问 |
| 已消耗 request | `6a48d67eda532a06d31156ff49b578f523bc89444d1a0e0ce678ae6254622386` |
| 后续执行 | 必须新版本、新路径、新 request 和单独完整 SHA256 授权 |

确认本草案仅代表接受设计；除非用户另外明确授权 implementation-only，否则不得据此修改代码、准备测试副本或执行测试。也不得自动创建部署 execution request。既有 v5 运输包、授权回执、launcher、失败目录、日志与 request 保持不变，不覆盖、不清理、不复用。

## 🔍 背景、证据及结论限制

### 已确认的失败事实

[本机失败观察记录](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_v5_cpu_deployment_failure_observation_v1_20261012.json) SHA256：

```text
8bcbfcf144c34d38622def9bb4f2ae4afaf45875c8d6a4b1e7ccd541c4ae9b44
```

v5 单次服务器执行中，67＋27＋67 CPU 测试均通过且子进程退出码为 0。库存子进程退出码为 1、`timeout=false`；在 `ENUMERATE` 阶段触发 `ContractError: directory symlink`。记录为 entries=40、files=23、planned_bytes=8874300、completed_bytes=0。最终 P3 未发布，注册进程组已回收并独立观察为空。CPU 测试通过不能替代库存覆盖、发布门控或 CUDA 等价性证明。

### 前一阶段只读调查观察

环境根 `ENV=/opt/conda/envs/adapointr-mamba`；项目根 `ROOT=/home/jovyan/adapointr_work/PoinTr`。前一阶段通过 WebShell 仅读取目录元数据，观察如下；本次起草未重新连接服务器。

| 链接（相对 ENV） | 原始链接文本 | 严格解析目标（相对 ENV） | 目标边界 |
| --- | --- | --- | --- |
| `lib/terminfo` | `../share/terminfo` | `share/terminfo` | ENV 内、lib 扫描根外 |
| `lib/python3.1` | `python3.10` | `lib/python3.10` | ENV 内、lib 扫描根内 |

两个目标均存在、为目录、规范路径，设备号均为 223。目标属主为 uid=1000、gid=100，目录模式为 0755。`share/terminfo` 直接子项计数为 42；`lib/python3.10` 为 207。未读取这些目标的文件内容，未证明链接的软件包来源或完整内容类别。

当前 `lib/terminfo` 在 lib 顶层枚举中为第 36 项。冻结实现先计入四个根，再以栈 LIFO 首先处理 ENV/lib，因此 36＋4=40 与失败计数吻合。这是强吻合的触发点推断，不是历史路径直接记录：失败日志没有 offending path，且目录枚举顺序不应作为未来策略或稳定身份。

项目 models/utils/extensions 顶层调查未发现链接；没有完成其全树链接普查，不能据此声明全树无链接。既有失败日志与本机记录均不得被改写为更强结论。

### 当前守卫为何失败

[v5 库存源码](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/r1b_synthetic_pf_impl_v5_20261012/audit_synthetic_pf_dependencies_v5.py:183) 对目录符号链接无条件拒绝。既有 test_08 专门验证这一默认拒绝行为，test_04 只验证文件别名去重，不覆盖受控目录别名。这是冻结策略与当前环境目录布局不兼容，不等同于发现恶意链接、环境损坏或超时。

## 🎯 选项比较与推荐决策

| 选项 | 收益 | 主要代价 | 草案选择 |
| --- | --- | --- | --- |
| 保持全部目录链接拒绝 | 逻辑简单、默认最严格 | 已知环境无法完成库存 | 保留为未列名默认行为 |
| 跟随所有 ENV 内目录链接 | 减少兼容性阻碍 | 扩大扫描、重复与循环风险 | 不采用 |
| 跳过所有目录链接 | 容易实现 | 静默漏扫、缺乏覆盖证明 | 不采用 |
| 两条精确规则＋默认拒绝 | 授权范围可审计、覆盖可解释 | 必须新增绑定、去重和发布验证 | 推荐待确认 |

推荐不递归进入任何目录符号链接：对 `python3.1` 只登记别名，目标由规范实体路径扫描一次；对 `terminfo` 只登记显式内容排除，不枚举其子树。未列名目录链接继续失败即停。文件符号链接保留现有必需库哈希覆盖，但必须逐条验证解析链和授权边界，不因目录例外而放宽。

`terminfo` 排除是需要用户确认的覆盖口径变更，而非“保持全环境覆盖”。新的 PASS 只能表示明确扫描根、选择器及排除项下的 CPU 静态代码/库库存通过；不得称完整 ENV 所有内容库存通过。若以后必须把该目标纳入范围，应另行修订协议和授权，不能自动跟随。

## 🔐 精确规则与不变的权限边界

### 扫描根与解析根分开

原有四个内容扫描根不变：`ROOT/models`、`ROOT/utils`、`ROOT/extensions`、`ENV/lib`。ENV 是资源与解析边界，不等于所有 ENV 子树都获准内容扫描。项目内但不在上述静态根中的数据、结果、凭据等也不获准访问。

静态 loader 阶段既有明确系统库根与必需依赖哈希规则保持不变；不得通过目录链接规则隐式扩大 `/usr/lib`、`/lib` 或 NVIDIA 库的内容扫描范围。

### 仅两条目录链接清单

| policy_id | 精确链接路径 | 精确 raw target | 精确 canonical target | 动作 |
| --- | --- | --- | --- | --- |
| `ENV_PYTHON_ALIAS_V1` | `ENV/lib/python3.1` | `python3.10` | `ENV/lib/python3.10` | `ALIAS_ONLY_REQUIRE_CANONICAL_COVERAGE` |
| `ENV_TERMINFO_EXCLUSION_V1` | `ENV/lib/terminfo` | `../share/terminfo` | `ENV/share/terminfo` | `EXPLICIT_CONTENT_EXCLUSION_METADATA_ONLY` |

上述 ENV 缩写只用于文档。未来生产 policy 必须绑定完整绝对路径、原始文本、目标类型和动作，随最终源码/policy 哈希进入新 request 与回执。不得按 basename、前缀、glob 或“凡 ENV 内”匹配；`python3.1evil`、其他位置的 `terminfo` 等不匹配。

生产前置核验要求两条规则各命中恰好一次。缺失、变为真实目录/普通文件、raw target 改变、目标不存在、类型改变、权限不明、增加中间链接或规范路径变化均失败，不能自动更新清单。设备/inode 是本次身份快照，不把旧容器数值硬编码为跨容器永久身份；目标路径/raw target 等逻辑绑定保持冻结。

允许项的含义不是授权遍历：两条链接都不得加入递归栈。`terminfo` 目标仅允许解析链及目录类型/权限/身份等必要元数据；不读取内容、不扫描子项。任何 loader 必需内容若指向显式排除目标，必须报告范围冲突并失败，不能把“已排除”当作完成必需哈希。

秘密目录、payload/checkpoint 后缀、禁止的嵌套 data/datasets/logs/results/checkpoints 守卫继续适用于原始路径和解析路径。未知链接即使落在 ENV 内、指向已扫描目录，也不能因 visited 命中而免于清单验证。

## ⚙️ 别名去重、越界与循环拒绝

### 分类与决策顺序

先验证路径授权，再进行去重；顺序不可反转。

```mermaid
flowchart TB
    accTitle: Controlled Directory Link Decisions
    accDescr: Directory links are validated before deduplication. Only exact alias or exclusion rules proceed; unsafe or unlisted links stop the workflow.

    inspect_link["读取链接元数据"] --> validate_chain["验证路径链和身份"]
    validate_chain --> chain_ok{"边界及身份通过？"}
    chain_ok -->|否| stop_workflow(["记录失败并停止"])
    chain_ok -->|是| match_policy{"精确规则匹配？"}
    match_policy -->|否| stop_workflow
    match_policy -->|是| choose_action{"冻结动作类型？"}
    choose_action -->|别名| bind_alias["登记别名与覆盖义务"]
    choose_action -->|排除| record_exclusion["登记元数据及排除原因"]
    bind_alias --> final_gate["发布前重验绑定与覆盖"]
    record_exclusion --> final_gate
```

### 规范目录与文件内容去重

1. 实体目录按规范绝对路径维护 pending/visited，登记 `(st_dev, st_ino)` 身份。目录别名只登记 alias→canonical 关系，绝不递归跟随；目标必须通过独立的规范实体路径被枚举完成。不同枚举顺序不能改变文件集合和内容哈希集合。
2. 对 `python3.1` 先登记也可以，但只能作为待验证覆盖义务；最终 canonical 目标未 visited、扫描中失败或身份漂移，都不得 PASS。不能把“目标存在”当作“目标已完整扫描”。
3. 选中文件继续按严格解析后的规范文件路径唯一哈希，保留每条可接受文件别名及其绑定。相同目标的大小只计入 planned/completed bytes 一次。别名本身仍计入 entries，不能用去重绕开 entry 预算。
4. 不新增跨不同规范路径的普通硬链接内容合并规则：保留现有计数口径。对不同目录路径出现同一 dev/inode 等难以解释的目录身份冲突，失败而非猜测两者等价。挂载别名也不自动获得授权。
5. 目录链接本身没有内容 SHA256；应对 raw target 文本及规范化 policy/绑定记录计算 SHA256，同时保存 lstat 身份。不得把链接文本哈希称为目标目录内容哈希。
6. alias record 不伪造别名子树的逐文件遍历记录。manifest 必须能证明 canonical 目录已扫描，并明确别名仅映射关系；不能制造未观察的路径覆盖。

### 解析链、安全拒绝与竞争条件

解析每次限制最多 32 次符号链接跳转，使用既有 phase/whole deadline；32 跳是新增更严格解析上限，不能扩展旧预算。逐组件跟踪已访问链接身份，重复身份、自指、互指、祖先回指或超过上限均报告 `DIRECTORY_LINK_CYCLE_OR_HOP_LIMIT` 并失败。去重不能吞掉循环。

`../share/terminfo` 中的 `..` 不是独立失败理由；按冻结文本解析后仍须逐组件符合授权元数据边界。但“先越界再返回”的解析链、指向 ROOT/ENV 外、经过凭据/真实数据目录、经未批准目录链接绕路，全部拒绝，且不得打开目标内容。两条例外预期为单跳、规范实体目标；额外中间链接即策略漂移，即使最终路径相同也失败。

所有合法链接保存前后 lstat、raw target、目标 stat 和规范路径，排除 atime，仅比较内容/身份相关字段（dev/inode/mode/nlink/size/mtime_ns/ctime_ns），发布前再次核验。inode/ns 整数在机器可读证据中不得经过浮点舍入。

未来实现应对实体目录采用 Linux 目录 FD 锚定、逐组件 no-follow 校验，扫描前后核对 fstat 与路径身份；选中文件使用已有 bounded/no-follow 内容读取和前后指纹。无法验证权限、身份或稳定解析时失败，不能 catch 后继续。测试模拟的稳定性通过，不足以声称 NFS 并发恶意重绑定已被完全消除；如果实现只用 resolve＋前后 stat，必须明确其非原子 TOCTOU 限制，不得宣传为原子安全。任何实现设计偏离这些要求应先提交修订，而不是临场降级。

## 📝 失败路径日志、manifest 与发布门控

### 结构化记录

目录链接每次分类至少记录以下字段；失败时无需所有值成功解析，未获得值用 null，附具体错误，不能丢失已经获得的原始路径。

| 字段组 | 必须字段 |
| --- | --- |
| 运行与阶段 | schema、run_id、UTC、phase、event、policy_sha256 |
| 原始位置 | scan_root、entry_path、entry_name、entry_index、path_kind |
| 链与动作 | raw_target、resolved_target、policy_id、action、reason_code |
| 身份与绑定 | link_fingerprint、target_fingerprint、link_text_sha256、boundary_result |
| 覆盖与预算 | canonical_scan_required、canonical_scan_completed、entries/files/bytes、deadline |

事件建议为 `DIRECTORY_LINK_OBSERVED`、`DIRECTORY_ALIAS_BOUND`、`DIRECTORY_EXCLUSION_BOUND`、`DIRECTORY_LINK_REJECTED`、`DIRECTORY_LINK_REVALIDATED`。路径中控制字符必须 JSON 转义，避免日志注入；不得读取或记录 token/凭据内容，禁止路径只记录诊断所需的路径元数据。日志错误、flush/fsync 失败或截断导致证据不完整，也必须失败。

异常应包含 offending path、可获得的 raw/resolved target、reason_code 和 phase。外层 failure receipt 保留首个真实错误及这些字段；不能只留下 `CONTROLLER_NONZERO`。后者可作为父进程失败状态，但不是完整根因替代。

### 内容覆盖与排除披露

完成 manifest 与最终 P3 应绑定同一 policy SHA256，并包含 directory_aliases、directory_exclusions 及各记录的内容相关指纹。policy 必须由独立的 request/auth/source 绑定提供期望值，不能从 candidate 反向推导合法清单。

排除条目须明确 `target_contents_enumerated=false`、`target_contents_hashed=false`、reason=`EXPLICIT_NON_SCANNED_TERMINFO_SUBTREE`。这表示协议排除，不是证明该目标没有 `.py/.so` 文件。禁止用“零字节排除”暗示目录为空或全部内容已核验。若对排除的充分性有异议，应先扩大协议审查而非暗中扫描。

最终 gate 必须独立重验两条规则、原始及目标身份、所有文件别名、canonical 目录覆盖、manifest 引用、测试计数、必需哈希及已有父文件。发布前篡改 policy、替换链接、变更目标、删掉排除条目或候选声称扫描了未扫描子树，都必须失败。发布仍使用不可覆盖同文件系统硬链接和既有 fsync/不确定提交失败约束；不得增加 overwrite/copy fallback。

### 不变预算

保留 entries=200000、files=50000、内容 bytes=8589934592、loader_targets=32、metadata_bytes=16777216、file_seconds=120、inventory_seconds=900、workflow_seconds=1300、cleanup_seconds=15、handshake_seconds=5，以及原有阶段/shared budgets。链接解析、身份与发布重验都消耗现有时间预算，不开启额外计时窗口、不因 heartbeat 重置 deadline。

链接记录计入已有元数据/完成证据大小约束；异常路径日志不能无限积累。未知链接在首个失败处停止，不为搜集更多错误继续扫描。不得以兼容性为理由提高任何既有上限。新增日志到既有 JSONL 时不破坏原消费者；新增字段的严格解析、manifest allowlist 与 artifact cap 必须同步更新并测试。

## 🧪 人工 CPU 回归测试范围

### 测试条件与旧测试保护

仅使用新隔离目录中的人工文本、目录和链接；不使用真实 ENV/lib 作为 fixture、不连接服务器、不导入 torch/CUDA、不读取真实 NPZ/checkpoint，不复用旧失败输出。纯人工解析逻辑可通过 mock 表达；实际链接、目录 FD、no-follow、inode 稳定性等仅在经单独授权的本机 Linux/ext4 测试环境验证。Windows 不支持 symlink 权限时不得 skip 后声称原生契约已通过，也不能以 mock 代替原生证据。

保留原 67 项 artificial contract 和 18 项本机进程场景的独立统计。test_08 继续验证未知目录链接默认失败；不能把它改成“任意目录链接通过”。test_04 保留文件 alias 内容去重断言。历史 85 项通过证据不被修改，也不能当作新增策略的测试结果。

以下新增 32 个独立测试契约（`DL01`—`DL32`）为预注册范围，不是当前已经实现/运行的测试。未来静态审查应冻结方法名与数量，禁止以一个参数循环暗减场景数。若实现为旧67＋新32，人工组预期99、本机进程组18、合计117；服务器若沿用 pre/canonical/post，拟为99＋27＋99，必须在新实现与 request 中另行核验和冻结，当前不授权这些次数。

| ID | 人工场景 | 必须断言 |
| --- | --- | --- |
| DL01 | 精确 python alias 正向匹配 | 绑定别名，不跟随链接 |
| DL02 | canonical 先枚举 | 目标扫描一次、别名有覆盖证明 |
| DL03 | alias 先观察 | 仅记义务，最终 target 扫描完成才可通过 |
| DL04 | target 未完成扫描 | final gate 拒绝 |
| DL05 | target 子树选中文件 | 哈希集合与无 alias 基准完全相同 |
| DL06 | 文件 alias 重复目标 | 内容 bytes/hash 不重复，aliases 不丢失 |
| DL07 | 精确 terminfo 排除 | 只记录元数据，目标枚举/打开 spy 为0 |
| DL08 | 排除记录覆盖口径 | 明确内容未扫描/未哈希，不能称全ENV |
| DL09 | 排除目标被 loader 必需引用 | 范围冲突失败，不跳过必需内容 |
| DL10 | 未列名 ENV 内目录链接 | 默认失败，记录完整路径 |
| DL11 | 同名异位置或近似 basename | 不匹配清单 |
| DL12 | 两条规则之一缺失 | 生产策略完整性失败 |
| DL13 | 列名链接变为目录/普通文件 | 类型漂移失败 |
| DL14 | raw target 改变、最终目标相同 | 精确文本绑定失败 |
| DL15 | 链接悬空/目标类型改变 | 无内容读取，明确错误 |
| DL16 | target ROOT/ENV 外 | 越界拒绝，外部内容打开0 |
| DL17 | 链经过外部后返回 | 逐组件拒绝，不以最终路径放行 |
| DL18 | 链经过秘密/payload路径 | 访问前拒绝，无内容泄漏 |
| DL19 | 单链接自指 | 循环失败，不去重吞掉 |
| DL20 | 双链接互指 | 循环失败、有链诊断 |
| DL21 | 指向祖先目录 | 拒绝回指，不递归 |
| DL22 | 超过32跳或额外中间链接 | 上限/精确策略失败，预算不重置 |
| DL23 | symlink readlink/lstat 权限错误 | 不吞异常，保留 offending path |
| DL24 | 观察后替换 link inode/raw text | final revalidation 失败 |
| DL25 | 保持路径但替换 target inode | 身份漂移失败 |
| DL26 | 实体目录 FD/路径身份不符 | 锚定验证失败，无降级 |
| DL27 | 不同目录规范路径同 dev/inode | 目录身份冲突拒绝 |
| DL28 | 只有 atime 变化及大整数精度 | 不误判内容漂移，整数不舍入 |
| DL29 | entries cap 与 deadline触发 | 别名仍计entry、失败即停，无预算扩张 |
| DL30 | 控制字符路径或日志写失败 | 转义完整，日志失效不能PASS |
| DL31 | candidate/policy/排除证据篡改 | 独立绑定及引用gate全部拒绝 |
| DL32 | 完整新policy人工commit与阶段锁 | 满足全部gate才发布，失败不发布、不重试、不进入GPU |

DL31 内多个子断言须列出覆盖字段，不能仅改一个字段就声称所有篡改场景覆盖。DL28 对 atime 的测试只证明新比较器语义，不追溯宣称旧失败由 atime 导致。原生链接测试需同时验证链记录与目标内容未被打开；不能只有 exception 断言。

## 📦 未来 implementation-only 影响范围

本节是建议，不授予实施权限。后续应新增独立 v6 四文件，保持 v5 四文件及 canonical GPU/preflight 工具不变：

- `audit_synthetic_pf_dependencies_v6.py`：精确 policy、绑定解析、元数据日志、目录alias/exclusion和必需覆盖gate
- `install_synthetic_pf_implementation_v6.py`：绑定新源码/policy、准确新测试计数、生成新candidate，不覆盖v5
- `supervise_synthetic_pf_implementation_v6.py`：独立验证policy、链接/目标身份及覆盖证据，保留原进程/发布守卫
- `test_synthetic_pf_dependency_audit_v6.py`：保留旧契约意图，新增32项人工回归；原18进程场景不弱化

采用源码内嵌精确 policy 并计算 canonical JSON SHA256；若另存policy文件，将不再是四文件运输包，必须先修订文件清单，不能临场补第五个生产文件。任何 import 顶层不得创建目录或运行CPU/GPU；旧文件不能因新模块 import 被写入 pycache。

v6 必须采用全新 run_id、stage/output/P3、job root/auth/control/launch、session和日志/PID/退出码/once-marker路径。完整路径在后续方案实施范围和 execution request 中冻结，本草案不创建可执行配置。不得复用v5的已存在stage/output/auth或旧request。

父证据使用只读继承绑定，v5失败证据追加为负结果父材料；新policy不会追溯改变v5结果。新增逻辑不能改变模型结构、metric、数据split、统计阈值、BNCal、development、训练、GPU preflight权限或任何数值设置。

## 📍 分阶段后续流程与验收

| 阶段 | 需要的单独确认/授权 | 明确禁止 |
| --- | --- | --- |
| 当前草案 | 用户确认本完整文档SHA256 | 不实施、不执行 |
| implementation-only | 授权新增v6四文件及必要本机driver静态改动 | 不部署服务器、不运行库存/GPU |
| 本机测试准备/执行 | 冻结环境、路径、117项统计及单次request；按既有阶段边界逐项授权 | 不复用旧隔离路径、不自动重跑 |
| post-test/P3 | 单独只读冻结审计，再汇总证据 | 不把mock作为原生Linux保证 |
| 运输包冻结 | 完整文件清单、SHA256、bytes及待授权部署范围 | 不自动上传/部署 |
| 用户上传与就绪审查 | 只读核验资源、源码、policy、路径与启动契约 | 不试运行真实库存 |
| 新CPUrequest | 仅创建待授权request | 不材料化或启动 |
| 单次CPU执行 | 新request完整SHA256授权后材料化并固定tmux一次 | 失败即停，不修复/重试/resume |
| post-deployment freeze | 单独只读冻结审计 | 不自动进入GPU或真实诊断 |

新实现必须在人工条件下证明：未知/越界/循环/漂移链接失败；合法目录alias不重复扫描且目标覆盖完整；精确排除披露且不访问内容；原选中文件与loader必需哈希覆盖不丢失；错误路径可定位；deadline、回收、不可覆盖发布及授权绑定保持严格。达到这些条件仅能创建下一阶段待授权材料，不代表可以直接部署或GPU运行。

## 🔗 审阅清单与引用材料

- [ ] 接受 `python3.1` 仅登记别名、规范目标独立扫描一次
- [ ] 明确接受 `terminfo` 内容排除与库存口径披露，不把它视为已完整核验
- [ ] 接受两条精确清单之外全部目录链接默认拒绝
- [ ] 接受逐组件边界、循环/跳数限制、身份重验和竞争条件限制
- [ ] 接受新增32项范围与旧契约保护，不提前宣称117项通过
- [ ] 接受v6新文件、新路径及旧v5负结果完整保留
- [ ] 确认草案不代替后续implementation-only和execution单独授权

本方案仅据项目源码、失败记录及本对话前一阶段只读元数据观察提出设计；没有外部文献性或平台普遍安全性声明。使用技术决策文档结构和文本流程图组织规则，不新增服务器观察。

相关文件：

- [冻结v5 execution request](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_v5_cpu_deployment_execution_request_v1_20261012.json)
- [v5 failure observation](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_v5_cpu_deployment_failure_observation_v1_20261012.json)
- [v5人工测试源码](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/r1b_synthetic_pf_impl_v5_20261012/test_synthetic_pf_dependency_audit_v5.py)
- [远程实验操作规范](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/references/server_operations/remote_codex_experiment_operations_guide.md)

本次新增仅此文档；没有修订生产源码、测试源码、历史证据或执行材料。等待用户对草案完整 SHA256 的确认。
