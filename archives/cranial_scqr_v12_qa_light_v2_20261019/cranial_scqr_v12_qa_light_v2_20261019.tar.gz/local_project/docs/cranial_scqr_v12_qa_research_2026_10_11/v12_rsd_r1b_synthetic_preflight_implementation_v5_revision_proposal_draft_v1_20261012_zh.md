# R1-B 人工 preflight implementation-only v5 修订方案与人工回归测试范围（草案 v1）

_Cranial-SCQR v1.2-QA 后续 R1-B｜2026-10-12｜仅供审核，未实施、未测试、未部署_

---

## 📋 状态与授权边界

| 字段 | 冻结值 |
| --- | --- |
| 文档状态 | `DRAFT_AWAITING_USER_CONFIRMATION` |
| 本轮授权 | 仅起草修订方案与人工回归测试范围 |
| 实现、测试、部署授权 | 均为 `false` |
| execution request 创建 | `false` |
| 服务器操作 | 本轮为零 |
| GPU、真实数据、checkpoint | 禁止 |

本草案建议新增 v5 实现，修复只读审查发现的 `V4-LC01`。它不是 execution request，也不是可执行授权；确认草案不等于授权部署或库存审计。所有后续步骤仍按独立授权边界进行。

本机项目根目录为 `E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution`；服务器工作目录为 `/home/jovyan/adapointr_work/PoinTr`，两者不自动同步。以下服务器路径仅为未来方案，不在本轮创建。

## 🔍 背景、证据与问题界定

### 父证据

[v4 上传与启动契约只读审查报告](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_v4_upload_readiness_launch_contract_readonly_audit_v1_20261012.json) SHA256：

`e834db8be19b190573c7b87416a7645258c2b1bc46808d53daf4c18a0dc687d1`

该审查确认五件运输文件、四个归档成员、父 P3 九文件、canonical 三文件、旧失败证据、协议、旧 request 和两份 YAML 文本哈希匹配。v4 stage、output、最终 P3、运行基目录及 tmux 会话均不存在。当前没有观测到文件漂移；问题属于静态发现的守卫缺口，不是已复现的服务器事故。

v4 运输包 SHA256：`a0f06963c5a2d2000341aaae12ecf51e0a01e7406b03d181df92818aa28ae773`，24334 bytes。

v4 待授权范围 SHA256：`2a3cb37ae9935e623d7c20bbad61449c626cb49c073bbe46b4d8585a6d80dd46`。

v4 本机 P3 SHA256：`78ffc4c6bffc70d2b2b151bcf72c8a5a6872e5d6d7b21e16907addd658701e59`。其 65 项本机测试结果仍作为历史证据保留，但不证明本次新守卫，也不替代服务器 P3。

### V4-LC01 的具体缺口

| 位置（v4） | 当前行为 | 缺少的约束 |
| --- | --- | --- |
| installer 247–248 行 | 记录 staged 四文件实际哈希 | 与授权四文件哈希精确相等 |
| installer 251–254 行 | completion 复制授权哈希 | 与实际 extras 一致 |
| audit `parent_check` | 核验历史父文件 | staged v4 自身四文件核验 |
| supervisor `validate_envelope` | 检查 SHA 格式与字段 | 与独立认证回执相等 |
| supervisor `publish_p3` | 发布结构合格的 candidate | 发布前源文件和引用产物重验 |

可能的失败路径是：归档验证和解包之后，staged 源文件变化；程序继续运行，extras 记录变化后的哈希，但 completion 仍声明原授权哈希。现有 candidate 和发布检查没有强制拒绝两者不一致。candidate 中另一个格式合法的 request/authorization SHA 也没有与发布端独立认证的预期值比较。

此次只解决该证据链完整性问题及其必要回归，不改变研究假设、模型、指标、数值策略、正式 gate 或历史证据限制。

## 🎯 方案选择与修改范围

### 方案比较

| 方案 | 能解决的部分 | 主要限制 | 建议 |
| --- | --- | --- | --- |
| 只增加最终 extras 比较 | 拒绝部分最终哈希矛盾 | 无调用前检查、无发布端独立认证 | 不采用 |
| 分阶段哈希守卫＋独立发布绑定 | 关闭当前缺口 | 仍非原子文件执行沙箱 | 采用 |
| 新增 cgroup／只读挂载执行沙箱 | 更强运行隔离 | 明显扩大权限和实现范围 | 本次不采用 |

### 拟新增文件

仅在本机新增以下四文件；所有 v1–v4 文件、旧包、报告、回执保持原样。

| 新文件 | 拟职责 |
| --- | --- |
| `audit_synthetic_pf_dependencies_v5.py` | 共享纯绑定守卫、worker 阶段检查 |
| `install_synthetic_pf_implementation_v5.py` | 每次子调用前与 candidate 前检查 |
| `supervise_synthetic_pf_implementation_v5.py` | 独立认证上下文、最终引用验证 |
| `test_synthetic_pf_dependency_audit_v5.py` | 保留回归并新增人工绑定用例 |

拟本机目录：`E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution\server_overlays\r1b_synthetic_pf_impl_v5_20261012`。本轮不创建该目录或代码。

若后续授权本机测试，还需新增一个运输包之外的 v5 本机测试 driver：`E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution\local_test_drivers\r1b_synthetic_pf_v5_cpu_once_driver_v1_20261012.py`，仅适配新目录、85 项计数和本机版本化输出。保留已验证的 v4 driver v2 清理、子进程身份和退出码策略；不得顺便重写生产守卫或增设原生测试场景。该 driver 的新增与测试必须写入后续明确授权范围，本轮不实施。

## 🔐 端到端绑定设计

### 独立可信上下文与单向哈希链

未来 supervisor 入口接收由单独授权 launcher 固定的回执路径与完整 SHA256。发布端自己读取回执字节并核验该 SHA，而不是从 candidate 中取得“预期 SHA”。使用严格 JSON：拒绝重复 key、NaN/Infinity、错误类型和超限内容。

回执绑定新 request SHA、四文件 SHA、归档 SHA/bytes、资源身份、权限、预算和固定路径。候选证据只能与该已认证上下文比较；不得自行覆盖该上下文。无需在源码中硬编码自身完整 SHA，避免自引用哈希问题。

单向关系保持：request 绑定最终实现与冻结范围；授权回执绑定 request SHA；若有 runtime，则单向绑定授权回执 SHA。request 不反向绑定尚未材料化回执/runtime 的最终 SHA，回执不反向绑定 runtime SHA。精确 launcher/bootstrap 与占位符实例化规则由未来完整 request 冻结，本草案不生成执行材料。

```mermaid
flowchart TB
    accTitle: Authenticated Evidence Binding Gates
    accDescr: Independent authorization anchors source and artifact checks. Any mismatch stops before final P3 publication.
    auth_context["独立认证授权回执"] --> source_gate["核验四文件实际字节"]
    source_gate --> child_call["通过后调用限定子工具"]
    child_call --> candidate_gate["核验候选与回执绑定"]
    candidate_gate --> artifact_gate["重验引用产物与父证据"]
    artifact_gate --> final_gate{"全部一致且未锁存失败？"}
    final_gate -->|通过| commit_p3["单点提交最终 P3"]
    final_gate -->|失败| stop_run["停止并保留失败证据"]
```

### 四文件强制校验

拟统一 `verify_implementation_bindings` 语义：精确四个 basename、固定目录、普通非链接文件、受限字节数、SHA256 全量相等。拒绝缺失、额外绑定、重复条目、越界路径、符号链接及非普通文件。所有路径组件按固定 canonical 目录检查，不能仅检查 basename。

使用 `lstat`／非跟随打开、打开后 `fstat` 与读前后 fingerprint 检查，流式 SHA；缺失、权限错误、大小变化、inode 替换、哈希不一致均直接失败。不得吞掉 ENOENT 或“更新期望值”为当前哈希。入口实际调用的 supervisor 文件也必须等于独立回执绑定的 supervisor 哈希；该文件与 staged 副本路径可不同，但两个实际字节绑定都必须验证。

检查阶段拟冻结为：

1. supervisor 入口与 authenticated archive bootstrap，在任何受监督工作分派之前核验实际 supervisor 来源；仍须先验证归档四成员，再执行 installer 或解包。
2. 四文件写入新 stage 后，首次测试之前全量验证。
3. 每次人工 pre、canonical27、人工 post、audit 子调用之前验证 stage 四文件；不允许通过先 import 再验哈希来绕过门控。
4. audit worker 在执行自身主要逻辑之前，以及最终验证阶段验证自己的四文件上下文；其当前 Python 进程已经加载的入口字节不能仅靠此检查证明，调用端预检查必须保留。
5. controller 构造 candidate 前核验四文件；`extras` 从通过验证的实际绑定生成，不得与授权哈希分别盲目组装。
6. supervisor finalizer 在 candidate 检查、引用产物检查后、提交前最后一个守卫阶段重验四文件及其自身调用源。任何失败不得进入 `os.link`。

在每个最终门控要求 `authorized implementation map == observed staged map == candidate extras map == completion implementation map`，含路径集合与字节数一致性；不能只比较两个都来源于 candidate 的字段。

### 候选 P3 与引用产物

发布端要求 candidate 中 request SHA、授权回执 SHA、run ID、版本、权限、计数、路径和资源字段与独立上下文一致。禁止缺字段时默认补为“通过”；仅 controller exit、registered group closure 等 supervisor 实际观测字段允许由 supervisor 填入。

产物验证必须有固定 allowlist、非链接 canonical 路径、字节数与 SHA 重验。至少覆盖人工 pre/post 日志、canonical27 日志、inventory completion 及其引用的 inventory/input/environment/progress 四份产物、process receipts，并核对测试计数和退出码。completion 与 `cpu_artifact_bindings` 的集合和绑定须一致；禁止任意 candidate 路径诱使发布端读取 NPZ、checkpoint 或其他目录。

历史父 P3 九文件、canonical 三文件、旧失败证据、协议/request 和两 YAML 文本维持原精确哈希门控；发布前也须重新核验。不要扫描新目录来推导可信集合，不执行库存工具进行验证，不重新计算研究结果。

全部文件重验仍在现有 FailureLatch、信号处理和总时限内进行。读取失败、超限或超时视为本次失败，不得降低覆盖、换大预算或自动重试。提交前产生的 source 文件不是最终 PASS；采用原有 exclusive hardlink 单点提交。提交后 fsync、观测或退出记录不确定时，仍为 `COMMIT_OBSERVATION_UNCERTAIN`、非零退出，保留现存证据，不自动删除或重写。

### 明确不宣称的保证

阶段守卫和读前后 fingerprint 缩小漂移窗口，但不是原子 PID fencing、只读执行沙箱或同 UID 对抗保护；不能证明不存在“检查后修改、执行后恢复”的瞬时攻击，也不能捕获任意未观测的外部会话。需要更强隔离时另立方案。不得把本次人工测试通过解释为 CUDA 路径等价、真实库存成功或服务器耐久性证明。

## ⚙️ 不变量、预算与产物限制

### 保持不变

- 原有不可逆 FailureLatch、READY/RELEASE/ACK 与 5 秒登记期限、PID/PGID/SID/start 身份和未知身份失败规则。
- workflow 1300 秒、inventory 900 秒、cleanup 15 秒；每个服务器 CPU 测试 60 秒。登记时间包含在总预算中，不额外放宽。
- IDENTITY＋CPU_ENV_INPUT 从 audit child launch 起共享 60 秒，即使无 progress；ENUMERATE 120、LOADER_RESOLVE 120、HASH_CONTENT 480、FINAL_VALIDATE＋PUBLISH 共享 60 秒。
- inventory entry 200000、files 50000、bytes 8 GiB、loader targets 32、metadata 16 MiB、single file 120 秒；未来 GPU preflight 600 秒不变。
- canonical27、v1.1 与 QA-1 正式训练/evaluator/BNCal 工具不修改；不进入正式 gate。
- 保持 GPU／真实 payload／checkpoint／训练／BNCal／development evaluation／自动创建下一 request 为禁止。

### 新守卫的额外有界性

源文件单个上限 2 MiB，四文件总上限 8 MiB；回执最大 1 MiB，candidate 最大 4 MiB。拟最终引用重验：最多 16 个明确 allowlist 产物，每个最大 16 MiB、总计最大 64 MiB；人工三份日志各最大 16 MiB，也计入总量。禁止递归遍历、glob 扩大集合、读取 payload。最终重验与发布共用最后阶段 60 秒子预算，并始终受 workflow1300 秒总预算约束，不新增独立可累加时限。

上述 16 文件/64 MiB 是本草案拟定的新守卫上限，不是现有服务器产物大小结论。若实现时固定合法产物清单超过16或64 MiB，必须停止提交设计差异供审核，不能静默截断、遗漏或放宽。读取采用分块检查期限；可能阻塞的内核 I/O 仍由原有外层期限/失败策略约束，不宣称任何文件系统调用必然可中断。

v5 本机 P3 和未来 server P3 区分：`PASS_LOCAL_IMPLEMENTATION_AND_ARTIFICIAL_CONTRACTS_ONLY` 不等于兼容 preflight reader 的 `PASS_SYNTHETIC_PREFLIGHT_IMPLEMENTATION_ONLY`。

## 📊 人工回归测试范围

### 计数与环境

拟保留原 47 项人工方法与 18 项本机无害 Linux process 场景，并新增下表 20 项人工方法：人工-only 共 67 项，本机全套共 85 项。更新 v5 计数断言、candidate completion、人工 fixtures 与版本化报告，不能把旧65结果替代新85结果。

既有 publication fixture 必须从临时人工回执及实际人工文件计算绑定；生产 finalizer 不允许提供“跳过真实性检查”开关。允许测试注入 fixture root/时钟/读取函数，但生产入口将它们固定为授权路径与真实实现。新增20项禁止原生子进程、真实库存、torch/GPU、服务器路径、真实数据和 checkpoint；所有文件仅在受控本机临时 fixture 下，结束后仅清理自身人工 fixture。

后续一次本机执行拟使用已隔离的 WSL Linux Python3.10，沿用已验证的本机守卫框架：总120秒（工作112秒、保留清理8秒）、fixture/日志各原有16 MiB上限、原有20组/120观察 helper限制。失败停止；没有授权不得自动调整计数、时限、环境或重跑。若85项不能满足预算，须先报告而不是延长。

### 新增20项方法矩阵

| ID | 人工输入／注入 | 必须观察到的结果 |
| --- | --- | --- |
| B01 | 完整一致的四文件与回执 | 验证通过，返回实际绑定 |
| B02 | 四文件逐一错误 SHA | 每种均拒绝；不调用 child |
| B03 | 缺失／额外／重复绑定 | 精确集合拒绝 |
| B04 | 链接／越界／非普通路径 | 读内容前拒绝 |
| B05 | 假读取期间 inode/size/fingerprint 变化 | 拒绝，不更新期望值 |
| B06 | PermissionError／ENOENT | 错误传播且失败锁存 |
| B07 | 解包后、首次测试前修改 | 不进入 pre 测试 |
| B08 | pre后／regression后／post后改变源 | 下一分派前停止 |
| B09 | audit前、candidate前改变源 | 不调用 audit／不写 candidate |
| B10 | worker上下文或实际supervisor源不符 | 入口／最终门控拒绝 |
| B11 | extras与completion／授权不一致 | 不生成可提交候选 |
| B12 | 格式合法但错误request SHA | finalizer拒绝，commit调用数0 |
| B13 | 错误回执SHA／字节／重复JSON key | 独立认证失败 |
| B14 | 错run ID／版本／resource／权限 | 不默认补为PASS |
| B15 | inventory completion字节/hash改变 | commit前拒绝 |
| B16 | 下游四产物或测试日志／receipt漂移 | 引用重验拒绝 |
| B17 | 产物越界／链接／额外集合／超限 | 无payload读取、commit调用数0 |
| B18 | 候选后、提交前再次改变源或父证据 | 最后门控拒绝 |
| B19 | 绑定重验期间假deadline／TERM锁存／I/O错 | 第一错误保留，非PASS |
| B20 | 全链一致＋独占提交成功 | 单次commit；完整P3绑定相等 |

B02最多4参数、B03最多3、B04最多4、B05最多3、B06最多2、B08最多3、B09最多2、B10最多2、B11最多3、B13最多3、B14最多4、B16最多8、B17最多4、B18最多2、B19最多3；未列出的每方法1参数。新增最多55个参数实例；连同继承方法全套 subcase 上限256，方法上限96。人工内容总计不超过8 MiB，超量情形用 stat/reader 的人工替身而不创建大文件或特殊设备。

失败用例除检查异常，还须检查 child/候选/commit调用计数、最终目标不存在、外部人工哨兵文件未变、第一次错误不被二次报告失败替换。B20要求真实临时人工文件绑定而非全`a*64`占位值；本机 hardlink fixture只证明该本机场景，不证明服务器支持。

### 必须保留的回归与验收

47项原人工回归与18项原本机进程场景均保留其测试意图；按 v5 合法fixture更新，不删除阻断性断言。覆盖登记前不派发、未知group不等于空、timeout无progress、日志错误失败、precommit signal禁止提交、postcommit不确定、外部进程不受影响、残留group拒绝PASS。

验收要求为：一次85方法 failfast、runner0、outer0、日志85精确计数、没有逃逸／未回收人工组、四文件及driver前后SHA一致、旧证据SHA不变，并完成仅本机 P3与独立静态审查。任何未证明事项单列，不用局部PASS替代整体验收。

未来服务器人工测试拟变为67／27／67，必须在新的 CPU request 中明确冻结；18项本机原生场景与本机 driver继续禁止服务器部署和执行。这里仅提出范围，不授权该未来执行。

## 📦 版本、阶段与后续授权

未来运行身份拟为 `r1b_synthetic_pf_impl_v5_20261012`；tmux session拟为 `r1b-synthetic-impl-cpu-audit-v5-20261012`。stage/output/base/授权/候选/发布source/最终P3均使用全新v5路径，不能复用v4。目录不存在与资源证据必须届时重新观察，不能把本草案中的历史观测当作未来核验。

1. 用户确认本草案并单独授权本机 implementation-only 与上述一次测试范围后，才新增四文件、限定本机driver和版本化测试材料；不部署、不运行真实库存。
2. 实现通过后先报告新代码SHA、本机P3、静态审查结论和限制；运输冻结仍需单独授权，不自动创建包或部署request。
3. 单独授权运输冻结后生成新五件套，用户上传；之后单独授权只读上传/资源/父证据/路径/启动契约核验。
4. 就绪审查通过后，另行授权创建完整待授权CPU request；冻结launcher文本、master日志/PID/退出路径、登记、守卫、所有哈希与单次规则。
5. 用户明确授权该request完整SHA后，才材料化授权回执、限定启动文件并运行一次CPU流程。硬链接／目录fsync的服务器适用性仍需在明确授权的范围内验证，不能在只读审查中写入探针。若不支持则失败停止，不自动换发布机制。
6. CPU流程结束还需独立只读freeze audit；其通过也不自动创建或运行GPU preflight，不进入真实R1-B诊断。

本次新增守卫既不要求重跑QA-1六运行，也不改变未裁决历史数值证据gap。v4上传原件和本机运输包保留，禁止自动重命名、覆盖、删除或视作v5使用。

## 🔗 审核清单与本轮交付

- [ ] 同意仅新建v5四文件及限定本机测试driver，不修改v1–v4或canonical工具
- [ ] 同意独立认证上下文、分阶段四文件守卫与最终引用重验
- [ ] 同意67人工＋18继承原生＝85本机方法与固定参数上限
- [ ] 同意原时间预算不放宽，新增最终门控60秒包含于1300秒总预算
- [ ] 同意16产物／64 MiB限制及超限先报告，不截断或自动改协议
- [ ] 同意所有实施、测试、运输、部署、CPU执行、GPU阶段继续分开授权

本轮实际仅新增这份草案；未修改代码、未运行测试或文件系统写探针、未连接服务器、未创建execution request/runtime/launcher/授权回执、未进行Git commit/tag/push。文档使用Markdown与嵌入式Mermaid表达可信绑定顺序；未声称已完成渲染或生产验证。

审核结论当前为待确认。若需要修订，新增文档版本并保留本草案原字节；不要把草案状态原地改成已执行。
