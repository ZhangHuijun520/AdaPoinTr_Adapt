# Cranial-SCQR v1.2-QA 阶段实验完整报告 v1

_截至 2026-10-11（Asia/Shanghai）；QA-1 六运行执行完成，整体 v1.2-QA 未全部结束；本机版本化研究记录。_

---

## 📋 执行摘要与完成状态

### 核心回答

不能将当前状态称为“Cranial-SCQR v1.2-QA 全部实验结束”。目前完成的是 QA-1 主矩阵的六个 seed0 训练、各自一次成功 BNCal、各自一次成功 development evaluation、分阶段冻结核验，以及随后单独授权的 LSQ−LS 描述性统计和安全性/历史数值证据复盘。QA-1 正式 gate 及科学分类尚未裁决；QA-2、QA-3、容量对照、Query-Space Mamba 和 confirmation20 未执行，且不能从本报告推导执行授权。

### 主要发现

1. 固定 checkpoint 条件下，LSQ−LS 的 RimCover-P95 在 Fold C 为 `-0.572073 mm`、Fold D 为 `-0.402413 mm`；pooled 为 `-0.487243 mm`，95% source-skull 分层 bootstrap CI 为 `[-0.894924,-0.088829] mm`。这是支持继续谨慎研究的边界覆盖信号，不是完整通过结论。
2. 全局几何质量没有一致改善。Fold D 的 Implant CD-L1 差值为 `+0.250150 mm`，Final CD-L1/HD95 也增加；主指标改善不能代表植入体总体质量同步改善。
3. LSQ 独有新 disaster 在 C 折有 1 个、D 折有 3 个；D 折总数由 LS 的 4 增至 LSQ 的 5。两折 zero-contact 均为 0。均值收益不能抵消新增失败病例。
4. B0 C/D、LS C 的训练与 BNCal 回执缺少完整数值策略快照；后期严格 evaluation 不能追溯补证。缺口不等于已证实违规，但限制跨候选归因和正式裁决。
5. 当前最可靠结论是：在这批固定表示、固定权重的内部 OOF 运行中，Query 增量有边界覆盖改善信号，同时伴随局部病例风险与全局质量权衡；尚不能称稳定、安全、可泛化的 winner，更不能称 Mamba 创新已成立。

### 阶段状态表

| 阶段 | 当前状态 | 解释 |
|---|---|---|
| P0 协议/数据边界锁定 | 已有冻结材料 | 不是执行授权 |
| C/D 梯度标定 | PASS | 冻结两折 lambda_scf |
| 六配置与零更新 preflight | PASS | 人工输入，无训练更新 |
| QA-1 六训练 | 完成并核验 | 各 3939 steps、101 traversals |
| QA-1 六 BNCal | 完成并核验 | 各 315 case、40 forwards |
| QA-1 六 evaluation | 完成并核验 | 各 105 case、21 source |
| LSQ−LS 描述性统计 | 完成并审计 | 不是正式 gate |
| 安全性/历史证据复盘 | 完成并冻结本机报告 | 不追溯认证 |
| QA-1 正式 gate/分类 | 未裁决 | 历史证据限制仍锁定 |
| QA-2/QA-3/Mamba/confirmation20 | 未执行 | 需新的分阶段授权 |

## 🎯 研究目的、模型设计与科学边界

### 研究背景与本阶段问题

用户的长期方向是基于 Mamba 的颅骨点云补全，但当前阶段采用先验证 Query 路径、再讨论 Mamba 的证据顺序。v1.1 中 Q0 相对 A1 的探索性信号需要在新的开发折复核；已经不支持的 direct contact log-bias/QC 路线不继续作为本阶段训练分支。本报告不重新评述文献，也不将旧方案中的文献信息作为当前检索结论。

QA-1 的核心问题：在 Local 与 SCF supervision 已存在的条件下，新增 Query conditioning 是否相对 LS 改善 RimCover-P95，并保持植入体/final 几何质量与病例安全性？因此唯一主比较为 `LSQ−LS`，距离差值为负表示 LSQ 更好。

### 六运行模型矩阵

| 模型 | Local geometry | SCF auxiliary | Query conditioning | 角色 |
|---|---|---|---|---|
| B0 | 关闭 | 关闭 | 关闭 | AdaPoinTr 嵌套基线 |
| LS | 开启 | 开启 | 关闭 | 既有 A1 别名 |
| LSQ | 开启 | 开启 | 开启 | 既有 Q0 别名 |

三候选均不启用 direct contact bias，beta 为 0；本阶段未实现或验证 Query-Space Mamba。B0 基线用于完整矩阵留存，但本轮未开展 LSQ−B0 的正式配对统计或解释，因为主比较的正式状态尚未裁决。

LSQ−LS 可描述 Query block 的条件增量，但目前没有 parameter-matched 非交互容量对照，不能把全部差异严格归因于 attention 信息交换；没有 L0/LQ，也不能独立识别 Local、SCF 或 SCF×Query interaction。

### 预注册阈值与解释

原规则包括 C/D 主差值均不增、pooled 差值 `<= -0.10 mm`、pooled CI 上界 `< 0`，以及无 LSQ 独有新 disaster、每折 disaster 不增加等安全条件。几何护栏分别为 Implant/Final CD-L1 差值 `<= +0.10 mm`、Final HD95 `<= +0.50 mm`、Final NSD@1mm `>= -0.01`；零接触增加进入 review zone。

本报告仅记录原规则，未计算逐项 gate 布尔结果、未赋予 `CONFIRMED_INTERNAL_REPLICATION` 或 `SAFETY_FAIL` 等正式分类，不移动阈值。`0.10 mm` 是固定采样表示下的工程资源阈值，不是临床容差；单一工程阈值不能据此支持临床可用性。

## 📚 数据、标定与执行合同

### 数据角色与拆分

数据为 `SkullBreakPC_out8192` 的 development84：84 source skull、420 case，每 skull 五种缺损：bilateral、frontoorbital、parietotemporal、random_1、random_2。各折 63 train skull/315 case，21 dev skull/105 case；按 skull 成组，禁止 case-level 随机拆分。

C/D dev 来源互斥，合计 42 skull/210 独特 case，但三个候选重复评估同一 case，六份 CSV 的 630 行不是 630 个独立病例。A-D dev 集覆盖 development84，折间训练集重叠；C/D dev skull 曾进入其他折训练，因此准确角色是内部 OOF 复核，不是独立外部验证或完全未暴露测试。

服务器数据根为 `/home/jovyan/datasets/SkullBreakPC_out8192`；manifest SHA256 为 `f1f8cae47ed7d5529dc2ca244179cedddbc039981cdc0ff24b25a5c81ad30538`。Fold C dev allowlist SHA256 为 `0bc9286bea354c60870818e47207a9da7f156704557f366ef27847d589f5c0b0`，Fold D 为 `7afc9edc6654891cc8593ab2ce172657e1227e4583ed3281b159ab3ae2be68ac`。

confirmation20、official test、old monitor、MUG 与未授权 SkullFix payload 保持禁止。本轮写报告只访问既有 JSON/文本及哈希，不访问这些 payload；不进行独立原始几何核验。

### C/D 梯度标定

继承固定选择规则：基于 skull_id 和冻结 salt 的 SHA256 排序选择每折 4 skull，每折 20 case、5 个 batch，候选 LS，模型 seed 31002。选定 source C 为 113/002/062/017，D 为 113/002/026/041。两折共享部分 case，因此总共 40 次 payload open 对应 30 个独特 case，而非 40 个独立病例。

| 项目 | Fold C | Fold D |
|---|---:|---:|
| median g_rec/g_scf | 8.912909312609397 | 8.346387037781536 |
| 冻结 lambda_scf | 0.8912909312609397 | 0.8346387037781536 |
| 完整模型 forward | 5 | 5 |
| Autograd 调用 | 10 | 10 |
| 权重裁剪生效 | 否 | 否 |

目标梯度比例为 0.1，lambda 由训练侧标定冻结，不复用 A/B 的 lambda，不根据 dev 结果调权重。回执显示模型状态不变、optimizer steps=0、checkpoint load/write=0，状态 PASS。标定作用是固定损失量级，不是证实 SCF 的机制因果作用。

### 零更新 preflight 与初始化

2026-09-22 的六运行 preflight 使用人工输入，六个 scratch 初始化、每候选/折一组 training 与 eval forward、共 12 个 forward、6 个 backward。optimizer constructions/steps、parameter/buffer updates、checkpoint load/write、NPZ open、dataset construction 和 development evaluator 均为 0。

共同主干初始化 hash 为 `617d9def43387cc0afed528decf5acba30b1ea2a459c910f63091529e198c924`；跨候选公共状态相同，同候选 C/D 完整初始状态及参数成员相同。人工输出 coarse `[1,256,3]`、fine `[1,8192,3]`；LSQ attention `[1,256,256]`，行和误差上界 `1.1920928955078125e-07`，梯度有限。该证据支持 preflight 合同，不是容量公平性或正式训练性能证据。

### 训练、BNCal、evaluation

训练继承 AdamW，learning rate `1e-4`、weight decay `5e-4`，FP32、AMP=false、batch=8、drop_last=true、39 loader batches，epoch labels 0–100，即 101 traversals、精确 3939 optimizer steps，grad clip norm=10。学习率按冻结 LambdaLR 合同，decay_step=21、lr_decay=0.9、lowest_decay=0.02；final-only checkpoint，不选 best，不 early stop，不 resume，不自动重跑；训练不访问 development。

BNCal 仅对应 fold-train 的 315 case，partial-only，batch=8、drop_last=false，40 forwards；参数不变、optimizer steps=0，仅规定 BatchNorm buffers 更新。最终 `ckpt-last-bncal.pth` 是 evaluation 源权重，而非另一次训练结果。

Evaluation 为 FP32、batch=1、workers=0、eval/no_grad，每运行一次 checkpoint load、105 NPZ opens、105 forwards。仅 partial 进入模型，implant/gt 在 forward 后作为 metric target；模型参数/buffers 不变，不保存预测点云，不自动进入下个运行。后期 evaluator 的 deterministic algorithms=true、warn_only=false、TF32=false、cudnn deterministic=true、benchmark=false 前后快照已核验。

## ⚙️ 实施历史、六运行账本与数值限制

### 执行与工程审计

采用 WSL+hpc5000 WebShell，长任务在 tmux 独立运行。PowerShell 显式传播 `$LASTEXITCODE`，launcher 先创建/验证日志父目录再重定向，输出使用新不可覆盖路径。服务器无 Git 工作树；本机规范材料与服务器并不自动同步。

已处理的工程问题包括资源绑定变化、训练/BNCal 独立守卫、授权回执与 runtime 的循环哈希依赖、tmux 启动目录/重定向问题、YAML 校验多层引号与父目录观测问题，以及后期 deterministic/TF32 hotfix。失败/未执行版本保留，成功版本不意味着失败尝试不存在；不将 transport 返回 0、session 消失或 checkpoint 存在单独作为成功证据。

训练、BNCal、evaluator implementation-only 与 post-implementation P3 分离；统计工具在 10 项人工 CPU tests 通过后才创建待授权 request，并在单独执行授权后运行。v1.1 分析工具未被本次 QA-1 统计实现修改。

### 六运行完成时间

以下为北京时间，精确到秒；版本号为各阶段成功运行的版本，不表示其前没有失败版本。

| Run（seed0） | 训练完成 | BNCal 完成 | Evaluation 完成 |
|---|---|---|---|
| B0 Fold C | 09-29 18:32:22 | 09-30 00:58:00 | 10-09 23:04:40 |
| B0 Fold D | 10-08 15:33:12 | 10-08 16:03:52 | 10-09 23:23:33 |
| LS Fold C | 10-08 20:24:36 | 10-08 21:12:01 | 10-09 11:29:37 |
| LS Fold D | 10-09 12:45:17 | 10-09 14:22:08 | 10-09 14:42:28 |
| LSQ Fold C | 10-09 16:55:54 | 10-09 17:25:10 | 10-09 17:48:34 |
| LSQ Fold D | 10-09 20:18:19 | 10-09 20:51:20 | 10-09 21:16:24 |

六条 training、BNCal 和 evaluation 已分阶段冻结并核验。训练计数均为 3939/101，BNCal 均为 40 forwards，evaluation 均为 105 cases/21 sources。六运行 evaluation 产物清单共 42 个成员，全部通过此前完整性审计；本轮再次核验各 evaluation 清单与单运行汇总。

### Final checkpoint 哈希索引

以下来自冻结回执与 source bindings；本轮未反序列化权重。训练 checkpoint 与 BNCal checkpoint 不可混用。

| Run | ckpt-last.pth SHA256 | ckpt-last-bncal.pth SHA256 |
|---|---|---|
| B0 C | `282f07942d680b6e652e5e1acf0270ee389d531674cf0ce7189d2300acfaa89c` | `3cc9906440ff2ca47d48d668f016d0fdf482a9c2860972fd874b48c0bc1640ce` |
| B0 D | `e03279f179642619b66d5a397ac9fcc751c903b664a560b3310d04ef56064f5c` | `d63141ae697017203e9af336fb4103c291e47f27b2febe9ba2f145863baf6393` |
| LS C | `f0c4d01e14fd6a488daa8d782f26a30cb60e8668bcdd53afadaba537ba3ec3e5` | `47d21ab4e5e577515eec314b21695166c5af0fa3c02ed29c9756fe85f80cbb7e` |
| LS D | `2faf9e4a13d7a6c82b39843eb991a7fe88c3244f985467b42bb747cd8528acdd` | `bdc2bf228e9aa57bcad58f2aecf06481aab367f308a6cae9629ba91462ca9c57` |
| LSQ C | `a67fa8421d4ebf7433e1cb2551df618881b40c9258212c81502f09777557e5f1` | `5c2f39f029b019843ae403103933d93b6061f127ac1a95d355940e8eb6a3befa` |
| LSQ D | `f469976f35b55e29b1346c90b4ca98ac8a90ff78fd0d1bcc578c837191d80bfb` | `71da7f3b68c3dc5b97aba4530480cc9e7622b75e74b1802f2200dce99bf788ad` |

### 数值策略证据状态

| Run | 训练/BNCal 数值快照 | 后期 evaluation 快照 |
|---|---|---|
| B0 C、B0 D、LS C | 缺失完整快照 | 已核验严格设置 |
| LS D、LSQ C、LSQ D | 有完整快照 | 已核验严格设置 |

LS C 训练 launcher 第 192–193 行设置 CUBLAS/NVIDIA TF32 override，第 202 行带 `--deterministic`；日志第 30、260 行记录 deterministic 意图。BNCal launcher 第 246–247 行可见 CUBLAS。上述属于配置或参数证据，不等于全部 backend flags 运行时断言，不能认证历史训练/BNCal 与后期实现完全匹配。缺失不能被追溯补写，也不能据此断言实际违规。

2026-10-11 报告只读来源所在 hostname 为 `shu-common-25721452-notebook-2b2doi-0`，不同于统计执行的 `…h4cmio-0` 和更早训练容器。文件可读/hash 一致支持产物保留，不构成新运行的资源重绑定授权。

## 📊 六运行结果与已冻结配对统计

### 单运行原始汇总

下表直接抄录单运行 source 等权汇总，未重新计算候选比较或 pooled B0 差值。各运行 n=105 cases/21 sources，所有 zero-contact count=0。距离单位为 mm；NSD 无量纲。

| Run | RimCover-P95 | Implant CD-L1 | Implant HD95 | Disaster |
|---|---:|---:|---:|---:|
| B0 C | 11.142993 | 4.220762 | 9.439216 | 9 |
| B0 D | 10.430084 | 3.501669 | 9.204368 | 11 |
| LS C | 7.031703 | 2.564158 | 6.654403 | 3 |
| LS D | 9.044280 | 2.917086 | 7.301843 | 4 |
| LSQ C | 6.459630 | 2.227645 | 5.655354 | 1 |
| LSQ D | 8.641867 | 3.167236 | 7.801530 | 5 |

| Run | Final CD-L1 | Final HD95 | Final NSD@1mm | Implant NSD@1mm |
|---|---:|---:|---:|---:|
| B0 C | 2.392491 | 5.660926 | 0.149538 | 0.193081 |
| B0 D | 2.401351 | 5.608633 | 0.147293 | 0.194464 |
| LS C | 2.226540 | 4.743732 | 0.151912 | 0.229157 |
| LS D | 2.284062 | 5.025316 | 0.148880 | 0.219955 |
| LSQ C | 2.201194 | 4.634117 | 0.152539 | 0.243056 |
| LSQ D | 2.336912 | 5.308277 | 0.147994 | 0.211128 |

| Run | Rim contact CD-L1 | Rim contact HD95 | Contact precision | Contact recall |
|---|---:|---:|---:|---:|
| B0 C | 7.269811 | 25.235362 | 0.449479 | 0.413867 |
| B0 D | 6.075102 | 23.236952 | 0.478554 | 0.470254 |
| LS C | 4.036591 | 16.659840 | 0.514674 | 0.525933 |
| LS D | 4.606191 | 18.554478 | 0.544292 | 0.501959 |
| LSQ C | 3.280838 | 14.007209 | 0.538780 | 0.555446 |
| LSQ D | 5.046010 | 19.440410 | 0.507126 | 0.490375 |

RimCover-P95 是每 case 的 reference defective-side rim 至 predicted implant 距离 P95，再按五缺损/source 聚合；不是将所有点或所有病例直接池化重算 P95。HD95、CD-L1、NSD 沿用冻结 evaluator；本报告不发明替代定义。Protocol 中 disaster 包含 nonfinite core geometry 或 contact HD95>50 mm 等冻结条件；本次具体事件沿用 CSV flags，未重算触发原因。

### LSQ−LS 主比较的固定权重统计

| 指标 | Fold C | Fold D | Pooled | Pooled 95% CI |
|---|---:|---:|---:|---|
| RimCover-P95 | -0.572073 | -0.402413 | -0.487243 | [-0.894924,-0.088829] |
| Implant CD-L1 | -0.336513 | +0.250150 | -0.043182 | [-0.331009,+0.215501] |
| Final CD-L1 | -0.025346 | +0.052849 | +0.013752 | [-0.011417,+0.041837] |
| Final HD95 | -0.109615 | +0.282961 | +0.086673 | [-0.058518,+0.245725] |
| Final NSD@1mm | +0.000627 | -0.000886 | -0.000130 | [-0.000619,+0.000384] |

统计样本单位是 42 个配对 source，Fold C/D 各 21；case 差值先等权归约到 source。Bootstrap 为每折独立抽样 21 source，pooled 各折权重 0.5，NumPy 2.2.6、default_rng/PCG64，source ID 字符串排序，每块 1000 次、共 10000 次，seed 20260910，linear percentile 2.5/97.5。每指标重置 RNG，配对候选共享同一 source 抽样索引。缺失/重复/非有限值禁止静默删去。

这份结果来自单独授权 request `a568b4219aaeef8ce9ea05df58df32ce2c8a3ebbba9a3daac39fc55dad3c3eda`。分析退出码 0，post-analysis freeze audit PASS；本报告不重算 bootstrap，不新增 p-value，不计算正式 gate 或次比较。

## ⚠️ 病例级风险、异质性与历史证据复盘

### 失败事件迁移

| Fold | LS disaster | LSQ disaster | LSQ 独有新事件 |
|---|---:|---:|---|
| C | 3 | 1 | train__025__random_2 |
| D | 4 | 5 | train__008__random_1；train__010__random_1；train__087__parietotemporal |

C 的 LS 独有事件为 `025/bilateral`、`051/frontoorbital`、`072/random_2`；D 为 `004/random_2`、`087/random_1`。病例的 train 命名前缀并不表示本次越界访问 train payload，它们在各 fold-dev allowlist 内。

四个 LSQ 新事件的 RimCover-P95 都比 LS 低：025/random_2 为 14.619335→12.882486，008/random_1 为 8.088278→7.509196，010/random_1 为 14.912389→14.509678，087/parietotemporal 为 17.363256→14.310884 mm。由此可见改善一侧 reference-rim coverage 并不足以保证 contact 或整体植入体质量，不能用“边界更好”消解 disaster。

### Fold D Implant CD-L1 恶化

21 skull 中 17 个 source 均值差值为正、4 个为负，说明正向恶化不局限于单一 source。恶化前三为 087 `+2.750441 mm`、008 `+0.942893 mm`、079 `+0.525093 mm`。完整 21-source 排序已在上一份冻结复盘报告保留，不在本报告筛掉有利或不利 source。

| 缺损类型 | n | LSQ−LS Implant CD-L1 均值 mm |
|---|---:|---:|
| bilateral | 21 | +0.192107 |
| frontoorbital | 21 | +1.071901 |
| parietotemporal | 21 | +0.308653 |
| random_1 | 21 | -0.360813 |
| random_2 | 21 | +0.038902 |

尾部病例 `087/frontoorbital` 为 `+20.496147 mm`，而同 skull 的 random_1 为 `-11.875353 mm`；两者都保留。折均值反映广泛小幅恶化与部分大幅尾部变化混合，不能通过删除 source、改指标、改阈值或事后择 seed 将其“修正”为成功。

以上是 outcome-level 观察，不证明 Query attention 造成某种特定几何错配。无已授权点云可视化或 forward 干预，因此“局部更贴边但其他方向失真”“coarse 支持不足”“dense refinement 失衡”等仅可作为未来诊断假设，不应写作已证实根因。

### 三层证据必须分开

1. 执行完整性：计数、exit code、文件哈希和授权链通过。
2. 几何科学结果：边界覆盖改善与其他几何指标/病例风险共存。
3. 数值可比性：早期三运行快照缺失，不能认证完整严格一致条件。

执行 PASS 不等于效果 PASS；bootstrap CI 为负不等于工程安全；存在历史缺口也不意味着忽略观察到的真实坏病例。修复工程可审计性后仍需要重新观察风险是否持续，不能预设所有坏结果都由数值策略造成。

## 🔍 专业解释、可靠结论与不能声称的内容

### 可以可靠记录

当前固定 checkpoint 比较中，Query 路径在 Local+SCF 条件下改善了 reference rim coverage；方向在 C/D 均为负，source-skull CI 支持该条件性均值改善信号。Fold C 的多数汇总几何指标同时改善，而 Fold D 呈现边界改善与 implant/final/contact 指标恶化的权衡。因而 Query 增量在不同折/病例类型下并非统一收益。

本阶段已经建立可核验的分阶段实验资产：标定、共同初始化 preflight、逐运行授权、精确 steps、train-only BNCal、partial-only evaluation 和受限统计工具。这些资产降低误重跑/越界/选择性报告风险，但不是算法 novelty 本身。

### 尚不能可靠声称

- LSQ 是稳定优胜模型、安全通过 QA-1，或具有临床可用性
- 边界改善一定来自 query 信息交换而非额外容量/优化状态
- SCF 通过 representation shaping 的机制已经被训练干预证实
- LSQ 相对 B0 的正式增量、跨 seed 稳定性或独立外部泛化已确认
- Mamba 本身贡献已成立、效率优于 Transformer，或足以支撑特定会议录用
- 历史训练/BNCal 的严格数值一致性已经被后期 evaluator 补齐

### 统计与实验限制

单 seed、两个内部 OOF 折、训练集重叠、developer 暴露数据、无外部确认、无独立容量对照、无 full factorial 分解、无现阶段效率基准，均限制外推。Bootstrap 仅捕捉固定权重下 source 重采样不确定性，不涵盖训练 seed、dense-surface 重采样、架构选择或不同中心分布的不确定性。它不提供临床置信范围。

正式状态保持 `NOT_ADJUDICATED_HISTORICAL_NUMERICAL_EVIDENCE_GAP`，科学分类为空。新增灾难和 Fold D 质量恶化是必须进入后续决策的风险信号；本报告不越权执行 gate，也不以暂未裁决为由无限扩大试验。

## 🎯 下一阶段建议与决策顺序

### 优先级 1：停止盲目加模块，先冻结问题

当前不建议立即实施 QA-2 的 L0/LQ、Query-Mamba、beta sweep 或大量 seed sweep。先保留当前负面安全证据，明确是否接受为解决一个具体诊断问题投入有限新预算。近期论文目标应优先形成可复现、风险明确、控制充分的实验论证，而不是为了保留“Mamba”标题堆叠结构。

### 优先级 2：最小追加诊断方案（尚未授权）

可以先起草只读几何/事件触发证据核对方案：优先对四个 LSQ 新 disaster 与 Fold D 尾部病例明确现有 flags 的触发分量、单位恢复和 case identity。若需要 NPZ、checkpoint 或推理则逐项另行授权；仅写报告并不允许这些访问。应包含预先固定的对照病例与全面统计口径，不能只展示成功或失败个例，更不能据图调整阈值。

若需要统一严格数值合同，讨论独立版本的 LS/LSQ×C/D 四运行诊断矩阵：不改变模型/loss/数据/训练预算/指标/SESOI，绑定所有 backend flags 运行前后断言及 snapshots，共同初始化、随机流、loader、BNCal/evaluator 策略一致。输出使用新不可变目录，保留旧结果。它回答“匹配条件下信号与风险是否复现”，不是填补过去快照。

seed0 matched replication 与 seed1 stability 是不同问题，必须事先选择；不得事后取较好 seed，也不得将旧 LSQ 与新 LS 拼接成完全匹配矩阵。即使保留同 seed 重复，仍是新独立实验，需用户明确批准其诊断目的、与原 safety 停止规则的关系和预算。

### 优先级 3：有条件的后续路线

| 新证据情形 | 建议 | 禁止的解释 |
|---|---|---|
| 匹配条件下仍有新 disaster/全局恶化 | 优先止损，转向任务专用局部表示/强基线 | 主均值改善即可忽略安全 |
| 信号消失或 seed 反向 | 冻结 Query 扩展路线并报告敏感性 | 无限扫描 seed 找正结果 |
| 数值可比、安全及后续独立授权均成立 | 再讨论 QA-2 Local/SCF/Query 分解 | 一次新实验自动授权 Mamba |
| Query 机制与稳定性被后续确认 | 增加容量对照，再评估 Query-Space Mamba | 额外容量效应就是 Mamba-specific |

若 Query 最终成立，原计划 QA-2 的 L0/LQ 分解、QA-3 的平衡 seed1、parameter-matched 对照以及 matched Transformer/MLP 控制仍不可省略。GM 仅优于不加模块的 G0，不足以归因 Mamba；质量与实际端到端成本需各自冻结并计入排序/逆排序开销。上述是原路线条件，不是本报告新执行计划。

如果决定停止 Query 路线，可将现有工作转化为失败机制、边界指标与全局质量权衡的研究依据，但需进一步实证和独立验证才能形成可信论文贡献。不能承诺这些现有结果必然满足 CCF C 发表要求。

### 最近一步

推荐先与导师决定“有限的新诊断协议”还是“停止 Query 扩展并转向局部表示/基线”，然后仅起草待确认协议。不得自动重训或正式 gate；confirmation20 继续封存，避免用确认集调参或挽救开发负结果。

## 🔗 来源、复现索引与本机保存边界

### 核心来源 hash

| 来源 | SHA256 |
|---|---|
| 原 v1.2-QA 正式计划 | `7c0b5a40c6a263e0b256dbe4fe7d895083c196d7db3482358601c7928054ed0b` |
| QA-1 预注册协议 | `10878972310ced7ddad1188a29b233686c17b5dd5cee72f27593846cef16c8b8` |
| C/D 标定回执 | `2ae2d39584755d265c020549c169ea18e979394263d8b3b06fe40343d0da760e` |
| 六运行 zero-update preflight 回执 | `f80516bf7710469441cc971f919e0993553d18bd03352c62e94d47645c7a4042` |
| 统计补充协议 | `85751899ec1c9d274c6f899049e45823e4acf9c41fe50504efae60561cbf0b8f` |
| QA-1 统计工具 | `ab6747315864035995b32aa1a5dc3bd17f0a78d493a74c4f533d11726388fde2` |
| 统计 CPU tests | `8f2c039a2d5327271be76f05384b37bf55912e8550662768c48a467a9032c463` |
| 统计 P3 | `251c5a1847a411d9c76e16df63c7224c5e97b5bdc0bea24d7cbefafb4a220359` |
| 统计 execution request | `a568b4219aaeef8ce9ea05df58df32ce2c8a3ebbba9a3daac39fc55dad3c3eda` |
| 统计结果 summary | `660adb3310532d5a4d8f08d9adde61f0a3961ce4676978e9ff9050da22774e89` |
| 统计 paired source deltas | `236efc1cc8be8b4721fb0fb385b65edd83e4bbadb05fcd0f61edcd60c60de555` |
| 统计 files.sha256 | `c99f85ec0de619a546d836200ea848dca3d158411594148ff015147e3614aa00` |
| 安全性复盘 request | `a17f87adc4d9fec71423a9edd8c0a261a187a8da05609c18952d39fdd545bbd7` |
| 本机安全性复盘报告 v1 | `269926bd16bb42f392fbd99269cdbc9cfe2104cffa0c0ade75c4931eda0ebd68` |

标定路径：`logs/cranial_scqr_v12_qa1/cd_gradient_calibration/v12_qa1_cd_gradient_calibration_v1_20260921T142811Z/calibration_receipt.json`。Preflight 路径：`logs/cranial_scqr_v12_qa1/zero_update_preflight/v12_qa1_zero_update_preflight_v2_20260922T143530Z/preflight_receipt.json`。上述相对路径均指服务器根 `/home/jovyan/adapointr_work/PoinTr`。

本机完整授权输入清单见 `E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_10/v12_qa1_statistics_execution_authorization_request_v1.json` 与同目录 `v12_qa1_safety_historical_evidence_review_request_v1.json`；完整安全性解释见同目录 `v12_qa1_safety_historical_evidence_review_report_zh_v1.md`。本报告附带单运行全部 JSON 指标的来源快照及本机 SHA256 清单，支持核对四舍五入表格。

来源快照：[qa1_six_run_summary_source_snapshot_v1.json](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/qa1_six_run_summary_source_snapshot_v1.json)。它保存六份 single_run_summary 内容、服务器相对目录、summary 与 execution receipt hash，不是原始 CSV 或 checkpoint 备份。原 JSON 摘录以源 hash 标识，本机重新序列化快照有自己的独立 hash。

### 保存与权限

本机项目根 `E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution` 是管理/报告目录；服务器项目是不同文件系统。本报告不是完整服务器实验归档，也不代表 `E:/ResearchBackups/AdaPoinTr` 已有用户确认的长期备份。不得因报告存在删除服务器 checkpoint、日志或归档。

本轮新增本机报告、来源快照和 hash 清单；未修改服务器文件、未运行训练/BNCal/inference、未读取 NPZ、未反序列化 checkpoint、未使用 GPU、未重算 bootstrap、未执行正式 gate、未创建新 execution request，也未 commit/tag/push。后续修订使用 v2，不覆盖本 v1。

本报告基于项目内冻结证据，不是文献综述或临床评估。技能用于组织状态、结果、证据和建议；所有未执行阶段与推断均明确标记，避免把工程 PASS、统计信号和临床/论文结论混为一谈。
