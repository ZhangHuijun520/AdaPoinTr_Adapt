# Cranial-SCQR v1.2-QA 后续正式实验计划（修订版 v1）

_2026-10-11，Asia/Shanghai；风险—收益辨析、有限机制诊断与条件式稳定性复核。_

| 项目 | 定义 |
|---|---|
| 计划 ID | `cranial-scqr-v12-qa-followup-rsd-plan-v1` |
| 文档状态 | `AWAITING_EXPLICIT_USER_CONFIRMATION` |
| 建议研究阶段 | `v1.2-RSD`：Risk–Signal Disambiguation |
| 原 QA-1 正式状态 | `NOT_ADJUDICATED_HISTORICAL_NUMERICAL_EVIDENCE_GAP` |
| 当前研究决策建议 | 暂不晋级原 QA-2，不实施 Query-Mamba |
| 本次交付范围 | 本机方案审阅与计划修订；没有服务器操作或新实验 |

本文是完整的阶段级研究设计，不是机器可执行协议，也不是 execution request。用户确认本计划只确认研究路线；实施、人工测试、preflight、真实数据访问、checkpoint 加载、训练、BNCal、推理、统计分析、正式 gate、归档和删除仍分别授权。涉及具体文件、资源、计数和实现身份的阶段必须再生成版本化子协议和待授权 request；不可直接用本计划启动实验。

---

## 📋 1. 审阅结论与必须修正的问题

### 1.1 总体评价

原建议稿的主要方向合理：不以 RimCover 均值改善抵消新增 disaster，不立即展开旧 QA-2/Mamba 大矩阵，先用已保存证据排查事件触发，再决定是否值得付出有限诊断预算，继续封存 confirmation20。它也正确强调 skull 级统计单位、容量对照、公平基线和负结果保留。

但原稿不能原样成为正式执行依据。主要不足是：正式 gate 与描述性证据混用，部分因果结论过强，旧安全停止规则与新诊断训练之间缺少明确的新协议接口，以及把可选研究任务写成必做任务。本修订保留其科学主线，收紧结论，减少无条件预算，并补齐分阶段授权、数据访问和可证伪设计。

### 1.2 关键修订对照

| 原稿问题 | 修订处理 | 理由 |
|---|---|---|
| 直接写 `PRIMARY_EFFICACY_SIGNAL=PASS`、`SAFETY=FAIL` | 描述性信号、历史证据状态、研究不晋级决策分别记录 | 不覆盖已确认统计补充协议，不冒称正式裁决已执行 |
| R0 直接生成全部正式 gate 表 | R0 默认只整理证据与 no-advance 建议；正式 gate 另立授权 | 文档审阅不是 gate 执行许可 |
| “信号真实、稳定、四折复现” | C/D 固定权重下方向一致；A/B 仅作历史假设来源 | 不同版本、不同对照不能拼成严格四折复现 |
| snapshot 完整就等同完全可比 | 同时核验代码、配置、初始化、随机流、数据与各阶段合同 | flags 快照是必要证据之一，不是充分条件 |
| query-off 无变化即证明训练权重主导 | 只记为未发现明显即时敏感性 | 小残差、冗余补偿、干预失败和测量分辨率均可能解释 |
| query-off 变好即证明 query capacity 重分配 | 只支持该固定权重下残差干预影响几何的证据 | 干预可能引入分布偏移，attention 不是机制因果证明 |
| “四次新训练是最小必要预算” | 新训练为 0 或条件式至多 4 次；允许审计后止损 | 风险已经可观察，不必为停止路线再训练 |
| 默认 seed1 是纯 seed 稳定性检验 | 定位为新严格合同下的 seed1 诊断；跨合同变化单列 | 历史缺口及实现变化不能归因于 seed 本身 |
| `LS≈L0` 就删除 SCF | 区分证据不足、近似相当与已验证等效 | 未显著不等于等效，不能从均值直接判机制 |
| identity + gated residual 被称为新创新 | 现有 Query 已有 identity residual；新方法必须增加可检验约束 | 避免将已有结构重新命名为新贡献 |
| 平均 gate budget 等于安全保证 | gate 预算仅是结构假设；还需约束残差幅度并验证几何 | 小 gate 仍可乘以大 residual；decoder 可放大变化 |
| GM 不胜 GT 就删 Mamba | 保留质量优势或质量非劣下实际效率优势两条证据路径 | 不能抹掉原计划允许的效率贡献路径 |
| 16384 和所有新基线“必须立即补齐” | 可行性审计提前，GPU 实验和分辨率分支有条件进入 | 防止近期小论文任务膨胀为无上限 benchmark 工程 |
| “一侧 rim 好”直接解释为临床安全 | disaster 仅称冻结工程异常，明确不等于临床终点 | 当前无临床专家、制造或真实病例验证 |
| 两周固定日程 | 改为产物驱动里程碑与停点 | 排队、适配、审批和重连耗时不可预承诺 |

### 1.3 不采用的默认行动

不默认执行原 QA-2 的 L0/LQ×A-D×seed0；不恢复 QC/direct log-bias；不扫 alpha、temperature、ordering 或 seed；不自动补做旧 snapshot；不把新结果替换旧 QA-1；不读 confirmation20 选择下一条路线。

若本计划后续获确认，RSD 是独立的开发诊断扩展，而非把原 QA-1 的安全停止规则改成“可以继续晋级”。每次新诊断必须明确为何允许有限实验、回答哪个问题、预算是多少、失败后如何停止。没有该接口就不执行新训练。

## 📊 2. 当前证据、研究问题与继承边界

### 2.1 已完成与未完成

QA-1 的 B0/LS/LSQ×C/D×seed0 六运行，训练、BNCal、development evaluation 及执行完整性冻结已完成；LSQ−LS 描述性统计与安全性/历史证据复盘已完成。整体 v1.2-QA 尚未完成，正式 gate/五类科学分类、QA-2、QA-3、容量对照、Mamba 和 confirmation20 未执行。

以下直接引用已冻结报告，不重新计算 bootstrap、gate 或新比较：

| LSQ−LS 指标 | Fold C | Fold D | Pooled | Pooled 95% CI |
|---|---:|---:|---:|---|
| RimCover-P95，mm | -0.572073 | -0.402413 | -0.487243 | [-0.894924,-0.088829] |
| Implant CD-L1，mm | -0.336513 | +0.250150 | -0.043182 | [-0.331009,+0.215501] |
| Final CD-L1，mm | -0.025346 | +0.052849 | +0.013752 | [-0.011417,+0.041837] |
| Final HD95，mm | -0.109615 | +0.282961 | +0.086673 | [-0.058518,+0.245725] |
| Final NSD@1mm | +0.000627 | -0.000886 | -0.000130 | [-0.000619,+0.000384] |

| 风险观察 | Fold C | Fold D |
|---|---|---|
| LS / LSQ disaster | 3 / 1 | 4 / 5 |
| LSQ 独有新 disaster | 025/random_2 | 008/random_1、010/random_1、087/parietotemporal |
| LS / LSQ zero-contact | 0 / 0 | 0 / 0 |
| 历史训练/BNCal 数值证据 | LS 缺完整快照 | LS、LSQ 有快照，仍需全合同核对 |

Fold D 21 个 source 中 17 个 Implant CD 差值为正，4 个为负；四个 LSQ 新 disaster 的 RimCover 都改善。它们支持“边界覆盖与其他质量维度可分离”的问题定义，但不证明 underfill、attention collapse 或 capacity 重分配已是根因。

数值证据缺口不能抵消坏病例；坏病例也不允许我们跳过既有证据前提，直接把未裁决状态改写成正式 `SAFETY_FAIL`。合理的保守研究建议是“不晋级当前 LSQ”，不需要先宣称完成正式科学分类。

### 2.2 数据角色

| 分区 | 用途 | 继续保持的边界 |
|---|---|---|
| development84 | 84 skull、420 case，适应性开发 | 不是独立 test |
| C/D fold-train | 每折 63 skull、315 case | 训练与 partial-only BNCal；不混入 dev |
| C/D fold-dev | 每折 21 skull、105 case | 获授权后诊断/评估；两折共 42 skull、210 case |
| A/B | 历史 hypothesis-generating evidence | 不因本计划自动重评或并入 C/D 主分析 |
| confirmation20 | 20 skull、100 case | `SEALED`，当前禁止访问 payload 和 outcome |
| official test / old monitor | 历史已暴露 benchmark | 不能包装为未暴露最终测试 |
| SkullFix / MUG / 其他来源 | 未来独立协议 | 不自动上传、下载、合并或读取 |

C/D 在 QA-1 首次观测时可称 prospective internal OOF replication；现在已看过结果，RSD 的同折复核属于适应性开发/内部诊断，不再称新的未暴露验证。折间训练集重叠，五种缺损同属一个 skull，不能把病例、折或 seed 当独立样本扩大 N。

### 2.3 要回答的四个问题

1. 事件：四个新 disaster 的冻结触发分量究竟是什么，是否存在 identity、尺度或指标实现问题？
2. 即时作用：在同一 LSQ 权重下去掉 Query residual，会怎样改变 rim 与全局几何？
3. 新运行：若值得投入，严格统一合同的 seed1 LS/LSQ 配对中，收益与风险如何表现？
4. 后续主线：证据更支持停止当前 LSQ、研究 Local/SCF，还是另立一个受约束 Query 版本？

这些问题不预设答案。不假定新 snapshot 会消除风险，也不假定必须拯救 Query 或把 Mamba 保留在论文标题中。

## 🎯 3. 阶段路线、进入门与研究停止规则

### 3.1 最小主线

```mermaid
flowchart TB
    accTitle: Conditional Followup Research Roadmap
    accDescr: Freeze existing evidence, audit event triggers, and use a limited intervention only when justified. New seed training and architecture expansion require separate decisions and authorizations.
    evidence_lock["R0 证据与不晋级记录"] --> event_audit["R1-A 事件触发审计"]
    event_audit --> diagnostic_choice{"是否值得有限诊断"}
    diagnostic_choice -->|否| stop_query["停止当前 LSQ 扩展"]
    diagnostic_choice -->|是| query_intervention["R1-B 固定权重干预"]
    query_intervention --> seed_choice{"是否需要 seed1 信息"}
    seed_choice -->|否| stop_query
    seed_choice -->|是| seed_diagnosis["R2 至多四次新训练"]
    seed_diagnosis --> branch_review["冻结结果并选择分支"]
    branch_review --> conditional_branch["Local 或新 Query 协议"]
    conditional_branch --> future_controls["稳定性与容量对照后再议 Mamba"]
```

R0/R1-A 本身可以支持止损；R1-B、R2 不是强制流水线。决策图表示依赖关系，不表示批量授权。

### 3.2 统一停止规则

| 情形 | 处理 |
|---|---|
| 输入 hash、allowlist、配对、实现身份或数值合同不一致 | 执行不成立，停止；先只读定位，不自动修复或重跑 |
| 输出目录已存在、计数超额、访问禁止分区 | 停止并冻结副作用证据；不可覆盖旧产物 |
| 新 disaster、某折灾难增加或几何硬护栏失败 | 不晋级该候选；不靠 pooled 均值抵消 |
| zero-contact 增加 | 进入人工 review，不直接判安全通过 |
| 信号未达到幅度、CI 不确定或折/seed 反向 | 保留不确定性/异质性；不扫 seed，不默认扩大矩阵 |
| 两次模型版本修改仍未获得预设安全与增益证据 | 建议终止该结构修复分支；扩大预算需新研究理由 |
| 没有值得回答的新问题 | 停止追加实验，而非为了填满预算运行 |

“两次模型版本修改”是本后续计划提出的开发预算上限，不是原 QA-1 gate，也不是已经获用户批准的承诺。工程 hotfix 与算法版本变更分开登记；hotfix 同样不得自动重试。

### 3.3 后续晋级不等于改变历史结论

若未来新版本在统一合同下通过安全和稳定性，只能支持新版本的结论，不反向将 seed0 QA-1 改成成功。旧 LSQ 不再作为待择优的 checkpoint 候选；旧负结果和风险清单保留。原 QA-2 继续暂停，需要新的因子分解协议，而不是沿用旧名称自动进入。

## 🔍 4. R0 与 R1-A：证据锁定及事件触发审计

### 4.1 R0：非执行证据锁定

建议下一项单独授权仅覆盖 R0+R1-A 的只读范围。R0 核验父计划、已确认补充协议、统计产物、freeze receipts 和相应实现 hash；记录执行完整性、数值证据和研究结论三个独立维度。只读任务若获准在本机写报告，需明确本机产物目录；服务器源文件保持不变。

拟输出：证据 ledger、历史缺口列表、原阈值来源索引与 `NO_ADVANCE_RECOMMENDATION`。这一建议是研究治理记录，不是五类正式分类或原 gate 的替代字段。

本计划不要求先解除历史证据锁再做诊断。若用户确实希望正式 gate adjudication，必须另行确认历史缺口如何处理、分类前提和执行范围，创建新的待授权 request；不能修改已确认补充协议 v1 或直接把建议稿中的 PASS/FAIL 表写入旧结果。

### 4.2 R1-A：限定输入和全量输出

允许输入应在 request 中逐项绑定：LS/LSQ×C/D 四份冻结 case-level CSV、skull-level CSV、相关 summary/receipt/manifest，以及实际生成 flags 的 evaluator 与 protocol 文本。不读取 B0 outcome 计算新比较；不加载 checkpoint、不打开 NPZ/STL、不构造模型、不使用 GPU、不运行训练或 BNCal。

已有复盘记录的事件、Fold D 17/4 source 符号分布与五缺损均值直接复用。新增工作仅补足尚未保存的事件触发分解、210-case transition ledger 与字段一致性，不重复执行既有 bootstrap。

按 `(fold, case_id, seed)` 配对，检查 source、defect、归一化/mm 转换身份。210 个独特 case 必须完整覆盖；不得静默删除缺失、重复或异常项。

| 必需输出 | 内容 |
|---|---|
| 210-case transition ledger | 两模型 flag、共有/独有事件、原始 core metrics、source、defect |
| Trigger decomposition | nonfinite 分量、contact HD95 与 50 mm 边界、zero-contact 单独列项 |
| 阈值邻近信息 | 原值与触发阈值距离；保留严格不等号和完整精度 |
| Fold/source/defect 汇总 | 同时报新增、消失、共有和总数，不只看净计数 |
| Tail index | 固定 source 排序和全量结果；已有尾部极值保持不删 |
| 数据/实现问题列表 | identity、尺度、缺字段、flag 规则与输出矛盾 |

disaster 规则必须逐字节绑定实际 protocol/evaluator，不能随意加“其他 core trigger”。若 CSV 无法说明具体触发原因，输出 `TRIGGER_UNRESOLVED_FROM_STORED_EVIDENCE`，列出缺失字段；不得由 Implant CD 大小猜测触发，也不得为了补原因自动打开 payload。若要从已存数值字段重现 flag，属于本次获明确授权的 CPU 审计计算，不是运行模型。

### 4.3 展示病例与对照选择

全量结果是主证据，精选个例仅用于可视化解释。四个已知新 disaster 是事后诊断目标，不是预注册随机样本，不能由它们估计总体发病率。

建议冻结每个事件两个对照：同 fold、同 defect、两模型均非 disaster 且非 zero-contact，按原 LS RimCover 与目标病例的绝对差排序，tie 按 `case_id` 字符串升序取前二。不得用新 instrumentation 选对照；不同事件选中相同 control 时保留并去重展示，报告实际数量，不保证一定八个独特 control。该匹配只是技术对照，不是临床/解剖学完整匹配。

同时保留 `087/frontoorbital`、`087/random_1` 两个反向尾部病例，避免只展示正向变化。匹配列表在读取新特征/预测前冻结；R1-A 未授权 payload 时不做几何图。

### 4.4 出口

若发现指标/身份错误，先独立处理工程有效性，不把错误修正当算法改进；所有受影响旧结果保留，是否重新评估另行授权。若数据和 flags 自洽，可选择停止当前 LSQ，或仅起草 R1-B 子协议。R1-A 完成不自动允许模型干预。

## ⚙️ 5. R1-B：冻结 checkpoint 的单一 Query 干预

### 5.1 设计与估计对象

固定 C/D、seed0 四个已完成 BNCal checkpoint：LS C/D 与 LSQ C/D。每个 dev case 三条件：

| 条件 | 权重 | Forward |
|---|---|---|
| LS-native | 对应 LS BNCal checkpoint | 原生无 Query 条件化 |
| LSQ-native | 对应 LSQ BNCal checkpoint | 原生 Query residual |
| LSQ-query-off | 与 LSQ-native 相同 checkpoint | 只在 residual 加法出口旁路残差 |

核心干预对比是 `LSQ-query-off − LSQ-native`，衡量该固定网络权重下去除残差的即时效应。LS-native 只是训练来源不同的参考；LSQ-query-off 不是 LS 模型，也不是“训练时从未使用 Query”的反事实。

从本机历史代码可见已有结构为 `queries + residual`，其中 residual 含 `alpha_q × warmup × update`。未来实施前必须核验服务器实际代码身份与调用点；本机文本不认证当前服务器实现。不得以直接修改 checkpoint 的 alpha 参数、改变 beta 或 warmup 来实施干预。建议使用独立 v1.2-RSD evaluator 的显式 bypass 开关，保留原模块和 state_dict，v1.1/原 QA-1 路径不变。

### 5.2 权限和次数

正式真实数据执行预算为：210 个独特 dev case、630 次 model forward、optimizer steps=0、parameter/buffer updates=0、训练 checkpoint write=0、BNCal=0。按 fold 分成两个单次 request，各 105 case、315 forwards；分折授权不推导另一折权限。

请求须另行冻结 checkpoint load 数量、NPZ open 数量、缓存行为和禁止路径：若每 case 读一次后供三条件使用，则每折 105 次 NPZ open；若设计不同，先修订协议，不能运行时扩大计数。四个 checkpoint 的 SHA256 由既有报告索引核对，并在执行前重新校验。原先未保存预测，不能把现有 CSV 当完整几何对照替代新的 native forward。

模型输入仅为 partial；GT implant/reference rim 仅在 forward 完成后用于指标和诊断标签。GT-positive proxy attention mass 为 post-forward 探索性统计，不允许影响 attention、选择 query、阈值、gate 或排序。BN buffers 不再校准；query-off 的潜在 train/inference 分布偏移作为限制报告，而不是做一次 BNCal 消除它。

### 5.3 最小 instrumentation 与定义

优先记录每 case 的低体积标量，不默认保存所有 attention 矩阵或中间特征。

| 层级 | 固定核心记录 | 解释边界 |
|---|---|---|
| Query | 学得 alpha、warmup、residual RMS、query RMS、相对 RMS | 残差幅度不是贡献归因 |
| Attention | 每 query entropy、exp(entropy)、最大权重的 case 均值 | concentration 不等于因果重要性 |
| Coarse | GT-rim→coarse P95、2 mm 内支持率、centroid/radius 相对 GT | GT 仅诊断标签，不用于 forward |
| Dense | 既有 primary/护栏、双向最近邻均值、case flag transitions | 不改变既有 CD 定义或聚合 |

建议定义：attention entropy 为 `−sum(a*log(a))`，零权重项按极限置零，使用自然对数；effective proxy count 为 `exp(entropy)`，范围 1 到 proxy 数。残差比为 `RMS(residual)/max(RMS(query),1e−12)`，全用 FP32，记录计算轴。Coarse centroid 是点均值，RMS radius 是至自身 centroid 的均方根距离；相对指标的 GT 点数与 mm 恢复规则须冻结。

Gini、top-10% mass、query cosine、density CV、outlier ratio、normal/curvature 不进入首轮核心包。若之后需要，先给出尺度、邻域、阈值、退化情况和存储预算，另立探索性补充；不能发现某个指标好看才新增并称主证据。

### 5.4 实施和 preflight 合同

执行前依次完成：只读 pre-implementation 核对；implementation-only；人工 CPU contract tests；post-implementation P3；单独授权人工 zero-update GPU preflight；创建真实数据待授权 request。

必需契约：

- instrumentation on/off 对 native 输出及模型状态不产生额外变化；旁路只影响 residual 加法，不改变权重或 Local/SCF
- 开关由显式 condition 选择，不修改冻结 runtime/checkpoint，不用全局 monkey-patch 污染后续条件
- LSQ-native 与 query-off 使用相同数据张量、mm 参数、case 顺序；eval/no_grad，BatchNorm/dropout 状态固定
- 在人工输入上验证 native→off→native 恢复、零 residual 恒等、非零 residual 干预有效；异常退出也恢复状态
- CPU 不冒充 CUDA 数值等价；CUDA preflight 只用冻结人工输入，次数在其 request 中锁定
- checkpoint 严格加载，missing/unexpected keys 为零；参数和 buffers 前后 hash 不变；计数器及禁止数据访问可核对
- 原 native case metrics 与既有 CSV 对照；执行前用人工或已授权 train-only 材料冻结容差，不由 dev 差值反调容差

若 native 在预先冻结容差之外变化，R1-B 不形成可解释机制结论，停止并保存诊断证据。哈希不同只说明字节不同，不能自动解释为参数不同；状态 hash 的序列化规则必须固定。

### 5.5 解释与可证伪结论

| 干预观察 | 可支持的表述 | 不可支持的表述 |
|---|---|---|
| rim 回退、全局/异常改善 | 当前权重下残差开启涉及 benefit–risk 权衡 | 已证明 query capacity 转向 rim 是唯一根因 |
| 多项输出变化很小 | 当前干预未发现明显即时敏感性 | 已证明所有差异来自训练权重 |
| rim 和全局均变差 | 网络对该 residual 有功能依赖，去除可能分布偏移 | Query 普遍安全有效，或 off 失败证明 native 可晋级 |
| 指标与 instrumentation 不一致 | 需要查测量/调用点或替代解释 | 挑出一张 attention 图宣称机制成立 |

“几乎无影响”“恢复”“主导”不能只凭肉眼。子协议必须在执行前冻结每指标容差/诊断幅度、fold/source 汇总规则和不确定性口径；暂未冻结这些值时只报告连续差值与逐病例变化，不做离散机制分类。若借用 `0.10 mm` 作诊断参考，只能称工程参考，不自动构成等效检验或临床无影响。

首轮不做 alpha/temperature sweep，不把 query-off 当待选临床模型，不保存其 checkpoint，不反向选案例优化结构。若需干预 bootstrap，另建 CPU 分析 request；不擅自复用 QA-1 统计程序计算新条件。

## 🔄 6. R2：条件式严格合同 seed1 复核

### 6.1 是否执行及 seed 选择

只有 R0/R1 产物冻结、导师/用户认为新运行确有信息价值，且明确接受独立诊断扩展预算时，才起草 R2 执行协议。默认建议 seed1，不默认重跑 seed0；seed0 matched replication 可作为替代方案，但两者目的不同。

| 方案 | 回答问题 | 限制 |
|---|---|---|
| 默认 seed1，四运行 | 新严格合同下另一训练随机状态的收益与风险 | 旧 C 折缺口仍在，跨新旧合同不能纯归因 seed |
| 替代 seed0，四运行 | 统一合同下同 nominal seed 的重新观察 | 不补证旧快照，不保证跨版本 bitwise 一致 |
| 不训练 | 已有风险是否足以停止当前 LSQ | 没有新稳定性证据，但仍是有效止损决策 |

不能先做 seed0，再因不理想改 seed1；也不默认加 seed2。若要严格分离“合同变化”与“seed变化”，需要同一最终实现下 seed0/seed1 完整匹配的额外设计和预算，本首轮不承担该问题。seed1 若安全也不能洗掉 seed0 风险；称“跨 seed 表现有差异”，不能在存在合同差异时直接称“seed 导致”。

### 6.2 四运行矩阵与不变项目

建议固定矩阵为 `LS/LSQ × Fold C/D × seed1`，四个 scratch、final-only run。既有六运行只作历史参考，不和新模型拼接为新匹配矩阵。

| 合同 | 保持值/要求 |
|---|---|
| 数据/表示 | 原 manifest、原 C/D allowlist、partial8192 / implant8192 |
| 模型/loss | 原 LS/LSQ、beta=0；不加新 gate、loss 或 Mamba |
| SCF 权重 | C `0.8912909312609397`；D `0.8346387037781536`，不重新按 dev 调整 |
| 训练 | AdamW，lr1e−4，wd5e−4，FP32，AMP=false，batch8，drop_last=true |
| 精确预算 | 39 batches × 101 traversals = 3939 optimizer steps，每 run |
| 其他训练合同 | 继承 scheduler、grad clip=10、增强、输入顺序、final-only，不 early stop/resume |
| BNCal | 训练成功冻结后另授权；315 train case，partial-only，40 forwards |
| Evaluation | BNCal 成功冻结后另授权；105 dev case，batch1、workers0、原 evaluator 指标 |

复用已冻结 lambda 是为控制变量，不声称它在 seed1 梯度比例仍精确为0.1。若想重新标定，这是新研究变量，必须单独论证，不能夹带进稳定性复核。

### 6.3 数值、随机流与实现身份

四运行使用同一最终训练/BNCal/evaluator 实现及软件合同；开始前冻结 Python、PyTorch、CUDA/cuDNN、NumPy、扩展源码和 binary hash、GPU 型号/UUID、driver、线程、依赖版本。容器 hostname/UUID 改变需要 resource-rebind 审计与新 request，不复用旧执行授权。

严格数值要求：deterministic algorithms=true、warn_only=false、cudnn deterministic=true、benchmark=false、matmul/cudnn TF32=false、CUBLAS workspace 明确冻结、FP32、AMP=false。在训练、BNCal、evaluation 各自 start/end 记录实际 flags 和断言，不只记录 CLI 意图。FP32 dtype 不意味着 TF32 已关闭。

公共主干相同 seed 使用相同初始 tensor hash；新增模块使用独立 RNG stream。DataLoader shuffle、worker seeds、增强随机流、数据采样和模型随机流分别冻结，避免 LSQ 多消耗随机数改变公共数据序列或主干初始化。不要只用同一整数 seed 就宣称配对随机性相同。

PyTorch 官方说明跨 release/platform 并不保证完全重现，因此快照与环境一致性必须共同核验；该通用原则不构成升级当前环境的理由。[^1] 自定义 CUDA 扩展还须在有限人工重复检查中验证，而不能认为全局 flags 自动覆盖每个外部 kernel。若工程限制无法获得所声称的严格合同，停止并修订结论范围，不悄悄降级为 warn-only。

### 6.4 执行与科学停止分开

四运行须逐 run 授权。建议在首个 request 前冻结平衡运行顺序：LS C→LSQ C→LSQ D→LS D；同 fold 尽量在同一软件/GPU 合同下完成，模型/数据 RNG 不由墙钟或顺序生成。

训练内不读取 dev、不根据 dev early stop。首轮若已确认硬风险，用户可选择提前停止剩余诊断预算；未完成平衡矩阵只能报告“部分诊断结果”，不得据此形成 C/D pooled 通过声明。技术失败立即停止，不自动补 run、resume 或热修复后重试。

完整矩阵最大新增 15756 optimizer steps、4 次 BNCal 共160 forwards、4 次 evaluation 共420 forwards。人工 preflight 另计，不能混进正式训练/评估数量。

### 6.5 分析与下一步

R2 仅以 LSQ−LS 为主比较；继续使用原 primary 与安全阈值，fold 和 pooled 作用域遵循已确认补充协议。所有主/安全门同时展示；不把单 seed 通过表述为临床安全或总体 Query winner。

| 新结果 | 研究处理 |
|---|---|
| 有收益且再次出现硬风险 | 停止当前 LSQ 晋级；如需新 Query，独立新版本协议 |
| 收益消失、实用幅度不足、折方向反向 | 停止扩展或冻结不确定性，不继续寻优 seed |
| 收益、安全及合同均合格 | 仅支持新诊断运行；旧风险保留，仍须后续稳定性/机制对照 |
| 结果不确定 | 不自动追加训练；先判断继续是否有清晰信息价值 |

统计与正式判定仍为独立执行阶段。预先注册阈值可以用于新 R2 的工程研究继续门，但不能绕过旧 QA-1 正式分类锁。停止当前 LSQ 不等于证明所有 Query 算法无效。

## 📚 7. 条件分支：Local/SCF、新 Query 与 Mamba

### 7.1 Local/SCF 分支：先隔离 loss 作用，再谈主贡献

如果 Query 停止，优先讨论 L0 vs LS，无需先实现 LQ。该分支是新的局部表示研究协议，不是原 QA-2 自动恢复，也不意味着 LS−B0 已完成正式推断。现有 B0/LS 单运行汇总只提示值得研究，不能支撑“LS 已稳定胜出”的论断；原 LSQ−B0 次比较仍锁定。

最小首批建议 `L0 × C/D × seed1` 两个新 run，配对复用 R2 的 LS seed1 仅限实现、公共初始化、数据随机流、训练/BNCal/evaluator 合同完全一致。若 R2 未做，L0/LS 两候选×两折需要四个新 run，不能谎称只需两个。

为识别 SCF supervision，建议 L0/LS 实例化相同 Local/SCF 结构与公共初始化，唯一实验性差异是冻结 `lambda_scf=0` vs `lambda_scf>0`；head 的 optimizer 成员、requires_grad、实际梯度和 weight decay 行为须明确。零权重路径不得因先计算 `0×NaN` 而污染训练，也不得改变主干随机流。结构和参数成员若不同，只能称复合消融，不能称纯 loss 因果对照。

LS 优于 L0 仅支持 SCF supervision 的条件增量；“representation shaping”仍需梯度到 shared H 以及独立 stop-gradient 训练干预等证据。推理关闭 beta=0 的 SCF head 应为 no-op，仅是契约检查。均值接近或 CI 跨0不证明等效；若证据不足但增益很小且风险/成本无优势，可基于简约原则选择 L0，同时如实写“不足以确认额外收益”。

未来如需总体方法优于无 Local 的 B0，必须另建新的匹配 B0 比较协议和预算，不拿早期缺快照的 B0 自动拼入严格矩阵。最终 minimal winner 至少与最近机制对照跨两个新合同一致的 seed 核验；历史 seed0 只能在证据充分时复用，否则保持缺口，不强称双 seed 已确认。

### 7.2 新安全约束 Query：一个候选、一条机制预测

只有 R1/R2 提供明确可检验设计线索，且用户另行选择该分支，才起草例如 `v1.3-CPQ` 的独立模型协议。不能把现有 LSQ 更名为 CPQ，不以新模型通过救活旧模型。

现有 Query 已有 identity + residual；仅添加 `Q+alpha*g*DeltaQ` 或另一 global residual 不能自动构成创新。若使用 gate 平均预算，它只约束 gate 数值，不约束 residual 范数，更不保证最终几何安全。新设计应给出可测试的约束对象，例如 query residual 的相对范数上限、全局信息路径不被替换，以及训练/推理一致的预算实现；具体数值必须在新 dev outcome 前冻结，不由本次结果反调。

不允许 GT-rim inference、hard top-K contact selector、无限 gain/temperature 搜索。首轮只选一个候选，配一个最近机制对照和必要容量对照，固定 seed/fold/训练上限；模型修改预算建议最多两个版本，第二版仍不成立则优先止损。两折单 seed 合格后是否追加第二 seed需另授权，不能把一次安全观测称普遍安全。

若研究 SCF×Query interaction，仍需同合同下 L0/LS/LQ/LSQ 2×2，而非用 query-off 取代训练因子。交互项 `(LSQ−LQ)−(LS−L0)` 及其主次地位需先冻结；不从不同 seed/版本拼接矩阵。

### 7.3 Mamba 的条件进入与两条保留路径

保留用户的长期 Mamba 方向，但当前不授权实现或训练。Query-Space Mamba 必须有已冻结且获支持的 query representation 基础、至少两个可比 seed 的稳定性、没有未处理的新增工程风险、query coupling 的必要容量对照，以及未打开的 confirmation20。

如果最终只支持 Local、没有 Query coupling 证据，不自动回到旧 encoder-post Mamba；若想研究 Local-token Mamba，需要独立问题和对照设计。不能把所有 Mamba 方向永久判无效，也不能为保留标题绕过当前证据顺序。

| ID | 模块 | 角色 |
|---|---|---|
| G0 | 冻结稳定基础 | 增量参考 |
| GM | 基础 + Query-Mamba | 待验证候选 |
| GT | 基础 + matched Transformer | token 交互架构对照 |
| GP | 基础 + matched MLP/residual | 非交互容量对照 |

控制训练预算、输入/输出 token、公共初始化和数据合同；报告参数/FLOPs 的实际差额。参数与 FLOPs 不能同时精确匹配时，应事前给出匹配优先级和容许偏差，而不是结果后称“matched”。排序及 inverse-sort、预处理、GPU 同步和数据传输计入端到端效率；不能只报 kernel 时间。anchor ordering 只由 partial/model feature 得到，不能用 GT。

原计划的 Morton/Z-order、双向/正反向共享等设计仍仅是候选；依赖/自定义 kernel 可否满足严格合同须先可行性审计。不能运行 ordering sweep后挑最佳值。

Mamba 保留门有两条、在看结果前选择主路径并冻结阈值：

1. 质量路径：GM 相对 GT 和 GP 有预设实际几何增益，并满足全部风险护栏。
2. 效率路径：GM 质量达到事前定义的非劣要求，并相对合理质量水平的 GT/GP 有实际端到端延迟或峰值显存优势。

质量非劣需明确估计量、CI 方向和 margin，不能用“差异不显著”替代；效率门的阈值不能事后挑 latency 或显存之一。只有在两条证据路径均不成立时，删除 Mamba-specific 核心主张；GM 只比 G0 好不能单独证明 Mamba 特有增量。query≈256 并不排除实测优势，也不能凭理论 O(N) 保证优势。

## 📈 8. 统计合同、强基线、分辨率与最终确认

### 8.1 统计单位与比较管理

每个 case 按原 evaluator 计算 metric；每 skull 五缺损等权均值，再 skull 等权均值。每 seed 独立 C/D 分层 source bootstrap：每折21 skull、pooled两折各0.5、10000次、seed20260910、source ID 字符串升序、PCG64/default_rng、每块1000且C后D、linear percentile；NumPy版本绑定最终实现。禁止所有点重算一个P95、case-level bootstrap、按结果删除source。

Bootstrap 是固定训练权重下的 source 重采样描述，不能覆盖训练 seed 或整个架构选择过程的不确定性。两个 seed 同一 skull 不构成两份独立病例。seed 内估计与 CI 分开展示；跨 seed 的 mean/SD/range仅描述，若做 per-skull seed平均仍以同一 source 为聚类单位，并且明确合同不齐的历史 seed 不纳入“严格一致”汇总。

同 fold 模型训练集重叠带来的跨 source/跨折学习依赖不由这个 bootstrap 完全刻画；不称外部泛化检验。缺损分层、tail percentile、instrumentation 相关和示例图默认探索性，不引入多项独立“显著成功”。正式多比较需独立冻结层级或校正方法，不事后为最小 p 值换主指标。

冻结工程护栏继续按 fold及pooled：距离变化为候选−对照，Implant/Final CD `<=+0.10 mm`、Final HD95 `<=+0.50 mm`、Final NSD `>=−0.01`；primary方向两折 `<=0`、pooled幅度 `<=−0.10 mm`、CI上界 `<0`。新独有 disaster为0且每折不增，zero-contact增加不得直接通过。这里只记录继承规则，不给旧 QA-1 计算布尔 gate。新分辨率或新目标定义不能自动继承同一SESOI。

灾难发生率和差值同时按case/source列出，事件沿用实际冻结规则。nonfinite应保存原始异常/缺失标记并停止连续指标推断，不以删行或NaN均值隐藏。稀少事件的“0个新增”是工程继续门，不证明临床无风险；不临时追加病例以获取有利置信区间。

### 8.2 强基线：可行性提前，训练有条件

近期已核验原始来源：MedPCFM 描述 deterministic PTv3 encoder-decoder 医学点云基线；MedPCFM-TED 涉及 teacher-guided one-step implant generation。[^2][^3] CompletionMamba 和 DAPointMamba 说明 Mamba PCC 并非空白领域，但后者是 domain-adaptive PCC，不是当前单域颅骨任务的直接等价模型。[^4][^5] 这些支持开展竞争基线审计，不能直接证明本方法无创新或任何基线在本split必然更强。

建议先完成不训练的公开代码/许可证/依赖/协议审计，将 deterministic PTv3 列为优先候选，AdaPoinTr/B0 保持必需内部基线；若论文保留 Mamba，再评估 CompletionMamba。同协议可行的近期医学基线优先于把所有通用 PCC 都重实现。

基线分三步分别授权：公开材料审计→实现适配与人工单batch preflight→真实数据训练。不能因论文声明code available就假设实际可运行；审计须固定官方repo、commit、license、完整配置、外部pretraining与数据来源。GPU可行性也属于执行，不在纯只读文献阶段运行。

公平性需分开标记：

- 同研究合同适配：同split、点数、数据、mm evaluator、训练预算，回答受控架构增量；明确偏离论文原recipe
- 原方法合理recipe复现：允许预先固定不同优化/BN/EMA策略及等预算开发，回答竞争性能；不混称严格同训练合同

强行把含LayerNorm/EMA的外部方法做与AdaPoinTr相同BNCal并非自动公平；先审计归一化和权重选择，采用预注册可比评估。external pretraining检查source重合，尤其禁止包含confirmation来源。若无法统一目标和split，只做协议差异表，不并列文献数字为排行榜。

MedPCFM-TED 原文使用 partial14746 / implant1638、联合SkullFix/SkullBreak split，并报告GH20096GB实验，这与当前8192/8192及development84不同，故不把其绝对CD/时间直接搬来排名。[^3] 本次仅确认其arXiv预印本；建议稿所述Satellite Event camera-ready身份未由本次来源核实，不写作已确认录用事实。

TriFlow与LOT-Bridge的MICCAI2026官方页面已核验，属于triplane/SDF相关颅骨重建近邻；当前只作表示/协议对照，不要求RSD阶段重训。[^6][^7] Hyper-PCN作为高阶关系PCC近邻，不是“颅骨图结构必然有效”的证据。[^8] 其他未逐篇核验的泛称和创新拥挤判断不作为本计划的硬前提。

### 8.3 8192→16384：条件式表示分支，不是当前必做

只有8192下候选与对照稳定、结构冻结且数据采样来源可合法明确时，才讨论分辨率分支。先定义改变input、output还是两者；“16384”不能含糊指单侧或总点数。首轮建议保持input8192，单独研究implant output8192→16384，避免同时改变上下文与输出密度；若要双侧提升，独立协议说明估计对象。

16384GT应从已授权原始表面按冻结sampling生成并验证，不把8192点复制/插值当新独立高分辨率GT。缺原始表面或未获生成授权时，此分支不启动，不猜测本机/服务器路径。

矩阵至少为baseline/method×两种output点数×同fold/seed；8192旧结果只有identity audit完全通过才可复用。指标需同时记录native cardinality与预设共同评价点数下的公平对照，避免密度带来的最近邻改善被当作架构贡献。共同采样算法/RNG在看结果前冻结，不从多个downsample择优。

若论文主张高分辨率surface/implant质量，再增加同一固定重建后处理的DSC、AbsRVE、ASSD、surfaceHD95、SurfaceDice；网格/voxel resolution、坐标、阈值、hole filling、制造约束分别固定。点云指标不能替代这些指标，也不能声称得到可靠临床植入体。没有明确高分辨率主张时，可把16384留作可选扩展并报告8192限制，不让其阻塞所有小论文工作。

### 8.4 Paper-readiness 与 confirmation20

打开confirmation前，必须冻结最终方法、最近机制/总体基线、至少一个合理强基线的可比性或无法复现理由、训练/BNCal/权重选择、seed规则、表示、primary、风险门、evaluator、统计实现和失败处理。近期目标是证据充分的小论文，不是每个新模块都做一遍；CCF C录用不能由这份计划保证。

confirmation20继续封存，不按失败分析需求临时访问。最终协议需要明确：在development84上如何从头训练最终method/control、哪些seed、final-only/BNCal、是否保存预测、总forward预算，以及一次性比较哪些冻结模型。只写“one-shot confirmation”而不规定最终训练合同是不完整的。

不根据dev或confirmation选择最好seed/checkpoint；不默认ensemble。多个预先固定seed可以在一次冻结确认实验中全报告，但不得看确认结果再保留最好者。确认失败如实冻结；不换结构、threshold或后处理后再次用同一确认集。SkullBreak official test标明历史暴露；SkullFix若另做跨数据集评估，必须先固定子集或完整官方协议、是否微调及source重合审计。

## 🔐 9. 执行、预算、产物与授权接口

### 9.1 阶段预算与里程碑

| 阶段 | 新训练 | 正式模型forward | 停点 |
|---|---:|---:|---|
| R0+R1-A | 0 | 0 | 证据/触发ledger冻结后，由用户决定是否继续 |
| R1-B | 0 | 630 | 两折各315；完成后不自动R2 |
| R2 | 至多4 | BNCal160+eval420 | 每run分阶段冻结；完整矩阵后单独分析 |
| L0分支 | 2或4 | 每新增run BNCal40+eval105 | 是否复用R2-LS决定预算 |
| 新Query分支 | 未批准 | 未批准 | 单候选/对照/seed矩阵另立协议 |
| Mamba首轮 | 通常6，G0不可复用则8 | 每新增run BNCal40+eval105 | GM/GT/GP×C/D×一seed；仍需后续稳定性 |
| 外部基线/16384/确认 | 未批准 | 未批准 | 先可行性/公平性/数据来源，后单独预算 |

表中Mamba只是远期量级说明，不是立即排期；若为满足同一新合同需要重新训练G0，要如实计入。两seed完整Mamba矩阵也不在本首轮预算内。人工contract tests/preflight forward及warmup另行冻结次数，不能用“约630”掩盖额外真实数据模型调用。

建议近期以三项产物而非日期作里程碑：M1证据与风险触发ledger；M2有必要时冻结单一干预结果；M3有必要时完成平衡seed1诊断并选择唯一主分支。优先完成M1，允许在此停止。文献/基线文本审计可作为独立不占GPU的任务提前安排，但不能自动安装依赖。

### 9.2 分阶段执行链

每阶段遵循：只读readiness→待确认子协议→implementation-only（如需）及人工CPUtests/P3→单独zero-update preflight→版本化execution request保持`AWAITING_EXPLICIT_USER_AUTHORIZATION`→用户授权完整SHA256→材料化→唯一一次tmux执行→单独post-execution freeze audit→单独分析/下一阶段。

已满足的检查只按identity audit复用，不为仪式重复运行；需hotfix则新实现/P3和新request。成功preflight不授权训练，训练成功不授权BNCal，BNCal成功不授权evaluation，evaluation成功不授权统计，统计成功不授权gate或后续run。

request冻结全部输入与实现SHA256、bytes、hostname/GPUUUID、环境、runID、session、日志/PID/退出码、输出路径、允许payload类别/数量、forward/step上限和禁止项。授权request的完整SHA256后，按单向顺序：授权回执→计算回执SHA256→runtime单向绑定回执→launcher；回执不反向绑定runtime hash，避免循环。

launcher先创建并验证日志父目录，再重定向；runtime父目录先创建验证再上传；YAML校验使用独立工具或heredoc，不依赖多层内联python引号；PowerShell显式`exit $LASTEXITCODE`。WebShell返回0不是成功证据，必须检查实际进程、退出码、精确计数与产物清单。单次launcher有一次性执行标记；失败/已尝试request不得重用。

### 9.3 文件系统、备份和恢复

服务器代码/运行范围为 `/home/jovyan/adapointr_work/PoinTr` 及明确授权的数据/结果目录。Windows项目根为 `E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution`，长期备份根为 `E:/ResearchBackups/AdaPoinTr`；两者与服务器不是同一文件系统，不自动同步。服务器命令不得引用E路径，不猜测Linux映射。

重连先查身份、进程、原日志/exit与结果，不能因tmux消失自动重启。容器/资源漂移只创建经授权rebind回执和新request，不偷偷改旧文件。Git commit/tag/push仍以本机规范仓库为准，未授权不执行；不初始化服务器Git，不升级依赖/代理/SSH。

最终结果归档应另授权，包含tar.gz、SHA256、bytes、内容清单及恢复验证；只有用户明确确认四个归档文件已下载并本机hash核验，才可另讨论删除服务器归档。本计划/报告不是完整checkpoint备份，不可因此清理服务器产物。

### 9.4 每阶段最小产物

子协议、父绑定、implementation/P3、preflight、execution request/授权回执、runtime/launcher、allowlist、初始化/参数成员hash、数值前后快照、日志/PID/exit、各类实际计数、checkpoint及BNCal清单（适用时）、case/source指标、连续差值与风险transition、探索性标签、中文报告、files.sha256及freeze receipt。各阶段分别写新不可覆盖目录，失败产物也保留。

R0/R1-A的只读报告不得冒称 GPU-execution receipt。正式结果与分析结果分目录，后续文字修订使用新版本，不改原始CSV、checkpoint、授权或阈值。

### 9.5 本计划完成后的建议下一步

本轮已完成建议稿审阅与本机计划修订；下一步不是启动R1-B/R2，而是由用户确认计划。随后可单独授权：

> 仅做R0证据锁定与R1-A已存CSV/flag触发审计；允许读取指定protocol、代码文本、回执和四份LS/LSQ C/D指标文件并在本机写版本化报告；不执行正式gate，不读取NPZ/STL，不加载checkpoint，不使用GPU，不训练、BNCal或推理，不创建runtime/launcher。

上述是一段建议的权限范围，不是用户已经发出的授权，也不是本次生成的execution request。若用户只确认文档而未授权该审计，停在本机文档交付。

## 🔗 10. 来源绑定、文献核验与待确认事项

### 10.1 本机本轮核验的父文件

| 文件 | SHA256 |
|---|---|
| 用户后续建议稿（桌面原件） | `b1f352b072f382006e294ade830ce68dcddc5f46dffcbe739595e6039efc8311` |
| 原v1.2-QA正式计划（桌面副本） | `7c0b5a40c6a263e0b256dbe4fe7d895083c196d7db3482358601c7928054ed0b` |
| 本机阶段报告v1 | `7e606df58d39f161fcd6732e745117ecfe7da41c4993f43be5781a3ef6b346b3` |
| 本机单运行来源快照v1 | `93b18652e2d496275ddf54d14eb207f80c6079e246bb04cc78a3a9178c169e1b` |
| 已确认统计补充协议v1 | `85751899ec1c9d274c6f899049e45823e4acf9c41fe50504efae60561cbf0b8f` |
| 本机安全/历史数值复盘报告v1 | `269926bd16bb42f392fbd99269cdbc9cfe2104cffa0c0ade75c4931eda0ebd68` |
| 远程操作规范 | `9ca5ec6aed3c7aa10b69451091f7541a66821e09b803136f64469dc74396c19d` |
| 本机历史query_conditioning.py | `e631f6649b3a218e63c39f15f6232607469106ae63b0c7cdf578636b110d9057` |

原件：[用户后续建议稿](C:/Users/zhj/Desktop/Cranial_SCQR_v12_QA_后续阶段完整实验计划_2026-10-11.md)；[原正式计划](C:/Users/zhj/Desktop/cranial_scqr_v12_qa_formal_experiment_plan_zh_v1.md)。

内部证据：[阶段报告](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/cranial_scqr_v12_qa_stage_experiment_report_zh_v1.md)；[单运行快照](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/qa1_six_run_summary_source_snapshot_v1.json)；[统计补充协议](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_10/v12_qa1_statistics_supplement_protocol_draft_v1_zh.md)；[风险复盘](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_10/v12_qa1_safety_historical_evidence_review_report_zh_v1.md)；[远程规范](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/references/server_operations/remote_codex_experiment_operations_guide.md)。

统计补充协议文件内部仍含draft/待确认历史字段，但用户已在本对话明确确认其SHA256；本修订不修改该不可变文件。服务器QA-1预注册协议hash `10878972310ced7ddad1188a29b233686c17b5dd5cee72f27593846cef16c8b8`、统计summary hash `660adb3310532d5a4d8f08d9adde61f0a3961ce4676978e9ff9050da22774e89`来自已冻结报告，本轮未重连服务器核验它们。未来request须重新绑定，不能把本机报告hash当服务器实时完整性凭据。

### 10.2 文献核验范围

本次只核验影响设计的原始论文/官方页面，不是完整系统综述，不保证全部近邻已覆盖。各文献性能为作者在其协议下的报告，不等于在本研究协议下复现；不得引入SOTA或临床可靠性外推。代码可用性/许可证/硬件可行性仍需独立审计。

[^1]: PyTorch. “Reproducibility.” 官方开发说明，2026-10-11访问；当前网页为2.14文档，仅引用跨版本/平台重现限制的通用说明，不建议升级本项目环境。https://docs.pytorch.org/docs/2.14/notes/randomness.html

[^2]: Kwarciak K., Wodzinski M. (2026). “MedPCFM: Improving Medical Point Cloud Completion by Integrating Point Transformers and Flow Matching.” arXiv预印本2606.24433v1，2026-06-23提交；方法与baseline部分。https://arxiv.org/html/2606.24433v1

[^3]: Kwarciak K., Wodzinski M. (2026). “MedPCFM-TED: One-Step Point Cloud Flow Matching for Implant Generation via Teacher-Guided Endpoint Distillation.” arXiv预印本2609.16934v1，2026-09-15提交；第3节数据与实验设置。https://arxiv.org/html/2609.16934v1

[^4]: Fu Z. et al. (2025). “CompletionMamba: Taming State Space Model for Point Cloud Completion.” IEEE Transactions on Image Processing 34:5473–5485，DOI10.1109/TIP.2025.3597041；作者所属机构研究成果页面。https://researchportal.murdoch.edu.au/esploro/outputs/journalArticle/CompletionMamba-Taming-State-Space-Model-for/991005810349607891?institution=61MUN_INST

[^5]: Li Y. et al. (2026). “DAPointMamba: Domain Adaptive Point Mamba for Point Cloud Completion.” AAAI40(8):6653–6661，官方出版页。https://ojs.aaai.org/index.php/AAAI/article/view/37596

[^6]: Liu Z., Wang X. (2026). “TriFlow: Triplane Latent Conditional Flow Matching for Efficient 3D Skull Shape Completion.” MICCAI2026官方开放获取页面；本次使用标题/作者/摘要，不以公开review作为模型性能证据。https://papers.miccai.org/miccai-2026/1089-Paper1927.html

[^7]: Yan Y. et al. (2026). “LOT-Bridge: A Latent Optimal Transport Bridge Based on Signed Distance Fields for Automatic Skull Defect Reconstruction.” MICCAI2026官方开放获取页面。https://papers.miccai.org/miccai-2026/0596-Paper1071.html

[^8]: Li L. et al. (2026). “Hyper-PCN: Hypergraph-Based Point Cloud Completion via High-Order Correlation Modeling.” CVPR2026官方开放获取页面。https://openaccess.thecvf.com/content/CVPR2026/html/Li_Hyper-PCN_Hypergraph-Based_Point_Cloud_Completion_via_High-Order_Correlation_Modeling_CVPR_2026_paper.html

### 10.3 待用户确认的研究决定

- [ ] 接受描述性信号、正式gate状态与不晋级决策分开；不覆盖旧分类锁
- [ ] 接受R0/R1-A优先，R1-B/R2条件式进入，新增训练可以为0
- [ ] 若选择R2，默认seed1四运行；不同时追加seed0/seed2，不以新结果替换旧结果
- [ ] 当前LSQ风险不允许由主均值或净disaster总数抵消，confirmation20继续封存
- [ ] Local/SCF、新Query和Mamba均需独立协议，不批量授权；Mamba保留质量/效率两条可证伪路径
- [ ] 近期优先完成有限证据链，不把全部新baseline、16384、symmetry、graph、MAE都列为必做

本轮仅新增本机计划及其独立SHA256侧文件，原建议稿、父计划、报告和代码未改；未连接服务器，未执行正式gate或新bootstrap，未读取真实NPZ/STL、加载checkpoint、使用GPU、训练、BNCal或推理，未创建execution request/runtime/launcher，未安装依赖、删除文件或执行Git操作。文档技能用于组织修订追踪、条件决策图和证据分层；不会替用户确认研究决定。下一版使用v2，不覆盖本v1。
