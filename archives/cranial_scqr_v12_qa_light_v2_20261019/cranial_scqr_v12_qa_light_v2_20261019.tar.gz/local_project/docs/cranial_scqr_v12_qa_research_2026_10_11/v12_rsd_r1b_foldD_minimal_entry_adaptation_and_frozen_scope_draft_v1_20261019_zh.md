# Cranial-SCQR v1.2-QA：Fold D 最小入口适配与冻结执行范围草案 v1

_2026-10-19｜只起草、待确认；不实施、不部署、不创建 execution request_

---

## 📋 1. 当前状态与决策

| 字段 | 值 |
| --- | --- |
| 文档状态 | DRAFT_AWAITING_USER_CONFIRMATION |
| 当前授权 | 仅起草方案 |
| implementation_authorized | false |
| execution_authorized | false |
| 未来实验范围 | Fold D／seed0／105 病例／315 forwards |
| 正式 gate | NOT_ADJUDICATED_HISTORICAL_NUMERICAL_EVIDENCE_GAP |
| 正式 classification | null |

目标是完成既定 R1-B 的另一折同进程配对诊断，不新增科学问题或通用框架。Fold C 已冻结且已解读；历史 Fold D 的风险病例只解释继续诊断的理由，不用于筛选本次病例、改变阈值或预测结果。

采用方案：从成功的 Fold C v3 入口建立 **Fold D 专用三文件**，只适配折别身份、路径／哈希及相应人工合同；保留原 Fold C 文件与证据原字节不变。不采用全局 C→D 文本替换，也不把入口扩展为任意 fold／任意模型的通用运行器。

依据：[Fold C 科研解读报告](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_foldC_scientific_interpretation_report_zh_v1_20261019.md)、[正式冻结审计](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_same_process_foldC_formal_post_intervention_freeze_audit_v1_20261019.json)、[已确认的同进程配对补充协议](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_historical_replay_and_same_process_paired_diagnostic_supplement_draft_v1_20261019_zh.md)。

本草案不是 execution request，不包含已授权 scope、runtime 或可执行 launcher。确认草案本身不等于部署或真实数据执行授权。

## 🔍 2. 已查明的最小入口阻断

本次只读检查本机已有源码及历史 request 文本，未连接服务器。

| 位置 | 当前约束 | Fold D 最小适配 |
| --- | --- | --- |
| contract：validate_request | fold 必须 C | 新入口只接受 D |
| contract：read_native_csv | 历史 CSV 行必须 C | 新入口只接受 D、seed0 |
| contract：输出命名空间 | paired_diagnostic_foldC_seed0_ | 改为独立 Fold D 前缀 |
| contract：prior_exposure | 固定 1／3／315／318 的 C 账本 | 分离既有 C 暴露与新 D 预算 |
| contract：ENTRY_NAMES／P3 | Fold C v3 三文件 | 绑定新 D 三文件最终哈希 |
| runner：import／launcher | v3 contract／entry 固定名称 | 精确引用 D 专用版本 |
| tests：fixture／AST 断言 | C 及 v3 名称 | D 正向、C／错配负向 |
| request 的模型与历史参考 | LS／LSQ Fold C | 两个 Fold D 冻结父产物 |

涉及的原文件：

- [contract v3](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/r1b_foldC_same_process_paired_v3_20261019/tools/cranial_scqr_v12_rsd_r1b_contract_v3.py)，SHA256 `43f5dbf00de8caa0f1fe7735f11666d41d91bd7ac02feb7ee5a382ad3197cf05`。
- [runner v3](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/r1b_foldC_same_process_paired_v3_20261019/tools/run_cranial_scqr_v12_rsd_r1b_v3.py)，SHA256 `737360c47273af44f59123a05acc43e26fb5ff38860274f5788f1e4b9ed323d0`。
- [tests v3](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/r1b_foldC_same_process_paired_v3_20261019/tools/test_cranial_scqr_v12_rsd_r1b_entry_v3.py)，SHA256 `0ab5943dc7d4f2637e7efe346d0c817e1078aacc7695d6534ba2a5dc0ad7a689`。

底层 checkpoint／reference 哈希表和 allowlist 映射已经有 D 条目，不新增依赖解析或重新发现算子。历史 CSV 行身份检查必须仍阻断错折、错病例、错 seed、重复、缺失与顺序不符，不能直接删除折别断言。

## 🔧 3. 后续 implementation-only 候选范围

若另行授权实施，生产候选仅新增下列三文件，位于本机新 overlay：

`E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/r1b_foldD_same_process_paired_v1_20261019/tools/`

| 文件 | 允许变化 |
| --- | --- |
| cranial_scqr_v12_rsd_r1b_contract_foldD_v1.py | D 身份、父证据／暴露账本、路径／P3 绑定 |
| run_cranial_scqr_v12_rsd_r1b_foldD_v1.py | 精确 import、entry 路径及身份接线 |
| test_cranial_scqr_v12_rsd_r1b_entry_foldD_v1.py | 人工 D fixture 与限定回归 |

拟安装映射为服务器项目根下同名 `tools/` 文件，必须不覆盖；当前不生成运输包或实施安装。

保留 schema 的既有同进程配对语义，以“D 专用入口名称＋严格 D 约束＋最终哈希”区分，不做无必要的协议格式重构。P3 仍精确绑定三文件，不泛化为任意文件数／宽松测试状态。

允许新增相应的本机验证日志、静态复核与 P3 证据文档，但不得借此增加生产 driver、守护进程或库存工具。若实际需要第四个生产文件、修改共享科研模块或改变下述科学／预算合同，停止并一次性列明缺口，不滚动补丁试跑。

保持不变：AdaPoinTr、query_conditioning、rsd_query_bypass、metric、Local／SCF、采样、后处理、PointNet2 provider／wheel、Chamfer、PyTorch／CUDA、旧 v1.1／QA-1 evaluator、所有 Fold C 入口、原 request 和冻结产物。

## 🎯 4. 科学合同与数据预算

### 4.1 固定对象及计数

只做 Fold D seed0 held-out development；21 source × 5 defect，各 105 病例，精确沿用 D allowlist 的原顺序。五类为 bilateral、frontoorbital、parietotemporal、random_1、random_2，不追加病例筛选、参数扫描、补跑或额外 warmup。

| 项目 | 成功完成的精确计数 |
| --- | ---: |
| 独特病例 | 105 |
| LS native forward | 105 |
| LSQ native forward | 105 |
| LSQ query-off forward | 105 |
| forward 总计 | 315 |
| NPZ 显式 open | 105 |
| partial／implant／gt 各读取 | 各 105 |
| checkpoint 严格加载 | 2 |
| checkpoint 哈希校验 | 4 |
| optimizer／参数更新／buffer 更新 | 各 0 |
| BNCal／训练 forward | 各 0 |

失败时这些数值为不可超限的上限，不允许为了达到精确计数继续执行。checkpoint 的两次执行前哈希及两次加载前哈希不加入通用额外哈希列表，以免重复读取。

禁止训练用途 payload、另一折 C payload、confirmation20、official test、old monitor、MUG、SkullFix；服务器路径不得引用 Windows E:。数据根固定为 `/home/jovyan/datasets/SkullBreakPC_out8192`。数据集记录中的 `official_split=train` 是原始数据来源标签，不是训练用途授权。

### 4.2 条件、输入与 RNG

每病例依次 LS_native → LSQ_native → LSQ_query_off。后两者共享同一 LSQ 实例、权重、BN buffers、partial 和原归一化；off 仅旁路 residual 加法，仍计算原 conditioner 和潜在残差。不调整 alpha、warmup、epoch、proxy 或 attention。

每病例只开一个 NPZ handle，先只读 partial；三个 forward 成功且输出有限后，才从同一 handle 各读一次 implant／gt 用于指标。不得把 GT、病例风险标签或历史指标输入模型，也不得全折缓存或新增 DataLoader worker。

沿用 `candidate-isolated-native-progression-v1`：LSQ native/off 从相同 pre-RNG 状态开始，其 post-RNG 必须相等，仅 native 的推进状态进入后续病例；记录 Python／NumPy／torch CPU／CUDA 指纹。不通过逐病例 reseed、额外 forward 或重置参数来掩盖漂移。

配对上游 coarse 精确相等，off applied residual RMS 精确为 0，potential residual 有限，Query 出口调用次数和参数／buffers 不变合同保留。任何违例停止，不重新加载恢复再继续。

### 4.3 数值、指标与历史比较

沿用 batch1、FP32、eval/no_grad、epoch=None、严格 deterministic／warn_only=false、cuDNN deterministic=true／benchmark=false、matmul与cuDNN TF32=false、matmul precision=highest、CUBLAS_WORKSPACE_CONFIG=:4096:8、OMP／MKL／torch／interop 线程数 1；不使用 AMP、compile、量化或 fallback。保持执行中的实际值断言。

保留原世界坐标 mm、FP64 指标路径、14 个连续指标、接触两方向诊断、rim 点数、zero-contact 和 disaster 定义。原 contact HD95 严格 >50 mm 的事件规则不变，不追加“恢复／有效／等效／主导”的阈值。空接触或必需几何／数值异常按原合同停止并保留 flags，不补零。

效应始终为 **当前同次 LSQ off − 当前同次 LSQ native**。LS 是不同训练产物参考，不是 off。历史 CSV 用于全部 210 个 native 行的独立比较，不作为配对 baseline，不对历史差异设置新 epsilon、筛病例或自动停止；但身份、文件哈希、参考完整性与有效性仍须阻断错误。旧零容差失败不得改写为成功。

只生成既定的病例、source 等权及五缺损描述和原事件转换，不做 bootstrap、CI、p 值、正式 gate 或新增分类。

## 🔗 5. Fold D 父产物与绑定边界

以下来自已冻结本机历史文本，不表示本次核验了服务器字节。当前容器及文件是否仍一致，须在后续单独授权的有界服务器就绪核对中确认。

D allowlist：

`logs/skullbreak_mamba_v12_development/protocol_v1/foldD_dev_case_ids.txt`；2478 bytes；SHA256 `7afc9edc6654891cc8593ab2ce172657e1227e4583ed3281b159ab3ae2be68ac`。

两个 BNCal checkpoint：

- LS：`experiments/CranialSCQRV12QA1_LS_foldD_seed0/cranial_scqr_v12_qa1_training_authorized_v1/cranial_scqr_v12_qa1_LS_foldD_seed0_v1_20261009T040037Z/ckpt-last-bncal.pth`；382569207 bytes；SHA256 `bdc2bf228e9aa57bcad58f2aecf06481aab367f308a6cae9629ba91462ca9c57`。
- LSQ：`experiments/CranialSCQRV12QA1_LSQ_foldD_seed0/cranial_scqr_v12_qa1_training_authorized_v1/cranial_scqr_v12_qa1_LSQ_foldD_seed0_v1_20261009T114815Z/ckpt-last-bncal.pth`；388541062 bytes；SHA256 `71da7f3b68c3dc5b97aba4530480cc9e7622b75e74b1802f2200dce99bf788ad`。

model 子映射来源均在 `cfgs/SkullBreak_models/cranial_scqr_v12_qa1_training_authorized_v1/`：

| YAML 文件 | bytes | SHA256 |
| --- | ---: | --- |
| CranialSCQRV12QA1_LS_foldD_seed0.yaml | 6598 | `ca7a59f0a1fec774cf06ea6d095a8005601ef7a95a1dceba8586602435e4dc32` |
| CranialSCQRV12QA1_LSQ_foldD_seed0.yaml | 6603 | `7350d709666f7c04f0f85e44c61af7a3780ada398460858730b36f9f04d37c05` |

只取 model，不展开 dataset base，不继承旧执行权限／训练 loader。对应 BNCal receipt 必须为 PASS，绑定其 run_key、checkpoint SHA，参数不变且 development_payload_opened=0；receipt 路径、bytes、SHA 已见[非执行来源索引](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_query_off_protocol_draft_source_index_v1.json)。

历史 CSV 绑定 SHA：

- LS D：`5c0bd80f45047132c813fcf702008c70d91036963f7553953e9d52902d3fc34a`。
- LSQ D：`04423809048e28700d7458407f38bb75e982b40c7c34870cadf835a0cee8482c`。

最终 request 创建前，必须从已有原始 evaluation／冻结审计记录解析两 CSV 的精确路径、bytes 并完成授权范围内核对，不猜测目录、不只靠文件名相似性。训练／BNCal receipt 和 YAML 也须完成完整精确绑定；缺项时不创建可执行 request。

上述两份历史 development request 的本机 SHA 已在本次核验：
LS D `5cffbf081176c7de636e09bf9fef2c76c8db8b00b6e26f9c827d00cb9e979616`；
LSQ D `aa4ae236b833f586cb256f039722b7914a545cdfe428197161dbad58290ca8fd`。这只认证文本来源，不承接其执行授权。

## ⚙️ 6. 资源、命名空间与单次启动合同

以成功 C 运行的相同资源／环境为候选继承值：

- hostname：`shu-common-25721452-notebook-hwq6lx-0`；GPU UUID：`GPU-34a1b996-2bd7-88e6-9dca-164b718caea6`。
- Python 3.10.20，torch 2.4.1+cu118，CUDA 11.8，cuDNN 90100；其余实际相关源码／二进制／provider 绑定沿用原精确清单。
- 启动前 GPU free≥22000 MiB、utilization=0、无其他 compute PID、磁盘 free≥2 GiB。
- 运行上限 7200 秒、timeout kill grace 5 秒；allocated／reserved 各≤20000 MiB；scalar output≤16 MiB、日志／单文件写入限制沿用 32 MiB。
- 保留资源监测与超限停止，明确没有专属 cgroup 硬隔离；不因无法硬隔离开发新框架。

未在本次重新认证当前服务器身份。若后续发现身份／数值依赖漂移，应停止原定启动并披露，不静默改绑，也不自动重复 preflight。

未来 runroot 候选固定为：

`logs/cranial_scqr_v12_rsd_r1b/paired_diagnostic_foldD_seed0_v1_20261019/`

其中 `result/` 保存结果；`control/` 下候选为 `authorization_receipt.json`、`runtime.json`、`launcher_once.sh`、`master.log`、`pid.txt`、`exit_code.txt`。tmux 候选为 `r1b-paired-foldD-seed0-v1-20261019`，run ID 为 `r1b_paired_foldD_seed0_v1_20261019`。当前不创建这些目录／文件／会话；最终 request 须冻结精确路径并在启动前确认全新、不存在、安全父目录。若已存在或发生碰撞则停止，不自行改名启动。

只有将来对完整 request SHA256 获得单独执行授权，才能按顺序材料化授权回执 → 哈希 → runtime（单向绑定回执）→ 单次 launcher。不得加入反向哈希循环。

延续已验证的 Windows 原始字节捕获、WSL --exec／hpc5000 exec -- 参数合同，PowerShell 显式 `exit $LASTEXITCODE`；先创建并验证控制／日志父目录再重定向，PID／exit 独立落盘。网络超时、返回 0、会话消失均不自动允许重启。

真实干预仅允许一次启动；失败即停，不修复重跑、不 resume、不回滚清理或补足次数。已消耗的 C request 不复用。

## ✅ 7. 有限人工验证、P3 与完成标准

以下为未来 implementation-only 的建议验收范围，**不是当前测试授权**。

沿用原 N01–N24 的 24 个测试方法，一次完成 D fixture／路径接线及新增的对应子断言，不另建通用测试链。只允许 Python 标准库、内存人工数据、fake torch／AST／mock I/O；不调用 WSL、不导入真实 torch／CUDA、不读取真实 NPZ／checkpoint、不启动实际 launcher。

集中覆盖：

1. D／seed0／三条件正向；C、其他 fold、错 seed、错 run_key／checkpoint／allowlist／历史 CSV 负向。
2. 精确 105 病例／315 forward／两加载／四哈希及 GT 后置；重复、缺失、错序、另一折访问和失败锁存拒绝。
3. 当前配对与历史比较独立；无 epsilon／选择过滤；native/off RNG、出口、参数／buffer 守卫保持。
4. request／authorization／runtime 原始路径软链接、越界、空授权及未授权无 I/O；单向绑定保持。
5. D 专用三文件与 launcher 路径、P3 最终哈希／24 项真实通过计数；旧 C P3 或绑定不得接受。
6. 旧三个源码原字节 SHA 不变；科学数据流、指标、状态／RNG、provider、预算主体只允许明确列出的折别身份差异。
7. 既有 C 成功 315 次和失败 3 次作为已发生历史；本次 D 新 315 次独立计账，不把既往 C 105 病例当作 D 既往访问。

实施前先完成一次 UTF-8 静态／AST 审查；通过后，执行唯一一次新版 24 项人工 CPU 合同测试，总 wall 预算≤120秒。失败或超时即停止，保留日志；不得自动修复后再次运行。若本机运行环境不能满足既有纯 CPU 测试合同，列明原因，不另开环境建设路线。

通过后完成正式只读 post-test freeze audit＋P3 汇总（须处于对应授权范围），记录三文件 bytes／SHA、24/24、零 GPU／真实数据访问、旧入口不变及全部剩余缺口。测试通过不代表 CUDA 或 Fold D 科研结果通过。

准备工作完成标准是：三文件适配收敛、限定验证与冻结证据完整、D 父产物精确来源明确。不得增加无关库存、传输、依赖或硬隔离功能作为新完成条件。预算用尽或出现范围外缺口时一次性报告并停止。

## 📦 8. 后续分阶段边界与冻结产物

本草案确认后，建议下一授权只覆盖第 3／7 节的 implementation-only。通过不自动授权服务器就绪、运输、安装或执行。

```mermaid
flowchart TB
    accTitle: Fold D Minimal Authorization Boundaries
    accDescr: 本次仅起草方案，未来实现、部署核验及正式执行分别需要授权；任何失败均停止，不自动重试。
    draft_scope["仅起草 D 最小范围"] --> approve_impl["单独授权本机适配"]
    approve_impl --> local_contract["静态审查与一次 CPU 合同"]
    local_contract --> review_result{"限定验证通过"}
    review_result -->|否| preserve_failure(["保留失败并停止"])
    review_result -->|是| evidence_ready["只读冻结审计与 P3"]
    evidence_ready --> server_scope["另行授权就绪与部署"]
    server_scope --> pending_request["创建待授权 D request"]
    pending_request --> approve_execute["完整 SHA 单独执行授权"]
```

在分别获授权的情况下，后续有界就绪核对只验证与 D 启动相关的身份、既有精确绑定、父产物文本／stat 和候选路径；不读 payload、不加载 checkpoint、不额外做 checkpoint 字节 hash，不重复 GPU preflight。真实执行时再完成上述冻结四次 checkpoint hash 和两次 load。

部署只运输新增 D 三工具及必要的精确协议／P3 证据，不重发／重装已验证 provider 或通用框架。全部目标不存在、不覆盖安装并核对哈希；独立 post-installation freeze audit 后才能据最终实现及就绪证据创建 request。request 必须保持 `AWAITING_EXPLICIT_USER_AUTHORIZATION`，无 runtime、launcher 或 tmux。

未来成功运行必须生成原结果集合：

- 315 行 per_condition_case_metrics.csv
- 105 行 paired_intervention_case_deltas.csv
- 210 行 historical_native_comparison.csv
- historical_consistency_audit.json、paired_rng_evidence.json
- execution_receipt.json、invocation.json、fold_descriptive_summary.json、files.sha256
- 独立控制日志／PID／exit 与授权链；失败时保留可观测的 failure receipt／部分结果

结果必须经单独授权的正式只读 freeze audit，核验哈希、完整集合、精确计数、状态、RNG、显存及边界后才能解读。不能只凭 exit0 宣布科研成功。

不自动 pooled 分析、bootstrap、正式 gate、训练、BNCal、QA-2 或下一方法设计。C 与 D 均保留，无论正负；若两次成功各 315，完整成功样本为 210 病例／630 forwards，而连同旧 C 失败的 3 次，该真实干预阶段累计实际为 633 forwards，人工 GPU preflight 另计。

## 🔗 9. 来源、未完成事项与本次实际动作

核心父 request：[Fold C 同进程 request](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_same_process_foldC_seed0_execution_request_v1_20261019.json)，SHA256 `4e36c6bfaecce3c9ae15c412f6079d8e9d9f0635f1de8df8c13c2493e121b0ca`。

科学协议：[R1-B 原协议](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_query_off_protocol_draft_v1_zh.md)，SHA256 `30eeb37fcc6e0172849c5dd4a5a457180d59b9cc0e521a9234b81158bc88b035`；配对补充协议 SHA256 `2740564568231035e37e561f28ce88c3eae729d90c8bbdf5c5b1df6e87a1143c`。已通过 preflight 的精确父链沿用，不把其人工结果声称为 D 科研结果。

当前尚未完成：D 专用三文件实现／人工验证／P3、D 历史 CSV 精确路径与 bytes 的最终绑定、当前服务器 D 就绪核对、运输安装及其审计、D execution request、单独执行授权。

本次实际仅只读本机文档／源码、核验三父文件及两历史 request 的哈希，并新增本草案及哈希旁文件。未修改任何代码，未运行测试／模型／WSL／客户端，未连接服务器，未读取真实 payload／checkpoint，未创建执行内容。长期备份与服务器删除权限不变。

