# R1-B v5 本机 WSL 原生 ext4 测试隔离方案（草案 v1）

_Cranial-SCQR v1.2-QA 后续 R1-B｜2026-10-12｜仅起草，待确认；未迁移、未清理、未运行_

---

## 📋 当前状态与授权边界

| 项目 | 状态 |
| --- | --- |
| 方案状态 | `DRAFT_AWAITING_USER_CONFIRMATION` |
| 本轮允许 | 阅读本机证据、起草本方案 |
| 生产代码修改 | 禁止 |
| 创建隔离环境／复制／移动 | 本轮禁止 |
| 清理残留／删除文件 | 本轮禁止 |
| 测试或写探针 | 本轮禁止 |
| 服务器、GPU、库存审计 | 禁止 |

本方案不是 execution request，也不授予测试或迁移权限。确认方案后，仍须分别明确授权准备、只读核验、单次测试和结果回收。没有新授权不得启动先前 driver v1/v2，不得覆盖旧日志、回执或 P3。

本机规范目录为 `E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution`。拟隔离目录位于本机 WSL Ubuntu-20.04，不属于自强5000容器；服务器 `/home/jovyan/adapointr_work/PoinTr` 不在本方案操作范围。E:、本机 WSL ext4、服务器三者均不得假定自动同步。

## 🔍 依据与目标

### 可核验的父证据

[WSL EIO 只读诊断](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_v5_local_wsl_drvfs_eio_readonly_diagnosis_v1_20261012.json) SHA256：

`7306e2e837292f3413338121871415792429c89fe5bc86b34a095556b78c0d6a`

该诊断观测 `/mnt/e` 为9p/DrvFS，WSL kernel为 `5.15.167.4-microsoft-standard-WSL2`；EIO附近内核日志出现9p元数据调用栈、引用计数异常和 `use-after-free`。并发扫描与临时目录删除可能触发该异常，但精确因果未复现。`/home/zhj` 所在挂载此前观测为 `/dev/sdc` 上的ext4；使用前须重验，不能将历史挂载信息视为永久事实。

两次历史失败各自保留：v1为继承发布fixture缺少独立绑定上下文；v2为driver扫描临时fixture收到EIO，终止runner。v2未运行到继承原生发布场景，因此fixture修复尚未完成85项验收。

[v1失败态 P3](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_v5_local_post_implementation_p3_v1_20261012.json) SHA256：`b19083c0152e23393ec6d8b768480b743731178f23f1c699783131da0a80f509`。

[v2失败态 P3](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_v5_local_post_fixture_hotfix_p3_v2_20261012.json) SHA256：`203aacc49f159e1862a575c0aa5374287c497c7810d507c47d495f52faea3ca1`。

### 隔离目的与限度

将一次测试的源码副本、fixture、driver工作日志和回执全部放在已核验的原生ext4，使测试活动不再通过 `/mnt/e` 进行并发文件创建、删除和扫描。E:继续作为规范源码与最终文档位置，不迁移整个项目或历史资料。

这是环境隔离与风险规避方案，不是“已经修复WSL内核”的结论。即使ext4测试成功，也只形成该环境的本机契约证据，不证明服务器900/1300秒库存流程、hardlink耐久性、GPU等价性或真实R1-B诊断就绪。

## 🎯 方案选择与路径设计

### 选项比较

| 方案 | 优点 | 限制 | 本次选择 |
| --- | --- | --- | --- |
| 忽略EIO继续 `/mnt/e` | 少迁移步骤 | 会掩盖非ENOENT错误 | 不采用 |
| 原生ext4独立副本 | 保留守卫，避开活动DrvFS路径 | 需副本／证据回收核验 | 采用 |
| 重启或升级WSL | 可能改变环境状态 | 未证明修复且可能中断其他任务 | 不纳入 |

### 拟定目录

拟单次隔离根：`/home/zhj/r1b-local-contract-isolation/v5-ext4-once-v1-20261012`。该路径是新提出的明确授权候选，不是猜测出的Windows映射，本轮不创建或核验其不存在。

| 拟路径（相对隔离根） | 用途 |
| --- | --- |
| `project/server_overlays/r1b_synthetic_pf_impl_v5_20261012` | 四文件独立字节副本与测试fixture |
| `project/local_test_drivers` | 本机driver v3副本 |
| `project/docs/cranial_scqr_v12_qa_research_2026_10_11` | 历史只读输入副本、新日志／回执 |
| `control` | 准备回执、单次标记、外层退出凭据 |
| `tmp` | 显式TMPDIR，仅限本次临时用途 |

新的 driver 规范源码拟为 `E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution\local_test_drivers\r1b_synthetic_pf_v5_cpu_once_driver_v3_ext4_20261012.py`。它必须经后续implementation-only授权才可新增，旧driver不改。

复制到ext4的生产三文件和测试文件保持以下当前字节绑定，不替换常量、import、fixture或测试语义：

| 文件 | bytes | SHA256 |
| --- | ---: | --- |
| `audit_synthetic_pf_dependencies_v5.py` | 29962 | `cb3b99547b1d630896bfb108c73d982fd798c7ae0dd269d51e35f6e819534c5d` |
| `install_synthetic_pf_implementation_v5.py` | 15937 | `2aa90eba43e69203d48686b50333db80b252cb69623833472c746bf402447b4e` |
| `supervise_synthetic_pf_implementation_v5.py` | 24857 | `002069eff1be30bd542be48157a9487482488a58475d7aa342e2883ab48df949` |
| `test_synthetic_pf_dependency_audit_v5.py` | 43683 | `50e70c1ede0aaef73b16aa049955125845343fc2fadc8f609c683111afff65ac` |

不复制模型、真实依赖目录、服务器结果、NPZ、checkpoint、Git仓库、个人凭据或整个overlay目录。特别禁止把现有 `cpu_contract_fixture_7aeu6k8_` 一并复制。

## 🔐 准备与只读核验契约

### 准备阶段（未来需授权）

1. 核验Ubuntu-20.04、用户、Python3.10解释器实际路径／版本／二进制SHA与原生文件系统。固定Python仍为已有 `/home/zhj/.local/opt/r1b-cpu-contract-python310-20261012/venv/bin/python`，不安装、升级或改动该环境；若其实际文件位于DrvFS或身份漂移则停止。
2. 对隔离根及全部父路径核验canonical、非链接、非bind指向DrvFS、目标不存在、挂载为ext4且可写；不能只凭路径前缀 `/home` 判定。记录设备号与挂载参数，源码、tmp和输出目录均重验。
3. 新建独占目录，逐文件从明确白名单复制；禁止软链接、硬链接、junction、整个目录递归搬运、同步删除或覆盖。E:和ext4间仅准备时读取已确认的本机映射；该映射不得用于服务器命令。
4. 对每个来源与目标重新计算SHA256、bytes，比较上表和冻结manifest；确认副本普通非链接文件、目标路径位于本次根。任何EIO、权限错误、哈希变化、目标已有内容都失败停止，不自动重复复制。
5. 新增本机driver v3，只调整本机路径、版本化输出、ext4身份守卫和输入绑定；保留原driver的身份核验、subreaper、总期限、资源上限和失败策略，不忽略EIO、不增加85以外的场景。
6. 准备完成只生成 `PREPARED_NOT_EXECUTED` 回执。此时不得运行suite、任何contract method或生产工具；AST解析与静态计数可在该准备授权中明示允许，但不import测试模块、不触发unittest。

原测试在 `HERE` 内创建临时fixture，并从同目录读取三生产工具，因此只复制四文件即可转移fixture活动位置，不需改测试文件。新driver的ROOT/OVER/DOCS指向本次 `project`，cwd也为本次project；不通过注入 `/mnt/e` PYTHONPATH 引入原仓库。

### 历史输入与哈希链

driver v3不能在运行期间读取E:历史证据。准备阶段将所需历史文件精确复制到ext4，并冻结输入manifest；新driver以该manifest中相对路径核验副本，同时独立绑定manifest SHA。输入manifest不包含自身SHA；测试scope绑定输入manifest与driver SHA，driver不反向硬编码该scope自身SHA，避免循环依赖。

历史输入允许集合：旧v4 driver失败JSON；v5 v1/v2测试scope、日志、回执；v5 v1/v2失败P3；本次EIO诊断JSON；v5 driver v1/v2的源码（只作历史证据，不执行）。共12文件，不自动扩展集合。其准确文件名、bytes、SHA须由后续准备清单逐个冻结；当前草案不是已生成manifest。历史文件即使复制到ext4，也不更改其中记录的旧 `/mnt/e` 路径或状态。

允许最多12份历史文件、总量16 MiB；四源码副本总量不超过8 MiB；准备的独立driver/manifest/scope/回执合计不超过1 MiB。超限或发现需要额外输入则报告，不自动读取其他目录。复制失败可保留本次partial准备目录和失败回执，但不得自动删掉重建。

### 只读就绪核验（未来需授权）

准备后单独核验原生mount、路径、四文件／driver／manifest哈希、历史输入一致性、85方法AST计数、目标日志／回执／once marker不存在，以及无预存fixture。核验不运行测试或hardlink写探针，不把准备成功当成执行授权。

就绪核验同时冻结完整单次本机测试scope与拟定启动命令、退出码传播、外层日志/PID记录、明确无 `/mnt/e` 活动I/O的规则。若创建execution request，须在用户明确授权其创建范围后进行，状态为 `AWAITING_EXPLICIT_USER_AUTHORIZATION`；其完整SHA另行执行授权。

## ⚙️ 单次测试的未来执行规则

下图每个执行节点均须对应后续授权，本轮仅定义流程。

```mermaid
flowchart TB
    accTitle: Local Ext4 Isolation Authorization Flow
    accDescr: Prepare verified independent copies, authorize one ext4 test, then freeze and recover evidence without changing production sources.
    review_plan["确认隔离草案"] --> prepare_copy["另行授权准备副本"]
    prepare_copy --> readonly_gate["单独只读核验就绪"]
    readonly_gate --> authorize_test["冻结范围并授权单次测试"]
    authorize_test --> run_once["ext4内执行85项一次"]
    run_once --> freeze_result["冻结成功或失败证据"]
    freeze_result --> recover_result["另行授权回收与核验"]
    recover_result --> preserve_copy["保留副本与历史残留"]
```

拟新run ID：`r1b_v5_local_ext4_contract_once_v1_20261012`。新日志与回执basename分别拟为 `v12_rsd_r1b_synthetic_preflight_v5_cpu_contract_ext4_once_v1_20261012.log`、`v12_rsd_r1b_synthetic_preflight_v5_local_driver_v3_ext4_cpu_test_receipt_v1_20261012.json`；必须区别于既有v1/v2，不覆写。once marker拟为隔离根 `control/test_started_v1.json`，独占创建在suite启动前，任何已有marker即拒绝运行。

运行期间：

- 只运行一次既有85方法suite（67人工＋18继承本机Linux场景），failfast；不拆分先跑67再跑85，不复用旧部分结果。
- 三生产工具与测试副本字节不变；不运行它们的production main、库存worker、canonical27或torch CPU probe。
- 保持120秒总预算，其中112秒工作、8秒清理保留；fixture聚合16 MiB、日志16 MiB、最多20组／120观察helper、每场景继承原1.5秒工作／2秒清理／6 helper上限。
- 环境使用 `-B`、禁止bytecode、`CUDA_VISIBLE_DEVICES=''`、原有OMP/MKL单线程；TMPDIR指向本次ext4 `tmp`，不改变系统默认临时目录。清除可能将import引向DrvFS的外部PYTHONPATH；核验实际导入文件路径。
- 四文件、driver、manifest、scope、历史输入和动态fixture均在ext4；活动日志/receipt也在ext4。不得每10ms跨 `/mnt/e` 扫描、写日志或重新校验E:源码。
- 保留ENOENT仅限自身瞬时fixture的现有规则；EIO、权限错误、身份不确定、log超限或deadline都锁存失败并停止，不自动修复／重跑。
- driver只回收已验证属于本次suite的进程组；不使用全局pkill。受信的测试自身tearDown可清理本次人工fixture；失败时遗留目录原位保留，不递归删除整个隔离根。
- PowerShell最外层显式传播 `$LASTEXITCODE`。外层0、runner0、完整日志85、18场景、无残留和哈希一致缺一不可；启动命令返回0不代替验收。

driver输出成功仍只代表本机suite，不能自动创建运输包、部署CPU request、GPU preflight或正式诊断。此次环境变化也不允许修改研究协议或正式gate。

## 📦 冻结、回收与P3解释

### ext4先冻结

无论成功或失败，停止suite后先在ext4完成限定证据冻结：driver receipt、suite log、一次执行scope/manifest、外层exit记录、残留清单、源码前后SHA与就绪回执。残留仅生成精确清单／统计，不自动删除。缺少退出凭据或未确认回收时不标PASS。

核验四文件和driver SHA未变、测试计数、signal场景实际错误原因、final publication与postcommit uncertainty测试证据。若全部通过，本机P3状态拟为 `PASS_LOCAL_IMPLEMENTATION_AND_ARTIFICIAL_CONTRACTS_ONLY`；否则为独立失败态，保留此次run不可再次执行。

该阶段不在suite仍运行时回收数据到E:。准备时间、单次测试时间和回收时间分别记录；不能把传输时间加入测试结果后假装改变已冻结120秒预算。

### 结果回收需单独授权

拟E:结果目录：`E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution\docs\cranial_scqr_v12_qa_research_2026_10_11\r1b_v5_local_ext4_contract_once_v1_20261012`。

仅复制上述固定证据allowlist，不把动态fixture或整个隔离根回传。每个产物先记录ext4 SHA／bytes，再用独占创建回收到新目录，在Windows端重算；原ext4字节保留，不做跨文件系统move或替换。P3置于该新结果目录，绑定测试源码实际哈希及ext4路径、回收manifest与Windows端核验结果，不能把ext4绝对路径改写成E:后称为同一文件。

回收若再次EIO／哈希不一致，则标记 `RESULT_RECOVERY_FAILED_NATIVE_EVIDENCE_RETAINED`，保留原ext4产物，不重跑suite；传输修复或再次复制须另行授权。ext4成功且未完成回收核验时，不能宣布本机规范P3已交付。

本机driver v3、隔离准备manifest和历史输入副本一律不进服务器四文件运输包。服务器运输仍以E:四文件最终哈希为准；测试后的本机P3必须注明“验证相同字节的ext4副本”，不声称原DrvFS并发路径已通过。

## 💾 历史残留与清理边界

原残留精确目录：`E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution\server_overlays\r1b_synthetic_pf_impl_v5_20261012\cpu_contract_fixture_7aeu6k8_`。

诊断时为6文件、2809 bytes，内含人工授权／progress和四个微型人工源码；不是生产源码或服务器授权。默认原位保留，不移动、不删除、不加入ext4副本。新运行在全新ext4目录检查自己的fixture为空，不需先删除旧E:残留才能运行；后续运输使用明确四文件allowlist，不递归打包overlay。

若用户日后要求清理，先重验该目录的resolved绝对路径、非reparse/link、六文件清单／SHA、无活动进程，再生成精确候选，由用户独立授权。不得删除overlay根、项目根、 `/home/zhj` 或WSL发行版数据，不得假设长期备份目录已完成核验。

新ext4隔离根也默认保留到结果回收与核验之后；清理仍需单独授权。方案中“隔离”意为新副本运行，不含自动移动历史残留或自动销毁环境。

## ✅ 验收与后续最小授权

本方案建议下一步仅授权“implementation-only 本机driver v3与准备清单实现”，不创建ext4目录、不复制、不测试；实现后报告driver哈希和静态审查，之后再单独授权ext4副本准备。准备后只读就绪核验与单次85项执行继续分开。

- [ ] 同意不改三生产源码与当前修复后的测试字节
- [ ] 同意新增本机driver v3，仅适配路径与独立输入/once守卫
- [ ] 同意全新ext4独立副本，不用跨文件系统链接或整仓复制
- [ ] 同意准备／就绪／执行／回收／清理各自独立授权
- [ ] 同意旧E:残留、v1/v2失败材料与新ext4原件默认保留
- [ ] 同意完整85＋双退出0＋无残留＋哈希一致才形成通过态本机P3
- [ ] 同意ext4通过不代表DrvFS已修复、服务器P3或GPU就绪

本轮实际仅新增本草案。没有新增driver、复制文件、创建隔离目录、运行测试、删除残留或更改WSL配置；生产四文件当前SHA保持不变。文档采用Markdown与Mermaid表达阶段授权和证据回收，未进行生产或渲染验证。
