# R1-B PointNet2 后端约束补充草案与 Python 3.10 核验／修复方案 v1

_2026-10-18｜本机方案，待用户确认；无服务器操作、代码实现或环境修复授权_

---

## 📋 1. 决策状态与依据

状态：`DRAFT_AWAITING_USER_CONFIRMATION`。本次只明确推荐的后端合同和后续核验／修复边界，不修改已冻结协议、旧 request、模型、适配器或环境。草案确认不等于实现、导入、安装、编译或 GPU 执行授权。

依据为[后端与算子只读审查](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_preflight_backend_operator_readonly_review_v1_20261018.json)，SHA256：
`1116e79c02ed55253880ba2372c3da97201ea8571898d6e5e7dab924dfb62a1d`。

| 已核实事实 | 影响 |
| --- | --- |
| 完整 forward 经过 PointNet2 适配器 FPS、gather | 后端进入实际计算路径 |
| 当前固定 `attn-graph` 不走可变形注意力分支 | 不为 three_nn／three_interpolate 新增试跑 |
| Chamfer 只导入并构造损失对象，loss_calls=0 | 不捆绑重编 Chamfer |
| 包装器在 ImportError 时选择 toy PyTorch fallback | 不能以成功导入代替后端身份核验 |
| 当前有限查找未确立 Python 3.10 PointNet2 编译提供者 | 未就绪，不等于全服务器不存在 |
| 历史六运行后端身份尚无充分证据 | 新后端不能反向认证历史结果 |

原协议 SHA256 为 `923254dab787341728af9a22031b482f55a45ebd6c2bc62cfcb427511c61456b`。其中 FP32、严格确定性、TF32=false、fallback=false 保持不变；原文未单独点名 PointNet2 精确实现，不能声称本草案只是机械转抄原合同。

## 🔍 2. 选项与推荐

| 选项 | 优点 | 限制 | 本草案建议 |
| --- | --- | --- | --- |
| 固定、核验编译后端 | 提供明确源码与二进制身份 | 可能需要单独修复环境，确定性仍须实际检验 | 正式 preflight 采用 |
| 固定现有纯 PyTorch 适配器分支 | 避免编译，便于人工验证 | 其源码定位为 toy fallback；不能默认数值等价或历史一致 | 不纳入本正式 preflight |
| 自动择优、失败后切换 | 能自动继续 | 后端身份不固定，掩盖失败并改变条件 | 禁止 |

推荐正式人工 GPU preflight 采用经核验的 `pointnet2_ops` 编译后端，使用当前既有 `utils.pointnet2_utils` 适配器，不改采样算法、初始点、tie-breaking、dtype、shape 或调用顺序。

这是研究者待确认的工程后端选择，**不是已安装成功**的陈述，也不证明编译后端在所有输入上更准确、与 fallback 等价或必然满足严格确定性。若研究者希望研究纯 PyTorch 后端，应另立明确命名、单独数值条件的分支，而非冒用此 preflight 的通过结论。

## 🎯 3. 拟冻结的后端合同

### 3.1 身份与函数绑定

后端标识拟定为 `POINTNET2_OPS_COMPILED_FP32_V1`。执行前必须同时满足：

1. 实际提供者是已冻结的 `pointnet2_ops.pointnet2_utils` 及其加载的 native 扩展，不是同名占位包、重新导出的 toy 实现或 JIT 临时产物。
2. `utils.pointnet2_utils.using_fallback()` 严格为 `False`；其当前源码及 hash 仍需被绑定。
3. 适配器的 `furthest_point_sample`、`gather_operation` 与已绑定 official 模块中相应对象具有身份一致性，不通过 monkey-patch 替换。
4. 包装器、Python 模块、native 二进制的实际规范路径、字节数、SHA256、来源版本或 commit、构建记录及加载器依赖均冻结；不能只看包名、版本号或文件名。
5. 对当前 Python 3.10 环境提供可核验的兼容性证据；`cpython-39` 文件不能充当该证据，不能靠改名或复制冒充。其他 ABI 形式若被提出，也必须有独立来源与兼容性证据。
6. 运行环境不自动下载、JIT 编译、安装、切换 provider 或跨未知路径寻找“可用替代”。

第 2～3 项是待授权实现的启动守卫要求；当前 preflight 没有完成这一显式后端守卫，不能把本草案作为已完成实现／P3 的证明。

### 3.2 实际算子与不可删改路径

图编码器的两级 `fps_downsample` 都调用 FPS＋gather；`PCTransformer.forward` 在 query_selection 分支之前还调用一次 `misc.fps(xyz,128)`。即使 learned_only 最终不用其坐标，也不删除该调用来规避依赖或耗时。

在完整 forward 成功走完的静态路径上，每次预计有三组 FPS＋gather；这不是本次的实测调用计数，不据此伪填执行日志。

其他计算保持现有 torch 路径：矩阵乘／topk 图邻域、attention、局部几何 cdist＋stable argsort、MLP／归一化、LSQ query residual 与出口旁路。没有要求把这些正常 torch 算子改成额外 native 扩展。

### 3.3 数值、计数与失败处理

FP32、严格确定性、warn_only=false、TF32=false、固定人工输入和两模型初始化保持原合同。成功计数仍为两次模型构造、八次独立出口、八次完整 forward；没有额外 GPU smoke forward。

torch 确定性开关本身不能替代对自定义 kernel 的来源与有限重复结果核验；原八次调用的张量／标量／状态一致性合同继续执行，不宣称全输入确定性。

任一提供者／哈希／路径／ABI／函数身份漂移、导入失败、不支持严格确定性、OOM、超时或计数错误：立即失败并保留证据，不自动 fallback、重试、resume、切换后端或降低精度。

Chamfer 距离和损失调用保持零，Mamba adapter 保持关闭；不新增其他扩展的算子试验。

## 🔧 4. Python 3.10 扩展核验／修复方案

以下是阶段方案，不是 execution request。所有阶段都必须另获与实际副作用匹配的授权；未知源码、版本、路径或预算不以占位值拼成可执行 request。

```mermaid
flowchart TB
    accTitle: PointNet Backend Decision Gates
    accDescr: Confirm the compiled backend policy, verify existing providers, and allow a separate repair proposal only when necessary. No GPU execution is implied.
    confirm_policy["确认后端补充协议"] --> inspect_provider["单独授权只读核验"]
    inspect_provider --> provider_ready{"已有兼容提供者？"}
    provider_ready -->|有证据| bind_provider["绑定现有源码与二进制"]
    provider_ready -->|无证据| propose_repair["提交精确修复范围"]
    propose_repair --> approve_repair["单独批准修复与验收"]
    approve_repair --> bind_provider
    bind_provider --> guard_gate["单独实现后端启动守卫"]
    guard_gate --> later_request["继续 CPU 证据与 preflight 授权"]
```

### 4.1 A 阶段：先只读核验，不先安装

目标是在当前明确容器与环境中，判断是否已有可复用的兼容 PointNet2 provider。

- 先核验 hostname、uid、Python 规范路径／版本／二进制 hash；不把旧容器身份视为现容器凭据。
- 仅检查由已观测路径、安装索引、明确提供的源码位置派生的 PointNet2 候选；不递归搜索整个 home、Conda 或系统目录。
- 只读记录来源版本／commit、安装元数据、包装器及二进制身份、编译器／CUDA 工具链元数据和加载器依赖线索；不执行 setup、hook、import、ldd 或 GPU 算子。
- 优先复用已有且可证的兼容提供者。来源不明／路径越界／实际 ABI 未证实则停止；有限查找阴性不能升级为全服务器缺失。
- 拟定预算上限：一次、最多四个只读远程调用、单调用硬超时 15 秒、合计服务器执行硬预算 60 秒；候选目录不超过八个、枚举项总数不超过 4096、文本不超过 16 文件／2 MiB、ELF 元数据最多四候选且每项不超过 256 KiB。Python identity hash 额外限 64 MiB。不全量读取二进制做库存。
- 后续授权范围应冻结实际路径和计量方式；预算不足则停止，不自动追加调用或扩展扫描。

A 阶段只是静态来源／可复用性判断，不能出具“已成功导入／已通过 CUDA”结论。若在其范围内无法补全 loader 关系，保留明确未解项。

### 4.2 B 阶段：必要时仅制定精确修复 request

只有 A 阶段未找到可证明兼容的 provider，才考虑修复。不直接从“site-packages 没有匹配名字”推出安装。

拟修复包仅限 PointNet2 的必要 Python 包装器及 native 扩展。必须先确定：

| 必须冻结的输入 | 当前状态 |
| --- | --- |
| 受信源码位置、精确版本／commit／源码哈希 | 未确定 |
| 与固定 torch／CUDA／Python 组合的构建方法 | 待核验 |
| 编译器、nvcc、CUDA toolkit 与目标 GPU 架构 | 待核验，不从 driver 版本推断 |
| 依赖是否已齐全、能否无下载／无升级构建 | 待核验 |
| 构建、暂存、最终 provider 与回滚保留路径 | 待实际范围冻结 |
| 时间、CPU、内存、磁盘与构建进程上限 | 待来源与构建任务确定 |

优先隔离构建、旁路暂存，不覆盖现有包；若最终需要写 Conda 环境，必须单独明确环境目标路径和现有文件冲突策略。模型源码修改授权不能代替环境安装授权。

禁止捆绑升级／降级 Python、torch、CUDA runtime、驱动、NumPy 等已有核心依赖；禁止重编 Chamfer、Mamba、causal-conv1d；禁止使用无版本包名直接联网安装。预编译 wheel 也须先核验来源及 hash，不能凭命名接受。

若发现必须升级核心栈才能构建，则本方案停止并报告新约束，不能扩大为整套环境重建。无可执行版本／路径／预算前，不生成“待授权即可运行”的安装 request。

### 4.3 C 阶段：将安装、导入与 GPU 计算分开验收

修复若获批准，单次构建／安装失败即停，不自动修补重跑；保留构建日志、退出码、源与产物 hash、实际变更清单。不主动删除旧产物。

安装后先做独立只读冻结审计。动态 CPU 导入核验需要单独授权：屏蔽可见 GPU，只核验官方模块、native 来源和适配器函数绑定，不调用 FPS／gather，不构造模型。导入路径的副作用必须事前审查，不能将环境变量屏蔽误作绝对无副作用保证。

GPU 可执行性只能由后续单独授权的固定人工 preflight 检查，不在本方案内加跑 FPS 小样本、模型 smoke forward 或计时循环。

### 4.4 D 阶段：最小启动守卫，不改模型

后端确认后，仅在 QA/R1-B 专用 preflight 入口／合同层补齐来源、using_fallback、函数绑定和失败即停断言；守卫自身 hash、CPU 人工合同与 P3 需重新冻结并获得独立 implementation-only 授权。不改 v1.1、模型采样路径或既有 fallback 代码。

如果现有入口不能在不增加 GPU 调用的情况下完成这些断言，先报告具体接口缺口，不默认扩展模型或建设新的审计框架。CPU 依赖核验、CPU probe 与 GPU preflight 的授权仍分开，不能由此草案推导出任何执行许可。

## ⚖️ 5. 历史数值与科研解释边界

当前没有足够证据确认历史六运行的 PointNet2 实际后端。选用编译后端后得到的人工 preflight 只证明新冻结条件下的有限工程合同，不能宣称历史训练／BNCal 已获数值认证，也不能据此重算或替换 QA-1 结果。

若后续发现历史用的是纯 torch 后端，而拟诊断用编译后端，应显式报告后端条件差异。是否另立匹配历史后端的诊断协议，由研究者决定；不默默混合两种后端结果，不自动重训或继续正式 gate。

本草案不改变 `NOT_ADJUDICATED_HISTORICAL_NUMERICAL_EVIDENCE_GAP` 或 classification=null。

## 🔗 6. 本次交付与下一步

本次只新增本机方案及机器可读决策摘要。采用决策记录结构和授权流程图区分推荐选择、未解输入与执行阶段；未连接服务器、未导入包、未测试、未编译、未安装、未创建 execution request／授权回执／runtime／launcher，未推送 Git。

推荐下一步：用户先确认本草案的编译后端约束。即使确认，也须单独授权 A 阶段限定只读核验；没有必要先安装或补测。

来源：
- [算子与后端只读分析](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_preflight_backend_operator_readonly_review_v1_20261018.json)
- [PointNet2／Chamfer 有界来源补证](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_pointnet2_chamfer_origin_supplement_observation_v1_20261018.json)，SHA256 `af2b7383edff0eb82b9c77ce56c7fbff6a771905f6a51dfe6a08a6d4ab5fd807`
- [原人工 GPU preflight 协议](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_gpu_zero_update_preflight_protocol_v1_zh.md)

本文不引入外部包版本推荐或未经核验的兼容性结论。Mermaid 为文本说明，未上传外部渲染或声称浏览器预览已通过。

