# R1-B v5 信号 fixture 兼容性修订方案与回归范围（草案 v1）

_Cranial-SCQR v1.2-QA 后续阶段 · 2026-10-12 · 仅供确认，不授权实现或执行_

---

## 📋 状态与授权边界

状态：`DRAFT_AWAITING_USER_CONFIRMATION`。

本次仅新增本机方案文档，读取现有测试与生产信号处理器，并校验本机四文件哈希。没有修改测试、生产守卫、driver、已冻结 request 或 ext4 副本；没有运行测试、导入生产工具、操作服务器或使用 GPU。

已消耗 request 完整 SHA256：

```text
bc75e278ee1a7f421177e7ed43cf5faaf2289a2fb14bb179632dc11688e736ca
```

其唯一调用已经完成，结果为 `FAILED_STOPPED_NO_RETRY`，不得再次执行，不得复用 scope、launcher、run ID、标记或输出路径。历史 request 本体保持原字节；其待授权字段属于创建时状态，不表示仍可再次授权执行。执行回执、单次标记和退出码共同证明该次授权已消耗。

## 🔍 失败事实与解释范围

上一轮真实退出码为 `1`，driver 用时约 `8.359 s`；unittest 报告 `Ran 80 tests in 7.607s`、`FAILED (failures=1)`。67 项人工契约通过，12 项原生进程契约通过，第 13 项原生契约失败，剩余 5 项未执行。

失败项为 `NativeContracts.test_60_supervisor_precommit_TERM`：

```text
实际 reason：SUPERVISOR_SIGNAL 15
期望 reason：SUPERVISOR_SIGNAL Signals.SIGTERM
```

本机测试源码第 777 行使用 `str(signal.SIGTERM)`；第 785 行的 test 61 同样使用 `str(signal.SIGINT)`。生产 supervisor 的 `interrupt(sig, _frame)` 在第 205 行使用回调参数 `sig` 构造数字信号原因。上述运行日志直接证明本次 test 60 的两端表示不同；test 61 存在同类源码风险，但因 failfast 未执行，不能声称它已失败或通过。

本次失败发生在 reason 精确断言：之前的“正式 P3 文件不存在”和 `FAILED_STOPPED_NO_RETRY` 状态断言未报错。仅可解释为已观测场景中的期望表示兼容问题，不是对全部信号、发布或清理路径的证明。

上一轮失败后只读检查：已登记场景组及 runner 组无残留，隔离 overlay 无 fixture。该结论限于当时记录的进程组快照；不宣称系统所有进程均已审计。ext4 本轮日志未显示先前的 EIO 错误，亦不证明 WSL/DrvFS 根因已修复。

证据位置均为本机 WSL，不是自强5000服务器：

```text
/home/zhj/r1b-local-contract-isolation/v5-ext4-once-v1-20261012/control/
/home/zhj/r1b-local-contract-isolation/v5-ext4-once-v1-20261012/project/docs/cranial_scqr_v12_qa_research_2026_10_11/
```

| 证据 | 字节数 | SHA256 |
| --- | ---: | --- |
| 授权 scope | 1780 | `1c5d20cc91a5a2863cc703971275dcbe5b0bc357ba62d313f65b99979a3f6ae5` |
| launcher | 881 | `1a4352c6e16002d5e8134725d83e429daea317b1215b0b3771e662288f2bded0` |
| `launch_cpu_contract_once_v1.exitcode` | 2 | `4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865` |
| `v12_rsd_r1b_synthetic_preflight_v5_cpu_contract_ext4_once_v1_20261012.log` | 18726 | `20f6ad46be0d075ac5cb6ceb04953bdb9bad74e30722d33b52f44d6085adcfd2` |
| `v12_rsd_r1b_synthetic_preflight_v5_local_driver_v3_ext4_cpu_test_receipt_v1_20261012.json` | 1009 | `c4c747ea46610fcc05bcd57ba0fb48e915ff9f351ced53108ab293413500db3f` |

这些为上一轮只读检查记录的哈希；本次没有恢复或复制 WSL 结果，也没有把历史哈希表当作新的正式 freeze audit。

## 🎯 建议的最小修订

建议只修正测试期望的数字表达，不改变生产输出协议。

```python
# 示意差异，尚未应用
# test 60
self.assertEqual(r['reason'], 'SUPERVISOR_SIGNAL '+str(int(signal.SIGTERM)))
# test 61
self.assertEqual(r['reason'], 'SUPERVISOR_SIGNAL '+str(int(signal.SIGINT)))
```

保留 `assertEqual` 的完整字符串精确匹配；不得改成前缀、包含、正则放宽，或同时接受枚举名称与数字值。保留 `formal_p3.json` 不存在、失败状态、真实 before_commit 信号触发、绑定 fixture 与发布前守卫。

| 选项 | 影响 | 草案判断 |
| --- | --- | --- |
| 测试常量显式转整数 | 两处期望表达式 | 推荐 |
| 改生产 reason 输出 | 生产协议及消费者 | 不在范围 |
| 降低 reason 断言强度 | 信号身份验证变弱 | 不采用 |
| 升级 Python 或切换解释器 | 环境及历史可比性 | 不采用 |

不修改 test 58/59 已有断言；它们现有前缀匹配不属于本次新增放宽。若需要统一增强运行中信号断言，应另列范围，不能夹带在这次两行 hotfix 中。

## 🔐 不变项与绑定更新

本机 overlay 根目录：

```text
E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution\server_overlays\r1b_synthetic_pf_impl_v5_20261012
```

| 文件 | 冻结 SHA256 | 修订约束 |
| --- | --- | --- |
| `audit_synthetic_pf_dependencies_v5.py` | `cb3b99547b1d630896bfb108c73d982fd798c7ae0dd269d51e35f6e819534c5d` | 字节不变 |
| `install_synthetic_pf_implementation_v5.py` | `2aa90eba43e69203d48686b50333db80b252cb69623833472c746bf402447b4e` | 字节不变 |
| `supervise_synthetic_pf_implementation_v5.py` | `002069eff1be30bd542be48157a9487482488a58475d7aa342e2883ab48df949` | 字节不变 |
| `test_synthetic_pf_dependency_audit_v5.py` | `50e70c1ede0aaef73b16aa049955125845343fc2fadc8f609c683111afff65ac` | 两处期望转换 |

这些哈希已在本次本机只读核验中保持一致。若未来实现改变测试文件，必须记录父哈希、精确两行 diff、最终字节数及新 SHA256，并进行 AST 审查；不能在已消耗 scope 或既有 manifest 中替换哈希。

旧 driver v3 内嵌旧测试哈希和旧隔离路径，不能直接启动修订后的测试。后续需另行授权新增版本化 driver（建议 v4），仅更新新测试绑定、新隔离根、run ID 和新输出路径，保留原有权限、计数、预算、身份核验及失败即停语义。这个 driver 工作不属于当前两行测试修订权限，也未在本次实施。

旧 ext4 副本、清单、授权回执、launcher、标记、结果和原 `/mnt/e` EIO 残留全部保留；不得原位更新或删除。未来使用全新独立 ext4 根，精确路径与历史证据集合在新准备清单中再冻结。

## 📋 回归范围与通过条件

### 不执行的静态核验范围

未来 implementation-only 阶段建议允许：只读源码及 AST，不 import；确认差异仅两处 `str(int(...))`，67 项人工＋18 项原生＝85 项方法及名称不变；fixture_finalizer、发布守卫、信号 hook、failfast 和主入口计数不变；三生产文件哈希不变。

兼容性负向覆盖通过扩展 test 60/61 各自已有方法内的纯表达式检查实现，不新增测试方法、进程场景或套件调用：数字期望与 `str(15)`/`str(2)` 相等，且 TERM 与 INT 期望互不相等；不需要断言枚举的 `str()` 必须是什么，以免将环境差异固化为测试需求。若采用这些新增检查，则最终 diff 不再仅两行，必须作为明确的附加 fixture 范围授权并列出，不能自动夹带。本草案默认两行修订，已有精确信号断言作为核心回归。

### 未来另行授权的单次运行范围

建议最终仍完整运行 85 项一次，不只运行失败项，也不续跑剩余五项。不得提前用未冻结的选择性运行当作调试循环。

| 回归组 | 数量 | 重点 |
| --- | ---: | --- |
| 人工契约 | 67 | 哈希、授权、失败锁及发布 |
| 原生 test 32–41、58–59 | 12 | 超时、进程树、信号清理 |
| 原生 test 60–61 | 2 | TERM/INT精确原因、无提交 |
| 原生 test 62–65 | 4 | 提交、提交后不确定、注册、无进度 |
| 合计 | 85 | 全量一次，failfast |

成功必须同时满足：runner/driver/outer 真实退出码 0；unittest 精确 85 项与最终 OK；18 条原生场景证据；符合逐场景预算及清理条件；冻结输入和生产哈希保持一致；没有已登记残留组或 fixture。本轮 79 项通过不能拼接为未来完整 85 项通过。

保持预算：total 120 s、work 112 s、cleanup reserve 8 s、fixture/log上限16 MiB、组上限20、已观测 helper上限120。已有合作式 driver 预算不能宣称是经过证明的外部硬超时；不得新增全局 kill 或静默扩大预算。

失败立即停止、保留真实退出码和首错，不重试、不 resume、不变更环境。CPU通过也不等于 CUDA 路径等价，不自动进入库存审计、服务器部署或 GPU preflight。

## ⚙️ 后续独立授权顺序

```mermaid
flowchart TB
    accTitle: Fixture Compatibility Authorization Stages
    accDescr: 每个阶段需要独立授权，方案确认不自动允许修改或测试，历史失败请求永不复用。
    confirm_draft["确认待审修订方案"] --> implement_fixture["单独授权测试修订与静态审查"]
    implement_fixture --> new_driver["单独授权新 driver 与准备清单"]
    new_driver --> prepare_copy["单独授权新 ext4 副本准备"]
    prepare_copy --> readiness_review["单独授权只读就绪审查"]
    readiness_review --> pending_request["单独授权待执行 request 创建"]
    pending_request --> authorize_sha["按完整 SHA 单独授权执行"]
    authorize_sha --> run_once["仅运行一次完整 CPU 契约"]
    run_once --> stop_boundary(["停止并等待后续审计授权"])
```

图示仅说明未来阶段，不是执行指令。今次草案不创建新 driver、ext4 目录、副本、授权 scope 或 execution request。

实现记录可注明 `STATIC_PASS_TESTS_NOT_EXECUTED`，但不得提前形成完整本机测试 P3 PASS。正式 post-test freeze audit/P3、结果恢复与运输另行授权。

## 🔗 追溯材料与待确认事项

- [已消耗 ext4 execution request v1](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_v5_local_ext4_cpu_execution_request_v1_20261012.json)
- [当前测试 fixture](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/r1b_synthetic_pf_impl_v5_20261012/test_synthetic_pf_dependency_audit_v5.py:771)
- [生产信号处理器](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/r1b_synthetic_pf_impl_v5_20261012/supervise_synthetic_pf_implementation_v5.py:203)

建议确认默认的“两处整数转换＋静态审查”方案。如拟实施，请单独授权该精确范围；不应将“确认草案”解释为测试执行授权。

本文件采用 decision record 的背景、备选、建议、风险及授权顺序结构，并以 Mermaid 保存阶段关系。仅作文本静态审阅，未进行渲染、程序验证或测试执行；没有 Git commit、tag 或 push。
