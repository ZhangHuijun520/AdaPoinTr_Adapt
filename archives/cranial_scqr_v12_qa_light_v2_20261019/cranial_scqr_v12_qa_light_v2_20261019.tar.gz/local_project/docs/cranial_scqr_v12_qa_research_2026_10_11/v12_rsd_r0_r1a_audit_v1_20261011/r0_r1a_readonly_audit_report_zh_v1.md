# Cranial-SCQR v1.2-QA：R0＋R1-A 只读证据与事件触发审计报告 v1

## 1. 审计结论与授权边界

本次完成用户已授权的 R0 证据锁定与 R1-A 已存事件触发审计。四份 LS/LSQ×C/D case CSV 的身份、覆盖、数值字段、事件标记及 source 汇总一致性核验通过；完整保存 210 个配对 case，没有排除、替换或重评估病例。

审计状态：`PASS_STORED_EVIDENCE_INTEGRITY_AND_TRIGGER_CONSISTENCY`。这仅说明已存证据在本次核验范围内自洽，不表示候选算法效果或安全性通过。

正式 gate 状态保持 `NOT_ADJUDICATED_HISTORICAL_NUMERICAL_EVIDENCE_GAP`；正式分类仍为 null。研究治理建议为 `NO_ADVANCE_RECOMMENDATION`，并非原五类分类或正式 gate 的替代结果。当前不晋级、不自动重训；可在此止损，或另行授权起草有限诊断子协议。

| 项目 | 记录 |
|---|---|
| 审计日期 | 2026-10-11，Asia/Shanghai |
| 授权依据 | 用户确认计划并授权“R0＋R1-A 只读证据与事件触发审计，不立即训练” |
| 父计划 SHA256 | `a656448a7323f82415babc3d65150befb890f742653bf499df811b31a306a870` |
| 服务器根目录 | `/home/jovyan/adapointr_work/PoinTr` |
| 当前 hostname | `shu-common-25721452-notebook-2b2doi-0` |
| 连接观测时间 | 2026-10-11T12:08:47+00:00 |
| 方式 | Windows WSL＋hpc5000 WebShell；标准库文本/元数据读取 |
| 本机产物 | 本报告所在独立版本化目录；不覆盖原计划、报告或源数据 |

本次没有读取 NPZ/STL payload、读取 checkpoint 字节或加载 checkpoint、构造模型、导入 PyTorch、访问 GPU、执行训练/BNCal/推理、重跑 bootstrap、计算正式 gate 或 LSQ−B0。没有修改服务器文件、创建执行 request/runtime/launcher、启动 tmux、安装依赖、Git 提交或删除文件。历史回执中的 forward、payload open、checkpoint load 数量属于历史实验，不是本次审计发生的访问。

本报告是只读证据审计产物，绝非 GPU 执行回执。当前容器不同于既有统计授权回执的 hostname；读取旧产物不复用旧执行授权。未来真实执行若涉及资源变更，仍须单独 resource-rebind 与新 request；本次未查询 GPU UUID。

## 2. R0：证据锁定、完整性与历史缺口

### 2.1 冻结来源与哈希核验

重新核验安全性/历史复盘 request 的 51 项绑定及统计 request 的 54 项绑定；另核验 evaluator 相关 21 项绑定与四运行训练/BNCal 历史文本共 32 项绑定。158 个绑定条目按服务器绝对路径去重后为 119 个文件，重复条目的 bytes/SHA256 一致。详细路径、字节数和完整哈希见 `r0_verified_source_bindings_v1.json`。该计数不包含 checkpoint payload；不要将它解释为“全部实验二进制归档已恢复验证”。

| 冻结对象 | SHA256 |
|---|---|
| QA-1 预注册协议 v1 | `10878972310ced7ddad1188a29b233686c17b5dd5cee72f27593846cef16c8b8` |
| 已确认统计补充协议 v1 | `85751899ec1c9d274c6f899049e45823e4acf9c41fe50504efae60561cbf0b8f` |
| 安全性/历史复盘 request v1 | `a17f87adc4d9fec71423a9edd8c0a261a187a8da05609c18952d39fdd545bbd7` |
| 统计 request v1 | `a568b4219aaeef8ce9ea05df58df32ce2c8a3ebbba9a3daac39fc55dad3c3eda` |
| 已存统计 summary | `660adb3310532d5a4d8f08d9adde61f0a3961ce4676978e9ff9050da22774e89` |
| 已存完整 42-source 差值 | `236efc1cc8be8b4721fb0fb385b65edd83e4bbadb05fcd0f61edcd60c60de555` |

四份 case CSV 各 105 行、21 source；逐 source 五种缺损等权汇总，与已存 source CSV 逐字段核对一致，容差 1e-10。四个历史 evaluation receipt 均记录 `PASS_DESCRIPTIVE_SINGLE_RUN_ONLY`、105 case forward、105 NPZ open、1 checkpoint load、参数和 buffers 前后不变；前后严格确定性/TF32 设置一致，且没有训练更新或正式 gate。对应 invocation 的 request、授权回执、runtime 和 manifest 哈希作为证据链保留。

这些历史记录是已有执行证据，不是本次再次运行验证。checkpoint 的实际字节 SHA256 本次未重算。统计退出码文本为 0；已存 summary 仍声明 gate_checks_computed=false、secondary_comparison_computed=false 和 automatic_next_stage=false。

### 2.2 三个维度分开记录

| 维度 | 本次结论 | 不可越界的解释 |
|---|---|---|
| 已存执行证据完整性 | 核验范围内的文本、CSV 与绑定一致 | 不等于本次验证模型或二进制 checkpoint |
| 历史数值条件证据 | 既有缺口未消除 | 后续严格 evaluation 不能追溯证明早期训练/BNCal 设置 |
| 科学/研究结论 | 维持描述性证据与不晋级建议 | 不生成正式五类分类或统计 gate 布尔值 |

历史统计 summary 列出的缺失快照运行仍为 B0 Fold C、B0 Fold D、LS Fold C。针对本次主比较，重新读取 LS Fold C 的训练 state/BNCal receipt，确实没有相应 numerical_policy 字段；其训练计数为 3939 optimizer steps、101 traversals、development 访问 false，BNCal 记录 optimizer steps=0、development payload open=0。这些计数不能替代数值模式快照。

LS Fold D、LSQ Fold C/D 的训练及 BNCal 文本包含严格确定性/TF32 策略与完成时快照。这里只记录证据存在性，不重新认证历史过程。B0 outcomes 仅在冻结绑定清单中作字节完整性核验，没有解析为新的候选比较。

### 2.3 原阈值来源索引

原阈值仅作为来源索引保存于 `r0_r1a_source_code_anchors_v1.json` 的 original_threshold_index_only_not_checks：

- 主指标 RimCover-P95；原主比较 LSQ−LS，负值较好；原协议 C/D 各折、pooled 差值及 CI 上界阈值保持不变。
- 原事件约束、zero-contact review 规则、Implant/Final CD、Final HD95、Final NSD 阈值保持不变。
- 本次没有把上述阈值逐项转为 PASS/FAIL，没有执行原五类科学分类。

既有 RimCover 描述结果为 Fold C −0.572073 mm、Fold D −0.402413 mm、pooled −0.487243 mm，已存 CI 为 [−0.894924, −0.088829] mm。本报告直接复用冻结 summary，没有重新 bootstrap；这些数字仍是固定 checkpoint 条件下的描述，不消除历史训练数值混杂或量化 seed 变异。

## 3. R1-A：全量身份、单位与字段审计

配对键为 (fold, case_id, seed)。两模型 case_id、source_skull_id、skull_id、defect_type 与冻结 allowlist/manifest 元数据一致；C/D 共 210 个独特 case、42 个 source，各 source 恰有五种缺损，两折 source 不重合。四份 CSV 共 420 行，所审计的 18 个数值字段全部有限；disaster 与 zero-contact 重建不一致数量均为 0。

元数据归一化 centroid 为有限三维量，scale 为有限正数。代码按 points×scale＋centroid 恢复 world/mm 后计算指标。这只是元数据与实现文本的一致性核验；未重新打开点云、验证采样质量或独立测量物理几何。

development84 allowlist 为 420 case。C/D 各 315 train＋105 dev，train/dev 不交叠，合并均等于 development84。manifest 中 legacy gate_split=test 的 C 有 5 case、D 有 20 case；它们均 official_split=train、monitor absent，且属于精确冻结 development allowlist。当前 QA-1 evaluator 不要求 legacy gate_split=train。因此这些旧标签不构成本次官方 test 访问或数据身份错误，也没有因此删除病例。不能由此推广为所有旧分区都已全面独立审计；实际点云与保护分区 payload 未读取。

## 4. 真实 disaster 规则与触发分解

冻结实现来源：

| 文件 | SHA256 |
|---|---|
| QA-1 evaluator | `5d3e92094cc1eeec8788dbec4543735d95947dcbdd0449541516242dcad5d808` |
| 继承的 v1.1 metric-row 实现 | `6be1c38b46270eff278ea7a54805ba0d572e8aef81a103350308072380c38798` |
| skullfix_metrics | `0c4342cd19fb19a659302b0e350c3be34bd21447d2034bdc9d2e81a180174ee5` |

QA-1 evaluator 第 543 行调用继承实现 _metric_rows。继承实现第 508–511 行的 core 是 Implant CD-L1、Implant HD95、Final CD-L1、Final HD95、RimCover-P95：

```text
disaster = int(any(nonfinite(core))
               OR (isfinite(rim_contact_hd95_mm)
                   AND rim_contact_hd95_mm > 50.0))
zero_contact_2mm = int(rim_predicted_rim_points == 0)
```

严格大于 50.0，不是大于等于；没有增加 Implant CD 等其他大小触发器。代码还会在非有限模型输出/core 时 fail-closed。本次所有已存 core 有限，所有 footprint 非空；事件均由接触 HD95 项触发。

继承协议的 zero-contact 文字存在“zero-contact 与 disaster counters 按指定规则增加”的潜在歧义，但实际实现将 zero-contact 单独计数：contact HD95 为 NaN 时不会仅由此触发上述有限-HD95条件。当前 420 行 zero-contact=0、指标均有限，该边界歧义未影响本次事件核验；未来若涉及空接触，须单独澄清协议/契约，不在本次修改代码或重编码 flags。

### 4.1 四个 LSQ 新增事件

下表为展示性小数，完整源字符串及触发距离见全量 CSV；判定使用原始精度。

| fold/source/defect | LS 接触 HD95/mm | LSQ 接触 HD95/mm | LSQ 距 50 mm/mm |
|---|---:|---:|---:|
| C/025/random_2 | 46.997949 | 53.447213 | +3.447213 |
| D/008/random_1 | 18.959702 | 51.538335 | +1.538335 |
| D/010/random_1 | 40.622367 | 68.398622 | +18.398622 |
| D/087/parietotemporal | 36.915941 | 65.670762 | +15.670762 |

四个 case 均 core 有限、zero-contact=0。它们不是 NaN、空接触或 CSV flag 错配事件，触发距离也不属于展示小数舍入跨界；但本次不能排除点采样/几何离散化的不确定性。

| case | RimCover LS→LSQ/mm | 预测接触 footprint 点数 LS→LSQ | precision LS→LSQ | recall LS→LSQ |
|---|---|---|---|---|
| C/025/random_2 | 14.619335→12.882486 | 120→38 | 0.375000→0.631579 | 0.222772→0.118812 |
| D/008/random_1 | 8.088278→7.509196 | 81→6 | 0.629630→0.666667 | 0.344595→0.027027 |
| D/010/random_1 | 14.912389→14.509678 | 120→179 | 0.450000→0.307263 | 0.287234→0.292553 |
| D/087/parietotemporal | 17.363256→14.310884 | 276→90 | 0.144928→0.122222 | 0.235294→0.064706 |

这里的点数是 partial 上预测植入物的接触 footprint 点数，不是模型预测植入物点数。三个事件 footprint 数量下降，010 则增加且 precision 下降。因此只能说接触 footprint 匹配呈异质变化，不能统一诊断为植入物 underfill 或接触崩塌，更不能归因于 query residual 的因果机制。

### 4.2 为什么 RimCover 改善与接触 HD95 恶化可同时发生

实现先在 defective partial 上定义两个 footprint：partial 点到 GT implant≤2 mm 的 reference_rim，及 partial 点到 predicted implant≤2 mm 的 predicted_rim。

RimCover-P95 是 reference_rim→完整 predicted implant 的单向最近邻距离 P95；接触 HD95 是 predicted_rim 与 reference_rim 两个 partial footprint 间双方向距离数组拼接后的 P95，不是两个方向 P95 的最大值。这是两个不同估计对象，前者改善不能保证后者改善。

CSV 没有两方向接触距离数组、方向 P95 或空间坐标，不能判定哪个方向主导、哪段边界错位、是否由局部外溢/漏覆盖或稀疏 sampling 导致。本次没有几何图、query-off forward、instrumentation 或机制干预。上述解释属于实现层面的可验证区别，不是空间根因结论。

## 5. 全量迁移、事件尾部与匹配对照

迁移命名中的 safe 仅指 disaster=0，不代表临床安全、整体性能通过或无风险。

| fold | 两者 flag=0 | LS 独有事件/消失 | LSQ 独有事件/新增 | 两者共有事件 |
|---|---:|---:|---:|---:|
| C | 101 | 3 | 1 | 0 |
| D | 98 | 2 | 3 | 2 |
| 合计 | 199 | 5 | 4 | 2 |

共 11 个独特事件病例、13 次 candidate-case 事件记录（LS 7、LSQ 6）。总数净变化会隐藏四个新事件，不能仅用净数解释安全改善。五缺损及全部 42 source 的迁移计数见 summary JSON，不只展示四个新增病例。

| fold/source/defect | LS 接触 HD95/mm | LSQ 接触 HD95/mm | 迁移 |
|---|---:|---:|---|
| C/025/bilateral | 58.499199 | 35.213019 | LS 独有 |
| C/025/random_2 | 46.997949 | 53.447213 | LSQ 独有 |
| C/051/frontoorbital | 71.351466 | 12.875401 | LS 独有 |
| C/072/random_2 | 53.690508 | 16.553983 | LS 独有 |
| D/004/random_2 | 84.869571 | 43.481471 | LS 独有 |
| D/008/random_1 | 18.959702 | 51.538335 | LSQ 独有 |
| D/010/random_1 | 40.622367 | 68.398622 | LSQ 独有 |
| D/022/frontoorbital | 61.661711 | 63.617328 | 共有 |
| D/087/frontoorbital | 65.424458 | 89.686799 | 共有 |
| D/087/parietotemporal | 36.915941 | 65.670762 | LSQ 独有 |
| D/087/random_1 | 67.462582 | 49.138175 | LS 独有 |

完整 42-source 既有差值按 fold/source 字符串升序复制到 tail index，未重算统计。210-case CSV 保留所有数值与 source/defect，包含 087/frontoorbital、087/random_1 两个方向相反尾部。直接复用既有复盘：Fold D Implant CD 的 source 差值 17 正、4 负；五缺损均值差值 bilateral +0.192107、frontoorbital +1.071901、parietotemporal +0.308653、random_1 −0.360813、random_2 +0.038902 mm。上述不是新增阈值；旧报告来源为本机 `docs/cranial_scqr_v12_qa_research_2026_10_10/v12_qa1_safety_historical_evidence_review_report_zh_v1.md`。

匹配规则完全沿用已确认计划：同 fold、同 defect、两模型 disaster 与 zero-contact 均为 0；按原 LS RimCover 与目标病例的绝对距离排序，tie 按 case_id ASCII 升序，取前二。

| 目标 | 对照 source | LS RimCover 匹配距离/mm |
|---|---|---|
| C/025/random_2 | 051；081 | 3.752759；4.369045 |
| D/008/random_1 | 004；095 | 0.258403；0.351431 |
| D/010/random_1 | 044；037 | 0.001228；0.662723 |
| D/087/parietotemporal | 005；029 | 3.032350；3.707013 |

实际 8 个独特对照；选择列表在任何新模型特征或几何访问之前冻结。025 与 087 的匹配距离较大，不能称为严格近邻对照；即便距离小也只是技术指标匹配，不控制缺损面积、解剖区域或其他混杂。未以未来 instrumentation 或新预测挑选对照。

## 6. 问题、限制与审计过程记录

没有发现本次范围内的缺行、重复配对、身份错配、有限尺度异常、字段缺失、事件重建矛盾或 source 汇总矛盾；这不是对所有未读取数据及模型实现的全面证明。主要未解决事项是历史数值快照缺失、空间机制未识别、空接触协议措辞歧义及部分对照匹配质量有限。

审计期间发生的技术问题已处理并记录，均不是实验失败或训练重试：

- 首次代码绑定枚举误将 list/dict 合并，标准库脚本报 TypeError；按实际 schema 修正读取方式后核验成功，无源文件变动。
- 一次元数据合并输出被截断，改为 C/D 分开读取；最终 210 case 完整，无删行。
- 初始核对错误假定 legacy gate_split 必须为 train；查阅实际冻结 evaluator 和 allowlist 后撤销该不适用假设，没有修改源数据或放宽既有合同。
- 一个补充清单长命令等待，取消该本地客户端；较短只读清单命令随后成功。保存先前成功的哈希核验，不将未完成命令的输出当证据。最终尾部 JSON 读取成功并再次核验原 SHA256。
- 本机 CIM 进程诊断不可用；没有执行 Stop-Process、删除或清理服务器文件。

CPU contract tests/P3 没有在本次重新执行；这里只读取/核验已冻结相关文本与实现绑定。当前 Python 3.8.10 是读取审计所用标准库环境，不宣称为历史训练环境。服务器可用空间约 9.2 GiB（观测值）不构成当前写入/运行授权。

## 7. 下一步建议与明确停止点

首选保持当前不晋级、不重训。四个事件已从“标记存在”推进到“冻结触发分量明确”，而非被证明是显示误差；已有均值改善不能抹去这些事件或历史证据限制。

若导师/用户认为区分即时 query residual 敏感性仍有信息价值，下一项可单独授权：**仅起草 R1-B 冻结 checkpoint 的 query-off 干预子协议**，状态待确认，不实现代码、不加载 checkpoint、不读取点云、不启动 GPU 或训练。可在子协议中预先定义原生输出再现、方向性接触距离与 footprint 诊断、干预计数、数值合同、预算和停止规则；GT 只能用于允许的 post-forward 指标，不能进入 model/query forward。子协议确认仍不等于执行授权。

不建议此时直接启动 R2、Mamba 大矩阵、seed sweep、16384 分辨率或新基线训练。R1-B/R2 都是条件式选择，不是本审计完成后自动进入的流水线。

## 8. 本机交付与复核

| 文件 | 用途 |
|---|---|
| r0_r1a_readonly_audit_report_zh_v1.md | 本报告：结论、证据、触发解释、限制与下一步 |
| r1a_paired_case_transition_ledger_v1.csv | 210 个配对病例；源数值字符串、完整 flags/core/接触指标及边界距离 |
| r1a_audit_summary_v1.json | fold/source/defect 全量计数与正式状态边界 |
| r1a_matched_control_cases_v1.json | 冻结匹配规则、目标、8 个对照及限制 |
| r0_verified_source_bindings_v1.json | 119 个去重服务器绑定、SHA256/bytes、数据合同 |
| r0_r1a_source_code_anchors_v1.json | 代码行、metric/flag 定义、原阈值来源索引 |
| r1a_tail_index_frozen_source_v1.json | 既有 42-source 差值全文及反向尾部 |
| r1a_identity_metadata_snapshot_v1.json | C/D allowlist 身份/归一化元数据及分区核对 |
| r0_historical_receipt_snapshots_v1.json | 已存训练/BNCal/evaluation/统计回执快照 |
| files.sha256 | 本机交付文件完整性清单；不包含其自身 |

同目录 JSON/CSV 为全精度审计账本；本报告表格的小数仅用于阅读，不用于重新判定。若后续修订，创建新版本，不覆盖本次或历史产物。该目录不是 `E:\ResearchBackups\AdaPoinTr` 长期归档，本次没有认证服务器归档已下载并本机恢复验证，因此不授权删除任何服务器文件。

文档采用 markdown-mermaid-writing 的证据/风险/下一步结构；CSV 核对遵循 spreadsheets 只读审计的键、单位、缺失与零值区分原则，未编辑原始数据或制作新的结果选择表。
