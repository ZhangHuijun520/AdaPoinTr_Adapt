# R1-B synthetic preflight implementation-only v4 修订方案与回归测试范围草案 v1

_2026-10-12；状态 `DRAFT_AWAITING_USER_CONFIRMATION`；仅制定方案，不构成代码实施、测试、运输冻结或服务器执行授权。_

---

## 📋 背景、证据与本轮边界

本草案针对 v3 启动契约审查发现的 `LC-01` 至 `LC-04`，提出新的 v4 本机 implementation-only 方案。目标是修复成功状态、身份登记、最终发布与前置阶段时限的门控缺口，不改变 Cranial-SCQR 实验数值、统计规则、真实数据权限或未来 GPU preflight 的 600 秒预算。

依据为[正式只读审计回执](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_v3_upload_readiness_launch_contract_readonly_audit_v1_20261012.json)，SHA256 `c0324e3d51f6c29705edcd34fdd750ce2c1cbf76d75b36bc868767cca1f62574`。审计结论是 `PASS_UPLOAD_AND_PARENT_EVIDENCE_DEPLOYMENT_BLOCKED`，不是部署失败；服务器没有部署或运行 v3。

| 已有证据 | 保留结论 | 不能推导的结论 |
| --- | --- | --- |
| v3 上传五件套与四成员 | 哈希完整匹配 | 可执行或已部署 |
| 父九文件、canonical 三工具、协议/YAML | 审计时一致 | 未来仍一致 |
| 新容器资源身份 | 审计时匹配 | 跨容器自动重绑定 |
| v3 本机 41/41 测试 | 既有场景通过 | 四项遗漏分支已覆盖 |
| v3 stage/output/P3/control/session | 审计时不存在 | v4 路径不存在 |

v3 本机 P3 回执 SHA256 `6684414c918b52fafcf9b8108d7f2f57d4a56ed3ebcc394bc825d8368e6d8c2f`；v3 运输包 SHA256 `9144ac5718f5892a86be21a00214f843e42a6dabf6899180c89401b731f939a8`；旧 v3 待授权范围 SHA256 `14b35fb1d22c89418e69306abd8906d6f739adebc68bc5907730c2c7517cea40`。这些文件均不回写，不删除，也不把本次草案确认解释为其执行授权。

本轮只新增这份本机 Markdown 草案。服务器连接、代码修改、测试、库存扫描、GPU、真实 NPZ/checkpoint、runtime/launcher/tmux、execution request 和运输包创建全部为零。

## 🎯 修订目标与方案选择

| 阻断 | v3 静态缺口 | v4 验收要求 |
| --- | --- | --- |
| LC-01 | 设置 PASS 后的监督器异常未强制失败 | 失败锁存，不允许恢复成功 |
| LC-02 | 未登记 leader 时的空字典可被当作空组 | 握手、身份凭据、三态组观测 |
| LC-03 | PASS P3 先发布、completion 后补 | 单文件完成证据与单提交点 |
| LC-04 | 无 progress 的前置校验可能等待 900 秒 | 自子进程启动起独立 60 秒阶段期限 |

建议采用“完整生命周期监督器＋显式身份握手＋单文件 P3 完成封装”。其代价是增加握手和提交状态，并需要人工失败注入；收益是将成功定义收敛到可核验的状态与产物组合。

最终发布备选方案如下。该选择需要用户确认，不在本轮实现。

| 选择 | 优点 | 风险/代价 | 草案意见 |
| --- | --- | --- | --- |
| 保留两文件顺序发布 | 改动较少 | 独立 completion 的缺失窗口仍在 | 不采用 |
| P3 内嵌完成证据、最终文件一次发布 | 保持现有 P3 reader 的消费字段 | 需明确提交后异常状态 | 推荐 |
| P3/completion 整目录提交 | 可同时暴露多个文件 | 目录提交与路径迁移增加复杂度 | 暂不采用 |

Python 文档说明 Unix 上普通 `rename`/`replace` 可能覆盖已有目标，不能把“先检查不存在再 replace”当作禁止覆盖的保证。建议在完成人工验证后采用同文件系统、拒绝已有目标的发布原语；`os.link` 是硬链接接口，但实际文件系统支持情况仍须后续核验，不能由文档推导服务器一定支持。[^1]

## 🔧 四项修订的具体契约

### LC-01：失败锁存与原始异常保留

监督器在所有前置检查、控制器监控、组回收、日志 flush/fsync/close、凭据准备和最终提交期间维护统一的失败锁存器。默认状态不是 PASS；“控制器返回 0”只能进入 `ELIGIBLE_FOR_FINALIZATION`，不是全流程成功。

- 首次异常、TERM/INT、期限到达、身份不明、残留进程或哈希漂移立即锁存失败原因。
- 失败锁存后即使后续回收成功，也只能证明进程已回收，不能撤销失败或进入发布。
- `PROCESS_REAP_UNCONFIRMED` 高于普通失败：不得发布 PASS，不能自动向未知身份发送信号。
- 二次记录/关闭错误分别记录，保留第一异常的类型、信息和阶段；无法写文件时仍需非零退出和 stderr 诊断，不声称已有完整回执。
- 任何日志落盘、close 或最终门控发生在成功返回之后的模式均不得保留；返回成功必须是全生命周期的结果。

建议终态为 `FAILED_STOPPED_NO_RETRY`、`PROCESS_REAP_UNCONFIRMED`、`COMMIT_OBSERVATION_UNCERTAIN` 或 `PASS_CPU_IMPLEMENTATION_V4_PENDING_READONLY_FREEZE`。状态字符串不是权限，全部均不自动授权下一阶段。

### LC-02：登记后释放与三态组观测

唯一 controller 仍由 supervisor 创建独立作业组；生产测试、audit 与 loader 子进程继承该组，不再自行创建新会话。新 controller 入口先停留在受管握手阶段，不执行 archive/bootstrap/安装工作。

1. supervisor 记录直接 Popen 子进程 PID，并核对 `/proc` 的 PID、PGID、SID、start ticks、父关系及预期组关系。
2. 将这些字段连同 supervisor 自身身份、run ID 和本次启动单调时间写入不可覆盖登记凭据，flush/fsync/close 成功后才可释放 controller。
3. controller 通过本次唯一继承的管道/握手通道确认释放；不能仅以可伪造的环境变量表示身份已登记。未释放、EOF 或握手期限到达时失败。
4. READY/RELEASE/ACK 等待不增加生产预算；登记与释放合计上限建议 5 秒，同时受 1300 秒总期限约束。人工测试可注入更短预算，不修改生产常量。

组观测明确区分：`UNREGISTERED`、`REGISTERED_EMPTY`、`REGISTERED_NONEMPTY`；读取失败或身份不一致另为 `OWNERSHIP_UNCONFIRMED`。只有已经确认登记的组，才能产生“已空”的证明。快退出且未完成登记只能失败，不得把 `{}` 视为 PASS。

持久化登记之后若需失败回收，应先重新核验已登记身份。leader 已退出的 orphan 组必须有同一轮已观测后代身份支持；PID/PGID/SID/start 漂移时停止信号发送并报告不确定。保留 TERM→有界等待→必要 KILL→直接子进程 wait 与组成员复核。回收针对本轮核验过所有权的组，禁止全局 `pkill`。

握手不解决所有内核竞态，也不赋予 cgroup/pidfd 组隔离保证。监督器 SIGKILL、容器强制销毁、未被观测到的第三方会话逃逸仍不在保证范围内；下次连接先只读审计登记和产物，不自动清理或重跑。

### LC-03：完成证据内嵌与单一提交点

冻结以下语义：正式 v4 P3 本身包含 `completion_evidence_v4`，不再要求先发布 PASS P3、再创建一个权威性的 sibling completion。外部终端退出记录只用于交叉核验，不能代替内嵌门控。

内嵌记录至少包含：本次 run/request/授权/实现绑定、三轮 CPU 测试计数及退出码、库存 completion 的 bytes/SHA、父哈希复核、controller 精确退出码、已持久化 leader 身份、注册组为空和回收确认、阶段与总期限门控、GPU/真实数据计数为零。这里的 controller 退出码不是尚未发生的 supervisor 最终退出码。

P3 保留 unchanged reader 所需的 `status`、`gpu_used`、`preflight_implementation_bindings` 等字段；新增完成记录，不修改三份 canonical 工具。已只读检查现有 reader 通过 request 绑定路径加载 P3，并按上述字段核验；它不强制 P3 必须位于原 v3 basename，也不会自动核验 v4 内嵌提交语义。因此未来 CPU post-freeze 审计必须核验完整 v4 envelope 后，才可另行起草任何下游 request，不能只看旧 reader 的 PASS 字段。

拟定发布顺序：

1. controller 仅产出非 PASS candidate；supervisor 取得控制器 0 退出、登记组闭包及全部门控。
2. 在本次 control 目录中独占创建完整发布源文件，序列化最终 P3＋内嵌完成证据；flush、fsync、close、重读语义/哈希全部完成。文件内容可能已有 compatible PASS，但它仅是未提交发布源，不能绑定为正式 P3。
3. 构造内嵌证据时不写自身最终 P3 SHA，避免循环依赖；最终 SHA 在完整字节生成后计算，留在退出/只读 freeze 证据中。
4. 在总期限内确认未锁存失败、没有 TERM/INT、正式目标不存在、父目录规范且无链接、源和目标同设备。以不覆盖的单一命名空间操作，将完整文件发布到唯一正式 P3 路径；不允许直接向正式 P3 路径逐步写 JSON。
5. 提交后的目录持久化、观察记录和退出码仍须核对。若提交前失败，正式 P3 必须不存在；若提交已发生但随后收到信号、落盘失败、期限到达或无法确认提交结果，状态是 `COMMIT_OBSERVATION_UNCERTAIN`，即使完整 P3 可见也不得把全流程标为 PASS。

若采用硬链接发布，源和正式目标指向同一份内容；提交前必须关闭所有可写句柄，提交后不得通过源路径改写同一inode。保留发布源不是允许编辑它，也不在本轮授权删除它。

单提交点解决的是“不完整 P3/缺失独立 completion”的窗口，不是对断电或任意信号的全能事务保证。提交后不能通过修改/删除已发布证据来伪装未发生；不确定时保留原件、非零退出、只读复核，并锁定后续 request。父目录 fsync 与故障恢复能力必须验证，不能把命名空间可见性等同于存储持久性。

TERM/INT 与总期限处理覆盖入口、监控、回收、凭据准备、发布及退出观察。处理器不在 `supervise()` 中途恢复；最终 cleanup 才恢复，并不得让恢复后的异常变成成功。提交瞬间信号竞态按上述不确定语义处理，不用屏蔽后忘记处理信号的方式绕过期限。

```mermaid
flowchart TB
    accTitle: Guarded Final Publication Flow
    accDescr: Registered controller closure permits finalization, but failures before commit prevent publication and uncertain observations after commit block all downstream requests.
    group_closed["登记组闭包通过"] --> prepare_envelope["准备完整 P3 envelope"]
    prepare_envelope --> before_commit{提交前门控通过?}
    before_commit -->|否| stopped["失败锁存 不发布"]
    before_commit -->|是| single_commit["唯一不覆盖提交"]
    single_commit --> observation_gate{提交后观察确认?}
    observation_gate -->|否| uncertain["提交不确定 锁定后续"]
    observation_gate -->|是| freeze_needed["待正式只读 freeze"]
    freeze_needed --> downstream_locked["下游仍需单独授权"]
```

### LC-04：无 progress 的独立身份期限

controller 在启动 audit child 时设置身份/CPU probe 共享绝对 deadline：`child_started_monotonic + 60`。不得等待第一条 progress 才开始计时。900 秒 audit 总期限同时从 child 启动计算，bootstrap/authority/parent_check 不计为免费开销。

- 尚无 progress、空日志、无换行的部分日志或 worker 挂起均保持前置身份阶段，60 秒到达即失败。
- 第一条 IDENTITY 或 CPU_ENV_INPUT 记录不能重置 deadline；二者共用最初 60 秒。
- 只有通过严格 schema、顺序及时间戳验证的阶段切换，才能转入后续阶段；不能由一条心跳延长期限。
- 若进度完整跳转到 ENUMERATE，但已违反前置共享期限，仍判失败；不以“现在已进入后续阶段”消除超时。
- 枚举、loader、内容哈希、final/publish 的原限额保留，并受 900/1300 秒期限共同约束。
- 超时由 controller 传播；外层 supervisor 一次回收完整受管组。不得由 child PID 猜 PGID，或为修复超时增加重试。

## ⏰ 不变预算、扫描覆盖与权限

| 生产约束 | v4 保留值 |
| --- | ---: |
| 每轮服务器 CPU 测试 | 60 秒 |
| controller 登记/释放 | 新增 5 秒子预算，包含于总预算 |
| IDENTITY＋CPU_ENV_INPUT | 共享 60 秒，自 audit child 启动 |
| ENUMERATE / LOADER_RESOLVE | 各 120 秒 |
| HASH_CONTENT | 480 秒 |
| FINAL_VALIDATE＋PUBLISH | 共享 60 秒 |
| 单次 audit / 全流程 | 900 / 1300 秒 |
| 失败回收 | 至多 15 秒，不额外计算 |
| 未来 GPU preflight | 600 秒，仍未授权 |

库存继续覆盖批准的 `models/utils/extensions` 与完整 Conda `lib` 代码集合，不为通过而缩小范围；上限为 entries 200000、去重 files 50000、内容 8GiB、loader targets 32、metadata 16MiB、单文件 120 秒。超限失败，不抽样、不截断、不缓存跳过。

全流程 1300 秒预算包含最终 v4 P3 发布及观察；worker 的 final/publish 60 秒与 supervisor 的最终封装发布是不同环节，后者仍受剩余总期限约束，不给额外免费时间。注册、内部解析和观测循环同样不得无限等待。

父九文件、三份 canonical preflight 工具、v1.1 路径、原协议/request、模型 YAML 与失败凭据保持不变。服务器身份候选仍是 `shu-common-25721452-notebook-2vuh4c-0`、uid 1000、GPU UUID `GPU-aeeaea56-513b-fc9b-7a70-bb6d37a0a04c`；这些是已有审计值，不是本轮重新观测。CPU代码若查询GPU，仅允许既有明确的 metadata query，不加载CUDA或运行计算。

## 📦 后续实施文件与路径提案

建议仅在新的本机目录 `E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/r1b_synthetic_pf_impl_v4_20261012` 新增四文件，旧 v3 原封不动保留：

| 文件 | 主要变更 |
| --- | --- |
| `audit_synthetic_pf_dependencies_v4.py` | 新命名空间、进度事件与前置阶段契约；覆盖和限额不缩减 |
| `install_synthetic_pf_implementation_v4.py` | 无progress deadline、候选完成证据、严格阶段流；继承生产组 |
| `supervise_synthetic_pf_implementation_v4.py` | 失败锁存、握手登记、全生命周期信号、single envelope commit |
| `test_synthetic_pf_dependency_audit_v4.py` | 继承测试与 LC-01～04 故障注入；本机真实信号测试 |

JSON 的 v4 schema、event/phase 枚举、完成字段、各单次路径和最终 test count 须在实施开始前列清，不能临时沿用 v3 authority。将本草案完整 SHA 绑定到未来实现/范围，不回写旧协议。

拟定服务器 namespace 为 `r1b_synthetic_pf_impl_v4_20261012`；以下仅是候选路径，本轮未创建、未连接服务器，也未核验不存在：

| 相对服务器项目根路径 | 用途 |
| --- | --- |
| `server_overlays/r1b_synthetic_pf_impl_v4_20261012` | 四个新增工具 |
| `docs/cranial_scqr_v12_qa_research_2026_10_11/r1b_synthetic_pf_implementation_v4_20261012` | 库存与人工CPU证据 |
| `docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_post_implementation_p3_v4.json` | 唯一正式内嵌完成P3 |
| `logs/cranial_scqr_v12_rsd_r1b/synthetic_impl_cpu_audit_v4_20261012/auth` | 仅独立CPU授权 |
| 同级 `launch` | 未来明确授权后创建launcher/bootstrap |
| 同级 `control` | 登记、candidate、发布源、退出/失败/不确定观察 |

固定CPU session候选为 `r1b-synthetic-impl-cpu-audit-v4-20261012`。具体 PID、exit、登记和发布源 basename 应在实现后范围与未来 execution request 中精确冻结；本草案不创建可运行 shell、runtime、授权回执或 request。

## 🧪 回归测试范围与本机安全上限

### 保留项与新增矩阵

继承 v3 的31项人工 CPU 契约和10项无害 Linux场景，但仅把它们当作待在 v4 最终哈希上重新验证的范围，不沿用旧PASS。新增覆盖按下表组织，允许固定参数化，最终 method/subcase 数在新测试前确定并冻结。

| 组 | 新增场景 | 通过标准 |
| --- | --- | --- |
| A01 / LC-01 | eligible后 flush、fsync、close分别失败 | 全部锁存失败、不发布 |
| A02 / LC-01 | 回收成功但已有主异常 | 不能重新PASS |
| A03 / LC-01 | 失败回执/二次关闭再次失败 | 第一异常保留、非零退出 |
| A04 / LC-02 | 未登记的快退出0、初始/proc读取失败 | 未知不能当空组 |
| A05 / LC-02 | 凭据写入失败、握手EOF/超时 | 不释放执行、不启动bootstrap |
| A06 / LC-02 | PID/PGID/SID/start漂移及orphan身份不足 | 不误杀、不PASS |
| A07 / LC-03 | envelope序列化/flush/fsync/close/重读失败 | 正式P3不存在 |
| A08 / LC-03 | 发布目标已有文件/链接、跨设备/不支持原语 | 不覆盖、不降级直接写 |
| A09 / LC-03 | 提交前信号或期限到达 | 无正式P3、明确失败 |
| A10 / LC-03 | 提交后fsync/观察失败、信号竞态 | 不确定、下游验证拒绝 |
| A11 / LC-03 | 提交P3缺少/篡改内嵌完成记录 | v4完整验证拒绝 |
| A12 / LC-04 | 无progress/部分行/CPU切换/重复START | 共享期限不重置 |
| A13 / LC-04 | 前置校验60秒边界、900/1300边界 | 精确边界拒绝；用人工时钟 |
| A14 / LC-04 | 非法阶段流、倒退/超前时间、伪心跳 | 不接受延长或跳过阶段 |
| A15 / 兼容 | 不变reader消费字段与v1-basename库存 | 不改 canonical，完整envelope另验 |
| A16 / 范围 | 惰性导入、四成员、数值/资源/权限门控 | 不访问生产路径或加载计算库 |

真实 Linux 新增场景至少包括：supervisor在controller运行时收到真实TERM和INT；在最终提交前收到真实TERM/INT；登记后controller TERM/KILL的后代回收；无progress且带无害后代的短deadline；正常登记释放后完整envelope提交；组外对照进程不受影响。提交后信号竞态可先通过确定性的注入钩子测试，再用有限真实场景补充，不用靠随机重复碰撞提高通过率。

采用READY/ACK同步到指定故障点，避免仅依赖sleep判断“信号发生在哪一阶段”。测试只向本轮已核验的fixture进程发信号；不发送supervisor SIGKILL来制造无人回收的场景，其灾难恢复不在本次测试范围。

### 建议下一步可授权的精确上限

| 本机测试限制 | 建议冻结值 |
| --- | ---: |
| 测试套件调用次数 | 1，failfast |
| 整套本机测试含回收 | 120 秒 |
| test methods / 固定参数子例 | 最多96 / 256 |
| 真实Linux场景 | 最多20，含继承场景，串行 |
| 每场景并发辅助进程 | 最多6；不含唯一test runner |
| 全套辅助进程启动总数 | 最多120 |
| 每场景工作 / 回收 | 最多1.5 / 2 秒 |
| 无害helper失联自退出 | 最多8秒，仅安全兜底 |
| 日志总量 / fixture文件总量 | 各16MiB上限 |

120秒是新的本机测试提案，区别于v3的60秒本机调用上限，须在下一步实施测试授权中明确接受；它不增加服务器每轮CPU测试60秒、库存900秒、编排1300秒或GPU600秒。helper自退出8秒不构成工作授权，若本轮2秒回收无法确认仍立即失败，不能等待兜底后把场景改判通过。

使用已准备的本机 WSL隔离 Linux Python 3.10.22：`/home/zhj/.local/opt/r1b-cpu-contract-python310-20261012/venv/bin/python`；这是本机路径，不能当服务器环境。fixture限定在新的本机v4 overlay中的专用人工目录；无需安装依赖，不加载torch/模型，不扫描Conda lib，不读取真实NPZ/checkpoint。WSL项目映射必须按既有验证结果核对，不猜测Linux路径。

测试安全driver须登记自己创建的辅助PID/组及启动身份。单场景结束先核验受管辅助进程全部退出，再开始下一场景；未知回收身份、超限或第一测试失败立即停止。整套超时也不能仅kill test runner而留下辅助新会话。只允许回收本轮人工fixture进程，不清理服务器或未知进程。测试结束清理仅限已确认属于本轮的临时fixture，版本化日志和失败证据保留。

最终服务器CPU测试只选择纯人工子集，不运行本机真实多会话fixture；该子集count必须按v4最终源码冻结，不能再沿用31来声称新增回归都已执行。canonical27回归保持独立且本轮/下一次本机测试不自动执行。

本机文件系统上的无害single-commit测试不证明服务器文件系统支持同一发布原语；部署就绪审查应记录这一环境前提。若不能在已授权范围内确认支持，保持 `execution_ready=false`，不得偷跑生产写入试验。

## 🔐 验收、证据与分阶段授权

v4本机implementation通过需要同时满足：四文件最终哈希固定、所有受授权测试通过、实际counts/进程/时间/字节上限有证据、LC-01～04逐项关闭、原v3和父文件不变、无真实数据/GPU/库存访问、无残留已登记helper，并完成新的本机post-implementation P3。

本机P3必须标为仅本机契约，不冒充服务器库存绑定P3。实际完成900/1300秒生产路径、CUDA600秒等价性、服务器hard-link/fsync支持、cgroup隔离和灾难恢复均不可写成已证明。

建议授权链为：

1. 用户确认本草案；确认不授权实施。
2. 用户另行授权四个v4文件及上述有界本机人工CPU/无害Linux测试；失败即停，不自动hotfix/retry。
3. 通过后仅报告本机P3、最终代码/日志SHA；运输冻结仍需单独授权。
4. 用户上传新的v4五件套后，单独授权只读核验与启动契约审查；v3包不能替代v4。
5. 仅在全部就绪条件关闭后，另行授权创建完整CPU execution request，保持待授权；再由完整SHA单独授权唯一执行。
6. 服务器CPU流程结束后，另行做只读freeze，核验最终P3完整envelope、退出/提交观察及库存清单；之后GPU仍锁定。

本机方案文档采用markdown-mermaid-writing的决策记录与可访问流程图组织证据和门控；技能不赋予Git commit/tag/push或实施权限。本轮不执行这些操作。

## 🔗 依据、风险与待确认事项

- [v3只读上传与启动契约审计](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_v3_upload_readiness_launch_contract_readonly_audit_v1_20261012.json)：四项阻断的正式来源
- [v3本机P3](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_v3_local_post_implementation_p3_v1_20261012.json)：保留41项既有场景与限制
- [v3待授权CPU部署范围](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_v3_pending_cpu_deployment_scope_v1_20261012.json)：仍不可执行，不修改
- [v3监督器源码](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/r1b_synthetic_pf_impl_v3_20261012/supervise_synthetic_pf_implementation_v3.py:63)：身份/状态/发布缺口的静态证据
- [v3controller源码](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/r1b_synthetic_pf_impl_v3_20261012/install_synthetic_pf_implementation_v3.py:92)：无progress阶段时限缺口
- [不变preflight reader的本机运输源](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_overlays/r1b_synthetic_pf_impl_v1_20261011/tools/run_cranial_scqr_v12_rsd_r1b_synthetic_gpu_preflight.py:305)：request路径绑定及兼容字段；不修改

请审核：是否采用单文件内嵌完成证据、登记/释放5秒子预算与本机120秒测试上限。审核本草案不自动创建v4代码或执行内容。若需要不同发布原语、更多进程场景、预算变化或canonical工具修改，须新版本方案及额外授权，不能在实现时扩大范围。

[^1]: Python Software Foundation. Python 3.10 `os` documentation，`link`、`rename`、`replace`及`fsync`：硬链接接口、Unix目标覆盖行为，以及缓冲文件flush后fsync的要求。https://docs.python.org/3.10/library/os.html
