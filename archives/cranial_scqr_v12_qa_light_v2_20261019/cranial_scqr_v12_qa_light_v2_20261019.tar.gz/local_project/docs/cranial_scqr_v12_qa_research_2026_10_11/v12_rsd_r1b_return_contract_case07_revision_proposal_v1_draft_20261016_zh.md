# R1-B 返回合同与第 7 项断言的限定修订方案 v1 草案

_2026-10-16，Asia/Shanghai；状态：DRAFT_AWAITING_USER_REVIEW。仅制定方案，不实施、不准备副本、不运行检查或测试。_

---

## 📋 结论与证据边界

建议一次性修订两个相邻问题：控制器前置失败返回缺少工作状态字段，以及第 7 项将错误规则与阶段混淆。目标是让返回合同明确、断言准确，不是把失败报告改成成功，也不是放宽身份、数据或执行守卫。

[失败产物正式冻结审计](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_prepared_original24_failed_batch_freeze_audit_v1_20261016.json)，SHA256：`cef3bbcab6c5742dcdfbbfc221f1a275a02dbe3c6821ee36fd4b5387beffb7ea`，确认原批次为6通过、1报错、17未执行，退出码1，证据保存通过。它没有证明24项通过。

[第 7 项限定原因报告](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_prepared_original24_case07_readonly_cause_v1_20261016.json)，SHA256：`1364e40643b2adc6d96c4075dcabcfd06bdc586868aeaaca7b5b216d8dd140b4`，区分了以下事实：

- 实际观察：测试第194行读取 `r['work_called']` 报 `KeyError`，前面的语义失败断言已完成
- 源码定位：`controller` 前置异常结果缺少该键；`send_receive` 返回结果则包含该键
- 源码推导：身份 helper 正常拒绝路径为 `rule=HELPER_REJECTED`、`phase=IDENTITY`，不是下一行断言要求的 `rule=IDENTITY`
- 未执行：第195行断言及后面的 `bad_value` 子场景尚未到达，不能把它们描述为第二次实测失败或已有通过结果

旧 request `803dee0cfbe4093380ce2df8a4dd568a0a376f57720df02edbbe42497fab35a1` 已消耗。其副本、fixture、运行目录与证据全部保留，不得覆盖、删除、resume、补跑剩余17项或再次执行该request。

## 🎯 拟采用的有限决策

| 方案 | 对缺字段的处理 | 对未知执行状态的处理 | 决定 |
| --- | --- | --- | --- |
| 只用 `.get('work_called', False)` | 隐藏缺字段 | 可能把未知当否 | 不采用 |
| 所有异常一律补 `False` | 补齐表面形状 | 混淆分派前后 | 不采用 |
| 必需字段＋明确三值语义 | 缺字段仍是合同错误 | 保留未知 | 拟采用 |

仅对本项目人工运输适配器的结果合同做修订，不修改模型、真实研究代码、训练参数或统计协议。既有 `Frames.work_called` 可继续作为内部“是否观察到有效WORK_BEGIN”的布尔记录；公开结果的 `work_called` 不能直接把内部初始False当成“证明未执行”。

将“本机返回合同修订”和“下一份Linux副本的路径/哈希重绑定”分开交付。第一步不需要也不允许为了修改两份源码而连接WSL、复用旧副本或扩展库存审计。

## 📚 返回合同的精确语义

### 生效边界与必需字段

统一合同适用于 `controller` 已接受合法授权和人工输入、创建本次结果存储后的返回结果。原先在授权、输入、单次占用检查中直接抛出的拒绝异常，继续抛出；不为“所有情况都返回字典”而吞掉授权异常或创建未经授权的证据目录。

拟用版本化控制器结果标识 `r1b-controller-result-v3` 表达本次语义变化。至少以下字段在受合同约束的成功及失败返回中必须存在；原有请求/程序/清单哈希、exec/HTTP计数和禁止重试字段仍保留，不删除其他已有诊断字段。

| 字段 | 类型 | 含义 |
| --- | --- | --- |
| `transport_semantic_pass` | bool | 完整运输语义是否通过 |
| `first_error` | dict或null | 原有首个失败，保留规则与阶段 |
| `secondary_errors` | list | 按顺序保留后续错误 |
| `outer_exit`、`remote_exit` | int或null | 已知退出码，不推定为0 |
| `remote_completion` | 固定状态字符串 | 已收齐结束证据或UNKNOWN |
| `remote_started` | bool或null | 远端入口是否有可信启动证据 |
| `last_remote_phase` | 字符串或null | 最近已校验的远端阶段 |
| `work_called` | bool或null | 工作阶段已进入、已证明未进入或未知 |

这里的 `remote_started` 专指受信人工工作producer入口，不是身份helper进程或WSL客户端是否启动。`remote_completion=CONFIRMED` 只表示结束证据齐全，不能表示语义成功。工作阶段开始也不等于工作完成，更不代表训练/GPU更新；原有零更新计数和守卫不变。

### 三值决策表

| 已知事实 | `remote_started` | `work_called` | `remote_completion` |
| --- | --- | --- | --- |
| 身份helper拒绝，尚未交给工作命令运输 | `false` | `false` | `UNKNOWN` |
| 分派工作命令前的其他本机失败 | `false` | `false` | `UNKNOWN` |
| 已可能发送工作命令，未收到可信启动帧 | `null` | `null` | `UNKNOWN` |
| 已收到REMOTE_BEGIN，后续证据不足且无WORK_BEGIN | `true` | `null` | `UNKNOWN` |
| 已绑定入口完整报告工作前拒绝并正常结束 | `true` | `false` | `CONFIRMED` |
| 已收到合法WORK_BEGIN，尚无完整结束证据 | `true` | `true` | `UNKNOWN` |
| 工作阶段已进入且完整结束，即使随后close失败 | `true` | `true` | `CONFIRMED` |

工作前拒绝的 `false` 必须有两类证明之一：工作命令尚不可能发出；或者同一次attempt、完整哈希/顺序绑定的受信producer给出REMOTE_BEGIN、工作前错误及失败结束，且未到WORK_BEGIN。单个ERROR帧、缺失结束帧、连接关闭、等待超时或未观察到WORK_BEGIN，都不足以单独证明未工作。

```mermaid
flowchart TB
    accTitle: Evidence Based Work State
    accDescr: Public work state is false only with proof of no dispatch or a bound pre-work rejection, true after a valid work-begin event, and unknown when dispatched execution lacks sufficient evidence.
    accept_input["接受合法输入与授权"] --> possible_dispatch{"工作命令可能已发出？"}
    possible_dispatch -->|否| proven_false["工作状态明确为false"]
    possible_dispatch -->|是| valid_work{"已验证WORK_BEGIN？"}
    valid_work -->|是| proven_true["工作阶段明确已进入"]
    valid_work -->|否| prework_end{"完整证明工作前拒绝？"}
    prework_end -->|是| proven_false
    prework_end -->|否| unknown_work["工作状态保持null"]
```

### 拟定实现方式与禁止项

在现有adapter内用小型结果构造/校验函数统一必需字段，并对controller向send_receive移交、以及可能发送工作命令的边界作明确状态记录。状态应在可能触发执行的发送调用之前标记为“可能分派”，不能等send成功返回后才标记；send抛错不证明对端没有收到内容。

controller在helper阶段失败时可证明没有分派工作命令，返回明确False。移交后的非预期异常，若缺少更精确证明，则保守返回null；不能在外层catch统一重置False。有效WORK_BEGIN出现后，即使后续失败，也不能把已知True改回False或null。

不改bootstrap或PROGRAM，不改帧schema、顺序/哈希绑定、身份与输入守卫，不降低输出、时间或调用次数上限，不增加网络、凭据、研究数据或GPU访问。不通过重命名生产错误来迎合断言。

## 🔧 第 7 项的对应修订

保留原24个case名称、顺序和每项预算。只修订 `test_07_manifest_identity_mode_block_work` 的返回合同及阶段断言，不因其他项未执行就顺便修改其他测试。

### 身份helper拒绝子场景

拟要求所有必需键存在，并用 `assertIs(..., False)` 而非 `assertFalse(...)` 验证工作状态与远端启动状态，避免null或整数0混过布尔断言。错误预期改为：

- `first_error.rule` 精确为 `HELPER_REJECTED`
- `first_error.phase` 精确为 `IDENTITY`
- `remote_completion` 保持 `UNKNOWN`，不能把“未启动”虚构成“已收到远端结束”
- 没有工作命令分派、没有上传、没有进入后续CREATE_DIRECTORY helper；证据仍能冻结

### `bad_value` 子场景

这是另一个独立人工场景，不沿用身份失败结果。保留value=999负例，拟断言：字段完整、工作状态严格False、REMOTE_BEGIN已确认、规则为 `ARTIFICIAL_INPUT`，最近已成功的输入前阶段为 `IDENTITY_VERIFIED`，错误后完整REMOTE_END已经解析。这里的错误阶段不是 `INPUTS_VERIFIED`，因为被拒绝的输入还没有通过该阶段。

应同时验证语义失败和结束证据确认能够共存，且没有WORK_BEGIN；不能仅因结果字典里填了False就认定守卫成立。这些均为待验证目标，本文未执行该场景。

## 🧪 有限人工回归范围与预算

后续若明确授权implementation-only，第一步最多修改现有目录中的adapter与contract-tests两文件：

- [transport_adapter_v2.py](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/local_tools/r1b_launch_transport_v2_20261016/transport_adapter_v2.py)，当前SHA256 `895112427394280c9dce312d69ac571a89fe97cd76da26f73ecfd48760789bc6`
- [transport_contract_tests_v2.py](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/local_tools/r1b_launch_transport_v2_20261016/transport_contract_tests_v2.py)，当前SHA256 `1c4ae27a01d2211d9c59d0025e1be709bd6333c5fa6083561ab5149ef4817580`

人工检查入口放在现有tests文件内的独立具名检查集合，不能并入原Contracts类改变24项数量，不能新增第五实现文件。仅使用内存Store、fake clock、fake backend和绑定的人工帧；运行真实结果构造、controller/send_receive及解析器逻辑，但不执行bootstrap/PROGRAM或真实helper，不创建Linux目录、FIFO或链接。

| 编号／拟定名称 | 限定验证目标 |
| --- | --- |
| RC01 `identity_helper_early_rejection` | helper正常拒绝；必需键、精确False、规则/阶段；无上传或工作分派 |
| RC02 `upload_failure_before_work_dispatch` | 内存上传异常但尚无工作命令；工作False，不虚构远端完成或写入状态 |
| RC03 `send_failure_execution_unknown` | 首次可能触发执行的send抛错；无结束证据时工作null，不重试 |
| RC04 `bound_bad_value_prework_rejection` | 绑定人工帧报告ARTIFICIAL_INPUT和完整失败结束；started=True、work=False |
| RC05 `work_begin_without_end` | 收到有效WORK_BEGIN但缺结束；work=True、完成UNKNOWN |
| RC06 `completed_work_then_close_error` | 工作完成后close失败；工作True、语义失败、首错与结束状态不混淆 |
| RC07 `mandatory_schema_and_type_roundtrip` | 缺work_called或用0代替bool必须拒绝；内存序列化保留False与null区别 |
| RC08 `handoff_exception_conservative_state` | controller已移交后发生未分类异常；无充分证据时工作null，保留原错误规则/阶段 |

八项人工检查拟在本机Windows Python中单次执行，总墙钟≤30 s、每项≤2 s，首个非预期失败即停。可用审计钩子拒绝检查进程中的子进程、网络、文件写入与目录变更。已有冻结证据只读，新的检查记录与结果文件只能写到独立版本化本机文档路径。

RC04是人工绑定帧验证，不等于真实producer的bad_value场景已经跑通；真正第7项及后续24项仍留待全新Linux批次。八项检查也不能替代Windows入口十项检查、正式冻结审计或完整P3。不自动重跑此前任何已消耗批次。

## 📦 旧副本保留与后续版本绑定

本次故障涉及adapter/tests，而不是Windows启动器本身。当前Windows driver仍精确绑定旧Linux四文件，不能在这两份源码更新后继续用旧request执行。第一步修订期间不为了“让hash通过”修改driver中的冻结值，不把Windows新文件复制到已消耗的Linux目录。

本方案的第一步不修改PowerShell入口与Windows driver；它们保持原哈希。这意味着新adapter/tests通过内存检查后，仍只是未部署候选，现有执行链应继续拒绝其与旧绑定的差异，这是预期保护，不是允许绕过的障碍。

之后只有另行授权，才能集中完成一次有限的四文件路径、哈希与版本重绑定，范围应同时覆盖：adapter/tests中的本机人工根路径、driver常量及内嵌只读reader中的根路径、PowerShell中adapter路径、case12的路径、元数据大小/哈希、候选报告引用和全新运行证据目录。不能只改一个 `LINUX_ROOT` 而漏掉固定字符串。

未来候选Linux隔离根可为 `/home/zhj/.local/share/r1b_transport_return_contract_v1_20261016`。这是待审核候选，不是已确认不存在的目录；本文未查询、创建或冻结其就绪状态。后续清单必须确认其全新、固定四文件及完整哈希、空fixtures和无evidence，并保留两端角色绑定，不恢复“Windows和Linux必然自动同步”的假设。若该路径已存在，则停止，不自动换名。

旧根 `/home/zhj/.local/share/r1b_transport_v2_once_20261016` 及Windows旧运行目录保持原样。不得为准备新测试而删除旧残留，不得引用本机长期备份的可能存在来证明可以清理服务器或本机证据。

## 📍 验收标准、授权门与止损

| 阶段 | 完成条件 | 此方案是否已授权执行 |
| --- | --- | --- |
| 草案审核 | 接受三值合同、断言和两阶段范围 | 当前待确认 |
| 本机implementation-only | 仅两文件修订；静态审查；一次八项内存检查 | 否 |
| 独立冻结/缺口复核 | 核验新证据、未改范围、未知状态与首错保真 | 否 |
| 路径/哈希绑定收尾 | 另行冻结新四文件与候选版本 | 否 |
| 新副本准备与就绪检查 | 明确新路径和完整清单，仍不运行 | 否 |
| 新24项request与执行 | 先创建待授权request，再明确授权完整SHA256 | 否 |
| 全批次后冻结与P3 | 按实际完整结果独立审查 | 否 |

第一步实施止损：一次两文件修订、一次静态门、一次八项内存批次。静态门核对必需字段、类型/未知语义、controller/helper规则保持、受信帧不放宽、原24名称和预算不变、bootstrap/PROGRAM字节不变、无默认执行及无额外文件。发现需要修改第三实现文件、增加真实I/O或扩展扫描时停止并报告，不逐点扩大范围。

静态或人工门失败即保存版本化结果，不自动修复重跑。所有门通过时，也只允许声称“本机返回合同候选通过有限人工验证”，不能声称真实Linux第7项、原24项、P3或研究preflight通过。

建议用户审核后，下一条授权仅覆盖“本机adapter/tests限定修订＋静态审查＋一次八项内存人工检查；不调用WSL、不准备副本、不改driver/PowerShell、不运行原24项”。此文字是建议授权范围，本次没有据此采取实施行动。

## 🔗 本次实际交付

本次只新增本文与SHA256清单；读取既有原因/冻结材料和相关源码，使用文档写作技能的决策结构、三值表与有界流程图明确已知、未知和后续门控。没有引用外部研究结论，也没有新增环境库存或研究任务。

源码修改、项目模块导入、测试/人工检查、WSL/服务器调用、副本准备/复制、执行request创建、授权回执/runtime/launcher生成、GPU操作和清理均为0。本文不修复 `CASE07-RETURN-01` 或 `CASE07-ASSERT-02`，仅给出待审核的有限修订合同。
