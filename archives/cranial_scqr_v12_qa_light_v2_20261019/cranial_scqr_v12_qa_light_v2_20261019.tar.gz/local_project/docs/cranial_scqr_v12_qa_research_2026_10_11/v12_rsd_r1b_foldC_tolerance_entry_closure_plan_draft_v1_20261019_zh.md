# R1-B Fold C：再现容差附件与入口兼容性合并收尾方案 v1

_2026-10-19，Asia/Shanghai｜仅起草、待确认｜不实施、不连接服务器、不重复 GPU preflight_

---

## 📋 1. 决策摘要与当前权限

建议一次性完成两个明确缺口：确认保守的 native 指标精确再现政策；使真实单折入口正确读取已经通过并正式冻结的 v7 preflight 证据链。收尾不改变研究问题、模型权重、干预出口、数据划分或指标，不建设新的通用库存、传输、监控或审计框架。

本方案状态为 `DRAFT_AWAITING_USER_CONFIRMATION`，不是 execution request，也不是 implementation-only 授权。当前仅新增本方案、容差 JSON 草案和两者的 SHA256 侧车；不创建授权回执、运行时配置、launcher 或 tmux，不读取真实 NPZ/STL、checkpoint 字节或病例 manifest，不调用 GPU。

| 决策项 | 本草案建议 | 当前状态 |
|---|---|---|
| native 再现政策 | 14 字段零松弛，身份及 flags 精确一致 | 待确认 |
| 证据读取适配 | 绑定 v7 原始分文件证据，不伪造旧格式回执 | 待实施授权 |
| 科研与原指标代码 | 保持字节身份不变 | 禁止修改 |
| 人工 GPU preflight | 保留现有 PASS，不安排重复执行 | 已正式冻结 |
| Fold C 真实干预 | 105 病例、315 次 forward | 未授权执行 |
| Fold D／合并统计 | 不纳入本次收尾或 request | 锁定 |

本方案采用 markdown-mermaid-writing 的决策记录结构；下图只描述授权依赖，不授予下一阶段权限。

```mermaid
flowchart TB
    accTitle: Fold C Minimal Closure Gates
    accDescr: 容差政策先确认，入口只做兼容性适配；人工验证与P3通过后才创建待授权request，真实执行另行授权，不重复GPU preflight。
    confirm_policy["确认零松弛容差政策"] --> authorize_impl["单独授权最小入口适配"]
    frozen_preflight["保留已冻结 v7 证据"] --> authorize_impl
    authorize_impl --> cpu_checks["一次限定人工 CPU 验证"]
    cpu_checks --> review_p3{"合同与 P3 齐全？"}
    review_p3 -->|否| stop_now(["停止并冻结具体缺口"])
    review_p3 -->|是| pending_request["创建 Fold C 待授权 request"]
    pending_request --> separate_auth(["等待完整哈希单独执行授权"])
```

## 🔗 2. 已冻结依据与证据边界

以下对象均已在上一轮本机只读核对中绑定，本次起草不把历史核验冒充实时服务器就绪检查。

| 对象 | 完整 SHA256 |
|---|---|
| 已确认 R1-B 协议 v1 | `30eeb37fcc6e0172849c5dd4a5a457180d59b9cc0e521a9234b81158bc88b035` |
| Fold C 本机就绪核对记录 | `11c3516d64b41cb1d870a39a31c11fec4922559c832435a0544688e522a44462` |
| v7 preflight request | `9b845598585aa594e80e2cf087b4ce41b7069e32bbc844f4da16f0e72719d1a9` |
| 正式 post-preflight freeze audit | `3163a04f3f1541c19e1e606bd33aa4d4cfac4285e7da9d7e4ec30fc2fbb81cac` |
| 原真实单折 runner | `8423a8496ec26810a1503443aaf26e66b2d3d042b185447c201284612afb34e0` |
| 原真实单折 contract | `ba5379efc48aa9bf420041e196e18ed6c322491cd3b176e07d5199c12f5230e0` |

v7 正式冻结支持：两个人工初始化模型、8 次出口调用、8 次完整 forward；11 项规定 tensor 对比精确一致；state／RNG／恢复诊断不变；严格确定性及 TF32 关闭；峰值 allocated 835195904 bytes、reserved 859832320 bytes。它没有加载真实 checkpoint，不能证明训练权重下的 native 指标再现，更不构成临床安全或正式 gate 通过。

当前冻结身份为 `shu-common-25721452-notebook-hwq6lx-0`，GPU UUID 为 `GPU-34a1b996-2bd7-88e6-9dca-164b718caea6`。后续执行前仍需只读重验，身份变化不能直接改期望值后复用授权。历史正式 gate 保持 `NOT_ADJUDICATED_HISTORICAL_NUMERICAL_EVIDENCE_GAP`，classification 为 null。

## 📊 3. 容差附件：零松弛准入政策

### 3.1 为什么不直接填写一个小的非零数

现有证据不足以给出历史真实指标的误差上界。用 fake fixture 的 0.001、科研效应阈值 0.10 mm、FP32 的名义精度，或人工输出相等，来推导历史再现容差，都缺少本项目依据。也不能先运行新 Fold C，再按偏差倒推容差。

本草案选择 `STRICT_ZERO_SLACK_REPLAY_ADMISSION`：不是宣称零误差已得到经验验证，而是事前选择不接受任何非零连续偏差的保守准入规则。它可能因环境或旧参考序列化差异而停止真实运行；这是明确接受的限制，不能转化为失败后调宽的理由。

当前附件 `basis_scope=ARTIFICIAL_ONLY` 只说明不使用新 dev 输出制定政策；`basis_kind=PROPOSED_CONSERVATIVE_POLICY_NOT_EMPIRICAL_ERROR_BOUND` 明确否认已估计历史误差。本次没有执行人工验证，JSON 保持草案状态，不能直接交给生产入口当成已冻结附件。

### 3.2 完整逐字段草案

所有比较先要求两值有限。连续字段逐项使用原规则 `abs_difference <= atol + rtol * abs(reference)`，不舍入、不截断、不改参考 CSV 精度；此处两项均为 0。比较的是解析后的指标数值，不要求 CSV 文本字面相同，也不证明预测坐标逐点相同。

| 连续字段 | 单位 | atol | rtol |
|---|---|---:|---:|
| `implant_cd_l1_mm` | mm | 0 | 0 |
| `implant_pred_to_ref_mean_mm` | mm | 0 | 0 |
| `implant_ref_to_pred_mean_mm` | mm | 0 | 0 |
| `implant_hd95_mm` | mm | 0 | 0 |
| `implant_nsd_at_1mm` | 比例 | 0 | 0 |
| `final_cd_l1_mm` | mm | 0 | 0 |
| `final_hd95_mm` | mm | 0 | 0 |
| `final_nsd_at_1mm` | 比例 | 0 | 0 |
| `rim_gt_rim_to_pred_mean_mm` | mm | 0 | 0 |
| `rim_gt_rim_to_pred_p95_mm` | mm | 0 | 0 |
| `rim_contact_cd_l1_mm` | mm | 0 | 0 |
| `rim_contact_hd95_mm` | mm | 0 | 0 |
| `rim_contact_precision` | 比例 | 0 | 0 |
| `rim_contact_recall` | 比例 | 0 | 0 |

身份字段 `case_id/source_skull_id/skull_id/defect_type/fold/seed` 按原合同精确一致。`rim_reference_rim_points/rim_predicted_rim_points/zero_contact_2mm/disaster` 同样精确，不受连续容差豁免。原 disaster 定义、50.0 严格大于边界及空接触停止政策不改变。

任何不一致保留 case、condition、字段、原参考值、观测值、绝对差和冻结阈值，然后停止该 fold；未完成的 fold 不能汇总成全量结果，不删 case、不补跑、不 resume，也不自动运行 Fold D。未来即使研究如何改善跨环境复现，也不能根据这批新 dev 偏差为同一尝试重新选择容差。

### 3.3 从草案到可使用附件

用户须明确确认本方案和 JSON 的完整哈希，包含“零松弛可能导致真实运行提前停止”的取舍。后续限定人工检查通过后，再新增独立已确认附件及确认回执，记录原草案 SHA256、确认依据和验证证据；草案原字节保持不变。不得仅把本草案 status 改成 `FROZEN_CONFIRMED_BEFORE_DEV`，也不得在没有用户确认时自签确认。

## ⚙️ 4. 真实入口的最小兼容性修订

### 4.1 读取真实 v7 证据链，而非补造旧回执

旧 runner 的 `text_execution_preconditions` 要求 completion 回执直接有 `resource`，并把同一实现映射用于原 P3、preflight 和当前入口。v7 completion 没有 `resource`：资源信息位于原 request 与 `environment_input_identity.json`；新入口也会有自己的新文件 hash。不能删掉资源检查、修改旧结果，或构造一个伪称原始的旧格式 PASS 回执来绕过差异。

拟在专用入口中显式验证以下有向绑定：

1. 当前 Fold C request 固定引用 v7 原 request 和正式 freeze audit 的完整 hash；原 request 已消耗，仅作为不可变父证据，不获得新执行权。
2. 使用正式 audit 的精确 16 文件清单及大小/hash，核对原 `files.sha256` 和原结果集合。总结果 3052912 bytes；单文件上限 4 MiB、结果集合 16 MiB、最多 64 文件沿用已获验证的有界读取，不扩展到整个依赖环境。
3. 对 completion、environment_input_identity、equality_scalar_state、numerical_memory 及其余被清单绑定的文件验证身份／计数／状态；要求 audit 为正式 PASS，completion 为 `PASS_SYNTHETIC_R1B_ZERO_UPDATE`，2 模型、8＋8 次调用和禁止计数符合冻结合同。
4. 从 v7 request 的 `resource_binding` 与环境记录取出准确字段，通过明确字段映射对照 Fold C request；不将新旧异构 JSON 整体做不可能成立的相等比较，不静默忽略关键字段。
5. 将原 v7 `implementation_sha256` 九文件映射与原 P3 的原映射精确对照。当前执行所依赖的六个共享科研文件继续逐文件字节一致；新 contract／runner／tests 使用独立版本化 `entry_bindings` 和新 P3，不伪称它们参加过旧 GPU preflight。
6. 正式 freeze audit 若仅在本机，未来必须作为明确运输文件放入项目内并核验，不假定它已自动存在服务器；本次不上传、不运输、不部署。

六个共享科研文件为 `models/AdaPoinTr.py`、`models/cranial_scqr/query_conditioning.py`、`models/cranial_scqr/rsd_query_bypass.py`、原 QA-1 evaluator、原 v1.1 evaluator、`utils/skullfix_metrics.py`。两份旧入口及旧 tests 保留为历史身份；不得把它们从原证据映射中抹去以适配新 P3。

### 4.2 当前 provider 与数值合同

只绑定现有 PointNet2 隔离 provider：

```text
/home/jovyan/adapointr_work/PoinTr/third_party/r1b_pointnet2_cp310_b5ceb6d_v2_20261018/provider
```

wheel SHA256=`530496a0d1d5dea6151a466b7c0874632322223308a7016910fb1bfbaaaab1e5`；native `.so` SHA256=`e70d00108bacba4a905dc011f4b8c4868f06ec2d44d8e322148e2e452578fbb5`。包装器、项目 adapter、其余已冻结 provider 文件的精确清单直接继承 v7 request，禁止仅检验目录存在就放行。

在未来单次真实执行启动前按既有路径注入合同使用该 provider，确认实际模块来源与编译后端、`using_fallback=false`；不得靠隐含 PYTHONPATH、自动 fallback 或 JIT 补编译。沿用 v7 已验证的固定解释器／项目／provider 加载次序，不升级 PyTorch，不重装 wheel、Chamfer 或其他依赖。

保留 torch 2.4.1+cu118、CUDA 11.8、cuDNN 90100、NumPy 2.2.6、SciPy 1.15.3 及 request 中精确 hash。确定性 true、warn_only false、cuDNN deterministic true、benchmark false、matmul/cuDNN TF32 false、FP32 highest、CUBLAS `:4096:8`、OMP/MKL/torch threads 各 1 均须记录实值并断言。nvidia-smi 24564 MiB 与 torch 25261047808 bytes 分别核验，禁止再次要求两种统计口径相等。

### 4.3 冻结修改面

后续 implementation-only 最多新增三份本机候选源码，放在新的 `server_overlays/r1b_foldC_entry_v2_20261019/tools/`：

- `cranial_scqr_v12_rsd_r1b_contract_v2.py`：只增加版本化证据链、容差确认及新旧绑定分域合同
- `run_cranial_scqr_v12_rsd_r1b_v2.py`：只适配前提检查、固定 provider／启动及失败记录接口
- `test_cranial_scqr_v12_rsd_r1b_entry_v2.py`：限定人工回归；不创建通用 driver 或 supervisor

三文件名字为拟定安装映射，不是当前已创建文件。确认附件、测试日志及 P3 属于明确的证据产物，不能借其名义增加其他可执行工具。实现发现必须改变三条件科学计算、checkpoint 加载语义、指标、RNG 或数据流时，立即列出具体差异并停止，不滚动扩张本方案。

`extra_geometry`、state hash、candidate-isolated RNG 流、条件顺序、GT 后置、逐 case 计数、指标与差值计算须以 AST／hash 或明确允许的接口差异清单检查。新入口不是旧 preflight 覆盖的全部新程序；CPU 验证只证明接口，真实权重/数据是否兼容仍由未来单次执行中的前置检查和 fail-stop 合同判断。若改变 forward 语义，则超出本方案，不能沿用“不重复 preflight”作为跳过验证的理由。

## 🎯 5. 不变的真实科研合同与启动预算草案

Fold C seed0，原 allowlist 顺序，21 source × 5 defect，固定 `LS_native → LSQ_native → LSQ_query_off`。LSQ native/off 共享同一实例及权重；2 次 checkpoint 反序列化、105 次 NPZ open、partial/implant/gt 各 105 次读取、315 次 forward attempts/completions 为成功完整目标。失败时只是上限，不能为凑计数继续。

GT 只在同病例三次成功 forward 后读取；不访问另一 fold、train、confirmation20、official test、old monitor、MUG、SkullFix、秘密或其他未授权 payload。保留路径越界、秘密、链接检查，不扫描整个环境找可放行对象。checkpoint 字节校验与反序列化分开计数，沿用四次受记账的 hash 验证；不得因 helper 重复读取实际造成更多次数却仍报告四次。

以下是拟议资源合同，须连同未来 request 审核，不是当前执行权限，也不是从人工耗时推出的性能预测：

| 约束 | 拟议固定值 | 依据及限制 |
|---|---|---|
| 单 fold 总 wall-time | 7200 秒 | 完整加载、hash、315 forward 与 CPU 指标的保守运维上限；不是耗时估计 |
| 外部终止宽限 | 5 秒 | 超时终止所属进程，不转 retry/resume |
| allocated／reserved 峰值 | 分别 ≤20000 MiB | 继承已冻结显存预算，不宣称 cgroup 硬隔离 |
| 启动显存／进程 | free ≥22000 MiB；无其他 compute PID | 执行前现场核对 |
| 启动可用磁盘 | ≥2 GiB | 不因旧记录推定仍足够 |
| 标量产物／主日志 | 16 MiB／32 MiB | 保留原协议上限，不截断字段满足上限 |
| 监测 | 启动、逐 case、退出及外部超时 | 使用现有进程/超时机制，不新建监测框架 |

显存监测与分配器统计不能保证瞬时硬限制，超限检测可能晚于分配；明确披露该限制。wall-time 由既有外部 timeout 执行，避免只在 forward 前检查导致 CPU 指标或启动卡住无人终止。失败尽力保存已有结果，硬终止来不及写完整回执时保留原日志/退出证据，不能伪造完整成功。

未来唯一 run/session/control/result 路径由新 request 精确冻结。必须先验证路径及所有目标不存在，再不覆盖创建日志和 runtime 父目录；授权回执 → hash → 单向绑定 runtime → 单次 launcher。沿用 raw-byte 捕获、`wsl --exec`、命令行长度上限、显式退出码与 PID 落盘合同，不修改原传输框架。request 创建时仍不材料化这些执行内容。

## 🔍 6. 一次限定人工验证与 P3 完成标准

未来 implementation-only 授权后，先做 S0/S1：UTF-8、语法、无顶层 torch/CUDA/真实路径 I/O、只改约定三文件、共享科研字节与关键 AST 不变、证据映射无循环和弱化守卫。失败即停，不自动修复或重跑。

通过后拟执行唯一一次 24 项本机标准库／内存人工契约检查，固定现有 `C:/Program Files/Python310/python.exe -B`、CUDA 不可见、总 wall-time 120 秒、证据输出合计 ≤8 MiB；不调用 WSL、不安装依赖、不构造真实模型。检查用人工字节/JSON/假 reader，绝不把 fixture 设置成可访问真实数据路径。以下编号为固定范围，不在失败后追加检查重跑：

| 编号 | 人工检查范围 |
|---|---|
| T01–T04 | 容差草案/未确认拒绝；14 字段精确集合；NaN/Inf/负值/布尔参数拒绝；零松弛接受相同数值并拒绝最小非零差 |
| T05–T08 | 身份/count/flag 不受容差豁免；有限值 float JSON/CSV 往返不人为舍入；空接触与 50.0 严格边界；失败字段诊断及不继续合同 |
| T09–T12 | v7 正常分文件链；任一 hash/size/清单篡改拒绝；缺失/额外/重复项拒绝；伪造/非正式 PASS audit 拒绝 |
| T13–T16 | 旧九文件映射精确验证；六共享科研文件漂移拒绝；新三文件 entry/P3 单独绑定；资源字段映射及两种显存口径不混用 |
| T17–T20 | provider 精确来源映射与 fallback 拒绝；未经授权入口不触及 payload/checkpoint；继承人工 one-case 状态机执行到 105/315 并拒绝越界；GT 读取必须后置 |
| T21–T24 | 原候选隔离 RNG 调用序列/保存恢复接口静态一致；raw-byte/参数/退出码及 PID 字符串合同；先建父目录和目标拒绝覆盖；超时/资源超限/失败无重试及无下一 fold |

这些是纯人工接口和静态合同检查，不证明真实 metric 浮点路径、CUDA forward、真实 checkpoint 或全部 OS I/O 正确。原安装前后 25 项 CPU 测试和 v7 76 项 CPU 测试作为已冻结历史证据引用，不重新执行、不冒充新入口已完成端到端 GPU 试验。

新 P3 至少包含：父源码 hash、精确三文件 hash、共享六文件身份、原九文件映射、新证据链附件、24 项实际计数/退出码/日志 hash、AST 允许差异、容差确认回执和局限。不得只将 CPU PASS 当成完整 P3；尚缺服务器存在性/当前身份/最终路径时，明确列缺口，不写 `READY`。

收尾预算为一次三文件实现、一次 S0/S1、一次 24 项人工检查及一次证据/P3汇总；任一步失败保存证据并停止。新缺口必须具体解释为何影响这一次 Fold C，不因检查发现无关问题就扩展框架或开启新通用审计链。

## 🔐 7. 验收、授权与停止点

可以创建 Fold C 待授权 request 的必要条件：用户确认容差政策及附件字节；限定实现/人工检查/P3齐全；v7 原冻结链可读取且 hash 正确；当前资源/固定 provider/六共享科研文件身份可核验；精确路径与预算已冻结。需要服务器文本补证时，另获一次固定清单的只读权限，范围仅限这些已命名文件，不打开病例 manifest、真实 payload 或 checkpoint。此项不等于部署授权。

满足条件后只创建一个版本化 request，保持 `AWAITING_EXPLICIT_USER_AUTHORIZATION`，报告完整 SHA256。安装新入口与真实执行的权限应在后续授权中明确，不能由本草案确认、容差确认或本机 P3 推导出来。执行结束后仍需单独正式 post-diagnostic freeze audit，再解读研究结果。

当前请审核两项核心取舍：是否接受 14 字段零松弛且不按新 dev 偏差调宽；是否接受三文件最小入口适配与一次限定人工检查范围。即使确认本方案，也不自动开始实施；用户须另外明确 implementation-only 权限。本次未创建真实 request，不自动安排其他病例筛选、参数扫描、训练、BNCal、gate、bootstrap、清理或 Git 操作。

## 📚 8. 本机来源与版本管理

项目根为 `E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution`，服务器项目根为 `/home/jovyan/adapointr_work/PoinTr`，两者不自动同步。所有下列本机链接均为真实证据路径；本文件中的候选文件名和未来执行路径不是已经创建或上传的事实。

- [Fold C 只读就绪核对](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_foldC_protocol_frozen_evidence_readonly_review_v1_20261019.json)
- [已确认父协议原文](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_query_off_protocol_draft_v1_zh.md)
- [正式 preflight 冻结审计](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_minimal_v7_formal_post_preflight_freeze_audit_v1_20261019.json)
- [v7 原 request](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_gpu_zero_update_preflight_execution_request_minimal_v7_20261018.json)
- [本次容差 JSON 草案](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_native_replay_tolerance_attachment_draft_v1_20261019.json)

不改父协议/旧 CSV/旧回执/已消耗 request。确认和后续修订均新增版本；SHA256 侧车只列本次两份草案，不包含自身。本次没有外部文献主张，也没有本机长期备份/恢复验证结论；不据此获得任何服务器删除权。
