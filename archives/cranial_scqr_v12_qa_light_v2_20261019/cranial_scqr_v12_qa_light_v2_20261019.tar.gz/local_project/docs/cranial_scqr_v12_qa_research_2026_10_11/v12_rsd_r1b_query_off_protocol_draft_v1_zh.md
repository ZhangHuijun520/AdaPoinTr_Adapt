# Cranial-SCQR v1.2-RSD：R1-B query-off 诊断子协议草案 v1

_2026-10-11｜固定权重的有限干预设计｜仅起草，待确认，不直接执行_

| 字段 | 当前值 |
|---|---|
| 文档状态 | DRAFT_AWAITING_USER_CONFIRMATION |
| 起草授权 | 用户授权“仅起草 R1-B query-off 诊断子协议，不直接执行” |
| implementation_authorized | false |
| execution_authorized | false |
| 正式 gate | NOT_ADJUDICATED_HISTORICAL_NUMERICAL_EVIDENCE_GAP |
| 正式分类／自动下一阶段 | null／false |

---

## 📋 1. 背景、设计选择与权限

[已确认后续计划](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/cranial_scqr_v12_qa_followup_formal_experiment_plan_zh_v1.md)第 5 节规定三条件与预算；[R0＋R1-A 冻结报告](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r0_r1a_audit_v1_20261011/r0_r1a_readonly_audit_report_zh_v1.md)确认 210 配对病例自洽，四个 LSQ 新事件均由接触 HD95>50 mm 触发，core 有限、zero-contact=0。RimCover 与 contact HD95 的对象不同，旧 CSV 不足以给出两方向接触距离或空间根因。

选择固定 checkpoint、单一残差出口旁路，而非重训、参数 sweep 或少数病例主结果。全量 210 case 为主证据；目标病例/对照/反向尾部只作事后诊断。协议确认后仍可决定止损，R1-B 不是强制阶段。

本次仅本机文档：核对计划、审计产物、本机代码及旧 request 文本，写草案和非执行来源索引。没有连接服务器、实施代码、运行实验契约测试/P3、读取 NPZ/STL/checkpoint、构造模型、访问 GPU、preflight、推理、训练或 BNCal；没有创建 execution request、授权回执、runtime、launcher 或 tmux。未来步骤不是当前权限。

## 🎯 2. 研究问题、三条件与干预定义

### 2.1 固定条件与估计对象

| 条件标识 | 权重 | Forward | 角色 |
|---|---|---|---|
| LS_native | 对应 fold 的 LS BNCal | 原生无 Query 条件化 | 异训练来源参考 |
| LSQ_native | 对应 fold 的 LSQ BNCal | 原生残差开启 | 干预基准 |
| LSQ_query_off | 与 LSQ_native 同实例、同权重 | 仅旁路 residual 加法 | 即时干预 |

核心逐病例差值为 **LSQ_query_off−LSQ_native**，估计“固定 LSQ 权重、既有 BN buffers 与这些输入下去除残差的即时效应”。off 不是 LS，不是“训练时未使用 Query”的反事实；LS_native 只作不同训练权重参考。不能追溯修复 LS Fold C 训练/BNCal 数值证据缺口。

首轮仅连续差值与原 flags 迁移，不新增“有效／恢复／几乎无影响／主导”分类阈值，不做 CI、p 值、bootstrap、等效检验或临床安全推断。如需干预统计分析，另立 CPU 分析协议/request，不直接把新条件塞入原 QA-1 程序。

### 2.2 出口旁路，不改变模块与权重

本机 [query_conditioning.py](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/work/PoinTr_mamba_v12_dev/models/cranial_scqr/query_conditioning.py) 文本结构为 queries+residual，其中 residual=alpha_q×warmup×update；[AdaPoinTr.py](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/work/PoinTr_mamba_v12_dev/models/AdaPoinTr.py) 的 _apply_scqr_query 调用 conditioner 后返回 conditioned.queries。本机 SHA256 与 R0/R1-A 历史绑定一致，但本次未重读服务器，不能认证当前服务器调用点。

拟显式 condition 合同：

- native 保留原生加法；off 仍计算原 conditioner、attention、potential residual，但向下游返回加法前 query。
- 不改 alpha_q、beta、warmup、state_dict；不删除/重新初始化模块，不改变 Local/SCF、proxy、head、采样/排序或后处理。
- LSQ_native/off 同模型实例，不重新加载、不补 BNCal、不改变 inference epoch。epoch/warmup 必须从实际历史 evaluator 语义核对并冻结。
- 不用全局 monkey-patch；显式 condition 只控制加法出口，异常也恢复 native 默认状态。分别记录 potential residual 与 applied residual。
- v1.1 与原 QA-1 native 路径保持不变。若共同模型代码需最小分派，须单独 implementation-only 明确授权，并验证默认路径输出和 state_dict schema 不变。
- 未来只读 pre-implementation 查清全部出口、每 forward 调用次数和旁路覆盖范围；若不是单一已知出口，停止修订，不扩大干预。

## 🔗 3. 父证据、checkpoint 与数据绑定

### 3.1 父证据及数值证据限制

| 对象 | SHA256 |
|---|---|
| 后续正式计划 v1 | a656448a7323f82415babc3d65150befb890f742653bf499df811b31a306a870 |
| R0＋R1-A 报告 v1 | 3d3dc2175fe5722c309c949222347052ff5f8374544fcbb73b44578a3ca34af3 |
| 210-case ledger | 81c5c1d5468ee9f632bd99666e9d4cc4c5e746bdaa49215ad2da6d611414acc3 |
| 冻结匹配对照 | 9f0c36a73a75e3a4e06344b2f0adbafc3fd3e0be0c5ab8f82ffba046fd2753ac |
| manifest 元数据 | f1f8cae47ed7d5529dc2ca244179cedddbc039981cdc0ff24b25a5c81ad30538 |

正式 gate 状态和分类不变，NO_ADVANCE_RECOMMENDATION 仍为研究治理建议，不是五类正式分类。单个网络的 off/native 干预减少了跨训练权重比较的解释负担，但不证明历史数值条件一致，也不产生训练 seed 变异证据。

### 3.2 四个冻结 BNCal checkpoint

下表来自哈希已核验的本机旧 development request 文本。完整相对服务器路径、旧 request SHA256、BNCal receipt、data scope 在同目录非执行来源索引 JSON 中保存。本次未读 checkpoint 字节；历史绑定不等于当前字节校验。

| checkpoint/run | 历史 bytes | 历史 SHA256 |
|---|---:|---|
| LS_foldC_seed0 | 382569207 | 47d21ab4e5e577515eec314b21695166c5af0fa3c02ed29c9756fe85f80cbb7e |
| LS_foldD_seed0 | 382569207 | bdc2bf228e9aa57bcad58f2aecf06481aab367f308a6cae9629ba91462ca9c57 |
| LSQ_foldC_seed0 | 388541062 | 5c2f39f029b019843ae403103933d93b6061f127ac1a95d355940e8eb6a3befa |
| LSQ_foldD_seed0 | 388541062 | 71da7f3b68c3dc5b97aba4530480cc9e7622b75e74b1802f2200dce99bf788ad |

将来仅在单独允许的阶段重新核验 bytes/SHA256，严格加载 missing/unexpected keys=0。checkpoint 字节 hash、参数 state hash、buffer state hash 分开记录，不能用 torch.save 文件差异推断权重差异。

### 3.3 allowlist 与禁止分区

仅 C/D seed0 held-out development：各 105 case、21 source、每 source 五 defect。C allowlist SHA256=0bc9286bea354c60870818e47207a9da7f156704557f366ef27847d589f5c0b0；D=7afc9edc6654891cc8593ab2ce172657e1227e4583ed3281b159ab3ae2be68ac。顺序为各原 allowlist 精确顺序，键为 (fold,case_id,seed)。

服务器项目根 /home/jovyan/adapointr_work/PoinTr，数据根 /home/jovyan/datasets/SkullBreakPC_out8192。official_split=train、monitor absent、精确 allowlist、安全 point_path 是合同；legacy gate_split 不替代当前 dev 角色。不得将 E: 转成猜测 Linux 路径，文档与服务器不自动同步。

禁止 train、另一 fold、confirmation20、official test、old monitor、MUG、SkullFix 或其他未授权 payload；路径解析必须拒绝目录/软链接逃逸。指标 GT 只能来自该 case 的授权 NPZ，不通过其他路径补读。

## ⚙️ 4. 单次执行预算与 GT 后置的数据流

### 4.1 未来预算，不是当前执行权限

| 计数 | 单 fold | C＋D 合计 |
|---|---:|---:|
| 独特 case | 105 | 210 |
| model forward | 315 | 630 |
| NPZ 显式 open | 105 | 210 |
| partial／implant／gt 各 member read | 各 105 | 各 210 |
| checkpoint 反序列化 | 2 | 4 |
| optimizer steps／参数或 buffer 更新 | 0 | 0 |
| BNCal／训练 checkpoint write | 0 | 0 |

成功完成必须恰达非零目标；失败时只作为不可超限的上限，不补跑。每 fold 一进程，LS 与 LSQ 各加载一次；off 重用 LSQ，不额外 load。checkpoint hash 的字节读取另计，不能和反序列化混记。

两个 fold 分别独立单次 request、完整 SHA256 授权和 post-audit；C 失败不自动 D，C 通过也不授权 D。同时驻留两模型的显存能力在独立人工 GPU preflight 验证；若必须增加 load/open 或改成多遍访问，先修订协议。

### 4.2 固定 case 流程

```mermaid
flowchart TB
    accTitle: Frozen Query Intervention Data Flow
    accDescr: 单次读取 partial，依次完成三个条件 forward 后才读取 GT 指标成员；再现或状态失败立即停止，不自动重试。
    open_case["打开唯一 allowlisted NPZ"] --> partial_only["仅读取 partial 输入"]
    partial_only --> three_forward["LS native 再 LSQ native 再 off"]
    three_forward --> metric_targets["三 forward 后读 implant 与 gt"]
    metric_targets --> compute_metrics["计算指标与旁路诊断"]
    compute_metrics --> replay_check{"native 再现及状态核验"}
    replay_check -->|通过| save_case["保存标量并释放 case"]
    replay_check -->|失败| freeze_failure(["冻结失败并立即停止"])
```

每 case 保持一个 NPZ handle：先读取/copy partial，其余 members 不读；三个 forward 全部完成且输出有限后，再从同一 handle 读取 implant/gt 各一次，计算指标后关闭。三条件相同 partial shape/dtype/内容、centroid/scale；不全 fold cache、不多 worker DataLoader、不增强/重采样。

model API 仅 partial 和事前冻结 condition/epoch。GT/reference rim/diagnostic labels 不进入 attention/query、排序、采样、阈值或 forward。不以“只用于指标”为理由先读取 GT。输出在内存中保留到三 forward 后指标完成，随后释放；首轮不保存预测坐标。

### 4.3 数值与 RNG 合同

未来 eval/no_grad、batch size=1、FP32；无 AMP/TF32/compile/量化。deterministic_algorithms=true、warn_only=false、cuDNN deterministic=true、benchmark=false、matmul/cuDNN allow_tf32=false、CUBLAS_WORKSPACE_CONFIG=:4096:8。开始/结束保存并断言实值，不能只看 YAML。不支持严格确定性的 kernel 直接停止，不换 warn-only/fallback。

RNG 首先保留历史 native 的 case 间推进语义。每 case 三条件采用相同 pre-forward RNG 快照，条件隔离使 off 不污染后续 native 流；Python、NumPy、torch CPU/CUDA RNG 和扩展内部随机性在最终合同固定。不以“每 case reseed”替代未核对的历史流程。实施前若不能明确定义原采样/RNG 顺序，停止，而非运行 dev 找容差。

## 📊 5. 指标与最小 instrumentation

### 5.1 原指标与事件规则保持

逐 case/condition 保存原 QA-1 全部 core/surface/RimCover/contact/zero-contact/disaster 数值和身份。保持 mm 恢复、FP64 指标路径及原 percentile 算法，不把两方向合并 P95 改成两方向 P95 最大值。

disaster 为五 core 任一 nonfinite，或 finite contact HD95 严格>50.0；zero-contact 另按 predicted footprint points==0 记录。不增加其他大小触发，不执行原 gate，也不添加新安全 PASS。

新增两方向 contact NN mean/P95：

- predicted footprint→reference footprint
- reference footprint→predicted footprint

两个 footprint 是 defective partial 上到 GT/predicted implant≤2 mm 的点索引集；intersection 用同一 partial 索引交集，不另加 tolerance。记录两 counts、intersection、precision/recall、原拼接 HD95、距 50 mm 原值距离。方向 P95 不相加/取最大冒充旧指标；数量不同时拼接 P95 的方向权重依赖点数，必须显示 counts。首轮不导出全距离数组/masks/点坐标，不绘几何图。

### 5.2 核心标量定义

| 层级 | 输出 | 计算对象 |
|---|---|---|
| Query | alpha_q、warmup、query/potential/applied residual RMS、relative RMS | 加法前 query 与对应出口 residual |
| Attention | entropy、effective proxy count、max weight 的 case 均值 | 每 query 的 proxy 分布 |
| Coarse | RimCover-P95、2 mm 支持率、centroid distance、radius ratio | coarse 与 post-forward GT 标签 |
| Dense/contact | 原指标、双方向 mean/P95/counts | dense implant 与 partial footprints |

1. Query RMS=sqrt(mean(x²))，FP32，对当前 B×N_query×D 全元素均值。relative=RMS(potential residual)/max(RMS(pre-add query),1e−12)。off applied RMS=0、potential 按原 conditioner 保留。LS 无此模块，填 null＋not_applicable，不能填零冒充测量。
2. Attention 每 query H=−Σa log(a)，自然对数、a=0 项=0，不用新增 eps 修改分布。分别 mean(H)、mean(exp(H))、mean(max(a))，不可用 exp(mean(H)) 或全局最大值替代。归一化轴及 sum≈1 的数值容差在 CPU 合同固定；LS not_applicable。
3. Coarse 指标：reference_rim→coarse 距离 P95 及≤2 mm 比例；centroid 点均值，输出 ||centroid_coarse−centroid_GTimplant||；radius=sqrt(mean(||point−centroid||²))，输出 radius_coarse/radius_GTimplant。GT implant 为完整尺度参照，仅 post-forward world/mm FP64 计算；GT radius 非正/非有限停止，不用 eps 掩盖。
4. 字段 schema 包含 dtype、轴、单位、缺失原因、条件与版本。instrumentation 不改变 forward dtype 或原 metric 精度。

首轮不加入 Gini/top10% mass/query cosine/density CV/outlier ratio/normal/curvature，也不计算 GT-positive proxy attention mass。以后如加入只能是单独补充的 post-forward 探索性标签，不得影响 forward 或择优分析。

### 5.3 空接触与非有限的建议停止策略

旧空接触协议文字存在潜在歧义。本草案建议保留旧 flags，不给原 disaster 新加定义；空 footprint 时保存 zero-contact、disaster、contact 显式 NaN/missing_reason，标记 R1B_NONFINITE_CONTACT_OR_EMPTY_FOOTPRINT 后立即停止该 fold。不填零、不删 case 继续、不形成完整 fold 连续汇总。

这是诊断执行完整性失败，不是新安全分类。非有限预测/core/attention/instrumentation 同样停止，保存已得证据。该方案待用户确认及契约测试；若希望空接触后继续，必须另立有定义的缺失统计协议，不能实施时自行选策略。

## 🔍 6. Native 再现、容差与状态不变

### 6.1 原 native CSV 比对

两个 native 条件逐 case 对照 R1-A 绑定的四份 CSV：

- 身份、seed、point count、flags 必须精确相同；不能用连续容差豁免事件改变。
- 连续字段再现容差在任何新 dev 输出之前冻结，每字段 absolute/relative 数值及组合规则形成版本化附件；发现偏差后不得调宽。
- 本草案不伪称容差已验证，不借 0.10 mm 当再现误差。只用人工输入或另行授权 train-only 材料建立依据，不能以新 C/D dev 误差调参。
- 容差附件未冻结不得创建真实数据 request；若依据不足，保留未验证状态，不自动放行。
- 旧 CSV 无预测坐标，指标再现不证明逐点预测相同；直接 tensor 无副作用验证由人工契约/preflight 承担。

容差只是工程再现判据，不是机制/等效性/临床阈值。首轮干预差值不作“无影响／大效应”分类。

### 6.2 后续 CPU 人工契约与独立 GPU preflight

拟测试项（本次不运行）：

- condition 白名单与非法条件拒绝；off 只旁路目标出口，不改 Local/SCF/state_dict schema。
- native→off→native 恢复；零 residual 恒等；人工非零 residual 导致出口预期差异，不人为要求完整网络输出一定非零。
- native instrumentation on/off tensor 与参数/buffer 不变；临时诊断 tensor 不持久化为 buffer；异常恢复无跨 case 污染。
- fake NPZ 验证 partial 前置、三个 forward 后 GT member 读取；路径逃逸、计数超额、重复 case 拒绝。
- 50.0 等于不触发／大于触发，非有限与空 footprint 停止；两个方向 P95 与拼接 P95 不混淆。
- 容差缺失/未确认拒绝 request；只读旧 CSV；禁止 skip/resume/retry。
- 2 load/fold、1 NPZ open/case、3 forward/case、缓存释放及调用点次数可核验。
- CPU 不冒充 CUDA 全模型等价；独立人工 GPU preflight 固定 synthetic inputs/shape/seed、初始化、严格数值环境、精确计数及预算，另建 request 并授权。人工 preflight 不加载真实 checkpoint、不用真实 payload。

人工 GPU preflight 验证 native/off/native 恢复、instrumentation 无副作用、重复标量再现及两模型显存能力。具体人工 forward 次数与张量尺寸须在其 request 冻结；父真实数据 630-forward 预算不包含隐含人工试跑。

### 6.3 canonical state hash

严格加载后、fold 开始前和结束后分开 hash 参数/buffers；异常时尽可能保存 after。固定 key ASCII/字符串升序、UTF-8 名称及长度、dtype、shape、连续 CPU 原始字节、字节序和格式版本，测试 name/dtype/shape/value 变化可检测。不能用 torch.save 字节 hash 替代状态证明。

每 case 检查 eval、无 optimizer、BN counters/buffers 未更新；完整开始/结束 hash 必须相同。不能 reload 回旧状态后宣称“未更新”。更新发生即失败冻结，不继续推理、resume 或 BNCal。

## 📈 7. 全量描述、冻结展示与解释边界

case 配对为完整主证据；每 source 五 defect 等权平均、每 fold 21 source 等权平均。不把 210 case 当独立训练样本、五缺损当独立 bootstrap 单位。

未来每 fold 输出三条件逐 case、off−native 连续差值、全 source/defect 描述和 flag 四类迁移（both flag=0、native-only、off-only、both事件），zero-contact 独立列项。不以净事件数替代迁移，不自动跨 fold 分析、gate 或 CI。正式只读 post-diagnostic freeze audit 后再解读。

两个 fold 均通过后，如另行授权合并描述，pooled 固定 fold 各0.5 等权；统计/ bootstrap 再另立 CPU request。LS_native 的差值只作异权重参考，不称即时干预归因。

固定 14 个不同展示病例，不依据新 instrumentation/结果换人：

| fold | 类别 | source/defect |
|---|---|---|
| C | 新事件 | 025/random_2 |
| C | 对照 | 051/random_2；081/random_2 |
| D | 新事件 | 008/random_1；010/random_1；087/parietotemporal |
| D | 对照 | 004/random_1；095/random_1；044/random_1；037/random_1；005/parietotemporal；029/parietotemporal |
| D | 反向尾部 | 087/frontoorbital；087/random_1 |

对照沿用原 LS RimCover 距离规则；025、087 匹配距离较大，不能称解剖/临床严格匹配。14例为事后诊断清单，不估总体发生率。首轮无几何图；以后保存预测/masks/渲染需独立数据和存储权限，不能增加隐含 forwards。

| 观察 | 可支持的描述 | 不可支持 |
|---|---|---|
| rim 变差、异常/全局改善 | 固定权重即时 benefit–risk 权衡线索 | Query 是唯一根因 |
| 干预差值小 | 连续幅度及可检测限制 | Query 无作用或全由训练造成 |
| rim 与全局都变差 | 网络依赖 residual／可能分布偏移 | native 安全有效、可以晋级 |
| instrumentation 与指标不一致 | 检查调用点/测量/替代解释 | attention 图证明因果机制 |

attention concentration 和 residual RMS 不是归因；off 的 inference 分布偏移是限制，不通过额外 BNCal 消除后继续沿用本协议。不把 off 当临床模型、不保存其 checkpoint，不用结果反向挑结构。

## 💾 8. 产物、失败冻结与操作边界

未来每 fold 全新独立 run 目录，不覆盖任何旧日志/实验或本机审计。拟产物为 invocation、单向授权/runtime 绑定、315行条件-case CSV、105行干预配对CSV、source/defect描述、scalar instrumentation、native replay audit、counter/state/numerical-policy receipt、退出码/日志、bytes/SHA256 清单。不写模型 checkpoint、预测坐标、全 attention/features 或 NPZ 副本。

拟首轮每 fold 标量/分析产物上限16 MiB、日志32 MiB；不能截断结果或删字段满足上限。若实施前证明不够，版本化修订。GPU wall-time/显存上限、完整软件/扩展 hash、真实输出路径在人工 preflight 后冻结，不猜测历史剩余空间仍有效。

任一身份/hash错误、已存在输出目录、越权数据访问、counter超限、严格数值设置异常、非有限/空接触、native再现超容差、state改变、未知condition、OOM/异常或启动证据不完整均停止。保留已完成与失败case，不报全fold成功，不自动重试/resume/进入另一fold、训练/BNCal/其他分析。

未来执行遵守操作规范：先创建并验证日志/runtime父目录再重定向/上传；PowerShell 明确 exit $LASTEXITCODE；退出码0不能代替session/PID/日志/进程确认和最终freeze audit。材料化顺序为授权回执→其SHA256→runtime单向绑定→单次launcher，回执不反向绑定runtime。hostname/GPU UUID变化先resource-rebind，不复用旧授权。

本机 E:/ResearchBackups/AdaPoinTr 长期备份没有因本草案获得任何下载/核验认证；禁止推导服务器删除权。没有Git commit/tag/push 或第三方上传研究数据授权。

## 🔐 9. 分阶段门槛、待确认项与当前停止点

| 阶段 | 权限要求 | 当前状态 |
|---|---|---|
| 草案 | 仅起草 | 本次已授权 |
| 协议确认 | 完整SHA256明确确认 | 待确认 |
| 服务器pre-implementation | 仅只读代码/调用点/历史文本 | 未授权 |
| implementation-only＋CPU tests＋P3 | 新RSD专用适配独立授权 | 未授权 |
| 人工zero-update GPU preflight | 独立request完整SHA256授权 | 未授权 |
| native容差附件冻结 | 人工依据和用户确认 | 未完成 |
| C fold request创建 | 全前提通过＋仅创建权限 | 未授权 |
| C fold单次执行／post-audit | 各自分阶段授权 | 未授权 |
| D fold request／执行／post-audit | 各自分阶段授权 | 未授权 |
| 合并解释／新增CPU统计 | 独立授权 | 未授权 |

协议确认只确认设计，不授权服务器审计、implementation、preflight、真实inference或训练。真实request须绑定最终实现/P3/tolerance/preflight、环境与扩展binary/source hash、资源、精确输入、唯一run/session/log/PID/退出码/输出路径；关键前提未冻结不得宣称READY。

用户待确认：

- [ ] 三条件、同LSQ实例、加法出口旁路，不把off当LS或候选临床模型
- [ ] 210 case／630 forward，失败不补跑；2load/fold、1open/case
- [ ] 三forward后才读GT；禁止保护分区及额外payload
- [ ] 最小标量＋接触方向诊断，不存预测/绘图/sweep/CI/gate
- [ ] 空footprint/非有限停止，旧flags不改
- [ ] native容差先冻结，不以新dev误差调宽
- [ ] 历史证据缺口及不晋级建议不因诊断消除
- [ ] 每后续阶段独立授权；失败不重试/resume

当前停止在待确认草案。确认后可选择下一项仅授权服务器 pre-implementation 只读核对，不直接实现或执行；也可要求修订/止损。

## 📚 10. 来源与版本管理

[非执行来源索引JSON](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_query_off_protocol_draft_source_index_v1.json) 保存四个旧request/checkpoint/BNCal/data scope及本机代码hash。它 execution_authorized=false、implementation_authorized=false，无新真实runtime/session/执行命令，不是待执行request。

原指标/flag来源沿用R0/R1-A冻结代码行：QA-1 evaluator SHA256=5d3e92094cc1eeec8788dbec4543735d95947dcbdd0449541516242dcad5d808；继承metric-row=6be1c38b46270eff278ea7a54805ba0d572e8aef81a103350308072380c38798；skullfix_metrics=0c4342cd19fb19a659302b0e350c3be34bd21447d2034bdc9d2e81a180174ee5。本次无新增外部文献或性能主张。

本草案按 markdown-mermaid-writing 决策记录结构组织，用一个数据流图明确GT后置与失败停止；技能不扩大权限。后续确认记录本草案完整SHA256，修订新v2不改v1/父计划/旧CSV。确认记录、容差附件与执行request将来是独立文件，避免循环绑定。版本校验侧车不包含自身，不代表本机长期归档或恢复验证。
