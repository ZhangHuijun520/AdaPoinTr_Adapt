# R1-B 人工 GPU preflight：implementation-only v2 修订方案草案 v1

_Cranial-SCQR v1.2-QA 后续阶段；2026-10-11；仅供审核，未实施、未执行。_

---

## 📋 状态与授权边界

| 字段 | 冻结值 |
| --- | --- |
| 草案状态 | `DRAFT_AWAITING_USER_CONFIRMATION` |
| 本轮权限 | 仅起草本机修订方案 |
| implementation v2 状态 | 未实现、未部署、未测试 |
| CPU 依赖审计 | 不重跑 |
| GPU/真实数据/模型执行 | 全部禁止 |
| execution request | 本轮不创建 |

本文中的预算、路径和验收规则均为**待确认提案**，不是授权回执或可执行 request。确认方案与授权实施是不同的动作；不能从草案确认自动推导安装、CPU 审计或 GPU 执行权限。服务器工作根目录仍为 `/home/jovyan/adapointr_work/PoinTr`，本机管理根目录与服务器文件系统不自动同步。

## 🔍 失败证据与定位限度

依据现有[本机失败观测记录](E:/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_implementation_failure_observation_v1.json)及上一轮只读调查：

- 单次安装流程退出码为 `1`；异常为依赖审计子进程 `TimeoutExpired`，阈值为 `180 s`，不是 WebShell 客户端超时。
- 安装前、安装后各 `27` 项 CPU 契约测试通过；三个新工具已安装，原有九个 R1-B 实现文件哈希未变。
- 三个依赖/输入/环境结果文件都未形成，P3 与 v2 execution request 未创建。
- 审计源码会遍历 `models`、`utils`、`extensions` 及整个 Conda `lib`，解析选定二进制的静态加载依赖，串行哈希符合规则的文件。
- 只读 `stat` 观测显示 PyTorch/NVIDIA 已知库目录中的共享库逻辑大小合计约 `4.75 GB`。该数值不是去重后最终清单总量，也不是实际读取量或吞吐率测量。
- 旧审计没有阶段进度；现有证据无法确认最后处于导入、枚举、加载器解析或文件哈希中的哪一阶段。

因此，“大范围扫描与串行哈希可能超出预算”是有依据的解释，但仍不是唯一、已证实根因。不得把新方案写成已经证明修复成功。

| 父证据 | SHA256 |
| --- | --- |
| 失败回执（服务器） | `fd231485c8c2d1b7c1ffe72f9ae72e843b72374ddebe1bc52cd9756280af177c` |
| 旧依赖审计工具 | `9fa2ec57a3cf8286859ad1b23dab5ed56815dd556aa7606a662b52bde6b600b8` |
| 原 R1-B P3 | `65f31131cbaedb0b904424f9e381901a6320040bf23376ecd43f09ca5ae3e390` |
| 人工 preflight 协议 v1 | `923254dab787341728af9a22031b482f55a45ebd6c2bc62cfcb427511c61456b` |
| 不可直接执行的 request v1 | `d968143ce8ce39daedc398b85419300a48425c63a3203ad75604bc5f1ba16ffd` |

## 🎯 方案选择与不变项

| 选项 | 收益 | 风险 | 提案结论 |
| --- | --- | --- | --- |
| 仅延长 180 秒 | 改动较少 | 无法定位再次超时 | 不单独采用 |
| 只哈希少数包 | 降低读取量 | 静默缩小覆盖 | 本版不采用 |
| 保留覆盖、限制规模、分阶段记录 | 保留证据并可定位 | 仍可能超时/超限 | 推荐 |

不变项：原九个 R1-B 文件、v1.1 路径、已有正式结果、输入定义、种子、严格确定性/TF32要求、模型构造和 forward 次数、相等性门控、零更新约束、真实 payload/checkpoint 禁止项，以及历史正式 gate 状态全部保持不变。

本次修订只针对 implementation-only 的依赖审计、安装编排、可观测性和相应 CPU 契约测试。不能借此把人工 CPU 验证改称 CUDA 等价性证明。

## 🔐 有界扫描与必要哈希覆盖

### 保留集合定义

保留旧版本的项目三个代码根与 Conda `lib` 代码扫描范围；保留 `.py/.pyc/.cpp/.cu/.h/.hpp`、`.so` 及数字版本后缀、允许的 `.dist-info` 元数据文件规则。Python 可执行文件、静态加载依赖、容器挂载的驱动库继续纳入内容 SHA256。三个新增工具和原九个 R1-B 文件仍单独精确绑定；只读模型 YAML 与协议/父 request/P3仍按既有守卫绑定，不能靠环境清单替代。

采用流式目录枚举，记录每个目录和候选条目的计数；目录符号链接不递归，文件别名记录“逻辑路径→解析路径”，解析目标必须留在批准根内。对同一解析路径只哈希一次，不因去重漏掉别名绑定。不能任意删除旧版本可能覆盖的子目录；若与旧集合规则有差异，列入差异报告并停止，等待单独确认。

### 提议硬上限

| 指标 | 上限 | 超限行为 |
| --- | ---: | --- |
| 已访问目录/文件条目合计 | 200,000 | 失败停止 |
| 去重后待哈希文件数 | 50,000 | 失败停止 |
| 去重后内容读取总量 | 8 GiB | 失败停止 |
| 静态加载解析目标数 | 32 | 失败停止 |
| 每次加载器解析 | 10 s | 失败停止 |
| 单个文件哈希 | 120 s | 失败停止 |
| 元数据单文件大小 | 16 MiB | 失败停止 |

这些上限是未实测的安全预算，不代表已知环境必然满足。条目上限须在收集全量集合之前递增检查；字节上限须在读取内容之前检查，不允许先全量扫描/读取后才判超限。遇到超限不得截断列表、跳过大库、抽样哈希或自动抬高上限。

仅允许代码和批准元数据内容读取；NPZ/STL/checkpoint、秘密目录、数据/结果目录不得因符号链接或目录嵌套被读取。非普通文件、逃逸链接、无法分类且可能影响覆盖的条目均 fail-closed。权限错误、文件消失/变化、库依赖 `not found`、解析器异常均失败；不回退到较弱清单。

每个内容哈希须记录读取前后 `stat` 指纹，拒绝可观察的修改；最后对清单成员及关键集合进行元数据/成员复核。此措施不等于文件系统快照或 OS 级沙箱，不能声称完全排除并发竞态。清单状态继续是静态 CPU 库存，不声称观测了完整动态 CUDA 加载链。

## 📝 阶段日志与失败证据

提议阶段：`IDENTITY → CPU_ENV_INPUT → ENUMERATE → LOADER_RESOLVE → HASH_CONTENT → FINAL_VALIDATE → PUBLISH`。

每阶段开始、结束和失败都写入新增版本目录中的 `progress_v2.jsonl`，行格式包含 schema、阶段、事件、UTC 时间、单调时间、累计耗时、目录/候选/去重计数、计划与完成字节数、当前批准路径、退出状态。不得记录 token、进程环境全量、输入坐标或模型张量。

日志采用行缓冲并立即 flush；阶段边界执行持久化刷新。每个大文件开始/完成均记录；读取中每 5 秒或每 64 MiB（先达到者）记录进度，并检查期限。心跳输出不替代超时守卫：阻塞 I/O 或导入阶段仍由独立父进程 watchdog约束。异常处理器能写失败回执时应写入，但硬终止场景只能依赖父进程和最后一条持久日志，不伪造子进程完整退出。

安装编排不得将所有 stdout/stderr 留在 `capture_output` 内存里直到结束；直接写专属日志。父进程记录子 PID、精确命令、开始/结束时间、超时阶段、TERM/KILL及回收状态；只终止自己核验过的本次子进程组，不使用宽泛 `pkill`。写日志失败本身也应使流程停止。

最终依赖、输入和环境文件只能在全部阶段通过后发布，随后最后写 `completion`。允许失败目录保留完整进度或部分材料，但没有 PASS completion及匹配清单/P3时一律不可用于 request。

## ⏰ 超时预算依据与冲突门控

### CPU 审计提案预算

| 阶段 | 硬上限 |
| --- | ---: |
| 身份、CPU 环境与人工输入 | 60 s |
| 有界目录枚举 | 120 s |
| 加载器解析（全阶段） | 120 s |
| 内容哈希（全阶段） | 480 s |
| 最终核验与发布 | 60 s |
| 审计总墙钟时间 | 900 s |

各阶段上限与总墙钟期限同时生效；不存在“阶段没超限就可超过总期限”。阶段预算总计 840 秒，剩余 60 秒留给编排开销，不能自动转移阶段上限。子进程终止/回收另设至多 15 秒，属于失败清理期限，不是继续计算的额外时间。

预算推导使用**未测量的规划假设**：按 20 MiB/s串行内容读取与哈希，8 GiB约需 409.6 秒，480 秒提供有限余量；约 4.75 GB库文件在该假设下约需 227 秒，已超过旧审计整体180秒。该计算解释为什么旧预算可能不足，并不证明真实吞吐率。实际低于该假设仍会失败，不能自适应延长预算。

CPU 测试仍固定每轮60秒；新增小型人工测试计数须在 implementation-only授权后、运输包冻结前报告，不能继续声称旧27项已经覆盖新编排。CPU审计可能长达15分钟，未来执行必须使用专属 tmux及PID/退出码证据，不依赖 WebShell连接；本轮不创建任何 tmux/launcher。外层编排需单独冻结总期限，不能沿用旧300秒客户端等待方式承载900秒审计。

### GPU preflight 的 600 秒限制保持不变

CPU 审计的900秒提案不授权改变未来GPU preflight的600秒总预算，也不授权在GPU执行前跳过库存复核或使用旧哈希缓存。若仍需核验多GB清单，后续能否同时满足600秒仍未知。

创建执行就绪 request前必须显式审查：前置库存复核、模型准备和固定8次forward能否在既定总期限内合理安排。不能仅凭新的CPU P3通过就声明该冲突已解决。若实现无法维持冻结预算，停止request创建，另起协议补充草案并等待确认；本方案不提前批准延长GPU期限或拆出不计时的隐形校验。

## 🔧 修改面与版本化部署提案

仅在后续单独授权实施后，计划新增以下文件，不覆盖旧实现运输目录：

| 新增文件（相对新 overlay根） | 用途 |
| --- | --- |
| `audit_synthetic_pf_dependencies_v2.py` | 有界扫描、日志和CPU结果 |
| `install_synthetic_pf_implementation_v2.py` | 已安装父哈希守卫、版本化编排 |
| `test_synthetic_pf_dependency_audit_v2.py` | 小型人工CPU契约测试 |

新安装编排以“三个canonical工具已存在且哈希精确匹配”为前提；不重复旧版的“目标必须不存在→写入”流程，不重写这些工具。旧九个R1-B文件、三个canonical工具、v1协议/request、失败回执和日志均保留。发现漂移立即停止。审计应显式使用当前canonical工具生成人工输入，不依赖旧stage中可漂移的副本。

拟使用全新路径（均未创建，实施前仍须只读确认不存在）：

- overlay：`server_overlays/r1b_synthetic_pf_impl_v2_20261011`
- CPU产物：`docs/cranial_scqr_v12_qa_research_2026_10_11/r1b_synthetic_pf_implementation_v2_20261011`
- P3：`docs/cranial_scqr_v12_qa_research_2026_10_11/v12_rsd_r1b_synthetic_preflight_post_implementation_p3_v2.json`
- CPU审计控制目录：`logs/cranial_scqr_v12_rsd_r1b/synthetic_impl_cpu_audit_v2_20261011`
- CPU审计会话：`r1b-synthetic-impl-cpu-audit-v2-20261011`

新P3须与现有 preflight reader要求兼容，并绑定新审计/编排/测试实现与最终库存。不能随意改变P3 schema或漏掉reader当前检查字段。若兼容性审查证明必须修改canonical守卫/工具，则停止并另报精确最小改动与父哈希，由用户新增授权，不夹带到这三个新增文件中。

## 🧪 CPU 验收与 P3 门控

未来新增测试全部使用临时人工目录、小型字节文件、假的加载器输出和假时钟；不枚举实际Conda树、不调用真实GPU、不加载真实模型或checkpoint。需覆盖：

1. 旧集合规则与新集合规则在人工fixture上相同，别名去重不丢绑定。
2. 必要源码/共享库/元数据均覆盖，所有禁用后缀/路径先拦截再读取。
3. 路径逃逸、目录链接、权限错误、文件变更、依赖缺失均失败。
4. 数量、字节、单文件、阶段及总期限边界均精确测试，超限不截断也不重试。
5. 日志阶段、flush、计数和人工心跳正确；中断后不得形成PASS完成标志。
6. 父watchdog对自己子进程组进行有界回收；部分输出和失败回执不成为有效库存。
7. CUDA初始化与真实模型构造为0，CPU人工输入身份与原冻结定义一致。
8. 新P3与现有reader兼容；旧v1request仍不可执行，无授权链循环。

未来验收顺序为新增人工CPU测试、已有canonical27项CPU回归、版本化部署后测试、一次单独冻结的CPU库存审计、只读post-implementation P3核验。每一步失败停止，不自动进入下一步。旧27项通过证据保留，但不替代新测试和新审计。

P3 PASS必须满足：全部测试计数/退出码正确、原九文件和三个工具哈希不变、库存完整且没有超限/遗漏、CPU环境与人工输入身份文件齐全、日志与最终结果哈希一致、`cuda_initialized=false`、真实payload/checkpoint/model/forward计数为0。只读元数据观察不计作模型执行。

## 🚫 失败处理与后续授权

任何身份不符、哈希漂移、覆盖不全、超限、超时、进程回收未确认、日志写入失败或测试失败，都产生 `FAILED_STOPPED_NO_RETRY` 或无法完整回收时的明确未决状态。不得自动resume、使用部分清单、删除失败目录、回退代码或换新路径再次执行。旧v1失败不被抹除，v2是单独版本尝试而非偷偷续跑。

```mermaid
flowchart TB
    accTitle: Revision Approval And Execution Boundaries
    accDescr: The draft requires separate implementation authorization and successful CPU evidence before a pending GPU request can be considered; failures stop without retry.
    draft_proposal["审核本机修订草案"] --> implementation_authority["单独授权 implementation-only"]
    implementation_authority --> cpu_validation["实现并验证 CPU 契约"]
    cpu_validation --> audit_authority["冻结单次 CPU 审计范围"]
    audit_authority --> p3_review{"新 P3 全部通过？"}
    p3_review -->|否| stop_failure(["停止并保留失败证据"])
    p3_review -->|是| readiness_review["审查 reader兼容与600秒约束"]
    readiness_review --> pending_request["另行创建待授权 request"]
    pending_request --> gpu_authority["单独获得 GPU 执行授权"]
```

确认本草案后的建议下一步仅为单独授权三个新增文件的implementation-only实现及小型人工CPU测试；是否包含canonical27项服务器回归、部署和900秒单次CPU审计，应在该授权中逐项写明。没有这些具体授权就不执行。GPU request只能在最终P3及readiness条件齐全、且创建request获授权后生成，状态保持 `AWAITING_EXPLICIT_USER_AUTHORIZATION`。任何授权回执/runtime/单次GPU launcher/tmux均须再等待完整request SHA256的独立执行授权。

## 🔗 审核确认清单

- [ ] 同意保留原哈希集合范围，增加硬规模上限，不静默缩小覆盖
- [ ] 同意阶段日志、父watchdog和版本化失败材料
- [ ] 同意900秒CPU审计是待验证工程预算，不是成功保证
- [ ] 同意保持GPU600秒限制；若冲突未解决，停止request创建
- [ ] 同意原九文件、三个canonical工具及旧失败证据不覆盖
- [ ] 同意方案确认不等于实施/审计/GPU执行授权

当前所有复选框均未勾选。本文仅新增于本机管理目录，不代表已上传服务器或已有长期归档备份；不执行Git commit/tag/push，不清理任何服务器文件。
