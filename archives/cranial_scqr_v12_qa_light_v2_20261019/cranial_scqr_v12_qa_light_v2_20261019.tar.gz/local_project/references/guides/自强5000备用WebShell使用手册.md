# 自强5000备用 WebShell 使用手册

_适用于平台端口转发或 SSH 不可用时，通过 Windows WSL 与 `hpc5000` WebShell 客户端控制自强5000容器 · 最后验证：2026-09-22_

---

## 📋 方案定位

本手册描述已经在本机和自强5000真实容器上验证通过的备用访问方案。正常情况下优先使用 SSH 别名 `zq5000-codex`；只有端口转发不可用、外部端口映射错误或 SSH 无法连接时，才切换到 WSL 中的 `hpc5000` WebShell 客户端。

`hpc5000` 通过自强5000平台网页终端的 WebSocket 和上传接口工作，不需要容器开放 SSH 端口，也不要求容器能够访问公网。它可以执行远程命令、打开交互 shell、上传文件和下载文件，但不能提供 SSH 隧道、端口转发或原生远程文件系统。

### 连接选择流程

```mermaid
flowchart TB
    accTitle: Remote Access Fallback Flow
    accDescr: Select SSH when the platform port mapping is valid, otherwise authenticate the local WebShell client and use it as the controlled fallback channel

    start([🔍 需要连接服务器]) --> test_ssh{SSH 可用且 HostKey 正确?}
    test_ssh -->|是| use_ssh[🔐 使用 zq5000-codex]
    test_ssh -->|否| open_terminal[🌐 打开当前容器网页终端]
    open_terminal --> copy_token[🔐 在浏览器复制新 token]
    copy_token --> login_webshell[⚙️ 在 WSL 登录 hpc5000]
    login_webshell --> verify_target{目标容器核对通过?}
    verify_target -->|是| use_webshell[✅ 使用 WebShell 备用通道]
    verify_target -->|否| stop[❌ 停止远程写入并重新核对 URL]

    classDef action fill:#dbeafe,stroke:#2563eb,stroke-width:2px,color:#1e3a5f
    classDef decision fill:#fef9c3,stroke:#ca8a04,stroke-width:2px,color:#713f12
    classDef success fill:#dcfce7,stroke:#16a34a,stroke-width:2px,color:#14532d
    classDef danger fill:#fee2e2,stroke:#dc2626,stroke-width:2px,color:#7f1d1d

    class open_terminal,copy_token,login_webshell,use_ssh action
    class test_ssh,verify_target decision
    class use_webshell success
    class stop danger
```

### 已安装组件

| 项目 | 当前路径或状态 |
| --- | --- |
| WSL 发行版 | `Ubuntu-20.04` |
| WebShell 客户端 | `/home/zhj/.local/bin/hpc5000` |
| 客户端源码 | `/home/zhj/.local/share/remote-agent-toolkit/release` |
| 隔离依赖 | `/home/zhj/.local/share/remote-agent-toolkit/site-packages` |
| 本地凭据代理 | WSL 用户运行时目录中的 Unix Socket |
| 凭据默认空闲期限 | 12 小时 |
| 服务器项目 | `/home/jovyan/adapointr_work/PoinTr` |

> ⚠️ **安全边界：** WebShell token 等价于当前容器的远程终端权限。不要把 token 发到聊天、写入 Markdown、保存到脚本、放进 Git、显示在终端输出或作为命令行参数传递。

---

## 🔍 首先判断是否需要备用方案

在普通 Windows PowerShell 中先测试原 SSH：

```powershell
ssh -o BatchMode=yes -o ConnectTimeout=10 zq5000-codex `
    "printf '[remote-ok]\n'; hostname; whoami; pwd"
```

SSH 成功且 `hostname` 与当前容器一致时，继续使用原 SSH 方案，不需要登录 WebShell。

以下情况应切换到备用 WebShell：

- `Test-NetConnection` 显示外部端口不可达
- SSH 返回 `Connection refused` 或持续超时
- 平台无法创建端口转发
- 外部 SSH banner 或 HostKey 与当前容器不一致
- Codex 的 SSH 远程项目持续显示网络重连

> 📌 **重要：** 遇到 `REMOTE HOST IDENTIFICATION HAS CHANGED` 时不要关闭 HostKey 校验，也不要盲目删除 `known_hosts`。先通过当前容器网页终端核对真实 HostKey。

---

## 🔐 每次登录备用 WebShell

### 第一步：获取当前容器网页终端 URL

在自强5000网页中打开当前容器的终端，复制浏览器地址栏中的纯 HTTPS URL。示例：

```text
https://hpc5000.shu.edu.cn/terminal/<pod>?namespace=shu-ai&podName=<pod>
```

必须确认：

- URL 使用 `https://hpc5000.shu.edu.cn`
- `podName` 是当前正在运行的容器 Pod
- URL 不包含 `token`、`Authorization` 或 `access_token`
- 不要复制 Markdown 格式的 `[地址](地址)`，只复制纯 URL

容器销毁并重建后，Pod 名通常会变化，因此要重新取得 URL。

### 第二步：复制新 token

保持自强5000平台已登录，并停留在平台页面。在浏览器开发者工具的 Console 中执行：

```javascript
copy(localStorage.getItem('shu_user_token'))
```

控制台显示 `undefined` 可能只是 `copy()` 的返回值，不代表复制失败。可以只检查 token 是否存在：

```javascript
Boolean(localStorage.getItem('shu_user_token'))
```

预期返回：

```text
true
```

### 第三步：进入 WSL

在普通 Windows PowerShell 中执行：

```powershell
wsl.exe -d Ubuntu-20.04
```

预期提示符类似：

```text
zhj@DESKTOP-UHVNFID:~$
```

`WSL 检测到 localhost 代理配置，但未镜像` 的提示不影响 WebShell 登录，因为客户端访问的是学校平台 HTTPS 地址。

### 第四步：首次登录或容器变化后登录

在 WSL Bash 中执行下面两步。先隐藏读取 token：

```bash
read -r -s -p 'Paste fresh token (hidden): ' T
printf '\n'
```

粘贴 token 时屏幕不会显示字符，这是正常现象。按回车后，使用当前容器的纯 URL 登录：

```bash
printf '%s\n' "$T" |
    /home/zhj/.local/bin/hpc5000 login \
        --token-stdin \
        --url 'https://hpc5000.shu.edu.cn/terminal/shu-common-25721452-notebook-hwq6lx-0?namespace=shu-ai&podName=shu-common-25721452-notebook-hwq6lx-0'

RC=$?
unset T
echo "login_status=$RC"
```

成功输出类似：

```text
Logged in: shu-ai/<pod> [<container>]
Token is held only by the local in-memory agent; clipboard was not modified.
login_status=0
```

### 第五步：token 过期但容器未变化时重新登录

目标 URL 已保存在本地且仍指向同一 Pod 时，不必再次输入 URL：

```bash
read -r -s -p 'Paste fresh token (hidden): ' T
printf '\n'
printf '%s\n' "$T" | /home/zhj/.local/bin/hpc5000 login --token-stdin
RC=$?
unset T
echo "login_status=$RC"
```

如果容器已经重建，必须重新使用带 `--url` 的完整登录命令，不能沿用旧 Pod。

---

## ✅ 每次登录后的强制核对

登录成功后先执行只读检查，不要直接修改代码或启动实验：

```bash
/home/zhj/.local/bin/hpc5000 status
/home/zhj/.local/bin/hpc5000 exec -- hostname
/home/zhj/.local/bin/hpc5000 exec -- id
/home/zhj/.local/bin/hpc5000 exec -- pwd
/home/zhj/.local/bin/hpc5000 exec -- nvidia-smi
```

验收表：

| 检查项 | 预期结果 |
| --- | --- |
| `status` | `agent: running`，目标 Pod 与网页终端一致 |
| `hostname` | 当前自强5000容器的 hostname |
| `id` | `uid=1000(jovyan)` |
| `pwd` | 通常为 `/home/jovyan` |
| `nvidia-smi` | 显示分配到的真实 GPU、驱动和显存 |

再核对项目目录：

```bash
/home/zhj/.local/bin/hpc5000 exec -- \
    "test -d /home/jovyan/adapointr_work/PoinTr && printf '[project-ok]\n'"
```

只有上述检查全部符合预期，才允许进入代码修改、测试或实验阶段。

---

## 🛠️ 执行远程命令

### 单条命令

```bash
/home/zhj/.local/bin/hpc5000 exec -- hostname
```

### 在项目目录执行复合命令

每次 `exec` 都是新的 shell，不会保留上一次的 `cd`、Conda 激活或环境变量。必须放在同一个命令中：

```bash
/home/zhj/.local/bin/hpc5000 exec -- \
    "cd /home/jovyan/adapointr_work/PoinTr && pwd && ls -la"
```

激活 Conda 环境：

```bash
/home/zhj/.local/bin/hpc5000 exec -- \
    "source /opt/conda/etc/profile.d/conda.sh && \
     conda activate adapointr-mamba && \
     cd /home/jovyan/adapointr_work/PoinTr && \
     python --version"
```

### 指定长命令超时

```bash
/home/zhj/.local/bin/hpc5000 exec --timeout 3600 -- \
    "bash /home/jovyan/adapointr_work/PoinTr/scripts/<script>.sh"
```

客户端超时不代表服务器进程已经停止。超时或断线后先检查 PID、日志和 GPU，再决定是否重试。

### 打开交互 shell

```bash
/home/zhj/.local/bin/hpc5000 shell
```

按 `Ctrl+]` 退出交互 WebShell。交互 shell 适合临时诊断，不适合承载长时间实验。

---

## 📦 上传和下载文件

### 上传单个文件

Windows 文件在 WSL 中通常位于 `/mnt/c`、`/mnt/d` 或 `/mnt/e`。示例：

```bash
/home/zhj/.local/bin/hpc5000 put \
    '/mnt/e/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/server_uploads/example.tar.gz' \
    '/home/jovyan/example.tar.gz'
```

默认拒绝覆盖远端已有文件。确认目标文件允许覆盖后才能显式增加 `--force`。

### 下载单个文件

```bash
/home/zhj/.local/bin/hpc5000 get \
    '/home/jovyan/result.tar.gz' \
    '/mnt/e/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/outputs/result.tar.gz'
```

### 传输目录

客户端一次传输一个文件。目录需要先在源端打包：

```bash
/home/zhj/.local/bin/hpc5000 exec -- \
    "cd /home/jovyan/adapointr_work/PoinTr && \
     tar -czf /home/jovyan/result_bundle.tar.gz logs/<result-directory>"
```

随后使用 `get` 下载压缩包。

### 校验传输完整性

服务器端：

```bash
/home/zhj/.local/bin/hpc5000 exec -- \
    "sha256sum /home/jovyan/result.tar.gz"
```

WSL 本地：

```bash
sha256sum '/mnt/e/Codex/2026-06-06/mamba-ccf-c-1-high-resolution/outputs/result.tar.gz'
```

两个 SHA256 必须完全一致。

---

## 🚀 测试和 GPU 实验

### 运行短测试或 preflight

先确认没有同名任务正在运行，再执行有界测试：

```bash
/home/zhj/.local/bin/hpc5000 exec --timeout 1800 -- \
    "source /opt/conda/etc/profile.d/conda.sh && \
     conda activate adapointr-mamba && \
     cd /home/jovyan/adapointr_work/PoinTr && \
     bash scripts/<preflight-or-test>.sh"
```

### 启动长时间实验

不要让训练依赖 WebShell 连接。使用项目既有的 `tmux` 启动脚本；如果项目没有该脚本，再使用经过审核的 `nohup` 启动脚本。

通用 `tmux` 示例：

```bash
/home/zhj/.local/bin/hpc5000 exec -- \
    "cd /home/jovyan/adapointr_work/PoinTr && \
     tmux new-session -d -s '<unique-session>' \
       'bash <absolute-launch-script> > <absolute-log> 2>&1' && \
     tmux list-sessions"
```

启动后必须检查：

```bash
/home/zhj/.local/bin/hpc5000 exec -- \
    "tail -n 120 '<absolute-log>'; nvidia-smi"
```

不能仅凭 tmux 会话存在或 GPU 有占用就宣称实验成功。还要确认日志进入真实计算、指标持续更新、输出目录正确。

### 监控实验

```bash
/home/zhj/.local/bin/hpc5000 exec -- \
    "tmux list-sessions 2>/dev/null || true; \
     tail -n 120 '<absolute-log>'; \
     nvidia-smi"
```

### 停止实验

停止任务前必须核对 tmux 会话名、PID、启动命令和日志属于本轮实验。不要使用 `pkill python`、`killall` 等宽泛命令。

---

## 🤖 让 Codex 使用备用通道

当需要 Codex 操作服务器时，在任务中明确说明：

```text
本轮优先测试 SSH 别名 zq5000-codex。
若 SSH 或平台端口转发不可用，使用已经登录的 WSL 客户端：
/home/zhj/.local/bin/hpc5000

目标项目目录：
/home/jovyan/adapointr_work/PoinTr

先执行 status、hostname、id、pwd、nvidia-smi 和项目目录检查。
确认 Pod 与当前网页终端一致后，才允许修改文件或运行实验。
token 不得读取、显示、写入文件或出现在命令参数中。
```

Codex 从 Windows 调用备用客户端的基本形式是：

```powershell
wsl.exe -d Ubuntu-20.04 -- `
    /home/zhj/.local/bin/hpc5000 exec -- hostname
```

对于包含管道、重定向、`cd` 或环境激活的复杂命令，应让 `hpc5000 exec` 在远端 Bash 中处理，避免 PowerShell、WSL 与远端 shell 的多层引号互相干扰。

---

## 🔒 安全和实验边界

### 必须遵守

- token 只通过隐藏标准输入进入 `hpc5000 login --token-stdin`
- 每次容器重建后重新取得网页终端 URL
- 每次登录后核对 hostname、用户、GPU 和项目目录
- 修改前读取目标文件和现有状态
- 上传下载前后校验 SHA256
- 长任务使用 `tmux` 或项目既有后台脚本
- 日志、结果和归档保存在持久化目录
- 服务器目录没有 `.git` 时，不在服务器伪造 Git 提交状态
- 版本控制以本机规范仓库为准，服务器用于执行与保存实验产物

### 禁止事项

- 不把 token 粘贴到聊天中
- 不把 token 写入环境文件、脚本、Markdown、Git 或 shell history
- 不关闭 TLS 验证
- 不使用未知域名或纯 HTTP 的终端 URL
- 不因连接超时而重复启动实验
- 不清理、覆盖或停止未经核对的文件和进程
- 不把 WebShell 登录成功等同于训练成功

---

## 🔧 故障排查

### `token validation failed or the token expired`

常见原因：

- token 已过期
- 复制到了字符串 `null`
- Console 不属于 `hpc5000.shu.edu.cn` 的已登录平台页面
- 登录 URL 指向旧 Pod
- token 变量名被误写成带反斜杠的名称

处理方法：

1. 在当前平台页面重新登录
2. 打开当前容器网页终端
3. 执行 `Boolean(localStorage.getItem('shu_user_token'))`
4. 确认返回 `true`
5. 重新执行 `copy(localStorage.getItem('shu_user_token'))`
6. 使用隐藏输入命令重新登录

### `agent: not running`

token 内存代理未启动、已过期或 WSL 已被关闭。重新复制 token 并执行登录命令即可，不需要重新安装客户端。

### `no saved target`

尚未保存目标 URL。使用带 `--url` 的完整登录命令。

### 登录到了旧容器

立即执行：

```bash
/home/zhj/.local/bin/hpc5000 logout
```

重新获取当前容器 URL 和 token，再登录。不要对错误 Pod 执行任何写入操作。

### PowerShell 出现 Bash 引号或括号语法错误

不要在 PowerShell 中嵌套复杂的 Bash、Python和 Markdown 链接。先执行：

```powershell
wsl.exe -d Ubuntu-20.04
```

进入 WSL 后再运行 Bash 命令。URL 必须是纯文本，不要粘贴 `[URL](URL)`。

### WSL 显示 localhost 代理未镜像

这通常不影响访问学校平台的 HTTPS WebShell。以 `hpc5000 login` 和 `hpc5000 exec -- hostname` 的实际结果为准。

### 命令超时

客户端超时不代表服务器进程停止。先查询：

```bash
/home/zhj/.local/bin/hpc5000 exec -- \
    "ps -eo pid,etime,args | sed -n '1,160p'; \
     tmux list-sessions 2>/dev/null || true; \
     nvidia-smi"
```

确认原任务不存在或已经失败后，才能重新启动。

### 上传或下载拒绝覆盖

这是保护机制。先核对两端文件和 SHA256；只有明确允许覆盖时才使用 `--force`。

---

## 🧹 退出和凭据清理

工作结束且不再需要备用通道时执行：

```bash
/home/zhj/.local/bin/hpc5000 logout
```

预期输出：

```text
Credential agent stopped; in-memory token released.
```

退出 `hpc5000` 不会停止已经通过 `tmux` 或 `nohup` 独立运行的服务器任务。

需要退出 WSL shell 时执行：

```bash
exit
```

---

## 📌 快速参考

| 操作 | 命令 |
| --- | --- |
| 进入 WSL | `wsl.exe -d Ubuntu-20.04` |
| 查看登录状态 | `/home/zhj/.local/bin/hpc5000 status` |
| 执行命令 | `/home/zhj/.local/bin/hpc5000 exec -- <command>` |
| 交互终端 | `/home/zhj/.local/bin/hpc5000 shell` |
| 上传文件 | `/home/zhj/.local/bin/hpc5000 put <local> <remote>` |
| 下载文件 | `/home/zhj/.local/bin/hpc5000 get <remote> <local>` |
| 释放 token | `/home/zhj/.local/bin/hpc5000 logout` |
| 服务器项目 | `/home/jovyan/adapointr_work/PoinTr` |
| 本机规范项目 | `E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution` |

### 每次使用的最短流程

```text
测试 SSH
→ SSH 不可用
→ 打开当前容器网页终端
→ 复制纯 HTTPS URL
→ 浏览器 Console 复制新 token
→ 进入 WSL
→ 隐藏输入 token 并登录 hpc5000
→ 核对 status、hostname、id、pwd、GPU、项目目录
→ 执行受控操作
→ 完成后 logout
```

---

_本手册基于 2026-09-22 的真实验证环境编写：Windows 11、WSL2 Ubuntu 20.04、`hpc5000` 本地客户端、自强5000 WebShell、服务器用户 `jovyan`。_
