# 自强 5000 新容器与 Codex 远程连接恢复手册

## 1. 适用场景

本文用于以下情况：

- 自强 5000 Notebook 容器被销毁后重新创建；
- 新容器继续挂载原来的 `/home/jovyan` 持久化目录；
- 平台端口转发的容器内部端口仍为 `22222`；
- Windows Codex 桌面端通过 SSH 主机别名 `zq5000-codex` 连接；
- 服务器需要通过 Windows 本地代理访问 OpenAI。

当前已验证的连接参数如下：

| 项目 | 当前值 |
|---|---|
| SSH 主机别名 | `zq5000-codex` |
| 服务器用户 | `jovyan` |
| 当前外部地址 | `10.10.49.27` |
| 当前外部端口 | `8004` |
| 容器内部 SSH 端口 | `22222` |
| Windows 本地代理 | `127.0.0.1:7890` |
| 服务器反向代理入口 | `127.0.0.1:1080` |
| 远程项目目录 | `/home/jovyan/adapointr_work/PoinTr` |
| 客户端密钥指纹 | `SHA256:Han30ejK7XWrnOmSKQd0trCVK9bMY4ilJsLK1Gl5wRU` |
| 服务器 HostKey 指纹 | `SHA256:MEMkjBwNP6qWTbVpdgxcDv36O7q86HsH1cdLmbovQ9g` |

> 外部地址和外部端口可能在重新创建端口转发后变化。每次都应以平台页面显示的信息为准，不能只根据内部端口 `22222` 推断。

## 2. 容器重建后的状态模型

只要原持久化卷仍然挂载，以下内容通常会保留：

- `/home/jovyan/.ssh/sshd/` 中的配置和服务器 HostKey；
- `/home/jovyan/.bash_profile`；
- `/home/jovyan/.codex/` 中的 Codex 配置和登录状态；
- `/home/jovyan/.local/` 中的 Codex CLI、Node.js 和代理包装器；
- `/home/jovyan/adapointr_work/PoinTr` 项目及实验结果。

以下运行时进程不会保留，必须重新启动：

- 新容器中的用户级 `sshd`；
- Windows 到服务器的反向代理 SSH 隧道；
- 旧容器中的 Codex App Server 和终端进程。

因此，常规恢复顺序是：

1. 核对平台端口转发；
2. 在新容器网页终端启动用户级 `sshd`；
3. 从 Windows 验证严格公钥登录；
4. 确认 Windows 本地代理运行；
5. 重建反向代理隧道；
6. 验证服务器能够访问 OpenAI；
7. 在 Codex 桌面端重新启用连接并打开远程项目。

## 3. 第一步：核对平台端口转发

在自强 5000 平台确认当前规则，例如：

```text
外部 10.10.49.27:8004 -> 容器内部 22222
```

记录当前外部地址和外部端口。如果它们与 Windows SSH 配置不同，应在启动 `sshd` 后修改 Windows 配置，见第 6 节。

## 4. 第二步：检查持久化 SSH 文件

在新容器的网页终端执行：

```bash
set +e

SSHD="/opt/conda/envs/user-sshd/bin/sshd"
KEYGEN="/opt/conda/envs/user-sshd/bin/ssh-keygen"
CONFIG="$HOME/.ssh/sshd/sshd_config"
HOST_KEY="$HOME/.ssh/sshd/ssh_host_ed25519_key.pub"

echo "===== Container identity ====="
id
hostname
hostname -I 2>/dev/null

echo "===== Required files ====="
for path in "$SSHD" "$KEYGEN" "$CONFIG" "$HOST_KEY"; do
  if [[ -e "$path" ]]; then
    stat -c '[present] %a %U:%G %n' "$path"
  else
    echo "[missing] $path"
  fi
done

echo "===== Configuration and HostKey ====="
if [[ -x "$SSHD" && -f "$CONFIG" ]]; then
  "$SSHD" -t -f "$CONFIG"
  echo "sshd config status: $?"
  sha256sum "$CONFIG"
fi

if [[ -x "$KEYGEN" && -f "$HOST_KEY" ]]; then
  "$KEYGEN" -lf "$HOST_KEY"
fi
```

当前正常值应为：

```text
sshd config SHA256:
4b339ac9f51ec4364bc583f16ba0dceff3ccce9248392b1e8da4bb1d1f958213

HostKey fingerprint:
SHA256:MEMkjBwNP6qWTbVpdgxcDv36O7q86HsH1cdLmbovQ9g
```

如果 `sshd`、配置或 HostKey 缺失，不要继续执行启动命令，也不要重新生成 HostKey。应先恢复或重新安装用户级 OpenSSH，并核对原有安全配置。

## 5. 第三步：安全启动用户级 sshd

仅在上一节检查通过后，在服务器网页终端执行：

```bash
set -euo pipefail
umask 077

SSHD="/opt/conda/envs/user-sshd/bin/sshd"
KEYGEN="/opt/conda/envs/user-sshd/bin/ssh-keygen"
CONFIG="$HOME/.ssh/sshd/sshd_config"
HOST_KEY="$HOME/.ssh/sshd/ssh_host_ed25519_key.pub"
LOG="$HOME/.ssh/sshd/sshd.log"
RUN_PID="$HOME/.ssh/sshd/sshd_foreground.pid"

EXPECTED_CONFIG_SHA="4b339ac9f51ec4364bc583f16ba0dceff3ccce9248392b1e8da4bb1d1f958213"
EXPECTED_HOST_FP="SHA256:MEMkjBwNP6qWTbVpdgxcDv36O7q86HsH1cdLmbovQ9g"

echo "===== Verify persisted SSH identity ====="

[[ "$(sha256sum "$CONFIG" | awk '{print $1}')" == "$EXPECTED_CONFIG_SHA" ]]

ACTUAL_HOST_FP="$("$KEYGEN" -lf "$HOST_KEY" | awk '{print $2}')"
echo "HostKey fingerprint: $ACTUAL_HOST_FP"
[[ "$ACTUAL_HOST_FP" == "$EXPECTED_HOST_FP" ]]

"$SSHD" -t -f "$CONFIG"

echo "===== Handle prior PID metadata ====="

if [[ -f "$RUN_PID" ]]; then
  OLD_PID="$(cat "$RUN_PID")"

  if kill -0 "$OLD_PID" 2>/dev/null; then
    echo "[error] PID $OLD_PID is currently in use:"
    ps -p "$OLD_PID" -o pid=,stat=,cmd=
    echo "[stopped] nothing was killed or replaced"
    exit 1
  fi

  rm -f -- "$RUN_PID"
  echo "[cleaned] stale PID file"
fi

echo "===== Confirm port 22222 is free ====="

/opt/conda/bin/python - <<'PY'
import socket

with socket.socket() as sock:
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", 22222))

print("[ok] internal port 22222 is free")
PY

echo "===== Launch rootless sshd ====="

printf '\n===== Container restart %s =====\n' "$(date -Is)" >> "$LOG"

nohup "$SSHD" \
  -D \
  -e \
  -f "$CONFIG" \
  >> "$LOG" 2>&1 &

SSHD_PID=$!
PID_TMP="$HOME/.ssh/sshd/.sshd_foreground.pid.$$"
printf '%s\n' "$SSHD_PID" > "$PID_TMP"
mv -f -- "$PID_TMP" "$RUN_PID"

sleep 2

if ! kill -0 "$SSHD_PID" 2>/dev/null; then
  echo "[error] sshd exited during startup"
  tail -n 80 "$LOG"
  exit 1
fi

echo "===== Verify local SSH banner ====="

/opt/conda/bin/python - <<'PY'
import socket

with socket.create_connection(("127.0.0.1", 22222), timeout=5) as sock:
    banner = sock.recv(256).decode("ascii", errors="replace").strip()

print(f"banner: {banner}")

if not banner.startswith("SSH-2.0-"):
    raise SystemExit("unexpected SSH banner")
PY

ps -p "$SSHD_PID" -o pid=,stat=,cmd=
tail -n 30 "$LOG"

echo "[ok] rootless sshd restarted"
```

成功标志：

```text
[ok] internal port 22222 is free
banner: SSH-2.0-OpenSSH_...
[ok] rootless sshd restarted
```

横幅检查会主动连接后立即断开，因此日志中的以下信息是正常的：

```text
kex_exchange_identification: Connection closed by remote host [preauth]
```

## 6. 第四步：核对 Windows SSH 配置

在普通 Windows PowerShell 中查看解析后的配置：

```powershell
ssh -G zq5000-codex |
  Select-String '^(hostname|user|port|identityfile|userknownhostsfile|stricthostkeychecking) '
```

当前配置文件为：

```text
C:\Users\zhj\.ssh\config
```

当前主机块应类似：

```sshconfig
Host zq5000-codex
    HostName 10.10.49.27
    Port 8004
    User jovyan
    IdentityFile ~/.ssh/id_ed25519_zq5000_codex
    IdentitiesOnly yes
    PreferredAuthentications publickey
    PasswordAuthentication no
    HostKeyAlgorithms ssh-ed25519
    UserKnownHostsFile ~/.ssh/known_hosts_zq5000_codex
    StrictHostKeyChecking yes
    ConnectTimeout 10
    ServerAliveInterval 60
    ServerAliveCountMax 3
```

如果平台外部地址或端口变化，只修改 `HostName` 和 `Port`。不要修改内部端口配置，也不要关闭 `StrictHostKeyChecking`。

## 7. 第五步：检查 ssh-agent 与严格 SSH 登录

Windows 重启后先检查专用密钥是否已加载：

```powershell
$ExpectedFP = "SHA256:Han30ejK7XWrnOmSKQd0trCVK9bMY4ilJsLK1Gl5wRU"
$AgentKeys = @(ssh-add -l 2>$null)
$AgentKeys

if ($AgentKeys -notmatch [regex]::Escape($ExpectedFP)) {
    ssh-add "$env:USERPROFILE\.ssh\id_ed25519_zq5000_codex"
}
```

然后测试端口和严格公钥登录：

```powershell
Test-NetConnection -ComputerName 10.10.49.27 -Port 8004

ssh -o BatchMode=yes zq5000-codex `
  "printf '[remote-ok]\n'; hostname; whoami; pwd"
```

成功时应看到：

```text
TcpTestSucceeded : True
[remote-ok]
<新容器 hostname>
jovyan
/home/jovyan
```

### HostKey 不匹配时

如果出现 `REMOTE HOST IDENTIFICATION HAS CHANGED`：

1. 停止连接；
2. 在服务器网页终端运行 `ssh-keygen -lf ~/.ssh/sshd/ssh_host_ed25519_key.pub`；
3. 与本文记录的服务器 HostKey 指纹比较；
4. 只有在确认服务器确实合法更换了 HostKey 后，才能更新专用 `known_hosts`。

不要为了快速连接而使用 `StrictHostKeyChecking=no`，也不要未经核验直接删除 `known_hosts`。

## 8. 第六步：重建 Windows 反向代理隧道

先确认 Windows 本地代理仍监听 `7890`：

```powershell
$ProxyListener = Get-NetTCPConnection `
  -LocalPort 7890 `
  -State Listen `
  -ErrorAction SilentlyContinue |
  Select-Object -First 1

if ($null -eq $ProxyListener) {
    throw "Windows 本地代理 127.0.0.1:7890 未监听"
}

"[ok] local proxy PID: $($ProxyListener.OwningProcess)"
```

再执行以下脚本。它不会根据旧 PID 盲目终止进程：

```powershell
$ErrorActionPreference = "Stop"

$SshExe = (Get-Command ssh.exe).Source
$SshDir = Join-Path $env:USERPROFILE ".ssh"
$Config = Join-Path $SshDir "config"
$PidFile = Join-Path $SshDir "zq5000_codex_reverse_socks.pid"
$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$Stdout = Join-Path $SshDir "zq5000_codex_reverse_socks_$Stamp.stdout.log"
$Stderr = Join-Path $SshDir "zq5000_codex_reverse_socks_$Stamp.stderr.log"

if (Test-Path -LiteralPath $PidFile) {
    $StoredPid = (Get-Content -LiteralPath $PidFile -Raw).Trim()
    $Existing = $null

    if ($StoredPid -match '^\d+$') {
        $Existing = Get-CimInstance Win32_Process `
          -Filter "ProcessId=$StoredPid" `
          -ErrorAction SilentlyContinue
    }

    if ($null -ne $Existing) {
        "PID $StoredPid is currently in use by $($Existing.Name)"
        $Existing.CommandLine
        throw "PID file is not stale; nothing was changed"
    }

    Remove-Item -LiteralPath $PidFile -Force
    "[cleaned] stale reverse-tunnel PID file"
}

$ProxyListener = Get-NetTCPConnection `
  -LocalPort 7890 `
  -State Listen `
  -ErrorAction SilentlyContinue |
  Select-Object -First 1

if ($null -eq $ProxyListener) {
    throw "Windows local proxy 127.0.0.1:7890 is not listening"
}

$Arguments = @(
    "-F", $Config,
    "-N",
    "-T",
    "-o", "BatchMode=yes",
    "-o", "ExitOnForwardFailure=yes",
    "-o", "ServerAliveInterval=30",
    "-o", "ServerAliveCountMax=3",
    "-R", "127.0.0.1:1080:127.0.0.1:7890",
    "zq5000-codex"
)

$Process = Start-Process `
  -FilePath $SshExe `
  -ArgumentList $Arguments `
  -PassThru `
  -WindowStyle Hidden `
  -RedirectStandardOutput $Stdout `
  -RedirectStandardError $Stderr

Start-Sleep -Seconds 3

if ($Process.HasExited) {
    Get-Content -LiteralPath $Stderr -ErrorAction SilentlyContinue
    throw "Reverse tunnel exited during startup"
}

[IO.File]::WriteAllText(
    $PidFile,
    "$($Process.Id)`r`n",
    [Text.UTF8Encoding]::new($false)
)

"[ok] reverse tunnel running PID=$($Process.Id)"
"stderr log: $Stderr"
```

该命令只允许服务器在回环地址建立 `1080` 监听，并把流量转发到 Windows 本地代理 `7890`。服务端安全边界应继续保持：

```sshconfig
AllowTcpForwarding remote
PermitListen 127.0.0.1:1080
GatewayPorts no
```

### 8.1 推荐：使用自动重连守护脚本

一次性 `ssh -N -R` 在网络连接被重置后会直接退出，不会自行重连。当前已安装守护脚本：

```text
C:\Users\zhj\.ssh\zq5000_codex_tunnel_watchdog.ps1
```

项目中的规范副本位于：

```text
E:\Codex\2026-06-06\mamba-ccf-c-1-high-resolution\references\server_operations\scripts\zq5000_codex_tunnel_watchdog.ps1
```

守护脚本会：

- 保证同一用户会话中只运行一个实例；
- 等待 Windows 本地代理 `127.0.0.1:7890` 可用；
- 建立受限反向转发 `127.0.0.1:1080 -> 127.0.0.1:7890`；
- 使用 SSH keepalive 检测失效连接；
- 断线后按 5 至 60 秒退避自动重试；
- 记录守护进程和 SSH 子进程 PID；
- 将日志限制为当前文件和一个最大约 5 MiB 的历史文件。

Windows 登录或重启后，在普通 PowerShell 中启动一次：

```powershell
$ErrorActionPreference = "Stop"

$Script = Join-Path `
  $env:USERPROFILE `
  ".ssh\zq5000_codex_tunnel_watchdog.ps1"

$PidFile = Join-Path `
  $env:USERPROFILE `
  ".ssh\zq5000_codex_tunnel_watchdog.pid"

$AlreadyRunning = $false

if (Test-Path -LiteralPath $PidFile) {
    $StoredPid = (Get-Content -LiteralPath $PidFile -Raw).Trim()

    if ($StoredPid -match '^\d+$') {
        $Existing = Get-CimInstance Win32_Process `
          -Filter "ProcessId=$StoredPid" `
          -ErrorAction SilentlyContinue

        $AlreadyRunning = (
            $null -ne $Existing -and
            $Existing.Name -ieq "powershell.exe" -and
            $Existing.CommandLine -match "zq5000_codex_tunnel_watchdog\.ps1"
        )
    }
}

if ($AlreadyRunning) {
    "[kept] watchdog already running PID=$StoredPid"
}
else {
    if (Test-Path -LiteralPath $PidFile) {
        Remove-Item -LiteralPath $PidFile -Force
    }

    Start-Process `
      -FilePath powershell.exe `
      -ArgumentList @(
          "-NoProfile",
          "-ExecutionPolicy", "Bypass",
          "-File", $Script
      ) `
      -WindowStyle Hidden

    Start-Sleep -Seconds 6
    Get-Content -LiteralPath $PidFile
    "[ok] tunnel watchdog started"
}
```

查看状态和日志：

```powershell
$SshDir = Join-Path $env:USERPROFILE ".ssh"

"watchdog PID: $((Get-Content (Join-Path $SshDir 'zq5000_codex_tunnel_watchdog.pid') -Raw).Trim())"
"SSH child PID: $((Get-Content (Join-Path $SshDir 'zq5000_codex_tunnel_child.pid') -Raw).Trim())"

Get-Content `
  -LiteralPath (Join-Path $SshDir "zq5000_codex_tunnel_watchdog.log") `
  -Tail 30
```

正常日志示例：

```text
[start] watchdog_pid=<PID> host=zq5000-codex forward=127.0.0.1:1080:127.0.0.1:7890
[connect] starting SSH reverse tunnel
[connected] child_pid=<PID>
```

网络中断后应出现：

```text
[disconnected] ...
[retry] waiting 5s
[connect] starting SSH reverse tunnel
[connected] child_pid=<new PID>
```

该守护脚本可以处理运行期间的网络波动，但 Windows 关机后进程仍会终止。目前没有注册计划任务；每次 Windows 重新启动或登录后，需要运行一次上述启动命令。

## 9. 第七步：验证服务器代理出口

在 Windows PowerShell 中执行：

```powershell
$ErrorActionPreference = "Stop"

echo "===== Verify remote port 1080 ====="

@'
import socket

with socket.socket() as sock:
    sock.settimeout(3)
    result = sock.connect_ex(("127.0.0.1", 1080))

print("proxy1080=" + ("listening" if result == 0 else f"not-listening:{result}"))
raise SystemExit(0 if result == 0 else 1)
'@ | ssh -o BatchMode=yes zq5000-codex 'python -'

if ($LASTEXITCODE -ne 0) {
    throw "服务器 127.0.0.1:1080 未监听"
}

echo "===== Verify OpenAI through reverse proxy ====="

$HttpCode = (& ssh -o BatchMode=yes zq5000-codex `
  "curl --proxy socks5h://127.0.0.1:1080 --silent --show-error --output /dev/null --write-out '%{http_code}' --connect-timeout 10 https://api.openai.com/v1/models").Trim()

$SshExitCode = $LASTEXITCODE

"openai_http=$HttpCode"

if ($SshExitCode -ne 0 -or $HttpCode -ne "401") {
    throw "代理出口验证失败：ssh=$SshExitCode http=$HttpCode"
}

echo "[ok] reverse proxy verified"
```

这里必须把 Python 源码通过管道送入远端 `python -`。不要把整段 PowerShell here-string 直接放在 `ssh zq5000-codex` 后面作为远程命令参数；Windows 原生命令参数转换可能移除其中的 Python 引号，使 `"127.0.0.1"` 变成无引号的 `127.0.0.1`，从而触发 `SyntaxError`。

未携带 API 密钥时，正常结果为：

```text
proxy1080=listening
openai_http=401
[ok] reverse proxy verified
```

`401` 表示网络和 TLS 链路已经抵达 OpenAI，只是该探测请求没有认证；这正是本步骤的预期结果。

## 10. 第八步：核验远端 Codex

```powershell
ssh -o BatchMode=yes zq5000-codex `
  'bash -lc "command -v codex; codex --version; test -d /home/jovyan/adapointr_work/PoinTr"'
```

当前预期输出包括：

```text
/home/jovyan/.local/codex-proxy-bin/codex
codex-cli 0.153.4
```

以下警告一般不妨碍运行：

```text
WARNING: failed to clean up stale arg0 temp dirs: Directory not empty (os error 39)
```

它表示 Codex CLI 未能清理某个旧临时目录，不代表 SSH、代理或 Codex 登录失败。不要因此删除项目目录或 `.codex` 目录。

## 11. 第九步：恢复 Codex 桌面端连接

1. 打开 **Settings -> Connections -> SSH**；
2. 找到 `zq5000-codex`；
3. 如果仍显示旧容器的重连状态，将连接关闭后重新开启一次；
4. 返回项目列表，打开远程项目 **PoinTr**；
5. 项目目录应为 `/home/jovyan/adapointr_work/PoinTr`；
6. 可以重新打开原远程任务；若旧任务仍卡在重连界面，则在 **PoinTr** 项目中新建任务。

建议发送以下只读测试：

```text
只做远程环境检查，不修改文件。请输出 pwd、hostname、whoami、codex --version 和 nvidia-smi。
```

成功标准：

- `pwd` 为 `/home/jovyan/adapointr_work/PoinTr`；
- `whoami` 为 `jovyan`；
- `codex --version` 能正常返回版本；
- `nvidia-smi` 能识别 `NVIDIA GeForce RTX 4090 D`；
- 不再反复显示 `Reconnecting... waiting for network`。

## 12. 快速故障定位

| 现象 | 常见原因 | 处理顺序 |
|---|---|---|
| `Test-NetConnection` 为 `False` | `sshd` 未启动，或外部映射改变 | 检查平台映射，再执行第 5 节 |
| `Connection refused` | 容器内部 `22222` 未监听 | 检查 `sshd_foreground.pid` 和 `sshd.log` |
| `Permission denied (publickey)` | 认证配置或客户端密钥不匹配 | 核对客户端指纹与服务器日志 |
| HostKey changed | 端点变化或 HostKey 被替换 | 停止连接，人工比对服务器指纹 |
| `ssh` 成功但服务器 `1080` 不监听 | Windows 反向隧道未启动 | 执行第 8 节 |
| `1080` 监听但访问 OpenAI 失败 | Windows `7890` 代理失效或隧道刚启动 | 先测本地代理，等待数秒后重测 |
| Codex 一直重连 | App Server 属于旧容器，或代理尚未恢复 | 恢复代理后关闭并重启 SSH 连接 |
| `codex` 在普通远程命令中找不到 | 非登录 shell 未加载环境 | 使用 `bash -lc 'codex --version'` |

查看服务端日志：

```bash
tail -n 120 "$HOME/.ssh/sshd/sshd.log"
```

查看 Windows 最新隧道错误日志：

```powershell
Get-ChildItem "$env:USERPROFILE\.ssh" `
  -Filter 'zq5000_codex_reverse_socks_*.stderr.log' |
  Sort-Object LastWriteTime -Descending |
  Select-Object -First 1 |
  Get-Content
```

## 13. 安全注意事项

- 永远不要上传或发送客户端私钥 `id_ed25519_zq5000_codex`；
- 不要关闭严格 HostKey 校验；
- 不要因 PID 文件存在就直接执行 `kill`；PID 可能被新容器中的其他进程复用；
- 不要把服务器代理监听改成 `0.0.0.0:1080`；应只绑定 `127.0.0.1:1080`；
- 不要开放密码认证；继续使用固定 ED25519 公钥；
- 不要删除 `/home/jovyan/.ssh`、`/home/jovyan/.codex`、`.bash_profile` 或 Codex 代理包装器；
- 新容器 hostname 和内部 IP 变化通常正常，外部映射和 HostKey 才是连接核验重点；
- 如果持久化卷、HostKey 或客户端密钥确实发生变化，应停止并重新建立信任链，不能套用旧指纹继续连接。

## 14. 当前已验证状态

最近一次恢复已验证：

```text
远端目录: /home/jovyan/adapointr_work/PoinTr
远端用户: jovyan
Codex: codex-cli 0.153.4
GPU: NVIDIA GeForce RTX 4090 D
Windows -> SSH: 正常
Windows 7890 -> server 1080: 正常
server 1080 -> OpenAI: 正常，未认证探测返回 HTTP 401
```

本手册中的固定哈希和指纹只适用于当前安全配置。若以后主动修改 `sshd_config`、重新生成 HostKey 或更换客户端密钥，应同步更新本手册中的对应值。
