# Codex 远程服务器实验操作规范

## 1. 文档目的

本文用于约束和指导 Codex 通过 SSH 远程连接自强 5000 后，在服务器项目中开展以下工作：

- 阅读、分析和修改实验代码；
- 修改配置文件和运行脚本；
- 执行单元测试、契约测试和 preflight；
- 执行推理、性能分析和 GPU 实验；
- 启动、观察和终止长时间任务；
- 冻结、校验、归档和下载实验结果；
- 清理服务器运输文件和临时产物；
- 在容器销毁、网络中断或 Codex 重连后安全恢复。

本文默认项目位置为：

```text
/home/jovyan/adapointr_work/PoinTr
```

默认远程用户为：

```text
jovyan
```

默认原则是：**先确认环境和边界，再修改；先测试和 preflight，再执行；先冻结和下载，再清理；任何权限均不得自动升级。**

## 2. 可直接粘贴给远程任务的首条指令

在 Codex 桌面端打开远程项目 **PoinTr** 后，可以把下面内容作为新任务的第一条消息：

```text
你当前工作在自强 5000 远程服务器项目：
/home/jovyan/adapointr_work/PoinTr

请遵守以下操作边界：

1. 首先只读检查 pwd、hostname、whoami、当前时间、磁盘空间、GPU 状态、Python/Conda 环境、Git 状态以及工作区现有修改，不要立即修改文件。
2. 确认当前目录确实是 /home/jovyan/adapointr_work/PoinTr；若路径、主机或用户不符，立即停止。
3. 在修改前列出拟修改文件、理由、影响范围、验证方法和回滚依据。
4. 不覆盖、不回退、不删除任何无法确认来源的现有修改或实验结果。
5. 默认只允许只读诊断。代码修改、配置修改、正式实验、训练、数据访问、结果覆盖和文件删除必须分别获得与其范围匹配的明确授权。
6. preflight 不得执行训练、optimizer step、模型更新、正式计时循环或访问未授权数据。
7. 不得从一次测试、preflight 或实验结果自动推导出下一阶段授权。
8. 长时间任务必须使用 tmux，并记录会话名、主日志路径、PID/退出码和启动时间。
9. 正式结果必须写入新的不可变目录；如果目标目录已存在，默认停止，不得覆盖。
10. 结果必须包含机器可读指标、中文报告、SHA256 清单、运行环境和权限边界说明。
11. 删除任何服务器文件前，必须先生成精确删除清单、核对绝对路径、验证保留产物，并确认本机下载或其他持久副本存在。
12. 不读取、打印或上传私钥、令牌、Cookie、auth.json 内容或其他秘密；只允许报告存在性、权限和必要的非秘密指纹。
13. 每次回复都明确报告：做了什么、修改了哪些文件、运行了哪些命令/测试、结果如何、哪些工作未执行、当前仍锁定的权限。

现在先执行只读环境审计并报告结果，不要创建或修改文件。
```

这段首条指令只是默认安全边界。具体实验仍应补充目标、父结果、允许的数据、允许的运行次数和明确禁止项。

## 3. 远程任务身份与路径核验

每个新任务、重连后的任务以及准备正式执行前，都应首先核验：

```bash
set +e

echo "===== Identity ====="
pwd
hostname
whoami
id
date -Is

echo "===== Project boundary ====="
PROJECT_ROOT="/home/jovyan/adapointr_work/PoinTr"
printf 'expected=%s\n' "$PROJECT_ROOT"
printf 'actual=%s\n' "$(pwd -P)"
[[ "$(pwd -P)" == "$PROJECT_ROOT" ]] && echo "[ok] project root" || echo "[error] wrong project root"

echo "===== Filesystem ====="
df -h /home/jovyan
du -sh "$PROJECT_ROOT" 2>/dev/null

echo "===== GPU ====="
nvidia-smi --query-gpu=name,driver_version,memory.total,memory.used,utilization.gpu,temperature.gpu,power.draw \
  --format=csv,noheader 2>/dev/null || nvidia-smi

echo "===== Python and Conda ====="
command -v conda || true
conda info --base 2>/dev/null || true
conda env list 2>/dev/null || true
command -v python || true
python --version 2>/dev/null || true

echo "===== Git ====="
if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git status --short --branch
  git rev-parse --show-toplevel
  git rev-parse HEAD
else
  echo "[warning] current directory is not a Git worktree"
fi
```

必须核对以下事项：

- `pwd -P` 是否为预期项目根目录；
- `hostname` 是否为当前新容器；
- `whoami` 是否为 `jovyan`；
- `/home/jovyan` 剩余空间是否足够；
- GPU 是否空闲，是否存在其他进程；
- 当前 Python 是否来自预期 Conda 环境；
- 当前目录是否为 Git 仓库；
- 是否存在用户或其他任务留下的未提交修改。

如果路径、用户、数据挂载或父结果不符合预期，应停止，不得通过猜测路径继续执行。

## 4. 权限分级与授权规则

### 4.1 L0：只读诊断

默认允许：

- 查看源代码、配置、日志和文本报告；
- 查看 Git 状态、提交和差异；
- 查看进程、GPU、磁盘和环境版本；
- 校验现有 SHA256 清单；
- 分析错误并提出方案。

默认禁止：

- 创建或修改文件；
- 安装依赖；
- 启动测试、推理或训练；
- 删除、移动或覆盖文件；
- 改变服务器服务和网络配置。

### 4.2 L1：代码实现与非执行验证

需要明确授权，授权应说明允许修改的模块和目标。可以包括：

- 修改代码、配置模板和文档；
- 新增单元测试或契约测试；
- 执行静态检查、语法检查和不进入模型计算的测试；
- 生成待审核的 overlay 或补丁。

仍然禁止自动进入 GPU 推理、正式计时或训练。

### 4.3 L2：preflight 与人工零步验证

需要单独授权，并明确固定输入、次数和输出目录。preflight 应满足：

- optimizer steps 为 `0`；
- model updates 为 `0`；
- 不产生训练 checkpoint；
- 不进入正式 benchmark 计时循环；
- 不访问未授权数据；
- 不改变已冻结结果；
- 只能写入新的、预先指定的 preflight 目录。

### 4.4 L3：推理、profiling 或性能 benchmark

需要单独的执行授权。授权至少应包含：

- 精确候选实现和父提交/父哈希；
- 数据来源或人工输入定义；
- warmup、计时次数、同步方法和统计指标；
- GPU 和软件环境；
- 固定结果目录；
- 是否允许重跑；
- 通过与失败后的唯一下一步。

结果未通过时不得自行修改实现并重跑。

### 4.5 L4：训练或模型更新

训练属于独立的高权限阶段，必须明确授权：

- 数据集、分区和封存边界；
- 配置、随机种子、fold 和 checkpoint 初始状态；
- optimizer、scheduler、epoch/step 上限；
- GPU 数量与资源预算；
- 输出路径、恢复策略和停止条件；
- 是否允许 seed-1、confirmation 或后续分支。

任何零步验证、推理结果或性能通过都不能自动授权训练。

### 4.6 L5：删除、归档与系统变更

以下操作需要单独明确授权：

- 删除或移动文件；
- 清理数据集、中间结果、归档或运输文件；
- 修改 SSH、代理、Conda、驱动或系统配置；
- 安装或升级依赖；
- 推送 Git 分支或 tag；
- 覆盖现有冻结结果。

授权必须具体到路径、文件类别和操作类型。“继续处理”不能解释为允许删除或覆盖。

## 5. 修改实验代码前的检查

修改前应完成：

1. 阅读目标模块及其调用方；
2. 搜索已有实现、测试和命名约定；
3. 检查工作区是否存在非本任务修改；
4. 确认源文件换行符和编码；
5. 确认父提交或父文件 SHA256；
6. 列出拟修改文件和验证计划；
7. 确认修改不会越过数据、训练或性能执行权限。

推荐命令：

```bash
rg --files
rg -n "目标符号或配置名" .
git status --short --branch 2>/dev/null || true
git diff --stat 2>/dev/null || true
git diff --check 2>/dev/null || true
file path/to/file
sha256sum path/to/file
```

如果当前目录不是 Git 仓库，应明确说明风险：

- 无法依赖 `git diff` 确定改动范围；
- 无法通过 commit 恢复；
- 必须对重要父文件记录 SHA256；
- 修改前应建立经过校验的本机或服务器副本；
- 不得以“清理”为名删除看似重复但来源不明的文件。

## 6. 代码修改规则

- 遵循仓库现有模块边界、命名和代码风格；
- 保持修改范围最小，不夹带无关重构；
- 不覆盖用户已有修改；
- 不擅自改变随机种子、数据划分、metric、阈值或统计方法；
- 不为了让测试通过而降低断言或改变冻结期望值；
- 不把人工输入结果标记为正式数据实验；
- 不把 profiling 结果解释为训练或生产授权；
- 对复杂逻辑添加简短且必要的注释；
- 修改后执行格式检查、语法检查和针对性测试；
- 报告每个修改文件及其行为变化。

若需要替换大段结构化配置，应使用 JSON/YAML 解析器等结构化方法，避免脆弱的字符串替换。

## 7. 配置文件管理

实验配置应区分：

- 模板：只描述允许填写的字段；
- 运行时配置：绑定本次执行的实际值；
- 协议：冻结规则、输入和门控；
- 授权：允许执行的唯一范围；
- 凭据：证明执行前条件满足；
- 结果：记录不可变输出和下一步。

配置变更前后应记录：

```bash
sha256sum path/to/config.json
python -m json.tool path/to/config.json >/dev/null
```

不得在正式执行后修改同一份 runtime config。需要修订时，应创建新版本并重新完成协议或授权流程。

## 8. 测试与 preflight

### 8.1 测试顺序

推荐顺序：

1. 语法与导入测试；
2. 目标模块单元测试；
3. 契约测试；
4. 人工输入正确性测试；
5. 零计数 CPU/CUDA preflight；
6. 经授权的正式推理或 benchmark。

不要一开始就运行完整测试套件或占用 GPU。

### 8.2 preflight 必须回答的问题

- 输入和父产物是否与协议一致；
- 运行时配置是否与授权一致；
- 输出目录是否不存在；
- GPU、Python、PyTorch 和 CUDA 是否符合要求；
- 是否能够构造模型但不执行正式计时；
- 计数器是否保持为零；
- 禁止的数据和阶段是否仍不可访问；
- preflight 是否可重复且不会产生正式结果。

### 8.3 失败处理

测试或 preflight 失败时：

1. 立即停止后续阶段；
2. 确认失败前是否产生副作用；
3. 列出已创建文件和进程；
4. 只读诊断根因；
5. 区分代码错误、导入错误、换行符差异、哈希漂移、环境差异和权限边界错误；
6. 如需 hotfix，单独提交并重新校验；
7. 不使用删除断言、跳过验证或放宽哈希来绕过失败。

## 9. 推理与 GPU 实验启动规范

### 9.1 启动前

```bash
nvidia-smi --query-gpu=name,utilization.gpu,memory.used,memory.total \
  --format=csv,noheader

df -h /home/jovyan
```

应确认：

- GPU 没有未知任务占用；
- 显存满足本次运行要求；
- 磁盘足以保存日志、trace、checkpoint 和结果；
- 授权、preflight 和 runtime config 的哈希均通过；
- 正式结果目录尚不存在；
- 重跑策略已经明确。

### 9.2 长时间任务必须使用 tmux

推荐结构：

```bash
SESSION="descriptive-experiment-name-v1"
LOG_DIR="/home/jovyan/adapointr_work/PoinTr/logs/<experiment>/tmux_v1"
mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/tmux_$(date +%Y%m%d_%H%M%S).log"

tmux new-session -d -s "$SESSION" \
  "bash -lc 'cd /home/jovyan/adapointr_work/PoinTr && <authorized-command>; status=\$?; echo \"[tmux] exit status: \$status\"; exit \$status' 2>&1 | tee '$LOG'"

echo "session: $SESSION"
echo "log: $LOG"
```

启动后立即记录：

- tmux 会话名；
- 主日志绝对路径；
- 启动时间；
- GPU 状态；
- 精确命令或运行配置；
- 预期输出目录。

### 9.3 观察任务

```bash
tmux list-sessions
tmux attach -t <session-name>
tail -n 300 <master-log>
nvidia-smi
```

`tail -f` 会持续等待新内容；看到最终 `[done]` 和退出状态后，按 `Ctrl+C` 退出 `tail -f`，这不会停止已经完成的实验。

### 9.4 不得误判完成

以下情况不等于实验成功：

- tmux 会话消失；
- GPU 利用率降为零；
- 进程退出码为零；
- 结果目录存在；
- 日志出现 `[saved]`。

还必须验证结果清单、语义门控、计数器和报告。

## 10. 网络与 Codex 连接注意事项

服务器通过 Windows 反向代理访问 OpenAI：

```text
服务器 127.0.0.1:1080
  -> SSH 反向转发
  -> Windows 127.0.0.1:7890
  -> Internet/OpenAI
```

在远程任务中只允许检查代理是否工作，不应修改 SSH 或代理配置，除非用户单独授权。

安全检查：

```bash
python - <<'PY'
import socket

with socket.socket() as sock:
    sock.settimeout(3)
    result = sock.connect_ex(("127.0.0.1", 1080))

print("listening" if result == 0 else f"not-listening:{result}")
PY

curl \
  --proxy socks5h://127.0.0.1:1080 \
  --silent \
  --show-error \
  --output /dev/null \
  --write-out '%{http_code}\n' \
  --connect-timeout 10 \
  https://api.openai.com/v1/models
```

未携带 API 密钥的网络探测返回 `401` 表示已经抵达 OpenAI。不要在日志中打印 API key、Cookie 或 `/home/jovyan/.codex/auth.json` 内容。

如果 Codex 显示重连：

1. 不要立即重复启动实验；
2. 先通过网页终端检查 tmux 和日志；
3. 检查服务器 `sshd` 是否仍运行；
4. 检查 Windows 反向隧道是否仍运行；
5. 恢复连接后先核对原任务是否已经完成或仍在运行。

## 11. 实验结果目录与不可变性

正式结果应采用带版本号的新目录，例如：

```text
logs/<research-line>/<experiment-name>_result_v1
```

规则：

- 创建前要求目标目录不存在；
- 运行结束后不再修改目录内结果；
- 修订或重跑使用 `v2` 或新的明确名称；
- 不将临时日志混入冻结结果；
- 不把 checkpoint、原始数据或密封数据默认放入轻量归档；
- 报告中注明排除项。

建议冻结内容：

- 原始机器可读指标 CSV/JSON；
- 汇总 JSON；
- 中文结果报告；
- 环境信息；
- runtime config；
- 授权与 preflight 凭据；
- 关键父文件哈希；
- `files.sha256`；
- 结果冻结凭据；
- 必要的 profiler trace。

生成清单：

```bash
cd <result-directory>
find . -maxdepth 1 -type f ! -name files.sha256 -print0 \
  | sort -z \
  | xargs -0 sha256sum > files.sha256

sha256sum -c files.sha256
```

注意：如果文件名、换行符或清单格式有冻结要求，应使用项目现有的归档/验证工具，不应临时重写清单。

## 12. 结果分析规则

- 区分正确性门控与性能门控；
- 区分描述性 profiling 与因果结论；
- 报告 min、median、mean、p95、max 时说明样本数和统计单位；
- 比率必须明确分子与分母；
- CUDA 计时必须说明同步位置；
- 峰值显存必须说明是否重置和同步；
- 人工数据结果不能外推为真实 D6 数据结果；
- 单卡单次结果不能声称具有跨设备稳定性；
- 负结果必须保留，不应通过选择性重跑隐藏；
- 若失败，报告失败门控、实际值、阈值和唯一允许的下一步。

## 13. 归档、下载与恢复验证

归档前必须：

1. 重新验证冻结结果；
2. 明确归档包含项和排除项；
3. 生成 payload manifest；
4. 创建压缩包；
5. 在独立临时目录恢复；
6. 验证恢复后的清单和语义；
7. 输出压缩包字节数、SHA256 和内容清单。

常见下载包包括：

```text
<name>.tar.gz
<name>.tar.gz.sha256
<name>.bytes
<name>.tar_contents.txt
```

用户确认本机下载完成并核验之前，不得删除服务器归档副本。

## 14. 删除与清理规范

删除应分为两个阶段。

### 14.1 只读清单阶段

- 列出候选文件的绝对路径；
- 统计文件数和总字节数；
- 计算 SHA256；
- 验证候选路径位于允许删除根目录；
- 验证保留目录和保留产物；
- 对无法分类的文件保持不动。

### 14.2 经授权删除阶段

删除前冻结：

- `deleted_files.tsv`；
- cleanup receipt；
- 删除数量和总字节数；
- 保留产物验证结果。

删除后再次验证：

- 候选文件全部不存在；
- 保留结果仍通过 `sha256sum -c`；
- cleanup receipt 本身完好；
- 磁盘空间变化合理。

禁止：

- 使用未经展开和验证的宽泛通配符删除；
- 删除整个 `/home/jovyan`、项目根、数据集根或日志根；
- 因为文件“看起来旧”就删除；
- 删除未下载的唯一归档；
- 删除正在被 tmux/进程写入的日志或结果；
- 删除未知来源的隐藏目录。

## 15. 数据集与密封数据边界

每项实验必须明确：

- 可以访问的数据集根目录；
- 可以访问的 split、fold 和 case ID；
- 是否允许访问 development、test 或 sealed 数据；
- 是否允许读取 STL、NPZ、checkpoint 或缓存；
- 输出是否可能泄漏密封分区信息。

默认规则：

- 未明确授权的数据一律不可访问；
- D6 development/test/sealed 等命名不等同于自动授权；
- 人工 descriptor 或人工矩阵实验不得读取真实 D6 case；
- 只读访问也属于数据访问，必须在授权范围内；
- 报告应记录实际访问 case 数量。

## 16. 依赖和环境管理

- 优先使用现有 Conda 环境；
- 不在 `base` 环境随意升级核心依赖；
- 不自动升级 PyTorch、CUDA、SciPy、timm 或编译扩展；
- 安装前记录环境、包版本和磁盘空间；
- 安装行为需要明确授权；
- 避免使用无版本约束的全局安装；
- 环境变更后重新执行导入、CUDA 和关键算子测试。

记录环境：

```bash
which python
python --version
python -c 'import torch; print(torch.__version__); print(torch.version.cuda); print(torch.cuda.is_available())'
python -c 'import scipy; print(scipy.__version__)'
conda list
```

完整 `conda list` 可能较长，正式归档可以写入文件；聊天回复只需汇报关键版本和保存路径。

## 17. Git、commit 和 tag

如果项目是 Git 仓库：

- 修改前执行 `git status --short --branch`；
- 不回退用户已有修改；
- 只暂存本任务文件；
- commit 前运行目标测试和 `git diff --check`；
- annotated tag 必须指向预期 commit；
- push 需要用户明确授权；
- push 后使用 `git ls-remote` 核对分支和 tag；
- 不使用 `git reset --hard`、`git checkout --` 或强制推送，除非用户明确要求且风险已说明。

如果服务器工作目录不是 Git 仓库：

- 明确报告该事实；
- 不执行初始化仓库，除非用户授权；
- Git commit/tag 通常应在本机的规范仓库完成；
- 通过带 manifest 的 overlay 将精确文件运输到服务器；
- 安装 overlay 前拒绝已有实现漂移。

## 18. 运输 overlay 规范

运输包建议包含：

```text
<overlay>.tar.gz
<overlay>.tar.gz.sha256
<overlay>.contents.sha256
<overlay>.contents.sha256.sha256
<overlay>.bytes
```

服务器安装前必须：

- 验证五个运输文件存在且非空；
- 验证压缩包 SHA256 和字节数；
- 检查归档成员不含绝对路径、`..`、链接或设备文件；
- 验证成员清单；
- 对目标文件执行 drift 检查；
- 安装后再次校验 canonical 文件哈希。

注意 Windows 上传界面可能把超长文件名缩短。文件名异常时，应先根据字节数和 SHA256 确认，再精确重命名，不能只凭相似名称猜测。

## 19. 容器销毁与重连后的恢复

容器重建后：

1. 按 [自强 5000 新容器与 Codex 远程连接恢复手册](./zq5000_codex_reconnect_guide.md) 恢复 SSH 和反向代理；
2. 打开远程项目，不要误在本机项目任务中执行服务器实验；
3. 重新核对 hostname、项目路径、GPU、磁盘和 Conda；
4. 查看原 tmux 会话是否仍存在；容器销毁后通常不存在；
5. 查看持久化结果目录、日志和冻结凭据；
6. 不因会话消失就自动重跑；
7. 根据冻结结果和退出凭据判断是否需要重新授权。

容器销毁会终止进程，但不一定删除 `/home/jovyan` 持久化文件。因此恢复时应先检查结果是否已经写入，避免重复执行。

## 20. 任务完成报告模板

远程任务完成后应按以下格式汇报：

```text
状态：完成 / 失败 / 已安全停止

环境：
- hostname：
- 工作目录：
- 用户：
- Conda/Python：
- GPU：

执行边界：
- 获得的授权：
- 保持锁定的权限：
- 实际访问的数据：
- optimizer steps / model updates：

文件修改：
- 修改：
- 新增：
- 删除：
- 未触碰的重要文件：

验证：
- 测试命令：
- 测试结果：
- preflight：
- 结果清单验证：

实验结果：
- 结果目录：
- 主日志：
- 核心指标：
- 门控结论：
- SHA256：

遗留事项：
- 未执行：
- 已知风险：
- 下一步建议：
```

## 21. 推荐的阶段化提示词

### 21.1 只读诊断

```text
只做只读诊断。核对远端身份、项目路径、Git/文件状态、GPU、磁盘、环境和父结果哈希。不要创建或修改文件，不要启动测试、推理或训练。报告发现的问题和建议的最小下一步。
```

### 21.2 实现修改

```text
授权你仅修改以下文件/模块：<范围>，目标是：<目标>。修改前检查现有变化并说明方案；修改后只运行不涉及训练和正式 GPU benchmark 的针对性测试。不得访问未授权数据，不得覆盖冻结结果，不得自动进入下一阶段。
```

### 21.3 preflight

```text
授权执行本协议的零计数 preflight。必须保持 optimizer_steps=0、model_updates=0，不进入正式计时循环，不访问 <禁止数据>，只允许写入 <preflight 目录>。失败时停止并检查副作用，不得自动修复后重跑正式实验。
```

### 21.4 单次 GPU 实验

```text
授权按已冻结协议和 runtime config 启动一次 <实验名>。只允许 <输入/数据>、<次数> 和 <输出目录>。必须使用 tmux，记录日志与退出码；结果无论正负都冻结。不得重跑、训练、访问其他数据或自动授权后续阶段。
```

### 21.5 归档

```text
授权对已冻结结果创建一份最小归档并执行独立恢复验证。包含 <内容>，排除 checkpoint、原始数据和密封数据。输出 tar.gz、SHA256、字节数和内容清单。不得删除服务器原件。
```

### 21.6 清理

```text
先只读生成精确删除候选清单，验证本机归档和服务器保留结果，不执行删除。待我确认清单后，再单独授权删除明确列出的文件；不得使用宽泛通配符，不得触碰未分类文件或隐藏目录。
```

## 22. 最终检查清单

在任何正式实验前确认：

- [ ] 当前任务确实属于远程项目 **PoinTr**；
- [ ] `pwd -P`、`hostname`、`whoami` 已核验；
- [ ] Git 或父文件状态已记录；
- [ ] 未知修改没有被覆盖或回退；
- [ ] GPU、磁盘和环境满足要求；
- [ ] 协议、授权、preflight 和 runtime config 完整；
- [ ] 数据访问范围明确；
- [ ] 输出目录不存在且位于持久化卷；
- [ ] 运行次数和重跑策略明确；
- [ ] tmux 会话名和日志路径已设计；
- [ ] 失败后不会自动升级或重跑；
- [ ] 结果冻结、归档和下载计划明确。

在清理前确认：

- [ ] 本机归档已经下载并核验；
- [ ] 删除清单包含精确绝对路径；
- [ ] 删除边界已获得明确授权；
- [ ] 保留结果在删除前通过校验；
- [ ] 不存在正在写入候选文件的进程；
- [ ] 删除后会再次验证保留结果。

遵守以上规范后，Codex 可以直接在远程服务器中协助修改实验、运行测试与 GPU 工作，同时把误覆盖、误重跑、数据越界、断线重复执行和结果丢失的风险控制在可审计范围内。
